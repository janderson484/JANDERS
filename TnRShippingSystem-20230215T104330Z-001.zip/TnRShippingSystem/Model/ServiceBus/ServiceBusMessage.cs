using System.Collections.Generic;

namespace VM.FleetServices.TnR.Shipping.Model.ServiceBus
{
    public class ServiceBusMessage
    {
        public Dictionary<string, string> Action { get; } = new Dictionary<string, string>();
        public Dictionary<string, string> Data { get; } = new Dictionary<string, string>();
    }
}
