namespace VM.FleetServices.TnR.Shipping.Model.ServiceBus
{
    public static class ServiceBusMessageProperties
    {
        public const string SenderId = "SenderId";
        public const string LogId = "LogId";
        public const string ClientCode = "ClientCode";
        public const string ActionCode = "ActionCode";
        public const string UserName = "UserName";
        public const string ReportType = "ReportType";
        public const string SearchCriteria = "SearchCriteria";      

    }
}
