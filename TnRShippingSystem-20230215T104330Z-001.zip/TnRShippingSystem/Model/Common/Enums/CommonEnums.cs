using System.ComponentModel;

namespace VM.FleetServices.TnR.Shipping.Model.Common.Enums
{
    public enum ApplicationCodes
    {
        [Description("RENEWALS")] Renewals,
        [Description("REGISTRATIONS")] Registrations
    }

    public enum CountryCodes
    {
        [Description("USA")] Usa
    }

    public enum WeightUOM
    {
        [Description("LB")] lb
    }
    public enum TransactionMapped
    {
        [Description("Replacement")] DUP,
        [Description("Other")] NC,
        [Description("Initial")] OR2,
        [Description("Registration")] ORR,
        [Description("Initial")] ORT,
        [Description("Transfer")] OUT,
        [Description("Transfer")] PA,
        [Description("Replacement")] RDC,
        [Description("Replacement")] RLP,
        [Description("Replacement")] RPL,
        [Description("Renewal")] RRR,
        [Description("Other")] RTN,
        [Description("Other")] SPL,
        [Description("Temp Tag")] TMP,
        [Description("Other")] TNC,
        [Description("Registration")] TRR,
        [Description("Other")] VOD
    }

    public enum WipStatus
    {
        [Description("CANCELLED")] CANCELLED
    }

    public enum TitleRequestTypes
    {
        [Description("Change State")] X,
        [Description("Turnback")] T,
        [Description("Retail/Rent2Buy")] R,
        [Description("Duplicate")] P,
        [Description("Proof of Ownership")] O,
        [Description("Return to Seller")] M,
        [Description("Retail Requires Execution")] L,
        [Description("Dealer Title")] D,
        [Description("Wholesale")] A,
        [Description("Salvage")] S,
        [Description("Correction")] C,
        [Description("Retail Lot")] B,
        [Description("Hold")] H,
        [Description("Other")] Z
    }

    public enum Vendors
    {
        [Description("AUTO_IMS")] AUTO_IMS,
        [Description("ADVENT")] ADVENT,
        [Description("DEALER_DIRECT")] DEALER_DIRECT,
        [Description("ABS")] ABS,
        [Description("VERRA")] VERRA
    }

    public enum HertzLocations
    {
        [Description("SRQZ1001RG")] Bradenton,
        [Description("DVTZ1001RG")] SunCity,
        [Description("SATZ1001RG")] SanAntonio,
    }
}
