using System;

namespace VM.FleetServices.TnR.Shipping.Model.Common.DTO
{
    public partial class ProcessingLocationsHistory
    {
        public int ProcessingLocationId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string DisplayName { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
