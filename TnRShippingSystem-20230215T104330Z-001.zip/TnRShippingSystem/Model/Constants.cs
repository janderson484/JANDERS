using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Model
{
    public static class CacheConstants
    {
        public const string ShipmentCommonBaseKeyName = "tnr:shipment:";
        public const string TnrCommonBaseKeyName = "tnr:common:";

        // Shipment common lookup table names
        public const string Couriers = "Couriers";

        // Tnr common lookup table names
        public const string Clients = "clients";
        public const string Countries = "countries";
        public const string DmvStates = "states";
        public const string ProcessingLocations = "vmlocations";

        // Tnr applications lookups
        public const string TnrBaseKeyName = "tnr";
        public const string TnrApplications ="applications";
    }

    public static class ViewShipmentsFilters
    {
        public const string StartDate = "StartDate";
        public const string EndDate = "EndDate";
        public const string CustomerCode = "CustomerCode";
        public const string ProcessingLocationCode = "ProcessingLocationCode";
        public const string TrackingNumber = "TrackingNumber";
        public const string CourierId = "CourierId";
        public const string User = "User";
    }

    public static class ProcessTypes
    {
        public const string Export = "Export";
        public const string BulkProcess = "Bulk Process";
        public const string Upload = "Upload";
        public const string Import = "Import";
    }
}
