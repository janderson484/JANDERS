using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class CreateReceiveShipmentsViewModel : BaseGridPaginateViewModel
    {
        public int ReceiveShipmentId { get; set; }
        [Display(Name = "Date Received")]
        [Required(ErrorMessage = "Date Received is required.")]
        public DateTime ReceivedDateTime { get; set; }
        [Display(Name = "Processing location")]
        [Required(ErrorMessage = "Processing location is required.")]
        public string Location { get; set; }
        public string UserName { get; set; }
        [Display(Name = "Courier")]
        [Required(ErrorMessage = "Courier is required.")]
        public string CourierName { get; set; }
        public int CourierId { get; set; }
        public string Customer { get; set; }
        [Display(Name = "Tracking Number")]
        [Required(ErrorMessage = "Tracking Number is required.")]
        public string TrackingNumber { get; set; }
        public int Documents { get; set; }
        public bool Active { get; set; }
        public string Comment { get; set; }
        public TnrApplication Tnrapplication { get; set; }
        public List<DropDownList> ProcessingLocationList { get; set; }
        public List<DropDownList> CourierList { get; set; }
    }
}
