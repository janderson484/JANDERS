using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class PersonalSettingsViewModel
    {
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int RowsPerPage { get; set; }
        public List<SelectListItem> RowsPerPageList { get; set; }
        public string UserId { get; set; }
        public int DaysofHistory { get; set; }
    }
}
