using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    /// <summary>
    ///  ViewModel accomodate search criteria values 
    /// </summary>
    public abstract class BaseGridPaginateViewModel
    {
        public string ClientCode { get; set; } 
        public int DefaultRowsPerPage { get; set; } = 150;
        public int RowsPerPage { get; set; } = 150;
        public int PageNumber { get; set; } = 1;
        public int TotalResultCount { get; set; } = 0;
        public int[] PageSizes { get; set; } = new int[] { 150, 250, 350, 500 };
    }
}
