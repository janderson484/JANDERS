using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class ShipmentDataViewModel
    {
        public string TrackingNumber { get; set; }
        public string CourierName { get; set; }
    }
}
