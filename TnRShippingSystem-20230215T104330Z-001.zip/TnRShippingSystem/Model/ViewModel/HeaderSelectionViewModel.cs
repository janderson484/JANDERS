using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class HeaderSelectionViewModel
    {
        public string HeaderClientCode { get; set; }
        public IEnumerable<SelectListItem> HeaderClientCodeList { get; set; }
        public string HeaderProcessingLocationCode { get; set; }
        public IEnumerable<SelectListItem> HeaderProcessingLocationCodeList { get; set; }
    }
}
