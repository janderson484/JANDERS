using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class NotificationViewModel
    {
        public int? NotificationId { get; set; }
        public int? LogId { get; set; }
        public string NotificationType { get; set; }
        public int TotalCount { get; set; }
        public int SuccessCount { get; set; }
        public int WarningCount { get; set; }
        public int ErrorCount { get; set; }
        public string Message { get; set; }
        public bool IsRead { get; set; }
        public string UserName { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string LastRefreshDate { get; set; }
        public string LogStatus { get; set; }

    }
}
