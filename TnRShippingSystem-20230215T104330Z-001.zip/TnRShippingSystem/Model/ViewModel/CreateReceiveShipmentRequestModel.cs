using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class CreateReceiveShipmentRequestModel : BaseGridPaginateViewModel
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string UserName { get; set; }
        public string CustomerCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string TrackingNumber { get; set; }
        public int CourierId { get; set; }
        public string User { get; set; }
        public IList<CreateReceiveShipmentsViewModel> Results { get; set; }

    }
}
