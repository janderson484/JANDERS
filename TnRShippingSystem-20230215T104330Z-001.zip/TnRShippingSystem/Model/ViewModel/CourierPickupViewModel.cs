using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class CourierPickupViewModel:BaseGridPaginateViewModel
    {

        [Display(Name = "Courier/ Dropoff")]
        [Required(ErrorMessage = "Courier/ Dropoff is required.")]
        public string CourierName { get; set; }

        [Display(Name = "Number of forms to Print")]
        [Required(ErrorMessage = "Number of forms is required.")]
        [Range(1, 100, ErrorMessage = "Number of forms Should be 1 to 100")]
        public int? NumberofForms { get; set; }
        public int CourierId { get; set; }
        public string TrackingNumber { get; set; }
    }
}
