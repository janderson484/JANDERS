using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class ExportSearchCriteriaViewModel
    {
        public string ReportType { get; set; }
        public string SearchCriteria { get; set; }
        public int TotalCount { get; set; }

    }
}
