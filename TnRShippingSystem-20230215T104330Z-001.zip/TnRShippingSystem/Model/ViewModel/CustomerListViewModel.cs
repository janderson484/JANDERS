using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class CustomerListViewModel
    {
        public string ClientCode { get; set; }

        [Display(Name = "ClientCode")]
        public IEnumerable<SelectListItem> ClientCodeList { get; set; }

        public string DmvState { get; set; }

        [Display(Name = "State")]
        public IEnumerable<SelectListItem> DmvStateList { get; set; }
    }
}
