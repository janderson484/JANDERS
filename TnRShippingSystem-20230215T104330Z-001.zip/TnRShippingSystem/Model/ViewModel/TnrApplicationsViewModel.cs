using System.Collections.Generic;
using VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class TnrApplicationsViewModel
    {
        public List<TnrApplication> TnrApplicationsList { get; set; }

    }
}
