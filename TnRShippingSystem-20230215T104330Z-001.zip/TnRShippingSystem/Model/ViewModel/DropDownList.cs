namespace VM.FleetServices.TnR.Shipping.Model.ViewModel
{
    public class DropDownList
    {
        public int Value { get; set; }
        public string Code { get; set; }
        public string DisplayName { get; set; }
        public int Id { get; set; }
    }
}
