using System;
using System.ComponentModel.DataAnnotations;

namespace VM.FleetServices.TnR.Shipping.Model.DTO
{
    public class ReceiveShipment
    {
        public int ReceiveShipmentId { get; set; }
        public DateTime ReceivedDateTime { get; set; }
        public string Location { get; set; }
        public string UserName { get; set; }
        public string CourierName { get; set; }
        public int CourierId { get; set; }
        public string Customer { get; set; }
        public string TrackingNumber { get; set; }
        public int Documents { get; set; }
        public bool Active { get; set; }
        public string Comment { get; set; }
    }
}
