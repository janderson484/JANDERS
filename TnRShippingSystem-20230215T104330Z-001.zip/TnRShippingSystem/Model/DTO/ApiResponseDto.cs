using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Model.DTO
{
    public class ApiResponseDto
    {
        public HttpStatusCode ResponseCode { get; set; }
        public string ErrorMessage { get; set; }
    }
}
