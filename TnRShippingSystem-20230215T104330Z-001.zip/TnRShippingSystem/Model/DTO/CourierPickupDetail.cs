using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace VM.FleetServices.TnR.Shipping.Model.DTO
{
    public class CourierPickupDetail
    {
        public int FirstVal { get; set; }
        public int Lastval { get; set; }
        public int SeqIncrement { get; set; }

    }
}
