using System.ComponentModel;

namespace VM.FleetServices.TnR.Shipping.Model.Enums
{
    public enum JobLogStatus
    {
        [Description("Ready")] Ready,
        [Description("In Progress")] InProgress,
        [Description("Completed")] Completed,
        [Description("Failed")] Failed
    }
    public enum Export
    {
        [Description("Shipments")] Shipments
    }

    public enum ShippingProcessNames
    {
        [Description("Export Shipments")] ExportShipments
    }

    public enum BlobContainerDirectories
    {
        [Description("Export Shipments")] ExportShipments
    }
}
