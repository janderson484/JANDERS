using System;

namespace VM.FleetServices.TnR.Shipping.Model
{
    public class JavaScriptEnumAttribute : Attribute
    {
    }
}
