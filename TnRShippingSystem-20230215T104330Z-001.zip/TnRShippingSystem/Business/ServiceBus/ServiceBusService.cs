using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ServiceBus;

namespace VM.FleetServices.TnR.Shipping.Business.ServiceBus
{
    public class ServiceBusService : IServiceBusService
    {
        /// <summary>
        /// The _sender svc.
        /// </summary>
        private readonly ISenderServiceBus _senderSvc;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBusService"/> class.
        /// </summary>
        /// <param name="senderSvc"></param>
        public ServiceBusService(ISenderServiceBus senderSvc)
        {
            _senderSvc = senderSvc;
        }

   
        /// <summary>
        /// Creates JSON message and sends to Service Bus
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        public async Task SendMessageAsync(Log log)
        {
            var msg = CreateJsonMessage(log);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }

        /// <summary>
        /// Sends the message to service bus queue.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="processingLocationCode">The processing location code.</param>
        public async Task SendMessageAsync(Log log, string processingLocationCode)
        {
            var msg = CreateJsonMessage(log, processingLocationCode);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }
        
        /// <summary>
        /// Creates the json message.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="processingLocationCode">The processing location code.</param>
        /// <returns>Message as JSON string</returns>
        public string CreateJsonMessage(Log log, string processingLocationCode = null)
        {
            var messageDictionary = new ServiceBusMessage();                   
            var msgText = JsonConvert.SerializeObject(messageDictionary);
            return msgText;
        }

        /// <summary>
        /// Creates JSON message and sends to Service Bus
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="log"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task SendDynamicMessageAsync<T>(Log log, T model)
        {
            var msg = CreateDynamicJsonMessage(log, model);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }

        /// <summary>
        /// Creates the json message for type class.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="log"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        public string CreateDynamicJsonMessage<T>(Log log, T model)
        {
            var messageDictionary = new ServiceBusMessage();
                  
            messageDictionary.Data.Add(ServiceBusMessageProperties.UserName, log.CreatedUser);
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionCode, log.ProcessName);
            messageDictionary.Action.Add(ServiceBusMessageProperties.LogId, log.LogId.ToString());


            var type = model.GetType();
            if (type.IsClass)
            {
                foreach (var propertyInfo in type.GetProperties())
                {
                    var value = propertyInfo.GetValue(model);
                    var name = propertyInfo.Name;
                    messageDictionary.Action.Add(name, Convert.ToString(value));
                }
            }
            var msgText = JsonConvert.SerializeObject(messageDictionary);
            return msgText;
        }
        

    }

    /// <summary>
    /// The ServiceBusService interface.
    /// </summary>
    public interface IServiceBusService
    {      
        /// <summary>
        /// The send message async.
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        Task SendMessageAsync(Log log);
        Task SendMessageAsync(Log log, string processingLocationCode);
        Task SendDynamicMessageAsync<T>(Log log, T model);
        
    }
    
}
