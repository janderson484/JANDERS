// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SenderServiceBusConfig.cs" company="American Traffic Solutions">
//   American Traffic Solutions
// </copyright>
// <summary>
//   The sender service bus config.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using Microsoft.Extensions.Logging;

namespace VM.FleetServices.TnR.Shipping.Business.ServiceBus
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;

    /// <summary>
    /// The sender service bus config.
    /// </summary>
    public static class SenderServiceBusConfig
    {
        /// <summary>
        /// The add send service bus service.
        /// </summary>
        /// <param name="services">The services</param>
        /// <param name="serviceBusOptions">The ServiceBus options</param>
        /// <returns></returns>
        public static IServiceCollection AddSendServiceBusService(this IServiceCollection services, ServiceBusOptions serviceBusOptions)
        {
            //services.AddSingleton<IServiceBusService, ServiceBusService>();
            services.AddSingleton<ISenderServiceBus>(provider => new SenderServiceTopicBus(provider.GetRequiredService<ILogger<SenderServiceTopicBus>>(), serviceBusOptions));

            return services;
        }

        /// <summary>
        /// The add send service bus service.
        /// </summary>
        /// <param name="services">
        /// The services.
        /// </param>
        /// <param name="configSection">
        /// The config section.
        /// </param>
        /// <returns>
        /// The <see cref="IServiceCollection"/>.
        /// </returns>
        public static IServiceCollection AddSendServiceBusService(this IServiceCollection services, IConfigurationSection configSection)
        {
            var serviceBusOptions = new ServiceBusOptions()
            {
                ConnectionString = configSection["ConnectionString"],
                QueueName = configSection["QueueName"]
            };

            return AddSendServiceBusService(services, serviceBusOptions);
        }

        ///// <summary>
        ///// The add dummy service bus service.
        ///// </summary>
        ///// <param name="services">
        ///// The services.
        ///// </param>
        ///// <returns>
        ///// The <see cref="IServiceCollection"/>.
        ///// </returns>
        //public static IServiceCollection AddDummyServiceBusService(this IServiceCollection services)
        //{
        //    services.AddSingleton<IServiceBusService, ServiceBusService>();
        //    //services.AddSingleton<ISenderServiceBus, DummySenderServiceBus>();

        //    return services;
        //}
    }
}
