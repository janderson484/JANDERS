using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ServiceBus;
using Message = Microsoft.Azure.ServiceBus.Message;

namespace VM.FleetServices.TnR.Shipping.Business.ServiceBus
{
    /// <summary>
    /// The sender service topic bus.
    /// </summary>
    public class SenderServiceTopicBus : ISenderServiceBus
    {
        /// <summary>
        /// The queue client.
        /// </summary>
        private readonly TopicClient _queueClient;

        private readonly ILogger _logger;


        public SenderServiceTopicBus(ILogger<SenderServiceTopicBus> logger, ServiceBusOptions serviceBusOptions)
            : this(
                logger,
                serviceBusOptions.ConnectionString,
                serviceBusOptions.QueueName)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SenderServiceTopicBus"/> class.
        /// </summary>
        /// <param name="logger">
        /// The name space.
        /// </param>
        /// <param name="nameSpace">
        /// The name space.
        /// </param>
        /// <param name="accessKeyName">
        /// The access key name.
        /// </param>
        /// <param name="key">
        /// The key.
        /// </param>
        /// <param name="queueName">
        /// The queue name.
        /// </param>
        public SenderServiceTopicBus(ILogger<SenderServiceTopicBus> logger, string nameSpace, string accessKeyName, string key, string queueName)
        {
            var connnectionString = $"Endpoint=sb://{nameSpace}.servicebus.windows.net/;SharedAccessKeyName={accessKeyName};SharedAccessKey={key}";
            _queueClient = new TopicClient(connnectionString, queueName);
            _logger = logger;
        }

        public SenderServiceTopicBus(ILogger<SenderServiceTopicBus> logger, string connectionString, string queueName)
        {
            _queueClient = new TopicClient(connectionString, queueName);
            _logger = logger;
        }

        
        /// <summary>
        /// This method calls the CreateMessage to add Service Bus User Properties to the message and then sends the message
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        public async Task SendMessageAsync(string msg, Log log)
        {
            try
            {
                var message = CreateMessage(msg, log);
                await _queueClient.SendAsync(message);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error sending to ServiceBus: {ex.Message} - {ex}");
                throw;
            }
        }

        /// <summary>
        /// Adds the message values to the Message User Properties
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        private Message CreateMessage(string msg, Log log)
        {
            var message = new Message(Encoding.UTF8.GetBytes(msg));    
            message.UserProperties.Add(ServiceBusMessageProperties.ActionCode, log.ProcessName);
            message.UserProperties.Add(ServiceBusMessageProperties.SenderId, "SHIPPING");

            return message;
        }
        
    }
}
