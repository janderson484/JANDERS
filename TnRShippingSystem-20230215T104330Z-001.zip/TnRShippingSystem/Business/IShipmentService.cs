using System.Collections.Generic;
using System.Threading.Tasks;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;

namespace VM.FleetServices.TnR.Shipping.Business
{
    public interface IShipmentService
    {
        Task<bool> LoadShipmentCommonLookupsAsync();
        Task<List<CreateReceiveShipmentsViewModel>> GetReceiveShipmentDataAsync(CreateReceiveShipmentRequestModel model);
        Task<ReceiveShipment> CreateReceiveShipmentAsync(ReceiveShipment model);
        Task<List<ShipmentDataViewModel>> GetShipmentDataAsync(string key);
        Task<Dictionary<string,string>> GetShipmentReceivedDateAsync(List<string> key);
        Task<Log> SubmitExportAllRequestAsync(CreateReceiveShipmentRequestModel request);
        Task<int> GetReceiveShipmentDataCountAsync(CreateReceiveShipmentRequestModel model);
        Task<List<CourierPickupViewModel>> GetTrackingNumber(CourierPickupViewModel CourierPickupmodel);

    }
}
