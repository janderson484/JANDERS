using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Business.Integrations
{
    public class ApiRouteConstants
    {
        public static string CreateShippingLabels() => "api/Shipping/CreateShippingLabels";
        public static string GetSendShippingLabels() => "api/Shipping/GetSendShippingLabels";
        public static string GetShippingLabelsByIds() => "api/Shipping/GetShippingLabelsByIds";
        public static string GetShippingLabelsByOrderIds() => "api/Shipping/GetShippingLabelsByOrderIds";
        public static string UpdateShippingLabels() => "api/Shipping/UpdateShippingLabels";
        public static string GetSelectedLabels() => "api/Shipping/GetSelectedLabels";
        public static string GetShipmentTrackingDetails() => "api/Shipping/GetShipmentTrackingDetails";
        public static string SendNotification() => "api/Notification/SendNotification";
        public static string CancelShippingLabels() => "api/Shipping/CancelShippingLabels";
        public static string GetShippingLabelsByLabelIds() => "api/Shipping/GetShippingLabelsByLabelIds";
        public static string GetActiveShippingAccount() => "api/Shipping/GetActiveShippingAccount";
    }
}
