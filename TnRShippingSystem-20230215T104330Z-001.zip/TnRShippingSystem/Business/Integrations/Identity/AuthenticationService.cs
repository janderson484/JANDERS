using System;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection;
using VM.FleetServices.TnR.Core.Common.Mvc;

namespace VM.FleetServices.TnR.Shipping.Business.Integrations
{
    public interface IAuthService
    {
        TokenResponse GetAccessToken();
    }

    public class AuthenticationServiceOptions
    {
        public string Authority { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
    }

    public class AuthService : IAuthService
    {
        private readonly ILogger<AuthService> _logger;
        private readonly HttpClient _httpClient;
        private readonly OpenIdSettings _openIdSettings;
        //private DiscoveryResponse _disco;
        private TokenResponse _token;
        private DateTime? _tokenIssueTime;
        private object _syncLock = new object();

        /// <summary>
        /// This class Authenticates with identity server and returns or refreshes access tokens 
        /// </summary>
        public AuthService(IOptions<OpenIdSettings> openIdSettings, IHttpClientFactory httpClientFactory, ILogger<AuthService> logger)
        {
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
            _openIdSettings = openIdSettings.Value;
        }

        /// <summary>
        /// Gets or refreshes an access token
        /// </summary>
        /// <returns>Token Response</returns>
        public TokenResponse GetAccessToken()
        {
            var response = RefreshAccessTokenAsync();
            return response.Result;
        }

        /// <summary>
        /// Creates a new token or refreshes a token if its expired
        /// </summary>
        /// <returns>Token Response</returns>
        private async Task<TokenResponse> RefreshAccessTokenAsync()
        {
            if (_token == null || _token.IsExpired(_tokenIssueTime))
            {
                _logger.LogInformation($"Service: - Method: {nameof(RefreshAccessTokenAsync)} - Requesting Identity access_token at {_openIdSettings.Authority}...");
                var startTime = DateTime.Now;
                try
                {
                    _token = await CreateNewTokenAsync();
                    _tokenIssueTime = startTime;
                }
                catch (Exception ex)
                {
                    _token = null;
                    _tokenIssueTime = null;

                    _logger.LogError($"Service: - Method: {nameof(RefreshAccessTokenAsync)} - Error occurred in {nameof(RefreshAccessTokenAsync)}\r\nError message: {ex.Message}");
                    throw;
                }
                _logger.LogInformation($"Service: - Method: {nameof(RefreshAccessTokenAsync)} - Identity access_token type={_token.TokenType} received from {_openIdSettings.Authority}:\n{_token.AccessToken}\n");

            }

            return _token;
        }

        /// <summary>
        /// Gets an access token
        /// </summary>
        /// <returns>Token Response</returns>
        private async Task<TokenResponse> CreateNewTokenAsync()
        {
            TokenResponse tokenResponse;

            //var client = new HttpClient();
            //var _disco = await client.GetDiscoveryDocumentAsync("https://demo.identityserver.io");

            //if (_disco == null)
            //{
            var _disco = await _httpClient.GetDiscoveryDocumentAsync(_openIdSettings.Authority);
            //}

            if (_disco.IsError)
                throw new Exception(_disco.Error);

            if (_token != null)
            {
                // REFRESH TOKEN

                tokenResponse = await _httpClient.RequestRefreshTokenAsync(new RefreshTokenRequest()
                {
                    Address = _disco.TokenEndpoint,
                    RefreshToken = _token.RefreshToken,
                    ClientId = _openIdSettings.ClientId,
                    ClientSecret = _openIdSettings.ClientSecret
                });

                if (!tokenResponse.IsError)
                    return tokenResponse;
            }

            // NEW TOKEN

            tokenResponse = _httpClient.RequestPasswordTokenAsync(new PasswordTokenRequest
            {
                Address = _disco.TokenEndpoint,
                ClientId = _openIdSettings.ClientId,
                ClientSecret = _openIdSettings.ClientSecret,
                UserName = _openIdSettings.UserName,
                Password = _openIdSettings.PassWord

            }).Result;

            if (tokenResponse.IsError || string.IsNullOrEmpty(tokenResponse.AccessToken))
            {
                var errorDescription = tokenResponse.Exception.InnerException != null
                    ? $"No api token created: {tokenResponse.Error}.\r\n{tokenResponse.Exception.InnerException.Message}"
                    : $"No api token created: {tokenResponse.Error}.";

                throw new Exception(errorDescription);
            }

            return tokenResponse;
        }
    }

    public static class TokenResponseExtensions
    {
        /// <summary>
        /// Checks if a token is expired against a date/time period
        /// </summary>
        /// <param name="token">The token</param>
        /// <param name="issueTime">The issue date time to verify expiration against</param>
        /// <returns>Boolean result</returns>
        public static bool IsExpired(this TokenResponse token, DateTime? issueTime)
        {
            if (!issueTime.HasValue || token.ExpiresIn <= 0)
                return true;
            return (issueTime.Value.AddSeconds(token.ExpiresIn - 120 > 0 ? token.ExpiresIn - 120 : token.ExpiresIn) < DateTime.Now);
        }
    }
}
