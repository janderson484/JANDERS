using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Data.SqlClient;
using VM.FleetServices.TnR.Shipping.Business.Helpers;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using VM.FleetServices.TnR.Shipping.Model;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using DTO = VM.FleetServices.TnR.Shipping.Model.DTO;
using Aspose.Pdf.Operators;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Shipping.Model.Enums;
using VM.FleetServices.TnR.Shipping.Business.ServiceBus;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Business
{
    public class ShipmentService : IShipmentService
    {

        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly ILogger<ShipmentService> _logger;
        private readonly IObjectCache _cache;
        private readonly CacheSettings _cacheSettings;
        private readonly IMapper _mapper;
        private readonly ILogService _logService;
        private readonly IServiceBusService _serviceBusService;

        public ShipmentService(IServiceScopeFactory serviceScopeFactory, ILogger<ShipmentService> logger, IObjectCache cache,
            IOptions<CacheSettings> cacheOptions, IMapper mapper, ILogService logService, IServiceBusService serviceBusService)
           
        {
            _serviceScopeFactory = serviceScopeFactory;
            _logger = logger;
            _cache = cache;
            _cacheSettings = cacheOptions.Value;
            _mapper = mapper;
            _logService = logService;
            _serviceBusService = serviceBusService;
        }

        #region Create Receive Shipment
        /// <summary>
        /// Load Shipment Common Lookups Async
        /// </summary>
        /// <returns></returns>
        public async Task<bool> LoadShipmentCommonLookupsAsync()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    _logger.LogInformation($"loading common lookups: , {nameof(LoadShipmentCommonLookupsAsync)}");

                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var couriers = await context.Couriers.Where(x => x.Active).ToListAsync();

                    _logger.LogInformation($"Saving common lookups to cache: , {nameof(LoadShipmentCommonLookupsAsync)}");

                    await _cache.SaveToCache($"{CacheConstants.ShipmentCommonBaseKeyName}:{CacheConstants.Couriers}:{_cacheSettings.Environment.ToLower()}", couriers, _cacheSettings.CacheExpirationInHours);

                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"{nameof(ShipmentService)} - Error loading Shipment common lookups: {ex.Message}");

                throw ex;
            }
        }

        /// <summary>
        /// add receive shipment
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task<DTO.ReceiveShipment> CreateReceiveShipmentAsync(DTO.ReceiveShipment model)
        {
            if (model == null)
                throw new ArgumentNullException(nameof(model));
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();
                    var newShipment = new Data.ShippingModel.Entities.ReceiveShipment
                    {
                        ReceivedDate = model.ReceivedDateTime,
                        ProcessingLocationCode = model.Location,
                        TrackingNumber = model.TrackingNumber,
                        CourierId = model.CourierId,
                        Comment = model.Comment,
                        Active = model.Active,
                        ClientCode = model.Customer,
                        DocumentCount = 0,
                        CreatedUser = model.UserName,
                        CreatedDate = DateTime.UtcNow,
                        ModifiedUser = model.UserName,
                        ModifiedDate = DateTime.UtcNow,
                    };
                    await context.ReceiveShipments.AddAsync(newShipment);
                    await context.SaveChangesAsync();
                    model.ReceiveShipmentId = newShipment.ReceiveShipmentId;
                    return model;
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ShipmentService)}; Method: {nameof(CreateReceiveShipmentAsync)}; Error: {e.Message}");
                throw e;
            }
        }

        /// <summary>
        /// Gets shipment data for the selected date range 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<List<CreateReceiveShipmentsViewModel>> GetReceiveShipmentDataAsync(CreateReceiveShipmentRequestModel model)
        {
            var receiveShipmentsResult = new List<CreateReceiveShipmentsViewModel>();
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var receiveShipments = await context.ReceiveShipments.Include(a=>a.Courier).Where(a => (a.ReceivedDate >= model.StartDate && a.ReceivedDate <= model.EndDate) &&
                            (string.IsNullOrEmpty(model.CustomerCode) || a.ClientCode.ToLower() == model.CustomerCode.ToLower()) &&
                            (string.IsNullOrEmpty(model.ProcessingLocationCode) || a.ProcessingLocationCode.ToLower() == model.ProcessingLocationCode.ToLower()) &&
                            (string.IsNullOrEmpty(model.TrackingNumber) || a.TrackingNumber.ToLower() == model.TrackingNumber.ToLower()) && (model.CourierId == 0 || a.CourierId == model.CourierId) &&
                            (string.IsNullOrEmpty(model.User) || a.CreatedUser.ToLower() == model.User.ToLower())
                        ).OrderByDescending(f => f.ReceivedDate).ToPageListAsync(model.PageNumber, model.RowsPerPage);
                   

                    foreach (var shipment in receiveShipments.Results.ToList())
                    {
                        receiveShipmentsResult.Add(new CreateReceiveShipmentsViewModel()
                        {
                            ReceivedDateTime = shipment.ReceivedDate,
                            Customer = shipment.ClientCode,
                            TrackingNumber = shipment.TrackingNumber,
                            UserName = shipment.CreatedUser,
                            Documents = shipment.DocumentCount,
                            Location = shipment.ProcessingLocationCode,
                            CourierName = shipment.Courier.Name
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(ShipmentService)}; Method: {nameof(GetReceiveShipmentDataAsync)}; Error: {ex.Message}");
                throw ex;
            }

            return receiveShipmentsResult;
        }

        /// <summary>
        /// Gets shipment data for  tracking numbers starting with the key
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<List<ShipmentDataViewModel>> GetShipmentDataAsync(string key)
        {
            var shipmentData = new List<ShipmentDataViewModel>();
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var receiveShipmentsData = await context.ReceiveShipments.Include(a => a.Courier).Where(a => a.TrackingNumber.ToLower().StartsWith(key.ToLower())).ToListAsync();                   

                    foreach (var shipment in receiveShipmentsData)
                    {
                        shipmentData.Add(new ShipmentDataViewModel()
                        {
                            TrackingNumber = shipment.TrackingNumber,
                            CourierName = shipment.Courier.Name
                        });
                    }

                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(ShipmentService)}; Method: {nameof(GetShipmentDataAsync)}; Error: {ex.Message}");
                throw ex;
            }

            return shipmentData;
        }


        #endregion

        #region  courier pickup sequence 
        /// <summary>
        /// get courier pickup sequence 
        /// </summary>
        /// <param name="model"></param>
        /// <returns>returns Tracking Sequence</returns>
        public async Task<List<CourierPickupViewModel>> GetTrackingNumber(CourierPickupViewModel CourierPickupmodel)
        {
            try
            {
                var CourierPickupResult = new List<CourierPickupViewModel>();
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                   var context = scope.ServiceProvider.GetService<IShippingModel>();
                   var couriers = await context.Couriers.ToListAsync();
                   var param = new List<SqlParameter> {
                        new SqlParameter("@Sequencesize",  CourierPickupmodel.NumberofForms),
                        new SqlParameter("@Sequencename", "Shipping.CourierTrackingId"),
                    };
                    
                    //Retrieve Tracking Sequence Number through DTO mapping
                    var SequenceValue =  await context.CourierPickupData.FromSqlRaw<CourierPickupDetail>("EXEC shipping.GetSequenceNumbers @Sequencesize,@Sequencename", param.ToArray()).ToListAsync();


                    var ResultValue = SequenceValue.Select(x => x.FirstVal).FirstOrDefault();

                    //Construct  Tracking Sequence 
                    if (ResultValue != null)
                    {
                        for (int i = 0; i <= CourierPickupmodel.NumberofForms; i++)
                        {
                            CourierPickupResult.Add(new CourierPickupViewModel()
                            {
                                TrackingNumber = "CF0" + CourierPickupmodel.CourierId + ResultValue + i,
                                CourierName = couriers.Where(a => a.CourierId.Equals(CourierPickupmodel.CourierId)).Select(x => x.Name).FirstOrDefault()
                            });
                        }
                    }
                }

                return CourierPickupResult;
            }
            catch (Exception  Ex)
            {
                _logger.LogError($"Service: {nameof(ShipmentService)}; Method: {nameof(GetTrackingNumber)}; Error: {Ex.Message}");
                throw Ex;
            }
        }
        #endregion

        #region Export Shipments

        /// <summary>
        /// Create request for export shipment process
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<DTO.Log> SubmitExportAllRequestAsync(CreateReceiveShipmentRequestModel request)
        {
            var exportSearch = new ExportSearchCriteriaViewModel();

            try
            {
                
               using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var logData = new Data.ShippingModel.Entities.Log
                    {
                        ProcessName = ShippingProcessNames.ExportShipments.GetDescription(),
                        TotalCount = request.TotalResultCount,
                        SuccessfulCount = 0,
                        ErrorCount = 0,
                        WarningCount = 0,
                        Status = JobLogStatus.Ready.ToString(),
                        CreatedUser = request.UserName,
                        ProcessStartDate = DateTime.Now,
                        CreatedDate = DateTime.Now,
                        ModifiedUser = request.UserName,
                        ModifiedDate = DateTime.Now,
                        ClientCode = request.ClientCode,
                        ProcessType = ProcessTypes.Export
                    };

                    // create log
                     var log = await _logService.InsertLogAsync(_mapper.Map<Data.ShippingModel.Entities.Log, DTO.Log>(logData));

                    // Save changes to DB
                      await context.SaveChangesAsync();

                    // Create message and send it to Azure Service Bus.
                    exportSearch.SearchCriteria = JsonConvert.SerializeObject(request);

                    await _serviceBusService.SendDynamicMessageAsync(log, exportSearch);

                    return log;
                   
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(ShipmentService)} - method {nameof(SubmitExportAllRequestAsync)}: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// Gets shipment data count for the selected date range 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<int> GetReceiveShipmentDataCountAsync(CreateReceiveShipmentRequestModel model)
        {
            var receiveShipmentsCount = 0;
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    receiveShipmentsCount = await context.ReceiveShipments.Where(a => a.ReceivedDate >= model.StartDate && a.ReceivedDate <= model.EndDate).CountAsync();                   
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(ShipmentService)}; Method: {nameof(GetReceiveShipmentDataAsync)}; Error: {ex.Message}");
                throw ex;
            }
            return receiveShipmentsCount;
        }

        public async Task<Dictionary<string, string>> GetShipmentReceivedDateAsync(List<string> key)
        {
            var response = new Dictionary<string,string>();
            var trackingNumberList = key.Select(a => a.ToUpper()).ToList();
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    response = await context.ReceiveShipments
                                            .Where(a => trackingNumberList.Contains(a.TrackingNumber.ToUpper()))
                                            .ToDictionaryAsync(a => a.TrackingNumber, a=> a.ReceivedDate.ToString());
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(ShipmentService)}; Method: {nameof(GetShipmentReceivedDateAsync)}; Error: {ex.Message}");
                throw ex;
            }
            return response;
        }

        #endregion

    }
}

