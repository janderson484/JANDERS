using System.Collections.Generic;
using System.Threading.Tasks;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using DTO = VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Business
{
    public interface ILogService
    {
        Task<LogSummaryViewModel> GetLogsAsync(LogSummaryViewModel model);
        Task<DTO.Log> GetLogStatusAsync(int logid);
        Task<LogDetailViewModel> GetLogDetailsAsync(LogDetailViewModel model);
        Task<DTO.Log> UpdateLogStatusByIdAsync(int logId, string logStatus);
        Task<DTO.Log> GetLogAsync(int logId);
        Task<DTO.Log> UpdateLogStatusAsync(DTO.Log log, List<DTO.LogDetail> logDetails);
        Task<DTO.Log> InsertLogAsync(DTO.Log logDetails);
    }
}


