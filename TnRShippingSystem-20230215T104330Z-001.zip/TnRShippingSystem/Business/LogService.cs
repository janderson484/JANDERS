using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using DTO = VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Model.Enums;
using Microsoft.Extensions.DependencyInjection;
using VM.FleetServices.TnR.Core.Common.Data.ExtensionMethods;

namespace VM.FleetServices.TnR.Shipping.Business
{
    public class LogService : ILogService
    {
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly ILogger<LogService> _logger;
        private readonly IMapper _mapper;

        public LogService(IServiceScopeFactory serviceScopeFactory, ILogger<LogService> logger, IMapper mapper)
        {
            _serviceScopeFactory = serviceScopeFactory;
            _logger = logger;
            _mapper = mapper;
        }

        #region Logs

        /// <summary>
        /// Gets list of Logs based on model properties
        /// </summary>
        /// <param name="model">Model containing Client, State, UserId, and UserAccessLevel</param>
        /// <returns>List of Log based on search criteria</returns>
        public async Task<LogSummaryViewModel> GetLogsAsync(LogSummaryViewModel model)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    IPaginate<Log> result;

                    if (model.IsAtLeastSupervisor)
                    {
                        result = await context.Logs.Where(x => x.ClientCode.Equals(model.ClientCode) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.FileName) || x.Filename.Contains(model.LogSearchCriteria.FileName)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.LogStatus) || x.Status.Equals(model.LogSearchCriteria.LogStatus)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessType) || x.ProcessType.Equals(model.LogSearchCriteria.ProcessType)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessName) || x.ProcessName.Equals(model.LogSearchCriteria.ProcessName)) &&
                                            (model.LogSearchCriteria.ProcessStartDate == null || model.LogSearchCriteria.ProcessStartDate == DateTime.MinValue || x.ProcessStartDate >= model.LogSearchCriteria.ProcessStartDate) &&
                                            (model.LogSearchCriteria.ProcessEndDate == null || model.LogSearchCriteria.ProcessEndDate == DateTime.MinValue || x.ProcessEndDate <= model.LogSearchCriteria.ProcessEndDate || x.ProcessEndDate == null) &&
                                            ((!model.LogSearchCriteria.ShowErrors && !model.LogSearchCriteria.ShowWarnings) ||
                                            ((model.LogSearchCriteria.ShowErrors && x.ErrorCount > 0) ||
                                            (model.LogSearchCriteria.ShowWarnings && x.WarningCount > 0)))).OrderByDescending(x => x.LogId).ToPaginateAsync(index: model.PageNumber - 1, size: model.RowsPerPage);
                    }
                    else  
                    {                       

                        result = await context.Logs.Where(x => x.ClientCode.Equals(model.ClientCode) && x.CreatedUser.Equals(model.UserId) &&
                                           (string.IsNullOrEmpty(model.LogSearchCriteria.FileName) || x.Filename.Contains(model.LogSearchCriteria.FileName)) &&
                                           (string.IsNullOrEmpty(model.LogSearchCriteria.LogStatus) || x.Status.Equals(model.LogSearchCriteria.LogStatus)) &&
                                           (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessType) || x.ProcessType.Equals(model.LogSearchCriteria.ProcessType)) &&
                                           (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessName) || x.ProcessName.Equals(model.LogSearchCriteria.ProcessName)) &&
                                           (model.LogSearchCriteria.ProcessStartDate == null || model.LogSearchCriteria.ProcessStartDate == DateTime.MinValue || x.ProcessStartDate >= model.LogSearchCriteria.ProcessStartDate) &&
                                           (model.LogSearchCriteria.ProcessEndDate == null || model.LogSearchCriteria.ProcessEndDate == DateTime.MinValue || x.ProcessEndDate <= model.LogSearchCriteria.ProcessEndDate || x.ProcessEndDate == null) &&
                                          ((!model.LogSearchCriteria.ShowErrors && !model.LogSearchCriteria.ShowWarnings) ||
                                           ((model.LogSearchCriteria.ShowErrors && x.ErrorCount > 0) ||
                                           (model.LogSearchCriteria.ShowWarnings && x.WarningCount > 0)))).OrderByDescending(x => x.LogId).ToPaginateAsync(index: model.PageNumber - 1, size: model.RowsPerPage);
                    }

                    if (result != null && result.Items.Count > 0)
                    {
                        model.Results = _mapper.Map<List<Model.DTO.Log>>(result.Items.ToList());
                        model.TotalCount = result.Count;
                    }
                    else
                    {
                        // If the results is null then kendo will throw an exception (Slice) because it cannot parse a null data value
                        model.Results = new List<Model.DTO.Log>();
                    }
                }

                return model;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LogService)}; Method: {nameof(GetLogsAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Service to get Log details based on log id
        /// </summary>
        /// <param name="model">LogDetailViewModel</param>
        /// <returns>returns model with Log and Log details information</returns>
        public async Task<DTO.Log> GetLogStatusAsync(int logid)
        {
            var result = new DTO.Log();
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();      
                    var logEntity = await context.Logs.Where(a => a.LogId == logid).SingleAsync();
                    result = _mapper.Map<DTO.Log>(logEntity);

                    return result;

                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LogService)}; Method: {nameof(GetLogDetailsAsync)}; Error: {e.Message}");
            }
            return result;
        }

        /// <summary>
        /// Service to get Log details based on log id
        /// </summary>
        /// <param name="model">LogDetailViewModel</param>
        /// <returns>returns model with Log and Log details information</returns>
        public async Task<LogDetailViewModel> GetLogDetailsAsync(LogDetailViewModel model)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var result = await context.LogDetails.Where(a => a.LogId == model.LogId)
                                                        .OrderByDescending(a => a.LogDetailsId)
                                                        .ToPaginateAsync(index: model.PageNumber - 1, size: model.RowsPerPage);

                    if (result != null && result.Items != null)
                    {
                        model.Results = _mapper.Map<List<Model.DTO.LogDetail>>(result.Items.ToList());
                        model.TotalCount = result.Count;
                    }

                    if (model.LogData == null)
                    {
                        var log = await context.Logs.Where(a => a.LogId == model.LogId).SingleAsync();

                        model.LogData = _mapper.Map<Model.DTO.Log>(log);
                    }

                    if (model.Results == null)
                    {
                        // If the results is null then kendo will throw an exception (Slice) because it cannot parse a null data value
                        model.Results = new List<Model.DTO.LogDetail>();
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LogService)}; Method: {nameof(GetLogDetailsAsync)}; Error: {e.Message}");
            }

            return model;
        }


        /// <summary>
        /// Updates the log status by ID
        /// </summary>
        /// <param name="logId"></param>
        /// <param name="logStatus"></param>
        /// <returns></returns>
        public async Task<DTO.Log> UpdateLogStatusByIdAsync(int logId, string logStatus)
        {
            DTO.Log log = null;
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();
                    var logEntity = context.Logs.Where(x => x.LogId == logId).SingleOrDefault();

                    if (logEntity == null)
                    {
                        _logger.LogInformation($"Log record not found for {logId}");
                        return log;
                    }
                    else
                    {
                        logEntity.Status = logStatus;
                        if (logStatus == JobLogStatus.Completed.GetDescription() || logStatus == JobLogStatus.Failed.GetDescription())
                        {
                            logEntity.ProcessEndDate = DateTime.Now;
                        }

                        context.Logs.Update(logEntity);
                        await context.SaveChangesAsync();

                        log = _mapper.Map<DTO.Log>(logEntity);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error updating log record for {logId}. Error message: {ex.Message} ");
                throw ex;
            }
            return log;
        }

        /// <summary>
        /// Gets Log row based on LogId
        /// </summary>
        /// <param name="logId">LogId of desired Log row</param>
        /// <returns>Log entity</returns>
        public async Task<DTO.Log> GetLogAsync(int logId)
        {
            var log = new DTO.Log();
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var logEntity = await context.Logs.Where(l => l.LogId == logId).FirstOrDefaultAsync();
                    log = _mapper.Map<DTO.Log>(logEntity);
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LogService)}; Method: {nameof(GetLogAsync)}; Error: {e.Message}");
            }
            return log;
        }

        /// <summary>
        /// Updates the log and log details
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        public async Task<DTO.Log> UpdateLogStatusAsync(DTO.Log log, List<DTO.LogDetail> logDetails)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();

                    var logEntity = await context.Logs.Where(x => x.LogId == log.LogId).SingleOrDefaultAsync();
                    if (logEntity == null)
                    {
                        _logger.LogInformation($"Log record not found for {log.LogId}");
                        return log;
                    }

                    logEntity.TotalCount = (log.TotalCount > 0) ? log.TotalCount : logEntity.TotalCount;
                    logEntity.SuccessfulCount = (log.SuccessfulCount > 0) ? log.SuccessfulCount : logEntity.SuccessfulCount;
                    logEntity.Filename = (!string.IsNullOrEmpty(log.Filename)) ? log.Filename : logEntity.Filename;
                    logEntity.WarningCount = (log.WarningCount > 0) ? log.WarningCount : logEntity.WarningCount;
                    logEntity.ErrorCount = (log.ErrorCount > 0) ? log.ErrorCount : logEntity.ErrorCount;
                    logEntity.Status = (!string.IsNullOrEmpty(log.Status)) ? log.Status : logEntity.Status;
                    logEntity.ProcessEndDate = log.ProcessEndDate;
                    logEntity.ProcessName = log.ProcessName;
                    if ((logEntity.ErrorCount > 0 || logEntity.WarningCount > 0) && logDetails != null && logDetails.Count > 0)
                    {
                        logEntity.LogDetails = (ICollection<Data.ShippingModel.Entities.LogDetail>)_mapper.Map<List<LogDetail>>(logDetails);
                    }

                    context.Logs.Update(logEntity);
                    await context.SaveChangesAsync();

                    log = _mapper.Map<DTO.Log>(logEntity);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LogService)}; Method: {nameof(UpdateLogStatusAsync)}; Error: {ex.Message}");
                throw;
            }
            return log;
        }

        /// <summary>
        /// Insert the log details
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        public async Task<DTO.Log> InsertLogAsync(DTO.Log logDetails)
        {

            var log = new DTO.Log();
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<IShippingModel>();
                    var logEntity = _mapper.Map<Log>(logDetails);
                    await context.Logs.AddAsync(logEntity);
                    await context.SaveChangesAsync();
                    log = _mapper.Map<DTO.Log>(logEntity);
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LogService)}; Method: {nameof(InsertLogAsync)}; Error: {e.Message}");
            }
            return log;
        }

        #endregion
    }

}
