using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.Shipping.Data.Repository;

namespace VM.FleetServices.TnR.Shipping.Business.Helpers
{
    public static class PaginateExtensions
    {
        /// <summary>
        /// Generic Paging method
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="query"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public static async Task<PaginateResult<T>> ToPageListAsync<T>(this IQueryable<T> query,
            int page, int pageSize) where T : class
        {
            var result = new PaginateResult<T>();
            result.PageSize = pageSize;
            result.RowCount = await query.CountAsync();

            var skip = (page - 1) * pageSize;
            result.Results = await query.Skip(skip).Take(pageSize).ToListAsync();

            return result;
        }

        public static PaginateResult<T> ToPageList<T>(this IEnumerable<T> query,
            int page, int pageSize) where T : class
        {
            // return await ToPageListAsync(query.AsQueryable(), page, pageSize);

            var result = new PaginateResult<T>();
            result.PageSize = pageSize;
            result.RowCount = query.Count();

            var skip = (page - 1) * pageSize;
            result.Results = query.Skip(skip).Take(pageSize).ToList();

            return result;
        }
    }

    public class PaginateResult<T> where T : class
    {
        public IList<T> Results { get; set; }
        public int PageSize { get; set; }
        public int RowCount { get; set; }
    }
}

