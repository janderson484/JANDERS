using System.Collections.Generic;
using AutoMapper;
using Entities = VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using DTO = VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Business.Mapping
{
    public class ShippingMappingProfile : Profile
    {
        public ShippingMappingProfile()
        {
            CreateMap<Entities.Log, DTO.Log>();
            CreateMap<DTO.Log, Entities.Log>();
        }
    }
}
