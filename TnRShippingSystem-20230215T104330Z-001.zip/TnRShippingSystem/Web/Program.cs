using System;
using System.IO;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace VM.FleetServices.TnR.Shipping.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Console.Title = "Web";
                CreateWebHostBuilder(args).Build().Run();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((context, config) =>
                {
                    var builtConfig = config.Build();

                    var kvUrl = builtConfig["KeyVaultConfiguration:KVUrl"];

                    if (!string.IsNullOrEmpty(kvUrl) && context.HostingEnvironment.EnvironmentName.Equals("Development"))
                    {
                        var tenantId = builtConfig["KeyVaultConfiguration:TenantId"];
                        var clientId = builtConfig["KeyVaultConfiguration:ClientId"];
                        var clientSecret = builtConfig["KeyVaultConfiguration:ClientSecretId"];

                        var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
                        var client = new SecretClient(new Uri(kvUrl), credential);
                        config.AddAzureKeyVault(client, new AzureKeyVaultConfigurationOptions());
                    }
                })
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<Startup>()
                //.UseApplicationInsights()
                .UseAzureAppServices()
                //.UseKestrel(options => { options.Limits.MaxRequestBodySize = int.MaxValue; });
                .ConfigureKestrel(serverOptions => { });
    }
}
