using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Serialization;
using VM.FleetServices.TnR.Core.Common.AzureStorage;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Core.Common.SignalR;
using VM.FleetServices.TnR.Shipping.Web.ActionFilters;
using VM.FleetServices.TnR.Shipping.Web.Helpers;
using VM.FleetServices.TnR.Shipping.Web.Models;
using VM.FleetServices.TnR.Shipping.Web.Security;

namespace VM.FleetServices.TnR.Shipping.Web
{
    public class Startup
    {
        public Startup(IHostingEnvironment env, IConfiguration configuration)
        {
            Environment = env;
            Configuration = configuration;

            //Aspose Licensing
            var license = new Aspose.Pdf.License() { Embedded = true };
            license.SetLicense("Aspose.Total.lic");

            if (!Aspose.Pdf.Document.IsLicensed)
                throw new Exception("License not found - Aspose.Pdf");

            // Aspose Barcode Licensing
            var licenseBarcode = new Aspose.BarCode.License();
            licenseBarcode.SetLicense("Aspose.Total.lic");
        }

        public IConfiguration Configuration { get; }
        public IHostingEnvironment Environment { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLocalization(options => options.ResourcesPath = "Resources");
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => false;
                options.MinimumSameSitePolicy = SameSiteMode.None;
                // options.Secure = CookieSecurePolicy.Always;
            });

            // Register the IConfiguration instance which MyOptions binds against.
            services.Configure<OpenIdSettings>(options => Configuration.GetSection("OpenIdSettings").Bind(options));
            services.Configure<ApiSettings>(options => Configuration.GetSection("ApiSettings").Bind(options));
            services.Configure<AppSettings>(options => Configuration.GetSection("AppSettings").Bind(options));
            services.Configure<CacheSettings>(options => Configuration.GetSection("CacheSettings").Bind(options));
            services.Configure<StorageOptions>(options => Configuration.GetSection("StorageOptions").Bind(options));
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            services.Configure<IISOptions>(options =>
            {
                options.AutomaticAuthentication = false;
                options.ForwardClientCertificate = false;
            });

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = "Cookies";
                options.DefaultChallengeScheme = "oidc";
            })
            .AddCookie()
            .AddOpenIdConnect("oidc", options =>
            {
                options.SignInScheme = "Cookies";

                options.Authority = Configuration.GetSection("OpenIdSettings")?.Get<OpenIdSettings>()?.Authority;
                options.RequireHttpsMetadata = false;

                options.ClientId = "fstnr.shipping";
                options.ClientSecret = "secret";

                options.ResponseType = "code id_token";

                options.GetClaimsFromUserInfoEndpoint = true;

                options.SaveTokens = true;
                options.Scope.Clear();
                options.Scope.Add("fstnrshippingapi");
                options.Scope.Add("umid");
                options.Scope.Add("offline_access");
                options.Scope.Add("openid");
                options.Scope.Add("profile");

                // Test note

                options.Events = new OpenIdConnectEvents
                {
                    OnUserInformationReceived = UserManagerClaimsTransformer.OnUserInformationReceivedAsync,
                    OnRemoteFailure = RemoteAuthFail
                };

            });

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<IApiClientService, ApiClientService>();
            //services.AddScoped<INotificationService, NotificationService>();
            services.AddSingleton<IClaimsTransformation, UserManagerClaimsTransformer>();
            services
                .AddMvc(options =>
                {
                    options.MaxModelValidationErrors = int.MaxValue;
                    options.Filters.Add<ViewBagInitializerActionFilter>();
                })
                .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
                .AddDataAnnotationsLocalization();

            services.AddOptions();
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddAzureStorageService(Configuration.GetSection("StorageOptions"));

            services.AddDistributedRedisCache(option =>
            {
                option.Configuration = Configuration.GetConnectionString("TnrDistributedCache");
                option.InstanceName = "TnrSharedRedisCache";
            });

            services.AddTransient<IObjectCache, ObjectCache>();

            var settings = Configuration.GetSection(nameof(AppSettings)).Get<AppSettings>();
            var expireMinutes = settings.CookieAuthentication.ExpireMinutes;

            services.AddSession(options =>
            {
                options.Cookie.Name = ".TnrShipping.Session";
                options.IdleTimeout = TimeSpan.FromMinutes(expireMinutes);
                // options.Cookie.IsEssential = true;
            });

            if (!Environment.IsDevelopment())
            {
                // require HTTPS for non development Environment
                services.Configure<MvcOptions>(options =>
                {
                    options.Filters.Add(new RequireHttpsAttribute());
                });
            }

            services.AddScoped<IUserSession, UserSession>();

            services.Configure<FormOptions>(x =>
            {
                x.ValueLengthLimit = int.MaxValue;
                x.MultipartBodyLengthLimit = int.MaxValue; // In case of multipart
            });
            services.AddLocalization(l =>
            {
                // we will put our translations in a folder called resources
                l.ResourcesPath = "Resources";
            });

            services.AddControllersWithViews()
                .AddMvcOptions(options => { options.EnableEndpointRouting = false; options.MaxModelValidationErrors = int.MaxValue; options.SuppressAsyncSuffixInActionNames = false; })
                .AddNewtonsoftJson(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());
            services.AddRazorPages()
                .AddMvcOptions(options => { options.EnableEndpointRouting = false; options.MaxModelValidationErrors = int.MaxValue; options.SuppressAsyncSuffixInActionNames = false; })
                .AddNewtonsoftJson(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            // Add Kendo UI services to the services container
            services.AddKendo();

            services.AddAuthorization(options =>
            {
                options.AddPolicy(AuthorizationPolicyNames.ApplicationReadPolicy,
                    policy => policy.Requirements.Add(new ApplicationAccessRequirement("external,internal,supervisor,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationAddModifyPolicy,
                   policy => policy.Requirements.Add(new ApplicationAccessRequirement("internal,supervisor,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationInvoicePolicy,
                    policy => policy.Requirements.Add(new ApplicationAccessRequirement("supervisor,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationAccessPolicy,
                    policy => policy.Requirements.Add(new ApplicationAccessRequirement("internal,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationConfigSettingPolicy,
                 policy => policy.Requirements.Add(new ApplicationAccessRequirement("admin")));

            });

            services.AddSingleton<IAuthorizationHandler, ApplicationAccessHandler>();


            //Configure SignalR
            services.AddSignalR();
            services.AddScoped<INotificationService, NotificationService>();

            services.AddCors(o => o.AddPolicy("CorsPolicy", builder => {
                builder
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                .WithOrigins("https://localhost:3015/");
            }));

            services.Configure<RequestLocalizationOptions>(options =>
            {
                var cultures = new List<CultureInfo> {
                    //new CultureInfo("en-US"),
                    //new CultureInfo("de-DE"),
                    //new CultureInfo("fr-FR"),
                    //new CultureInfo("en-GB")
                    new CultureInfo("en"),
                    new CultureInfo("es")
                };
                options.DefaultRequestCulture = new RequestCulture("en");
                options.SupportedCultures = cultures;
                options.SupportedUICultures = cultures;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            //app.UseCookiePolicy();

            app.UseAuthentication();

            app.UseRefreshAccessToken();

            app.UseSession();

            app.Use(async (context, next) =>
            {
                context.Request.EnableBuffering();
                await next();
            });

            if (!Environment.IsDevelopment())
            {
                // require HTTPS for non development Environment
                var options = new RewriteOptions()
                    .AddRedirectToHttps();
                app.UseRewriter(options);
            }

            app.UseRouting();
            app.UseAuthorization();
            app.UseCors("CorsPolicy");

            // app.UseMvc();

            app.UseEndpoints(endpoints =>
            {
                // endpoints.MapRazorPages();
                endpoints.MapHub<NotificationHub>("/notificationHub/{username}");
               // endpoints.MapControllers();
               // endpoints.MapDefaultControllerRoute();
                //endpoints.MapRazorPages();
                endpoints.MapControllerRoute(
                   name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private Task RemoteAuthFail(RemoteFailureContext context)
        {
            context.Response.Redirect("/Account/SignIn");
            context.HandleResponse();
            return Task.CompletedTask;
        }
    }
}
