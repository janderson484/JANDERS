// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {

    //Added for fetch exact match menu name
    $.expr[':'].textEquals = $.expr.createPseudo(function (arg) {
        return function (elem) {
            return $(elem).text().match("^" + arg + "$");
        };
    });

    var currentPage = localStorage.getItem("activePage");

    if (currentPage) {
        $("nav").find("a:textEquals('" + currentPage + "')").parent("li").addClass('active');
    }

    $('#left-panel a').click(function () {
        var activePage = $(this).text();
        localStorage.setItem("activePage", activePage);
    });
    $("#config-settings a").click(function () {
        localStorage.setItem("activePage", "");
    });
    $("#userLogoutLink").click(function () {
        localStorage.setItem("activePage", "");
    });


});
