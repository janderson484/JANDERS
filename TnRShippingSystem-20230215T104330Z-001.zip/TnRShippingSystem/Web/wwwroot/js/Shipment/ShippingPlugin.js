$.fn.barcodePlugin = function (options) { 
    var _this = this;
    //alert("Plugged in!");
    var shippingService = new ShippingService();
    var BARCODE_DETECT_MIN_CHARS = 3;
    var BARCODE_DETECT_INTERVAL = 300;
    var barcodeDetected = false;
    var controlDataKey = "barcodeDetected";
    var keypress = false;
    var keychars = [];
    this.each(function () {
        _this.bind("keydown", function (keyEventObject) {
            //Determine if a barcode was scanned or not
            keychars.push(String.fromCharCode(keyEventObject.which));
            if (keypress === false) {
                keypress = true;
                setTimeout(function () {
                    if (keychars.length >= BARCODE_DETECT_MIN_CHARS || (barcodeDetected && keychars.length > 0)) {
                        // keys are being rapidly input, possible barcode
                        barcodeDetected = true;
                        //alert("Barcode detected!");
                    }
                    else {
                        // keys are not being entered fast enough to be a barcode      
                        barcodeDetected = false;
                        //alert("Barcode not detected!");
                    }
                    _this.data(controlDataKey, barcodeDetected);
                    keychars = [];
                    keypress = false;
                }, BARCODE_DETECT_INTERVAL);
            }
        });
        _this.bind("blur", function (eventObject) {
            //Get the barcode content (if any)
            var barcodeContent = $(_this).val(); //eventObject.data.text;  
            //Clean scanned input
            barcodeContent = barcodeContent.replace(/[\x7e\x0b]/g, '');
            barcodeContent = barcodeContent.replace(/\s/g, '');
            barcodeDetected = ((_this.data(controlDataKey)));
            //Determine the type of courier from the tracking number entered and parse the content if required
            var trackingResult = shippingService.getCourierFromTrackingResult(barcodeContent, barcodeDetected);
            barcodeDetected = false;
            //alert(trackingResult.trackingNumber);
            //Fire an event to any attached handlers
            _this.trigger("trackingNumberParseCompleted", trackingResult);
        });
    });
    // Return the jQuery object for chaining.
    return this;
};
//# sourceMappingURL=ShippingPlugin.js.map 
