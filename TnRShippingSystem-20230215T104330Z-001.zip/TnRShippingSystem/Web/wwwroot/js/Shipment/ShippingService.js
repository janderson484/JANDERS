var Courier;
(function (Courier) {
    Courier[Courier["Unknown"] = 0] = "Unknown";
    Courier[Courier["FedEx"] = 1] = "FedEx";
    Courier[Courier["UPS"] = 2] = "UPS";
    Courier[Courier["USPS"] = 3] = "USPS";
})(Courier || (Courier = {}));
;
;
var ShippingService = /** @class */ (function () {
    function ShippingService() {
    }
    ShippingService.prototype.getCourierFromTrackingResult = function (barcodeContent, isBarcodeDetected) {
        if (barcodeContent) {
            //Fedex
            if ((barcodeContent.length === 12) ||
                (barcodeContent.length === 14) ||
                (barcodeContent.length === 26) ||
                (barcodeContent.length === 32) ||
                (barcodeContent.length === 34)) {
                // Parse the tracking number
                var parsedTrackingNumber = this.parseTrackingNumber(Courier.FedEx, barcodeContent);
                var fedExUrl = "https://www.fedex.com/apps/fedextrack/?action=track&tracknumbers=" + parsedTrackingNumber + "&locale=en_CA&cntry_code=ca_english";
                return { courierName: "FedEx", courierId: Courier.FedEx, trackingNumber: parsedTrackingNumber, url: fedExUrl };
            }
            //UPS
            if ((barcodeContent.length === 18) &&
                (barcodeContent.substr(0, 2).toUpperCase() === "1Z")) {
                var upsUrl = "https://wwwapps.ups.com/WebTracking/track?track=yes&trackNums=" + barcodeContent;
                return { courierName: "UPS", courierId: Courier.UPS, trackingNumber: barcodeContent, url: upsUrl };
            }
            // USPS
            if ((barcodeContent.length === 22) ||
                (barcodeContent.length === 30) ||
                (barcodeContent.length === 13)) {
                var uspsUrl = "https://tools.usps.com/go/TrackConfirmAction?tLabels=" + barcodeContent;
                return { courierName: "USPS", courierId: Courier.USPS, trackingNumber: barcodeContent, url: uspsUrl };
            }
        }
        return { courierName: "Unknown", courierId: Courier.Unknown, trackingNumber: barcodeContent, url: "" };
    };
    ShippingService.prototype.parseTrackingNumber = function (courier, barcodeContent) {
        switch (courier) {
            case Courier.FedEx:
                if (barcodeContent.length === 32)
                    barcodeContent = barcodeContent.substr(barcodeContent.length - 16).substr(0, 12);
                if (barcodeContent.length === 34)
                    barcodeContent = barcodeContent.substr(barcodeContent.length - 14);
                //if (barcodeContent.length === 12
                //    && barcodeContent.substr(0, 2) !== "00")
                //    barcodeContent = "00".concat(barcodeContent);
                break;
            default:
                break;
        }
        return barcodeContent;
    };
    return ShippingService;
}());
;
//# sourceMappingURL=ShippingService.js.map