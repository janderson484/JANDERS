// Add an event listener for an event on the main page. this will be triggered when postmessage is called from the main page
self.addEventListener("message", go);
importScripts("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.11.5/xlsx.core.min.js");

function go(message) {

    if (!message.data.file)
        return;
    console.log("File received to start processing");
    handleExcel(message.data.file, message.data.includeheader, message.data.maxPlateCount);
}


var rABS = true; // true: readAsBinaryString ; false: readAsArrayBuffer


function handleExcel(f, includeheader, maxPlateCount) {
    

    var reader = new FileReader();
    reader.onload = function (e) {
        console.log("File reader callback started");
        var success = false;
        var message = "";
        var plates = [];
        var invalidPlates = [];
        var dupPlates = [];
        var regexExpr = /^[a-zA-Z0-9]{1,12}$/;

        var fileName = e.target.filename;
        var allowedExtensions = /(\.xls|\.xlsx|\.csv)$/i;

        if (!allowedExtensions.exec(fileName)){
            message = "File type not allowed.";
            self.postMessage({ "command": "done", "message": message, "success": success, "plates": plates, "filename": e.target.filename });
        }             

        try {

            // var data = e.target.result;
            var binary = "";
            var bytes = new Uint8Array(e.target.result);
            var length = bytes.byteLength;
            for (var i = 0; i < length; i++) {
                binary += String.fromCharCode(bytes[i]);
            }

            var workbook = XLSX.read(binary, { type: 'binary', cellDates: true, cellStyles: true });

            //if (!rABS) data = new Uint8Array(data);
            //var workbook = XLSX.read(data, { type: rABS ? "binary" : "array" });
            console.log("Workbook read");
            //make sure there is at least 1 worksheet
            if (workbook.SheetNames.Length == 0) {
                message = "No worksheets in uploaded file.";
                self.postMessage({ "command": "done", "message": message, "success": success, "plates": plates, "filename": e.target.filename });
            }

            var sheet = workbook.Sheets[workbook.SheetNames[0]];

            //get range
            var range = sheet['!ref'];         
            var cellRange = XLSX.utils.decode_range(range);            

            var plateCol = 0;
            var cellValue, cellAddr, cellRef;          
            cellRef = 'A1';         

            var startRow = includeheader ? 1 : 0;                      

            console.log("PLATE column found. Retrieving values.");                     

            for (var row = startRow; row <= cellRange.e.r; row++) {
                cellAddr = { c: plateCol, r: row };
                cellRef = XLSX.utils.encode_cell(cellAddr);
                if (cellRef in sheet) {
                    cellValue = sheet[cellRef];
                    if (cellValue) {
                        if (!cellValue.v.match(regexExpr)) {
                            invalidPlates.push(cellValue.v)
                        }
                        else {
                            if (plates.indexOf(cellValue.v) != -1) {
                                dupPlates.push(cellValue.v);
                            }
                            else {
                                plates.push(cellValue.v);
                            }
                        }
                    }
                }
            }

            if (plates.length > maxPlateCount) {
                message = "Invalid file: Allowed plates - " + maxPlateCount + ", Read " + plates.length + " plates."
                plates = [];
            } else {

                if (plates.length > 0) {
                    success = true;
                    message = "File successfully processed. " + plates.length + " valid records read. ";
                } else {
                    message = "No valid PLATE numbers found. ";
                }

                if (invalidPlates.length > 0) {
                    message = message + "<br/>" + invalidPlates.length + " invalid plates found: " + invalidPlates.join(',') + ".";
                }

                if (dupPlates.length > 0) {
                    message = message + "<br/>" + dupPlates.length + " Duplicate plates found: " + dupPlates.join(',') + ".";
                }
            }

            console.log("Finished processing.");
            self.postMessage({ "command": "done", "message": message, "success": success, "plates": plates, "filename": e.target.filename });

        } catch (ex) {
            //show error message if cannot read file
            message = 'Unable to parse file. Please select a valid excel file.';
            self.postMessage({ "command": "done", "message": message, "success": success, "plates": plates, "filename": e.target.filename });
        }

    };
    reader.filename = f.name;
    console.log("Starting to read file");
    reader.readAsArrayBuffer(f);
}
