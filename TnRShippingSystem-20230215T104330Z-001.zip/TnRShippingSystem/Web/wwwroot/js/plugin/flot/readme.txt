What did we customize in the flot.cust.js?

We have hardcoded the themecolors as default; however they are still changable through flot init() options.