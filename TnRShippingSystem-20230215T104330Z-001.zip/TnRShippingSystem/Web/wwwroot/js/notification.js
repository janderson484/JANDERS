

$(function () {

    $.ajax({
        type: "GET",
        url: "/Home/GetConfigurationValue"
    }).done(function (data) {


        //var connection = new signalR.HubConnectionBuilder().withUrl(data.configurationValue + "notificationHub?username=" + data.userId).build();
        var connection = new signalR.HubConnectionBuilder().withUrl(data.configurationValue + "notificationHub?username=" + data.userId).build();

        connection.on("ReceiveNotifications",
            function (notification) {

                var response = JSON.parse(notification);
                //var testNotification = '{ "notificationId": 123,  "logId": 1234, "notificationType": "Export", "totalRecordsCount": 0, "successfulRecordsCount": 0,  "warningRecordsCount": 0, "erroredRecordsCount": 0,  "message": "Test",  "isRead": false,  "userName": MPINNINTI,  "createdBy": mpinninti,  "createdDate": "2020-01-01T00:00:00",  "lastRefreshDate": "2020-01-01",  "logStatus": "Success"}';
                //var response = $.parseJSON(notification);

                var isValidUser = IsValidUserForNotification(response.UserName, response.NotificationType);
                if (isValidUser)
                {
                    if (response.LogStatus == "Failed") {
                        $.notify(response.NotificationType + " is failed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "error");
                    }
                    else {
                        if (response.ErrorCount > 0) {
                            $.notify(response.NotificationType + " is completed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "error");
                        }
                        else if (response.WarningCount > 0) {
                            $.notify(response.NotificationType + " is completed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "warning");
                        }
                        else {
                            $.notify(response.NotificationType + " is completed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "success");
                        }
                    }
                    if ((response.NotificationType == "Export" || response.NotificationType == "Bulk Process") && response.Message != "" && response.Message != null) {
                        if (response.Message.indexOf('csv') > 0) {
                            ExportCSV(response.Message);
                        }
                        else if (response.Message.indexOf('pdf') > 0) {
                            onClickAttachment(response.Message);
                        }
                    }

                    //Refreshes the notifications dropdown
                    var notificationsContainer = $('#Logs');
                    notificationsContainer.load("/Home/GetNotificationViewComponentAsync");
                }
                
            });

        connection.start().then(function () {
            console.log("connected");
        }).catch(function (err) {
            console.error(err.toString());
        });

    });
});


function IsValidUserForNotification(user, notificationType) {
    var isSuccess = false;
    $.ajax({
        type: "POST",
        url: "/Reports/ValidUserToDownload",
        dataType: "json",
        async: false,
        data: { userName: user, processType: notificationType },
        success: function (response) {
            isSuccess = response.isValid;
        },
        error: function () {
            isSuccess = false;
        }
    });
    return isSuccess;
}
