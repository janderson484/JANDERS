$(document).ready(function () {
    $("#SearchTextField").each(function (i) {
        var tagsInput = $(this);

        // get internal tags input element..
        var internalTagsInput = tagsInput.tagsinput("input");

        // bind to paste event on internal tags input to parse data pasted in from excel
        $(internalTagsInput).on("paste",
            function (e) {

                // get pasted data..
                var pasteData = "";
                if (window.clipboardData && window.clipboardData.getData) { // IE
                    pasteData = window.clipboardData.getData("text");
                } else { // other browsers 
                    pasteData = e.originalEvent.clipboardData.getData("text");
                }

                // parse data..
                var cleanData = pasteData.replace(/(?:\r\n|\r|\n|\t|;| )/g, ",");
                // set data in internal input element
                $(this).val(cleanData);

                // trigger enter key so tags control process all inputs.. (turn every comma separated value into a tag)
                $(this).trigger(jQuery.Event("keypress", { keycode: 13 }));

                // re-enable validation on insert
                e.preventDefault();

            });

        // bind to focus and blur events on internal input to set focus class on container..
        // this is needed since setting focusClass on tagsinput() did not work
        var container = $(internalTagsInput).parent();
        $(internalTagsInput).focus(function () {
            $(container).addClass("form-control-focus");
        });
        $(internalTagsInput).blur(function () {
            $(container).removeClass("form-control-focus");
        });
    });

});
