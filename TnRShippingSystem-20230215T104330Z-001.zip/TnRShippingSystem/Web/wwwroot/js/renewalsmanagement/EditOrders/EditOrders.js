
function setKendoWindowPosition(kendoWindowRef, topY) {
    // Calculate position of kendo window
    // The kendo window must have a fixed width and height to start with
    var x = 0;
    var y = 0;
    var pointX = 0;
    var pointY = 0;

    // Get browser Window width and height
    x = $(window).width();
    y = $(window).height();

    // Determine coordinates and set window position
    pointX = (x - kendoWindowRef.wrapper.width()) / 2;
    pointY = (y - kendoWindowRef.wrapper.height()) / 2;
    kendoWindowRef.setOptions({ position: { top: 0, left: 0 } });
    kendoWindowRef.setOptions({ position: { top: pointY - topY, left: pointX } });
}

function onClickBulkUpdate(windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the bulk update option/button after selecting orders to bulk update

    if (getSelectedOrderCount() === 0) {
        // None selected!
        $.notify("Bulk Update Error\r\nPlease select orders for bulk update action", "error");
        return;
    }

    //Get the selected orders (if any)
    var ordersList = getSelectedOrders();
        
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Order Data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: ordersList
    });
    // Open the window
    theKendoWindow.open();
}

function onClickEditorLink(windowName, contentUrl) {
    //Load the KendoWindow and position it, then open the window,
    //based on clicking the editor link to show report content.
    //Related to bulk update action
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);

    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);
    theKendoWindow.content("Loading Editor Data...");
    theKendoWindow.refresh({
        url: contentUrl
    });

    theKendoWindow.open();
}

function filterFieldValues() {
    // Used by the BulkUpdateWindowContent Partial View
    // Called from the dropdown list control
    return {
        fieldId: $("#fields").val()
    };
}

function getSelectedOrders() {
    // Gets the selected orders from the order grid
    var items = {};
    var grid = $("#grdViewRenewalOrders").data("kendoGrid");
    var selectedElements = grid.select();

    for (var j = 0; j < selectedElements.length; j++) {
        var item = grid.dataItem(selectedElements[j]);
        var x = item.OrderId;
        items['orders[' + j + ']'] = x;
    }

    return items;
}

function getSelectedOrderCount() {
    // Gets the selected order count
    var grid = $("#grdViewRenewalOrders").data("kendoGrid");
    var selectedElements = grid.select();
    return selectedElements.length;
}

function SelectBulkErrorOrders() {
    // Select any orders in the orders grid that had errors when performing a bulk update operation
    var bulkErrorOrderIds = $("#BulkUpdateErrorOrders").val();

    if (bulkErrorOrderIds !== "") {
        var grid = $("#grdViewRenewalOrders").getKendoGrid();
        var arr = JSON.parse(bulkErrorOrderIds);

        for (var i = 0; i < arr.length; i++) {
            var item = arr[i];
            var dataItem = grid.dataSource.get(item);
            var row = grid.tbody.find("tr[data-uid='" + dataItem.uid + "']");
            grid.select(row);
        }
    }
}

function onBulkUpdateFieldsChange(e) {
    var dataItem = this.dataItem();
    var fieldDescription = dataItem.FieldDescription;
    var fieldId = dataItem.FieldId;
    var dropDownList = $("#fieldValues").data("kendoDropDownList");
    dropDownList.wrapper.show().focus();

    // Hide or show the mailto or owning area input boxes based on master field user selection

    $("#MailTo").attr('type', 'hidden');
    $("#MailTo").hide();
    $("#OwningArea").attr('type', 'hidden');
    $("#OwningArea").hide();

    if (fieldDescription === "Mail To" && fieldId === 3) {
        dropDownList.wrapper.hide();
        $("#MailTo").attr('type', 'text');
        $("#MailTo").show().focus();
    }
    if (fieldDescription === "Owning Area" && fieldId === 2) {
        dropDownList.wrapper.hide();
        $("#OwningArea").attr('type', 'text');
        $("#OwningArea").show().focus();
    }
}

function getUserLocalDateTime() {
    // Gets the local time of the current machine
    var d = new Date();
    var localDateTime = d.toLocaleDateString() + " " + d.toLocaleTimeString();
    return localDateTime;
}

function OnClickFileMappingAddUpdate(windowName, contentUrl, type, mappingId) {
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading screen...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: { fileType : type, id : mappingId }

    });
    // Open the window
    theKendoWindow.open();
}

function onClickGetActiveOrders(windowName, contentUrl, data) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the bulk update option/button after selecting orders to bulk update      

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Order Data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: {model: data}
    });
    // Open the window
    theKendoWindow.open();
}
function onClickGetShipLabels(windowName, contentUrl, data) {
    //Load the kendoWindow and position it, then open the window,     

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Label Data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: { model: data }
    });
    // Open the window
    theKendoWindow.open();
}
function onClickRegAgentAddUpdate(windowName, contentUrl, data) {
    //Load the kendoWindow and position it, then open the window,     

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Registration Agent Data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: { regAgentDataViewModel: data }
    });
    // Open the window
    theKendoWindow.open();
}
function onClickExceptionCodeAddUpdate(windowName, contentUrl, data) {
    //Load the kendoWindow and position it, then open the window,     

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Exception Code Data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: { exceptionCodeDataViewModel: data }
    });
    // Open the window
    theKendoWindow.open();
}
