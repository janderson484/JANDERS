
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using static VM.FleetServices.TnR.Shipping.Web.Models.Constant;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Shipping.Web.Helpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.Infrastructure.Implementation;
using Kendo.Mvc.UI;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.Shipping.Web.Controllers
{
    [Authorize]
    public class LogsController : BaseController
    {
        private readonly IApiClientService _apiClientService;
        private readonly ILogger<LogsController> _logger;
        private readonly ApiSettings _apiSettings;

        public LogsController(IOptions<ApiSettings> apiSettings, IApiClientService apiClientService, ILogger<LogsController> logger) : base(apiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
        }
        #region Logs

        /// <summary>
        /// This method will return user to Logs page where user can view logs based on his rights
        /// </summary>
        /// <returns>returns view with logs data</returns>
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (!User.IsShippingUser())
            {
                return AccessDenied();
            }
            var searchCriteria = GetDefaultLogSummaryViewModel();
            return View(searchCriteria);
        }

        /// <summary>
        /// private method to get default log summary model
        /// </summary>
        /// <returns>returns model</returns>
        private LogSummaryViewModel GetDefaultLogSummaryViewModel()
        {
            var model = new LogSummaryViewModel { ClientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)), UserId = User.GetUserId() };
            //var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            //model.ClientCode = clientLocationPreference?.ClientCode;
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();
            model.RowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage;
            return model;
        }

        /// <summary>
        /// private method to get log summary data based on serach criteria
        /// </summary>
        /// <param name="searchCriteria">input request</param>
        /// <returns>returns data</returns>
        private async Task<LogSummaryViewModel> GetLogSummaryDataAsync(LogSummaryViewModel searchCriteria)
        {
            try
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLogSummary();
                _logger.LogInformation($"Method: {nameof(GetLogSummaryDataAsync)} - Before processing log summary web API");
                _apiClientService.SetClientCode(searchCriteria.ClientCode);

                searchCriteria.UserId  = User.GetUserId();
                searchCriteria.Results = null;

                var response = await _apiClientService.PostRequestAsync(uri, searchCriteria);
                _logger.LogInformation($"Method: {nameof(GetLogSummaryDataAsync)} - After processing log summary web API");

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;

                    var logs = JsonConvert.DeserializeObject<ServiceResponse<LogSummaryViewModel>>(result);
                    if (logs != null)
                    {
                        logs.Data ??= new LogSummaryViewModel();
                        logs.Data.LogSearchCriteria = new SearchLogSummaryViewModel();
                        HttpContext.Session.Set(SessionKeys.LogSummarySearch, logs.Data);
                        return logs.Data;
                    }
                }

                _logger.LogError($"Method: {nameof(GetLogSummaryDataAsync)} - No valid response from API");

                return new LogSummaryViewModel();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogSummaryDataAsync)} - {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// private method to get default log detail model
        /// </summary>
        /// <returns>returns model</returns>
        private LogDetailViewModel GetDefaultLogDetailViewModel(int logId)
        {
            var logs = HttpContext.Session.Get<LogSummaryViewModel>(SessionKeys.LogSummarySearch);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);

            var model = new LogDetailViewModel() { LogId = logId, LogData = logs?.Results?.Where(a => a.LogId == logId).FirstOrDefault() };


            var personalSettings = GetPersonalSettingsAsync();

            model.RowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage;

            return model;
        }

        /// <summary>
        /// private method to get log and log details data based on serach criteria
        /// </summary>
        /// <param name="searchCriteria">input request</param>
        /// <returns>returns data</returns>
        private async Task<LogDetailViewModel> GetLogDetailsByLogAsync(LogDetailViewModel searchCriteria)
        {
            try
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLogDetails();
                _logger.LogInformation($"Method: {nameof(GetLogDetailsByLogAsync)} - Before processing log summary web API");
                _apiClientService.SetClientCode(User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));

                searchCriteria.Results = null;

                var response = await _apiClientService.PostRequestAsync(uri, searchCriteria);
                _logger.LogInformation($"Method: {nameof(GetLogDetailsByLogAsync)} - After processing log summary web API");

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var logDetails = JsonConvert.DeserializeObject<ServiceResponse<LogDetailViewModel>>(result);
                    HttpContext.Session.Set(SessionKeys.LogDetailsSearch, logDetails.Data);
                    return logDetails.Data;
                }
                else
                {
                    _logger.LogError($"Method: {nameof(GetLogDetailsByLogAsync)} - No valid response from API");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogDetailsByLogAsync)} - {ex.Message}");
                throw ex;
            }
        }


        /// <summary>
        /// This method will return user to Logs summary page where user can view logs based on his rights
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> GetLogSummaryAsync([DataSourceRequest] DataSourceRequest request)
        {
            var result = new DataSourceResult();
            var clientCode = HttpContext.User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
            var searchCriteria = HttpContext.Session.Get<LogSummaryViewModel>(SessionKeys.LogSummarySearch);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            if (searchCriteria == null)
            {
                searchCriteria = GetDefaultLogSummaryViewModel();
            }

            // determines if this is a new search or any change in parameters - if the below three statements are true, the there is no change in search criteria, returns the data from the session, else performs a new search.
            // request page number = search criteria page number
            // request page size = search criteria page size
            // search criteria results contains data.
            if (request.Page == searchCriteria.PageNumber && request.PageSize == searchCriteria.RowsPerPage && searchCriteria.Results != null && request.Sorts.Any())
            {
                var sortColumnName = request.Sorts[0].Member;
                var sortColumnOrderAscending = request.Sorts[0].SortDirection == Kendo.Mvc.ListSortDirection.Ascending ? true : false;

                // if the sort column is not available, returns the data.
                if (sortColumnName.IsNullOrEmpty())
                {
                    result.Data = searchCriteria.Results;
                }
                else
                {
                    // else gets the property name and sorts according to the flag set earlier
                    var propertyInfo = typeof(Log).GetProperty(sortColumnName);
                    result.Data = sortColumnOrderAscending ? searchCriteria.Results.OrderBy(a => propertyInfo.GetValue(a, null)) : searchCriteria.Results.OrderByDescending(a => propertyInfo.GetValue(a, null));
                }

                result.Total = searchCriteria.TotalCount;

                return Json(result);
            }

            try
            {
                foreach (var filter in request.Filters.SelectMemberDescriptors())
                {
                    switch (filter.Member)
                    {
                        case LogSearchFilters.ProcessStartDate:
                            searchCriteria.LogSearchCriteria.ProcessStartDate = Convert.ToDateTime(filter.Value);
                            break;
                        case LogSearchFilters.ProcessEndDate:
                            searchCriteria.LogSearchCriteria.ProcessEndDate = Convert.ToDateTime(filter.Value);
                            break;
                        case LogSearchFilters.FileName:
                            searchCriteria.LogSearchCriteria.FileName = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.LogStatus:
                            searchCriteria.LogSearchCriteria.LogStatus = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.ProcessType:
                            searchCriteria.LogSearchCriteria.ProcessType = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.ProcessName:
                            searchCriteria.LogSearchCriteria.ProcessName = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.ShowErrors:
                            searchCriteria.LogSearchCriteria.ShowErrors = Convert.ToBoolean(filter.Value);
                            break;
                        case LogSearchFilters.ShowWarnings:
                            searchCriteria.LogSearchCriteria.ShowWarnings = Convert.ToBoolean(filter.Value);
                            break;
                        default:
                            break;
                    }
                }

                searchCriteria.PageNumber = request.Page;
                searchCriteria.RowsPerPage = request.PageSize;

                //var userPreferences = HttpContext.Session.Get<UserPreferenceViewModel>(SessionKeys.UserPreferences);
                searchCriteria.ClientCode = clientCode;

                var logSummaryData = await GetLogSummaryDataAsync(searchCriteria);
                if (logSummaryData != null)
                {
                    result.Data = logSummaryData.Results;
                    result.Total = logSummaryData.TotalCount;
                }
                else
                {
                    result = new DataSourceResult();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogSummaryAsync)} - {ex.Message}");
            }

            return Json(result);
        }


        /// <summary>
        /// action method to get log details based on log id
        /// </summary>
        /// <param name="id">log id</param>
        /// <returns>returns view with log and log details</returns>
        [HttpGet]
        public async Task<IActionResult> LogDetails(int id)
        {
            var searchCriteria = GetDefaultLogDetailViewModel(id);

            searchCriteria = await GetLogDetailsByLogAsync(searchCriteria);

            return View(searchCriteria);
        }


        
        /// <summary>
        /// action method to get log details
        /// </summary>
        /// <param name="request">input request</param>
        /// <returns>returns log and log details</returns>
        [HttpPost]
        public async Task<IActionResult> GetLogDetails([DataSourceRequest] DataSourceRequest request)
        {
            var result = new DataSourceResult();

            var logDetails = new List<LogDetail>();
            var searchCriteria = HttpContext.Session.Get<LogDetailViewModel>(SessionKeys.LogDetailsSearch);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            if (searchCriteria == null)
            {
                searchCriteria = GetDefaultLogDetailViewModel(searchCriteria.LogData.LogId);
            }

            // determines if this is a new search or any change in parameters - if the below three statements are true, the there is no change in search criteria, returns the data from the session, else performs a new search.
            // request page number = search criteria page number
            // request page size = search criteria page size
            // search criteria results contains data.
            if (request.Page == searchCriteria.PageNumber && request.PageSize == searchCriteria.RowsPerPage && searchCriteria.Results != null && request.Sorts.Any())
            {
                var sortColumnName = request.Sorts[0].Member;
                var sortColumnOrderAscending = request.Sorts[0].SortDirection == Kendo.Mvc.ListSortDirection.Ascending ? true : false;

                // if the sort column is not available, returns the data.
                if (sortColumnName.IsNullOrEmpty())
                {
                    result.Data = searchCriteria.Results;
                }
                else
                {
                    // else gets the property name and sorts according to the flag set earlier
                    var propertyInfo = typeof(LogDetail).GetProperty(sortColumnName);
                    result.Data = sortColumnOrderAscending ? searchCriteria.Results.OrderBy(a => propertyInfo.GetValue(a, null)) : searchCriteria.Results.OrderByDescending(a => propertyInfo.GetValue(a, null));
                }

                result.Total = searchCriteria.TotalCount;

                return Json(result);
            }

            try
            {
                searchCriteria.PageNumber = request.Page;
                searchCriteria.RowsPerPage = request.PageSize;

                var logDetailsData = await GetLogDetailsByLogAsync(searchCriteria);

                if (logDetailsData != null && logDetailsData.Results != null)
                {
                    logDetails = logDetailsData.Results.ToList();
                }

                result.Data = logDetails;
                result.Total = logDetailsData.TotalCount;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogDetails)} - {ex.Message}");
            }

            return Json(result);
        }
        

        /// <summary>
        /// Action methos to update log status based on LogId
        /// </summary>
        /// <param name="logId"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> UpdateLogStatusAsync(int logId, string status)
        {
            try
            {
                var log = new Log
                {
                    LogId = logId,
                    Status = status
                };

                var uri = _apiSettings.Uri + ApiRouteConstants.UpdateLogStatusByIdAsync();
                var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
                _apiClientService.SetClientCode(clientCode);

                var response = await _apiClientService.PostRequestAsync(uri, log);

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var apiResponse = JsonConvert.DeserializeObject<ServiceResponse<Log>>(result);

                    if (apiResponse.Data != null)
                    {
                        var logViewModel = apiResponse.Data;

                        return Json(new { isSuccess = true, data = logViewModel });
                    }
                    else
                    {
                        return Json(new { isSuccess = false, Message = apiResponse.ErrorMessage });
                    }

                }
                else
                {
                    _logger.LogError($"Method: {nameof(UpdateLogStatusAsync)} - No valid response from API");
                    return Json(new { isSuccess = false, Message = "No valid response from API" });
                }
            }
            catch (Exception ex)
            {
                return Json(new { isSuccess = false, Message = ex.Message });
            }
        }

        /// <summary>
        /// private method to get personal settings data 
        /// </summary>
        /// <returns>returns data</returns>
        private async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync()
        {
            /*
            var user = User.GetUserId();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
            var response = await _apiClientService.GetResponseAsync(uri);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(responseResult);
            */
            var result = new PersonalSettingsViewModel
            {
                ClientCode = "HERTZ",
                ProcessingLocationCode = "FL-BRADENTON",
                RowsPerPage = 25,
                UserId = "JKILGORE",
                DaysofHistory = 10
            };

            return result;
        }



        #endregion
    }
}
