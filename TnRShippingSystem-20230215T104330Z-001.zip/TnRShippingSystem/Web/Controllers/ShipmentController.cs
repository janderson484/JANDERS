using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Policy;
using System.Threading.Tasks;
using Aspose.Pdf.Text;
using Aspose.Pdf;
using System.Web;
using Kendo.Mvc.Infrastructure.Implementation;
using Kendo.Mvc.UI;
using Kendo.Mvc.UI.Fluent;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.AzureStorage;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Shipping.Model;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.Enums;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Web.ActionFilters;
using VM.FleetServices.TnR.Shipping.Web.Helpers;
using VM.FleetServices.TnR.Shipping.Web.Models;
using VM.FleetServices.TnR.Shipping.Web.Security;
using static VM.FleetServices.TnR.Shipping.Web.Models.Constant;
using System.IO.Pipes;
using Aspose.Pdf.Drawing;
using static Aspose.Pdf.Operator;
using Aspose.BarCode.Generation;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
using Azure;
using System.Drawing;
using System.Net;
using static AutoMapper.Internal.ExpressionFactory;
using VM.FleetServices.TnR.Shipping.Web.Controllers;

namespace VM.FleetServices.TnR.SVRS.Web.Controllers
{
    [Authorize]
    [ValidateSessionActionFilter]
    public class ShipmentController : BaseController
    {
        private readonly ApiSettings _apiSettings;
        private readonly IApiClientService _client;
        private readonly ILogger<ShipmentController> _logger;
        private readonly CacheSettings _cacheSettings;
        private readonly IObjectCache _objectCache;
        private readonly IBlobStorage _blobStorage;
        private readonly StorageOptions _storageOptions;

        public ShipmentController(IOptions<ApiSettings> apiSettings, IApiClientService apiClientService, ILogger<ShipmentController> logger,
              IOptions<CacheSettings> cacheSettings, IObjectCache objectCache, IBlobStorage blobStorage, IOptions<StorageOptions> storageOptions) : base(apiSettings, apiClientService, logger)
        {
            _apiSettings = apiSettings.Value;
            _client = apiClientService;
            _logger = logger;
            _cacheSettings = cacheSettings.Value;
            _objectCache = objectCache;
            _storageOptions = storageOptions.Value;
            _blobStorage = new CloudBlobStorage(storageOptions.Value.StorageConnection, storageOptions.Value.BlobContainer);
        }
        public IActionResult Index()
        {
            if (!User.IsShippingUser())
            {
                return AccessDenied();
            }
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(Index)}: Method invoked at {DateTime.Now}");
            var shipmentData = HttpContext.Session.Get<CreateReceiveShipmentRequestModel>(SessionKeys.CreateShipmentsDataSearch);

            var receiveShipmentsDataResults = new DataSourceResult
            {
                Data = new List<CreateReceiveShipmentsViewModel>(),
                Total = 0
            };

            receiveShipmentsDataResults.Data = shipmentData.Results;
            return View(receiveShipmentsDataResults);
        }

        #region Create Receive Shipment
        /// <summary>
        /// to get receive shipment page
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        [HttpGet]
        public async Task<IActionResult> ReceiveShipment()
        {
            if (!User.IsShippingUser())
            {
                return AccessDenied();
            }
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(ReceiveShipment)}: GET Method invoked at {DateTime.Now}");
            var model = new CreateReceiveShipmentsViewModel();
            var tnrAppList = await _objectCache.GetTnrApplicationsLookUpsAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            model.Tnrapplication = tnrAppList.Where(x => x.ApplicationCode == TnrApplicationConstants.TransactionProcessing).FirstOrDefault();
            model.Tnrapplication.Url = await GetUploadDocumentUrlAsync();
            model.Tnrapplication.DisplayName = "Upload Documents";
            return View(model);
        }

        /// <summary>
        /// post method to save receive shipment
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        [HttpPost]
        public async Task<IActionResult> ReceiveShipmentAsync(CreateReceiveShipmentsViewModel model)
        {
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(ReceiveShipment)}: POST Method invoked at {DateTime.Now}");
            bool isSuccess = false;
            string responseText;
            try
            {
                var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));

                var newShipment = new ReceiveShipment
                {
                    ReceivedDateTime = model.ReceivedDateTime,
                    Location = model.Location,
                    TrackingNumber = model.TrackingNumber,
                    CourierId = model.CourierId,
                    Comment = model.Comment,
                    Active = true,
                    Customer = clientCode,
                    UserName = User.GetUserId(),
                };

                _client.SetClientCode(clientCode);
                var uri = _apiSettings.Uri + ApiRouteConstants.CreateReceiveShipmentAsync();
                var apiResponse = await _client.PostRequestAsync(uri, newShipment);
                _logger.LogInformation($"Method: {nameof(ReceiveShipment)} - After processing Create Receive Shipment web API");

                if (apiResponse.IsSuccessStatusCode)
                {
                    var result = apiResponse.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<ReceiveShipment>>(result);

                    if (serviceResponse != null && serviceResponse.ResponseCode == System.Net.HttpStatusCode.Accepted)
                    {
                        isSuccess = true;
                        responseText = "Received Shipment successfully";
                    }
                    else
                    {
                        isSuccess = false;
                        responseText = serviceResponse.ErrorMessage;
                    }
                }
                else
                {
                    isSuccess = false;
                    responseText = "Http Response was not successful";
                    _logger.LogError($"Method: {nameof(ReceiveShipment)} - No valid response from API");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(ReceiveShipment)} - Unable to save changes. Message: {ex.Message}");
                isSuccess = false;
                responseText = "A critical error occurred performing the create receive shipment operation!\r\nPlease try again.";
            }
            return Json(new { IsSuccess = isSuccess, UploadDocumentUrl = await GetUploadDocumentUrlAsync(model.TrackingNumber), ResponseText = responseText });
        }

        private async Task<string> GetUploadDocumentUrlAsync(string trackingNumber = "")
        {
            var tnrAppList = await _objectCache.GetTnrApplicationsLookUpsAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            var uploadDocumentUrl = tnrAppList.Where(x => x.ApplicationCode == TnrApplicationConstants.TransactionProcessing).Select(x=>x.Url).FirstOrDefault();
            var controllerActionName = "/Document/UploadDocuments";
            uploadDocumentUrl = string.IsNullOrEmpty(trackingNumber) ? uploadDocumentUrl + controllerActionName : $"{uploadDocumentUrl}{controllerActionName}?trackingNumber={trackingNumber}";
            return uploadDocumentUrl;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        [HttpGet]
        public async Task<JsonResult> GetLocationAndCourierListAsync()
        {
            var locations = await _objectCache.GetTnRProcessingLocationsListAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            var couriers = await _objectCache.GetShipmentCommonLookUpsAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            return Json(new { Locations = locations.OrderBy(x => x.DisplayName), Couriers = couriers.OrderBy(x => x.Name) });
        }

        /// <summary>
        /// To get shipments data 
        /// </summary>
        /// <returns>returns view with a viewmodel</returns>
        [HttpGet]
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> ViewShipments()
        {
            if (!User.IsShippingUser())
            {
                return AccessDenied();
            }
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(ViewShipments)}: Method invoked at {DateTime.Now}");
            var createReceiveShipmentsViewModel = new CreateReceiveShipmentsViewModel() { PageNumber = 1 };
            var processingLocationList = await _objectCache.GetTnRProcessingLocationsListAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            var couriers = await _objectCache.GetShipmentCommonLookUpsAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            createReceiveShipmentsViewModel.ProcessingLocationList = processingLocationList.Where(x => x.Active).Select(x => new Shipping.Model.ViewModel.DropDownList { DisplayName = x.ProcessingLocationCode, Code = x.ProcessingLocationCode, Id = x.ProcessingLocationId }).OrderBy(x => x.Code).ToList();
            createReceiveShipmentsViewModel.CourierList = couriers.Where(x => x.Active).Select(x => new Shipping.Model.ViewModel.DropDownList { DisplayName = x.Name, Code = x.Name,Id= x.CourierId }).OrderBy(x => x.Code).ToList();
            return View(createReceiveShipmentsViewModel);
        }

        /// <summary>
        /// This method retrieves a list of active clients starting with input key in JSON Format
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<JsonResult> GetClientLookUpAsync(string key)
        {
            var clientList = await _objectCache.GetTnRClientsAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            clientList = clientList.Where(x => x.ClientCode.ToLower().StartsWith(key.ToLower())).ToList();
            return Json(clientList);
        }

        /// <summary>
        /// Gets list of shipments for the selected date range
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> GetReceiveShipmentDataAsync([DataSourceRequest] DataSourceRequest request)
        {
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(GetReceiveShipmentDataAsync)}: Method invoked at {DateTime.Now}");

            var receiveShipmentsDataResults = new DataSourceResult
            {
                Data = new List<CreateReceiveShipmentsViewModel>(),
                Total = 0
            };

            var searchCriteria = HttpContext.Session.Get<CreateReceiveShipmentRequestModel>(SessionKeys.CreateShipmentsDataSearch);
            var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));

            if (searchCriteria == null || searchCriteria.ClientCode != User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)))
            {
                searchCriteria = new CreateReceiveShipmentRequestModel()
                {
                    ClientCode = clientCode,
                    PageNumber = 1,
                    DefaultRowsPerPage = 125
                };

            }

            if (request.Page == searchCriteria.PageNumber && request.PageSize == searchCriteria.RowsPerPage && searchCriteria.Results != null && request.Sorts.Any())
            {
                var sortColumnName = request.Sorts[0].Member;
                var sortColumnOrderAscending = request.Sorts[0].SortDirection == Kendo.Mvc.ListSortDirection.Ascending ? true : false;


                if (!sortColumnName.IsNullOrEmpty())
                {
                    var propertyInfo = typeof(CreateReceiveShipmentsViewModel).GetProperty(sortColumnName);
                    receiveShipmentsDataResults.Data = sortColumnOrderAscending ? searchCriteria.Results.OrderBy(a => propertyInfo.GetValue(a, null)) : searchCriteria.Results.OrderByDescending(a => propertyInfo.GetValue(a, null));
                }


                return Json(receiveShipmentsDataResults);
            }

            var uri = _apiSettings.Uri + ApiRouteConstants.GetReceiveShipmentDataAsync();

            _logger.LogInformation($"Method: {nameof(GetReceiveShipmentDataAsync)} - Before processing get Receive Shipment Data web API");
            _client.SetClientCode(User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));

            foreach (var filter in request.Filters.SelectMemberDescriptors())
            {
                switch (filter.Member)
                {
                    case ViewShipmentsFilters.StartDate:
                        searchCriteria.StartDate = Convert.ToDateTime(filter.Value);
                        break;
                    case ViewShipmentsFilters.EndDate:
                        searchCriteria.EndDate = Convert.ToDateTime(filter.Value);
                        break;
                    case ViewShipmentsFilters.CustomerCode:
                        searchCriteria.CustomerCode = filter.Value.ToString();
                        break;
                    case ViewShipmentsFilters.ProcessingLocationCode:
                        searchCriteria.ProcessingLocationCode = filter.Value.ToString();
                        break;
                    case ViewShipmentsFilters.TrackingNumber:
                        searchCriteria.TrackingNumber = filter.Value.ToString();
                        break;
                    case ViewShipmentsFilters.CourierId:
                        searchCriteria.CourierId = Convert.ToInt32(filter.Value.ToString() == "" ? 0 : filter.Value.ToString());
                        break;
                    case ViewShipmentsFilters.User:
                        searchCriteria.User = filter.Value.ToString();
                        break;
                    default:
                        break;
                }
            }

            try
            {
                var response = await _client.PostRequestAsync(uri, searchCriteria);
                _logger.LogInformation($"Method: {nameof(GetReceiveShipmentDataAsync)} - After processing get Receive Shipment Data web API");

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var receiveShipmentModel = JsonConvert.DeserializeObject<ServiceResponse<List<CreateReceiveShipmentsViewModel>>>(result);

                    searchCriteria.Results = receiveShipmentModel.Data;
                    searchCriteria.TotalResultCount = receiveShipmentModel.Data.Count;
                    HttpContext.Session.Set(SessionKeys.CreateShipmentsDataSearch, searchCriteria);
                    receiveShipmentsDataResults.Data = receiveShipmentModel.Data;
                    receiveShipmentsDataResults.Total = receiveShipmentModel.Data.Count;

                }
                else
                {
                    _logger.LogError($"Method: {nameof(GetReceiveShipmentDataAsync)} - No valid response from API");
                    return null;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetReceiveShipmentDataAsync)} - {ex.Message}");
                throw ex;
            }
            return Json(receiveShipmentsDataResults);
        }

        #endregion


        #region Create Courier  Pickup Form

        /// <summary>
        /// To bind courier pickup form model
        /// </summary>
        /// <returns>returns view with a viewmodel</returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        [HttpGet]
        public async Task<IActionResult> CourierPickup()
        {
            if (!User.IsShippingUser())
            {
                return AccessDenied();
            }
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(CourierPickup)}: Method invoked at {DateTime.Now}");
            var model = new CourierPickupViewModel();
            return View(model);
        }



        /// <summary>
        /// To get courier data from common Lookup
        /// </summary>
        /// <returns>returns courier dropdown data</returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        [HttpGet]
        public async Task<JsonResult> GetCourierPickupListAsync()
        {
            var couriers = await _objectCache.GetShipmentCommonLookUpsAsync(_cacheSettings, _client, _apiSettings, User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
            return Json(new { Couriers = couriers.OrderBy(x => x.Name) });
        }


        /// <summary>
        /// post method to  Create Courier Pickup Sequence 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        [HttpPost]
        public async Task<IActionResult> PrintCourierPickupAsync(CourierPickupViewModel model)
        {
            _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(CourierPickup)}: POST Method invoked at {DateTime.Now}");
            try
            {
               HttpContext.Session.Remove("AddCourierPickupResponse");
                var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
                _client.SetClientCode(clientCode);
                var uri = _apiSettings.Uri + ApiRouteConstants.CreateCourierPickupAsync();
                var apiResponse = await _client.PostRequestAsync(uri, model);
                _logger.LogInformation($"Method: {nameof(CourierPickup)} - After processing Create Courier Pickup web API");

                if (apiResponse.IsSuccessStatusCode)
                {
                    var result = apiResponse.Content.ReadAsStringAsync().Result;
                    if (result.Length > 0)
                    {
                        var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<List<CourierPickupViewModel>>>(result);

                        if (serviceResponse != null && serviceResponse.ResponseCode == System.Net.HttpStatusCode.Accepted)
                        {
                            HttpContext.Session.Set("AddCourierPickupResponse", serviceResponse.Data);
                            return Json("Success");
                        }
                        else
                        {
                            HttpContext.Session.Set("AddCourierPickupResponse", "FAIL|" + serviceResponse.ErrorMessage);
                            return Json("Fail");
                        }
                    }

                    HttpContext.Session.Set("AddCourierPickupResponse", "Success");
                    return Json("Success");
                }
                else
                {
                    HttpContext.Session.Set("AddCourierPickupResponse", "FAIL|Http Response was not successful");
                    _logger.LogError($"Method: {nameof(CourierPickup)} - No valid response from API");
                    return Json("Fail");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(CourierPickup)} - Unable to Create Courier Pickup Form Message: {ex.Message}");
                HttpContext.Session.Set("AddCourierPickupResponse", "FAIL|A critical error occurred performing the create courier pickup operation!\r\nPlease try again.");
                return Json("Fail");
            }
          
        }

        /// <summary>
        /// Creates an Courier Pickup Form  in PDF format
        /// </summary>
        /// <returns>FileStreamResult containing the pdf for the browser to open</returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        [HttpGet]
        public async Task<FileStreamResult> OpenCourierPickupPdfAsync()
        {
            try
            {
                #region PDF Generation Code

                _logger.LogInformation($"{nameof(ShipmentController)} - {nameof(OpenCourierPickupPdfAsync)}: POST Method invoked at {DateTime.Now}");
                var mainDocumentOutputStream = new MemoryStream();

                var fileStreamResult = await Task.Run(() =>
                {
                    //retrieve session data
                    var reportModel = HttpContext.Session.Get<List<CourierPickupViewModel>>("AddCourierPickupResponse");

                    //Determine number of pages to create
                    var totalPages = reportModel.Count;
                  
                    // The form represents the pdf template containing the fields to populate from the model
                    using (var pdfForm = new Aspose.Pdf.Facades.Form())
                    {
                        var asm = Assembly.GetExecutingAssembly();
                        using (var CourierPickupFormStream = asm.GetManifestResourceStream("VM.FleetServices.TnR.Shipping.Web.Properties.CourierPickupForm.pdf"))
                        {
                            pdfForm.BindPdf(CourierPickupFormStream);
                            //Contains the documents(pages) that will later be merged into one final pdf
                            var documentsList = new List<Document>();
                            // FILL THE HEADER AND FOOTER INFO IN THE FORM TEMPLATE ...............................
                            // Header and footer info will be printed on every page
                            // Create each page.
                            // Each page is treated as a pdf document and added to the documents collection
                            // The collection of documents are later merged into one final pdf document
                            for (var pageNumber = 1; pageNumber <= totalPages-1; pageNumber++)
                            {

                                var pdfFormStream = new MemoryStream();
                                pdfForm.Save(pdfFormStream);
                                var pdfDocument = new Document(pdfFormStream);
                                var pdfPage = pdfDocument.Pages[1];

                                int Resolution = 250;//300 dpi high resolution of the barcode image
                                int leftBarcodePosition = 398;//left position of the barcode image
                                int topBarcodePosition = 70;//top position of the barcode image

                                //convert the barcode image to a PNG stream . Barcode for top of a page
                                BarcodeGenerator generator = new BarcodeGenerator(EncodeTypes.Code39Standard, reportModel[pageNumber-1].TrackingNumber);
                                generator.Parameters.Resolution = Resolution;//set the barcode image resolution
                                Bitmap image = generator.GenerateBarCodeImage();
                                generator.Parameters.Barcode.CodeTextParameters.Location = CodeLocation.Above;
                                var paramsTopCode = generator.Parameters;
                                paramsTopCode.Barcode.CodeTextParameters.FontMode = FontMode.Manual;
                                paramsTopCode.Barcode.CodeTextParameters.Font.FamilyName = "Arial";
                                paramsTopCode.Barcode.CodeTextParameters.Font.Size.Point = 25;
                                paramsTopCode.CaptionAbove.NoWrap = true;
                                MemoryStream imageStream = new MemoryStream();
                                generator.Save(imageStream, BarCodeImageFormat.Png);
                                pdfFormStream.Position = 0;

                                //Rectangle where the image will be placed in the top/left corner
                                System.Drawing.Rectangle imageRect = new System.Drawing.Rectangle(leftBarcodePosition, topBarcodePosition, (image.Width * 30) / Resolution, (image.Height * 45) / Resolution);
                                Aspose.Pdf.Rectangle pdfRect = new Aspose.Pdf.Rectangle(imageRect.Left, pdfPage.Rect.Height - imageRect.Bottom, imageRect.Right, pdfPage.Rect.Height - imageRect.Top);
                                //add the image to the created PDF page
                                pdfPage.AddImage(imageStream, pdfRect);

                                int BottomResolution = 250;//300 dpi high resolution of the barcode image
                                int BottomleftBarcodePosition = 398;//left position of the barcode image
                                int BottomtopBarcodePosition = 520;//top position of the barcode image


                                //Barcode for bottom of a page
                                BarcodeGenerator generatorbottom = new BarcodeGenerator(EncodeTypes.Code39Standard, reportModel[pageNumber - 1].TrackingNumber);
                                generatorbottom.Parameters.Resolution = Resolution;//set the barcode image resolution
                                Bitmap bottomimage = generatorbottom.GenerateBarCodeImage();

                                var paramsbottomCode = generatorbottom.Parameters;
                                paramsbottomCode.Barcode.CodeTextParameters.FontMode = FontMode.Manual;
                                paramsbottomCode.Barcode.CodeTextParameters.Font.FamilyName = "Arial";
                                paramsbottomCode.Barcode.CodeTextParameters.Font.Size.Point = 25;
                                paramsbottomCode.Barcode.CodeTextParameters.Location = CodeLocation.Above;

                                TextFragment textFragment = new TextFragment(reportModel[pageNumber - 1].CourierName);
                                textFragment.Position = new Position(396, 215);
                                // Set text properties
                                textFragment.TextState.FontSize = 12;
                                textFragment.TextState.Font = FontRepository.FindFont("Arial");
                                // Create TextBuilder object
                                TextBuilder textBuilder = new TextBuilder(pdfPage);
                                // Append the text fragment to the PDF page
                                textBuilder.AppendText(textFragment);

                                MemoryStream imageStreamCodeText = new MemoryStream();
                                generatorbottom.Save(imageStreamCodeText, BarCodeImageFormat.Png);
                                pdfFormStream.Position = 0;

                                //Rectangle where the image will be placed in the botom 
                                System.Drawing.Rectangle imageRectBottom = new System.Drawing.Rectangle(BottomleftBarcodePosition, BottomtopBarcodePosition, (image.Width * 30) / BottomResolution, (image.Height * 45) / BottomResolution);
                                Aspose.Pdf.Rectangle pdfRectBottom = new Aspose.Pdf.Rectangle(imageRectBottom.Left, pdfPage.Rect.Height - imageRectBottom.Bottom, imageRectBottom.Right, pdfPage.Rect.Height - imageRectBottom.Top);
                                //add the image to the created PDF page
                                pdfPage.AddImage(imageStreamCodeText, pdfRectBottom);

                                pdfDocument.Flatten();
                                pdfDocument.Save();
                                documentsList.Add(pdfDocument);
                            }
                            // Construct the final document
                            var mainPdfDocument = new Document();
                            foreach (var document in documentsList)
                            {
                                mainPdfDocument.Pages.Add(document.Pages[1]);
                            }
                            mainPdfDocument.Save(mainDocumentOutputStream);
                        }
                    }
                    return new FileStreamResult(mainDocumentOutputStream, "application/pdf");
                });
                return fileStreamResult;
                #endregion
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(OpenCourierPickupPdfAsync)} - {ex.Message}");

                var pdfDocument = new Document();
                pdfDocument.Pages.Add();
                var pdfPage = pdfDocument.Pages[1];

                var txtFragment = new TextFragment("COURIER PICKUP FORM") { Position = new Position(10, 730) };
                txtFragment.TextState.FontSize = 10;
                txtFragment.TextState.Font = FontRepository.FindFont("Verdana");
                txtFragment.TextState.ForegroundColor = Aspose.Pdf.Color.FromRgb(System.Drawing.Color.Black);
                var textBuilder = new TextBuilder(pdfPage);

                textBuilder.AppendText(txtFragment);

                var newFragment1 = (TextFragment)txtFragment.Clone();
                newFragment1.Text = "An error occurred creating courier pickup. Please contact support!";
                newFragment1.Position = new Position(10, 690);

                textBuilder.AppendText(newFragment1);

                var newFragment2 = (TextFragment)txtFragment.Clone();
                newFragment2.Text = $"Error Message: {ex.Message}";
                newFragment2.Position = new Position(10, 675);

                textBuilder.AppendText(newFragment2);

                var documentStream = new MemoryStream();
                pdfDocument.Save(documentStream);

                return new FileStreamResult(documentStream, "application/pdf");
            }

        }
        /// Exports Shipment
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        [HttpPost]
        public async Task<IActionResult> ExportShipmentsAsync(CreateReceiveShipmentRequestModel model)
        {
            var jsonObject = new JObject();
            try
            {
                var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
                _client.SetClientCode(clientCode);
                var searchCriteria = HttpContext.Session.Get<CreateReceiveShipmentRequestModel>(SessionKeys.CreateShipmentsDataSearch);
                if (searchCriteria != null)
                {
                    searchCriteria.ClientCode = clientCode;
                    searchCriteria.UserName = User.GetUserId();
                    searchCriteria.TotalResultCount = model.TotalResultCount;

                    var uri = _apiSettings.Uri + ApiRouteConstants.SubmitShipmentExportRequest();
                    _logger.LogInformation($"Method: {nameof(ExportShipmentsAsync)} - Before processing Export All web API");
                    var response = await _client.PostRequestAsync(uri, searchCriteria);
                    _logger.LogInformation($"Method: {nameof(ExportShipmentsAsync)} - After processing Export All web API");
                    jsonObject.Add("Message", "Request to export shipment submitted");
                    jsonObject.Add("ExportStatus", true);
                }
                else
                {
                    jsonObject.Add("Message", "Failed to export shipment");
                    jsonObject.Add("ExportStatus", false);
                }
            }
            catch (Exception)
            {
                _logger.LogError($"Method: {nameof(ExportShipmentsAsync)} - Error in submitting service bus request");
                jsonObject.Add("Message", "Critical Error, failure in exporting report!");
                jsonObject.Add("ExportStatus", false);
            }
            return Json(jsonObject);
        }

        /// <summary>
        /// Downloads the CSV document from BLOB
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> ExportCSVReportDocumentAsync(string link)
        {          

            var blobDirectory = BlobContainerDirectories.ExportShipments.ToString();

            try
            {
                link = HttpUtility.UrlDecode(link);

                if (string.IsNullOrWhiteSpace(link))
                    throw new Exception("Invalid document or document does not exist");

                link = link.Split('/').Last();
                if (link.Contains("\\"))
                {
                    link = link.Split("\\").Last();  
                }

                var streamResult = await Task.Run(async () => 
                {
                    var stream = new MemoryStream();
                    var blobStream = await _blobStorage.DownloadBlobAsync(_storageOptions.BlobContainer, blobDirectory, link, stream, BlobType.AppendBlob);
                    blobStream.Seek(0, SeekOrigin.Begin);
                    return blobStream;
                });

                return new FileStreamResult((MemoryStream)streamResult, "text/csv") { FileDownloadName = link.IndexOf('\\') > 0 ? link.Split('\\').Last() : link };
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(ExportCSVReportDocumentAsync)} - {ex.Message}");
                return View("~/Views/Shared/Error.cshtml");
            }
        }

        #endregion
    }
}
