using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Mvc;

namespace VM.FleetServices.TnR.Shipping.Web.Controllers
{
    public class BaseController : Controller
    {
        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly ILogger _logger;


        #region Constructor
        public BaseController(IOptions<ApiSettings> apiSettings, IApiClientService apiClientService, ILogger logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            ViewBag.UserPreferenceExists = false;
        }
        #endregion

        #region Access Denied

        [Authorize]
        public IActionResult AccessDenied()
        {
            return View("~/Views/Account/AccessDenied.cshtml");
        }

        #endregion
    }
}
