using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Mvc;

namespace VM.FleetServices.TnR.Shipping.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly OpenIdSettings _openIdSettings;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IOptions<OpenIdSettings> openIdSettings, ILogger<AccountController> logger)
        {
            _openIdSettings = openIdSettings.Value;
            _logger = logger;
        }

        [Authorize]
        public IActionResult SignIn()
        {
            return RedirectToAction("Index", "Home");
        }

        public IActionResult SignOut()
        {
            // clear session data, check if Abandon is available in asp.net core
            HttpContext.Session.Clear();
          
            // Remove the authentication cookie and return the user to the client application.            
            return SignOut("Cookies", "oidc");
        }

        [Authorize]
        public IActionResult Information()
        {
            var uri = new Uri(new Uri(_openIdSettings.Authority), "Account/UserProfile");
            return Redirect(uri.ToString());
        }

        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}
