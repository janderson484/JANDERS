using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Core.Common.SignalR;
using VM.FleetServices.TnR.Shipping.Model.Enums;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Web.ActionFilters;
using VM.FleetServices.TnR.Shipping.Web.Helpers;
using VM.FleetServices.TnR.Shipping.Web.Models;
using VM.FleetServices.TnR.Shipping.Web.Security;
using static VM.FleetServices.TnR.Shipping.Web.Models.Constant;

namespace VM.FleetServices.TnR.Shipping.Web.Controllers
{
    [ValidateSessionActionFilter]
    public class HomeController : Controller
    {
        private readonly ApiSettings _apiSettings;
        private readonly IApiClientService _client;
        private readonly ILogger<HomeController> _logger;

        public HomeController(IOptions<ApiSettings> apiSettings, IApiClientService client, ILogger<HomeController> logger)
        {
            _apiSettings = apiSettings.Value;
            _client = client;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.UserPreferenceExists = false;
            return View();
        }

       
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public IActionResult GetConfigurationValue()
        {
            var result = new { configurationValue = _apiSettings.Uri, userId = HttpContext.User.Identity.Name };
            return Json(result);
        }

        [HttpGet]
        public IActionResult KeepAlive()
        {
            return Content("I am alive!");
        }

        [HttpGet]
        public IActionResult Kill()
        {
            return Content("Set cookie flag!");
        }
    }
}
