namespace VM.FleetServices.TnR.Shipping.Web.Models
{
    public class ReportEditorModel
    {
        public string ReportLog { get; set; }
    }
}
