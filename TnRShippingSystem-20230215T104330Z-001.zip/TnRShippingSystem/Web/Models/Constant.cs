using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Shipping.Web.Models
{
    public class Constant
    {
        public static class ApiRouteConstants
        {
            public static string GetTnrApplicationsLookups() => "api/MasterDataManagement/LoadTnrApplicationsLookups";
            public static string LoadTnrCommonLookups() => "api/MasterDataManagement/LoadCommonLookups";
            public static string GetNotifications() => "api/TPS/GetNotifications";
            public static string GetLogSummary() => "api/Log/GetLogs";
            public static string GetLogDetails() => "api/Log/GetLogDetails";
            public static string GetPersonalSettings() => "api/Configuration/GetPersonalSettings";
            public static string UpdateLogStatusByIdAsync() => "api/Log/UpdateLogStatusById";
            public static string GetReceiveShipmentDataAsync() => "api/Shipment/ReceiveShipments";
            public static string CreateReceiveShipmentAsync() => "api/Shipment/CreateReceiveShipment";
            public static string LoadShipmentCommonLookups() => "api/Shipment/LoadShipmentCommonLookUps";
            public static string GetClientContactsAsync() => "api/Renewals/GetClientContacts";
            public static string CreateCourierPickupAsync() => "api/Shipment/CreateCourierPickup";
            public static string SubmitShipmentExportRequest() => "api/Shipment/SubmitExportAllRequest";
            public static string SendNotification() => "api/Notification/SendNotification";
        }

        public static class SessionKeys
        {
            public const string LogDetailsSearch = "LogDetailsSearch";
            public const string LogSummarySearch = "LogSummarySearch";
            public const string ClientLocationUserPreferences = "ClientLocationUserPreferences";
            public const string SelectedClientCode = "SelectedClientCode";
            public const string SelectedRowsPerPage = "SelectedRowsPerPage";
            public const string UserPreferences = "UserPreferences";
            public const string CreateShipmentsDataSearch = "CreateShipmentsDataSearch";
            public const string ClientContacts = "ClientContacts";
        }

        public static class LogSearchFilters
        {
            public const string FileName = "FileName";
            public const string LogStatus = "LogStatus";
            public const string ProcessType = "ProcessType";
            public const string ProcessName = "ProcessName";
            public const string ProcessStartDate = "ProcessStartDate";
            public const string ProcessEndDate = "ProcessEndDate";
            public const string ShowErrors = "ShowErrors";
            public const string ShowWarnings = "ShowWarnings";
        }
        public static class TnrApplicationConstants
        {
            public const string ShippingManagement = "SM";
            public const string TransactionProcessing = "TP";
        }
    }
}
