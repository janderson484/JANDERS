namespace VM.FleetServices.TnR.Shipping.Web.Models
{
    public class AppSettings
    {
        public bool TnrApplicationsDisabled { get; set; }
        public bool EnableGridFiltering { get; set; }
        public CookieAuthentication CookieAuthentication { get; set; }
        
    }

    public class CookieAuthentication
    {
        /// <summary>
        /// Session expiration in minutes. Default is 30 minutes
        /// </summary>
        public int ExpireMinutes { get; set; } = 30;

        /// <summary>
        /// Display a message box before session expires. Default is 5 minutes.
        /// </summary>
        public int SessionExpireNotificationMinutes { get; set; } = 5;
    }
}
