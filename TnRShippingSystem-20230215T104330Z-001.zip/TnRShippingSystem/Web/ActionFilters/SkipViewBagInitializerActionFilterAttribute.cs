using System;

namespace VM.FleetServices.TnR.Shipping.Web.ActionFilters
{
    public class SkipViewBagInitializerActionFilterAttribute : Attribute
    {
    }
}
