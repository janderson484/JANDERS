using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace VM.FleetServices.TnR.Shipping.Web.ActionFilters
{
    public class ViewBagInitializerActionFilter : ActionFilterAttribute
    {
        public override void OnResultExecuting(ResultExecutingContext context)
        {
            var descriptor = (ControllerActionDescriptor)context.ActionDescriptor;
            var attributes = descriptor.MethodInfo.CustomAttributes;

            if (attributes.Any(a => a.AttributeType == typeof(SkipViewBagInitializerActionFilterAttribute)))
            {
                return;
            }

            ((Controller)context.Controller).ViewBag.UserPreferenceExists = true;
        }
    }
}
