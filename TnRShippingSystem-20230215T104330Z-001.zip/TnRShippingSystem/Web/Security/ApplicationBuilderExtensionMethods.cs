using Microsoft.AspNetCore.Builder;

namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    public static class ApplicationBuilderExtensionMethods
    {
        public static IApplicationBuilder UseRefreshAccessToken(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RefreshAccessTokenMiddleware>();
        }

    }
}
