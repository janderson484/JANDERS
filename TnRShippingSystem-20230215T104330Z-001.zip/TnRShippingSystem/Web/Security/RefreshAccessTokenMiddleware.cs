using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Shipping.Web.Models;

namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    public class RefreshAccessTokenMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<RefreshAccessTokenMiddleware> _logger;
        private readonly OpenIdSettings _openIdSettings;
        private readonly JwtSecurityTokenHandler _tokenHandler;
        private readonly AppSettings _appSettings;

        public RefreshAccessTokenMiddleware(RequestDelegate next, IHttpContextAccessor httpContextAccessor, ILogger<RefreshAccessTokenMiddleware> logger, IOptions<OpenIdSettings> openIdSettings, IOptions<AppSettings> appSettings)
        {
            _next = next;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
            _openIdSettings = openIdSettings.Value;
            _tokenHandler = new JwtSecurityTokenHandler();
            _appSettings = appSettings.Value;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            _logger.LogDebug("\n\n\n\nRefreshAccessTokenMiddleware.Invoke started..");

            string accessToken = null;
            List<AuthenticationToken> tokens = null;

            var info = await _httpContextAccessor.HttpContext.AuthenticateAsync("Cookies");
            if (info?.Properties == null)
            {
                _logger.LogDebug($"Unable to refresh token. Cookie is empty");
            }
            else
            {
                tokens = info.Properties.GetTokens()?.ToList();
                accessToken = tokens
                    ?.FirstOrDefault(x => x.Name.Equals(OpenIdConnectParameterNames.AccessToken))
                    ?.Value;
            }
            _logger.LogDebug($"Access Token is {accessToken ?? "null"}");
            if (accessToken != null)
            {
                // process access token
                var now = DateTimeOffset.UtcNow;

                var expirationDateStr = tokens.FirstOrDefault(x => x.Name.Equals("expires_at"))?.Value;
                var expirationDate = DateTimeOffset.Parse(expirationDateStr);

                _logger.LogDebug($"token expiration date time is {expirationDate} ");
                _logger.LogDebug($"Current date time is {now} ");

                var refreshTokenValue = _httpContextAccessor.HttpContext.Request.Cookies["RefreshAccessToken"];
                var isNewToken = refreshTokenValue == "true" ? true : false;

                var expiresIn = expirationDate - now;
                // if (expiresIn.TotalSeconds <= 0)

                //If User is active(performing some action or click on stayin) with in CookieAuthentication.ExpireMinutes or
                //if Token remaining life time is <= _appSettings.CookieAuthentication.ExpireMinutes+_appSettings.CookieAuthentication.ExpireMinutes
                if (isNewToken || expiresIn.TotalSeconds <= ((_appSettings.CookieAuthentication.ExpireMinutes + 1) * 60))
                {
                    // get refresh token.
                    var refreshToken = tokens.FirstOrDefault(x => x.Name.Equals(OpenIdConnectParameterNames.RefreshToken))?.Value;
                    _logger.LogDebug($"Refresh Token is {refreshToken ?? "null"}");
                    if (string.IsNullOrEmpty(refreshToken))
                    {
                        _logger.LogInformation($"Access Token has expired. But no refresh token available.");
                    }
                    else
                    {
                        //_logger.LogInformation($"Access Token has expired. Requesting new one.");
                        //var disco = await DiscoveryClient.GetAsync(_openIdSettings.Authority);

                        //// refresh token
                        //var tokenClient = new TokenClient(disco.TokenEndpoint, "fstnr.lbmgmt", "secret");
                        //var tokenResponse = await tokenClient.RequestRefreshTokenAsync(refreshToken);
                        //if (tokenResponse.IsError)
                        //{
                        //    _logger.LogWarning($"Unable to refresh token. {tokenResponse.ErrorDescription}");
                        //}
                        //else
                        //{
                        //    // Save updated tokens..
                        //    _logger.LogDebug($"Saving updated tokens..");
                        //    info.Properties.UpdateTokenValue(OpenIdConnectParameterNames.AccessToken, tokenResponse.AccessToken);
                        //    info.Properties.UpdateTokenValue(OpenIdConnectParameterNames.RefreshToken, tokenResponse.RefreshToken);
                        //    var expiresAt = (DateTimeOffset.UtcNow + TimeSpan.FromSeconds(tokenResponse.ExpiresIn));
                        //    info.Properties.UpdateTokenValue("expires_at", expiresAt.ToString("o", CultureInfo.InvariantCulture));
                        //    await _httpContextAccessor.HttpContext.SignInAsync("Cookies", info.Principal, info.Properties);
                        //}

                        using (var client = new HttpClient())
                        {
                            _logger.LogInformation($"Access Token has expired. Requesting new one.");

                            // Get UserManager claims from UserInfo Endpoint
                            var disco = await client.GetDiscoveryDocumentAsync(_openIdSettings.Authority);

                            //    _logger.LogInformation($"Access Token has expired. Requesting new one.");
                            //var disco = await DiscoveryClient.GetAsync(_openIdSettings.Authority);

                            var options = new TokenClientOptions()
                            {
                                Address = disco.TokenEndpoint,
                                ClientId = "fstnr.tps",
                                ClientSecret = "secret"
                            };

                            // refresh token
                            var tokenResponse = await client.RequestRefreshTokenAsync(new RefreshTokenRequest
                            {
                                Address = disco.TokenEndpoint,
                                RefreshToken = refreshToken,
                                ClientId = "fstnr.tps",
                                ClientSecret = "secret"
                            });

                            if (tokenResponse.IsError)
                            {
                                _logger.LogWarning($"Unable to refresh token. {tokenResponse.ErrorDescription}");
                            }
                            else
                            {
                                // Save updated tokens..
                                _logger.LogDebug($"Saving updated tokens..");
                                info.Properties.UpdateTokenValue(OpenIdConnectParameterNames.AccessToken, tokenResponse.AccessToken);
                                info.Properties.UpdateTokenValue(OpenIdConnectParameterNames.RefreshToken, tokenResponse.RefreshToken);
                                var expiresAt = (DateTimeOffset.UtcNow + TimeSpan.FromSeconds(tokenResponse.ExpiresIn));
                                info.Properties.UpdateTokenValue("expires_at", expiresAt.ToString("o", CultureInfo.InvariantCulture));
                                await _httpContextAccessor.HttpContext.SignInAsync("Cookies", info.Principal, info.Properties);
                            }
                        }
                    }
                }
                else
                {
                    _logger.LogDebug($"Token expires in {expiresIn.TotalSeconds} seconds ");
                }



            }
            _logger.LogDebug("RefreshAccessTokenMiddleware.Invoke Ended..\n\n\n\n");
            await _next.Invoke(httpContext);
        }
    }
}
