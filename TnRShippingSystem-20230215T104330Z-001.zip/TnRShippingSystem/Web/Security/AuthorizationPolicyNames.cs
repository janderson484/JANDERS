using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    public static class AuthorizationPolicyNames
    {
        /// <summary>
        /// Application Read Policy (internal, external, supervisor, admin)
        /// </summary>
        public const string ApplicationReadPolicy = nameof(ApplicationReadPolicy); // internal, external, supervisor, admin             

        /// <summary>
        /// Application Add Modify Policy (internal, supervisor, admin)
        /// </summary>
        public const string ApplicationAddModifyPolicy = nameof(ApplicationAddModifyPolicy); // internal, supervisor, admin

        /// <summary>
        /// Application Invoice Policy (supervisor, admin)
        /// </summary>
        public const string ApplicationInvoicePolicy = nameof(ApplicationInvoicePolicy); // supervisor, admin

        /// <summary>
        /// Application Access Policy (internal, admin)
        /// </summary>
        public const string ApplicationAccessPolicy = nameof(ApplicationAccessPolicy); // internal, admin

        /// <summary>
        /// Application Config Setting Policy (admin)
        /// </summary>
        public const string ApplicationConfigSettingPolicy = nameof(ApplicationConfigSettingPolicy); // admin
    }
}
