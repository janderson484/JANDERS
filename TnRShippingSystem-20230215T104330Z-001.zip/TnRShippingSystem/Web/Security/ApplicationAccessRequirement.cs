using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    public class ApplicationAccessRequirement : IAuthorizationRequirement
    {
        public string Role { get; set; }

        /// <summary>
        /// Sets user role from  ApplicationAccessRequirement registration
        /// </summary>
        /// <param name="role"></param>
        public ApplicationAccessRequirement(string role)
        {
            Role = role;
        }
    }
}
