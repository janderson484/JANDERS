using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Shipping.Web.Models;
using static VM.FleetServices.TnR.Shipping.Web.Models.Constant;

namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    public class ApplicationAccessHandler : AuthorizationHandler<ApplicationAccessRequirement>
    {
        /// <summary>
        /// Http Context Accessor
        /// </summary>
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// TNRProcessing
        /// </summary>
        private const string TNRPROCESSING = "TNRPROCESSING";

        /// <summary>
        /// Application Type
        /// </summary>
        private const string APPLICATIONTYPE = "RENEWALS";

        /// <summary>
        /// Constructor to set the http context
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public ApplicationAccessHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Handles the Aplication access Authorization 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <param name="applicationType"></param>
        /// <returns></returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ApplicationAccessRequirement requirement)
        {
            var clientCode = _httpContextAccessor.HttpContext.Session.GetString(SessionKeys.SelectedClientCode) ?? "HERTZ";

            if (string.IsNullOrEmpty(clientCode))
                return Task.CompletedTask;

            var roles = requirement.Role.Split(",");

            for (var i = 0; i < roles.Length; i++)
            {
                var role = roles[i].ToUpper();
                roles[i] = (role == "SUPERVISOR" || role == "ADMIN") ? $"{TNRPROCESSING}-{role}".ToUpper() : $"{APPLICATIONTYPE}-{roles[i]}".ToUpper();
            }

            // non-admin client
            if (roles.Select(role => context.User.GetClientRight(clientCode, role)).Any(right => right != null))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;


        }
    }
}
