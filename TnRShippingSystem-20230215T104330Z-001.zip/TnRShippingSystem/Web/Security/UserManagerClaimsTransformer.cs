using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Newtonsoft.Json.Linq;

namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    /// <summary>
    /// Transform Claims to remove all level protocol claims that are not needed 
    /// </summary>
    /// <returns></returns>
    public class UserManagerClaimsTransformer : IClaimsTransformation
    {
        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var id = principal.Identity;

            if (!id.IsAuthenticated)
            {
                return Task.FromResult(principal);
            }

            // get claims from current identity that we want to keep
            var subClaim = principal.FindFirst(UserManagerClaimTypes.Subject); // this is the UserId..
            var sourceClaim = principal.FindFirst(UserManagerClaimTypes.Source);
            var nameClaim = principal.FindFirst(ClaimTypes.Name);
            var emailClaim = principal.FindFirst(ClaimTypes.Email);
            var userManagerClaims = principal.Claims.Where(t => t.Type.StartsWith("/ats/usermanager/")).ToList();
            var bannerMessage = principal.FindFirst(UserManagerClaimTypes.UserMessage);

            // create a new identity...
            var nid = new ClaimsIdentity(id.AuthenticationType, "sub", "role");

            // add claims..
            if (subClaim != null)
                nid.AddClaim(subClaim);
            if (sourceClaim != null)
                nid.AddClaim(sourceClaim);
            if (nameClaim != null)
                nid.AddClaim(new Claim(ClaimTypes.Name, ToTitleCase(nameClaim.Value)));
            if (emailClaim != null)
                nid.AddClaim(emailClaim);
            if (userManagerClaims.Any())
                nid.AddClaims(userManagerClaims);
            if (bannerMessage != null)
                nid.AddClaim(bannerMessage);

            // return newly created identity
            var newPrincipal = new ClaimsPrincipal(nid);
            return Task.FromResult(newPrincipal);

        }

        public static Task OnUserInformationReceivedAsync(UserInformationReceivedContext c)
        {
            var nid = new ClaimsIdentity(c.Principal.Identity.AuthenticationType, "sub", "role");
            nid.AddClaims(c.Principal.Claims);

            var jsonObjectClaims = JObject.Parse(c.User.RootElement.GetRawText());

            foreach (var token in jsonObjectClaims)
            {
                //usermanager claims need to be split
                if (token.Key.StartsWith("/ats/usermanager") && token.Value.HasValues)
                {
                    //split token
                    foreach (var subToken in token.Value)
                    {
                        var newClaim = new Claim(token.Key, subToken.ToString());
                        nid.AddClaim(newClaim);
                    }
                }
                else
                    nid.AddClaim(new Claim(token.Key, token.Value.ToString()));
            }
            c.Principal = new ClaimsPrincipal(nid);
            return Task.FromResult(0);
        }

        IEnumerable<char> CharsToTitleCase(string s)
        {
            if (string.IsNullOrEmpty(s))
                s = "";

            bool newWord = true;
            foreach (char c in s)
            {
                if (newWord)
                { yield return Char.ToUpper(c); newWord = false; }
                else
                    yield return Char.ToLower(c);
                if (c == ' ')
                    newWord = true;
            }
        }

        string ToTitleCase(string input) => new string(CharsToTitleCase(input).ToArray());
    }

}
