namespace VM.FleetServices.TnR.Shipping.Web.Security
{
    public static class UserManagerClaimTypes
    {
        public static string UserMessage => "usermessage";

        public static string Subject => "sub";

        public static string FullName => "name";

        public static string Source => "src";

        public static string Email => "email";
    }
}
