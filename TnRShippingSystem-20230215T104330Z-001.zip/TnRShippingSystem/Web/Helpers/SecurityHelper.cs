using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.Shipping.Web.Helpers
{
    public static class SecurityHelper
    {
        private const string Supervisor = "TNR-SHIPPING-SUPERVISOR";
        private const string Internal = "TNR-SHIPPING-INTERNAL";
        private const string External = "TNR-SHIPPING-EXTERNAL";
        private const string Admin = "TNR-SHIPPING-ADMIN";
        private const string CLAIMSTYPE = "/ats/usermanager/rights";

        public static bool IsShippingUser(this ClaimsPrincipal user)
        {
            return (!IsShippingExternalUser(user) && IsShippingReadWriteUser(user));
        }

        public static bool IsShippingReadOnlyUser(this ClaimsPrincipal user)
        {
            return !IsShippingReadWriteUser(user);
        }

        public static bool IsShippingReadWriteUser(this ClaimsPrincipal user)
        {
            return IsShippingInternalUser(user) || IsTnrSupervisorUser(user) || IsTnrAdminUser(user);
        }

        public static bool IsTnrInvoiceUser(this ClaimsPrincipal user)
        {
            return IsTnrSupervisorUser(user) || IsTnrAdminUser(user);
        }

        public static bool IsTnrAdminUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == CLAIMSTYPE).Select(a => a.Value).Any(a => new[] { Admin }.Any(a.Contains));
        }

        public static bool IsShippingExternalUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == CLAIMSTYPE).Select(a => a.Value).Any(a => new[] { External }.Any(a.Contains));
        }

        public static bool IsTnrSupervisorUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == CLAIMSTYPE).Select(a => a.Value).Any(a => new[] { Supervisor }.Any(a.Contains));
        }

        public static bool IsShippingInternalUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == CLAIMSTYPE).Select(a => a.Value).Any(a => new[] { Internal }.Any(a.Contains));
        }

        public static bool IsShippingSingleClientUser(this ClaimsPrincipal user)
        {
            var rights = new List<string> { Admin, Supervisor, Internal, External };
            var userRights = user.Claims.Where(a => a.Type == CLAIMSTYPE).Select(a => a.Value);

            if (userRights.Any())
            {
                var ShippingClients = userRights.Where(a => rights.Any(a.Contains)).Select(a => a).ToList();

                if (ShippingClients.Any() && ShippingClients.Count == 1)
                {
                    return true;
                }
            }

            return false;
        }

        public static string GetSelectedClient(this ClaimsPrincipal user, string selectedClientCode)
        {
            // if (!string.IsNullOrEmpty(selectedClientCode))
            return selectedClientCode ?? "HERTZ";

            //var clients = user.GetClientList().Select(a => a.Code).ToList();

            //if (clients == null || clients.Count == 0)
            //    return null;

            //return clients[0];
        }
    }
}
