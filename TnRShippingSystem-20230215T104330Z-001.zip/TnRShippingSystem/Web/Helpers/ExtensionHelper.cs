using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Shipping.Model;
using VM.FleetServices.TnR.Shipping.Model.Common.DTO;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Web.Models;
using static VM.FleetServices.TnR.Shipping.Web.Models.Constant;

namespace VM.FleetServices.TnR.Shipping.Web.Helpers
{
    public static class ExtensionHelper
    {
        /// <summary>
        /// This method retrieves a list of Processing Locations
        /// </summary>
        /// <returns></returns>
        public static async Task<List<ProcessingLocation>> GetTnRProcessingLocationsListAsync(this IObjectCache cache, CacheSettings cacheSettings, IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            var locations = new List<ProcessingLocation>();

            try
            {
                locations = await cache.RetrieveFromCache<List<ProcessingLocation>>($"{CacheConstants.TnrCommonBaseKeyName}:{CacheConstants.ProcessingLocations}:{cacheSettings.Environment.ToLower()}");

                if (cacheSettings.RefreshCache || locations == null)
                {
                    var result = await LoadTnRCommonLookupsAsync(cache, cacheSettings, _client, _apiSettings, clientCode);

                    if (result)
                    {
                        locations = await cache.RetrieveFromCache<List<ProcessingLocation>>($"{CacheConstants.TnrCommonBaseKeyName}:{CacheConstants.ProcessingLocations}:{cacheSettings.Environment.ToLower()}");
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return locations;
        }

        /// <summary>
        /// This method retrieves a list of customers
        /// </summary>
        /// <returns></returns>
        public static async Task<List<Client>> GetTnRClientsAsync(this IObjectCache cache, CacheSettings cacheSettings, IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            var clients = new List<Client>();

            try
            {
                clients = await cache.RetrieveFromCache<List<Client>>($"{CacheConstants.TnrCommonBaseKeyName}:{CacheConstants.Clients}:{cacheSettings.Environment.ToLower()}");

                if (cacheSettings.RefreshCache || clients == null)
                {
                    var result = await LoadTnRCommonLookupsAsync(cache, cacheSettings, _client, _apiSettings, clientCode);

                    if (result)
                    {
                        clients = await cache.RetrieveFromCache<List<Client>>($"{CacheConstants.TnrCommonBaseKeyName}:{CacheConstants.Clients}:{cacheSettings.Environment.ToLower()}");
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return clients;
        }

        /// <summary>
        /// get shipment common lookups
        /// </summary>
        /// <returns></returns>
        public static async Task<List<Courier>> GetShipmentCommonLookUpsAsync(this IObjectCache cache, CacheSettings cacheSettings, IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            var couriers = new List<Courier>();

            try
            {
                couriers = await cache.RetrieveFromCache<List<Courier>>($"{CacheConstants.ShipmentCommonBaseKeyName}:{CacheConstants.Couriers}:{cacheSettings.Environment.ToLower()}");

                if (cacheSettings.RefreshCache || couriers == null)
                {
                    var result = await LoadShipmentCommonLookUpsAsync(_client, _apiSettings, clientCode);

                    if (result)
                    {
                        couriers = await cache.RetrieveFromCache<List<Courier>>($"{CacheConstants.ShipmentCommonBaseKeyName}:{CacheConstants.Couriers}:{cacheSettings.Environment.ToLower()}");
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return couriers;
        }

        private static async Task<bool> LoadTnRCommonLookupsAsync(IObjectCache cache, CacheSettings cacheSettings, IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            _client.SetClientCode(clientCode);

            var commonUri = _apiSettings.TnRUri + ApiRouteConstants.LoadTnrCommonLookups();
            var tnrResponse = await _client.GetResponseAsync(commonUri);

            if (tnrResponse != null && tnrResponse.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static async Task<bool> LoadShipmentCommonLookUpsAsync(IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            _client.SetClientCode(clientCode);

            var commonUri = _apiSettings.Uri + ApiRouteConstants.LoadShipmentCommonLookups();
            var response = await _client.GetResponseAsync(commonUri);

            if (response != null && response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

         #region Tnr Applications Lookups
        /// <summary>
        /// Get TnR Applications Lookups
        /// </summary>
        /// <returns></returns>
        public static async Task<List<TnrApplication>> GetTnrApplicationsLookUpsAsync(this IObjectCache cache, CacheSettings cacheSettings, IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            var tnrApplications = new List<TnrApplication>();

            try
            {
                tnrApplications = await cache.RetrieveFromCache<List<TnrApplication>>($"{CacheConstants.TnrBaseKeyName}:{CacheConstants.TnrApplications}:{cacheSettings.Environment.ToLower()}");

                if (cacheSettings.RefreshCache || tnrApplications == null)
                {
                    var result = await LoadTnrApplicationsLookUpsAsync(_client, _apiSettings, clientCode);

                    if (result)
                    {
                        tnrApplications = await cache.RetrieveFromCache<List<TnrApplication>>($"{CacheConstants.TnrBaseKeyName}:{CacheConstants.TnrApplications}:{cacheSettings.Environment.ToLower()}");
                    }
                }
            }
            catch (Exception )
            {
                return null;
            }

            return tnrApplications;
        }

        private static async Task<bool> LoadTnrApplicationsLookUpsAsync(IApiClientService _client, ApiSettings _apiSettings, string clientCode)
        {
            try
            {
                _client.SetClientCode(clientCode);

                var uri = _apiSettings.TnRUri + ApiRouteConstants.GetTnrApplicationsLookups();
                var response = await _client.GetResponseAsync(uri);

                if (response != null && response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    // Success response
                    return true;
                }
            }
            catch (Exception )
            {
                throw;
            }

            return false;
        }
        #endregion
    }
}
