using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Web.Helpers;
using static VM.FleetServices.TnR.Shipping.Web.Models.Constant;

namespace VM.FleetServices.TnR.Web.Components.TnApplications
{
    public class TnrApplicationsViewComponent : ViewComponent
    {
        private readonly IApiClientService _apiClient;
        private readonly ApiSettings _apiSettings;
        private readonly IObjectCache _cache;
        private readonly CacheSettings _cacheSettings;

        public TnrApplicationsViewComponent(IOptions<ApiSettings> apiSettings, IApiClientService apiClient, IObjectCache cache, IOptions<CacheSettings> cacheSettings)
        {
            _apiClient = apiClient;
            _apiSettings = apiSettings.Value;
            _cache = cache;
            _cacheSettings = cacheSettings.Value;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var clientCode = HttpContext.User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));

            var tnrApplications = await _cache.GetTnrApplicationsLookUpsAsync(_cacheSettings, _apiClient, _apiSettings, clientCode);

            var tnrApplicationsViewModel = new TnrApplicationsViewModel();
            if (tnrApplications == null || !tnrApplications.Any())
            {
                // Safe catch if collection is null or empty
                tnrApplicationsViewModel.TnrApplicationsList = new List<TnrApplication>()
                {
                    new TnrApplication() {
                            Active = true,
                            DisplayName="Error loading data. Please refresh the page.",
                        }
                };
            }
            else
            {
                //var mdmsApplicationData = tnrApplications.Where(x=>x.ApplicationCode == "MD") 
                tnrApplicationsViewModel.TnrApplicationsList = tnrApplications.Where(x => x.Active).ToList();
            }

            return View("Default", tnrApplicationsViewModel);
        }
    }
}
