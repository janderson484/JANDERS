using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities
{
    public partial class Courier
    {
        [Key]
        public int CourierId { get; set; }
        public string Name { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
