using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities
{
    public partial class ReceiveShipment
    {
        [Key]
        public int ReceiveShipmentId { get; set; }

        public DateTime ReceivedDate { get; set; }
        public string ProcessingLocationCode { get; set; }

        public int CourierId { get; set; }
        public string ClientCode { get; set; }
        public string TrackingNumber { get; set; }
        public int DocumentCount { get; set; }
        public string Comment { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime StartDate { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime EndDate { get; set; }

        public virtual Courier Courier { get; set; }
    }
}
