using System;
using System.ComponentModel.DataAnnotations;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities
{
    public partial class TnrApplication
    {
        [Key]
        public int ApplicationId { get; set; }
        public string ApplicationCode { get; set; }
        public string DisplayName { get; set; }
        public string UiPortalIcon { get; set; }
        public string UiDropDownIcon { get; set; }
        public int UiRowNumber { get; set; }
        public string Url { get; set; }
        public bool Active { get; set; }
        public int SortOrder { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
