using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities
{
    public partial class LogDetail
    {
        [Key]
        public int LogDetailsId { get; set; }
        public int LogId { get; set; }
        public string ErrorType { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorRecord { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Log Log { get; set; }
    }
}
