using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities
{
    public partial class Log
    {
        public Log()
        {
            LogDetails = new HashSet<LogDetail>();
        }

        public int LogId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string ProcessName { get; set; }
        public string ProcessType { get; set; }
        public string Filename { get; set; }
        public int TotalCount { get; set; }
        public int SuccessfulCount { get; set; }
        public int ErrorCount { get; set; }
        public int WarningCount { get; set; }
        public string Status { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ProcessStartDate { get; set; }
        public DateTime? ProcessEndDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public virtual ICollection<LogDetail> LogDetails { get; set; }
    }
}
