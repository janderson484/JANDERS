using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities
{
    public partial class PersonalSetting
    {
        public int PersonalSettingId { get; set; }
        public string UserId { get; set; }
        public int RowsPerPage { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public int DaysofHistory { get; set; }

    }
}
