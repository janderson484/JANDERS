using System.ComponentModel.DataAnnotations.Schema;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using VM.FleetServices.TnR.Shipping.Model.Common.DTO;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using DTO = VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel
{
    public partial class ShippingModel : DbModelBase, IShippingModel
    {
        public ShippingModel()
        {

        }

        public ShippingModel(DbContextOptions<ShippingModel> options) : base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("shipping");

            modelBuilder.Entity<CourierPickupDetail>().HasNoKey();
        }

        protected override void Configure()
        {
            AddEntityTypeConfiguration(new CourierEntityConfiguration());
            AddEntityTypeConfiguration(new ReceiveShipmentEntityConfiguration());
            AddEntityTypeConfiguration(new LogEntityConfiguration());
            AddEntityTypeConfiguration(new LogDetailEntityConfiguration());
            AddEntityTypeConfiguration(new NotificationEntityConfiguration());
            AddEntityTypeConfiguration(new PersonalSettingEntityConfiguration());

        }

        public virtual DbSet<Entities.Courier> Couriers { get; set; }
        public virtual DbSet<Entities.ReceiveShipment> ReceiveShipments { get; set; }
        public virtual DbSet<Entities.Log> Logs { get; set; }
        public virtual DbSet<Entities.LogDetail> LogDetails { get; set; }
        public virtual DbSet<Entities.Notification> Notifications { get; set; }
        public virtual DbSet<Entities.PersonalSetting> PersonalSettings { get; set; }
        public  DbSet<DTO.CourierPickupDetail> CourierPickupData { get; set; }

    }
}
