using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config
{
    public class NotificationEntityConfiguration : IEntityConfiguration<Notification>
    {
        public void EntityConfiguration(EntityConfiguration<Notification> config)
        {
            config.ConfigureTable("Notifications", t => t.NotificationId);

            config.ConfigureProperty(t => t.NotificationId, "NotificationId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LogId, "LogId");
            config.ConfigureProperty(t => t.NotificationType, "NotificationType", IsRequired.Yes, 25);
            config.ConfigureProperty(t => t.TotalCount, "TotalCount");
            config.ConfigureProperty(t => t.SuccessCount, "SuccessCount");
            config.ConfigureProperty(t => t.WarningCount, "WarningCount");
            config.ConfigureProperty(t => t.ErrorCount, "ErrorCount");
            config.ConfigureProperty(t => t.Message, "Message", IsRequired.No, 500);
            config.ConfigureProperty(t => t.IsRead, "IsRead");
            config.ConfigureProperty(t => t.UserName, "UserName", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
        }
    }
}
