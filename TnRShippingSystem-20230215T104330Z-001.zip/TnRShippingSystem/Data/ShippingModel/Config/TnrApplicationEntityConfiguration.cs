using System;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config
{
    class TnrApplicationEntityConfiguration : IEntityConfiguration<TnrApplication>
    {
        public void EntityConfiguration(EntityConfiguration<TnrApplication> config)
        {
            config.ConfigureTable("TnrApplications", t => t.ApplicationId);

            config.ConfigureProperty(t => t.ApplicationId, "ApplicationId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.ApplicationCode, "ApplicationCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.DisplayName, "DisplayName", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.UiPortalIcon, "UiPortalIcon", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.UiDropDownIcon, "UiDropDownIcon",IsRequired.Yes,100);
            config.ConfigureProperty(t => t.UiRowNumber, "UiRowNumber");
            config.ConfigureProperty(t => t.Url, "Url", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.SortOrder, "SortOrder");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.CreatedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "ModifiedDate");
        }
    }
}
