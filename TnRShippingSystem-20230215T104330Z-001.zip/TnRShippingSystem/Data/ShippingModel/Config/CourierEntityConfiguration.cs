using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config
{
    public class CourierEntityConfiguration : IEntityConfiguration<Courier>
    {
        public void EntityConfiguration(EntityConfiguration<Courier> config)
        {
            config.ConfigureTable("Couriers", t => t.CourierId);

            config.ConfigureProperty(t => t.CourierId, "CourierId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.Name, "Name", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
