using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config
{
    public class ReceiveShipmentEntityConfiguration : IEntityConfiguration<ReceiveShipment>
    {
        public void EntityConfiguration(EntityConfiguration<ReceiveShipment> config)
        {
            config.ConfigureTable("ReceiveShipments", t => t.ReceiveShipmentId);

            config.ConfigureProperty(t => t.ReceiveShipmentId, "ReceiveShipmentId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.ReceivedDate, "ReceivedDate");
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.CourierId, "CourierId");
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.TrackingNumber, "TrackingNumber", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.DocumentCount, "DocumentCount");
            config.ConfigureProperty(t => t.Comment, "Comment", IsRequired.No, 100);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
            config.ConfigureProperty(t => t.StartDate, "StartDate");
            config.ConfigureProperty(t => t.EndDate, "EndDate");
        }
    }
}

