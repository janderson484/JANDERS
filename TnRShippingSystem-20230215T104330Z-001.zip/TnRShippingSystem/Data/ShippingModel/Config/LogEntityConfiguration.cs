using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config
{
    public class LogEntityConfiguration : IEntityConfiguration<Log>
    {
        public void EntityConfiguration(EntityConfiguration<Log> config)
        {
            config.ConfigureTable("Logs", t => t.LogId);

            config.ConfigureProperty(t => t.LogId, "LogId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.ProcessName, "ProcessName", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.ProcessType, "ProcessType", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.Filename, "Filename", IsRequired.No, 1000);
            config.ConfigureProperty(t => t.TotalCount, "TotalCount");
            config.ConfigureProperty(t => t.SuccessfulCount, "SuccessfulCount");
            config.ConfigureProperty(t => t.ErrorCount, "ErrorCount");
            config.ConfigureProperty(t => t.WarningCount, "WarningCount");
            config.ConfigureProperty(t => t.Status, "Status", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ProcessStartDate, "ProcessStartDate");
            config.ConfigureProperty(t => t.ProcessEndDate, "ProcessEndDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");

            config.ConfigureNavigationProperty(t => t.LogDetails, l => l.Log, d => d.LogId);
        }
    }
}
