using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel.Config
{
    public class PersonalSettingsHistoryEntityConfiguration : IEntityConfiguration<PersonalSettingsHistory>
    {
        public void EntityConfiguration(EntityConfiguration<PersonalSettingsHistory> config)
        {
            config.ConfigureTable("PersonalSettingsHistories", t => t.PersonalSettingId);

            config.ConfigureProperty(t => t.PersonalSettingId, "PersonalSettingId");
            config.ConfigureProperty(t => t.UserId, "UserId", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.RowsPerPage, "RowsPerPage");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.StartDate, "StartDate");
            config.ConfigureProperty(t => t.EndDate, "EndDate");
        }
    }
}
