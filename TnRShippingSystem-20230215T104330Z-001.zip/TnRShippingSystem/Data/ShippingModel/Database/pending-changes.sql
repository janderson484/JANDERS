CREATE TABLE [shipping].[Couriers]
(
	[CourierId] INT IDENTITY(1,1) NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[Active] BIT NOT NULL,
	[CreatedUser] NVARCHAR(50) NOT NULL,
	[CreatedDate] DATETIME2(7) NOT NULL,
	[ModifiedUser] NVARCHAR(50) NOT NULL,
	[ModifiedDate] DATETIME2(7) NOT NULL,

	CONSTRAINT [PK_Couriers] PRIMARY KEY CLUSTERED (CourierId ASC)

) 
GO

CREATE TABLE [shipping].[ReceiveShipments]
(
	[ReceiveShipmentId] INT IDENTITY(1,1) NOT NULL,
	[ReceivedDate] DATETIME2 NOT NULL,
	[ProcessingLocationCode] NVARCHAR(20) NOT NULL,
	[CourierId] INT NOT NULL,		
	[ClientCode] NVARCHAR(15) NULL,
	[TrackingNumber] NVARCHAR(50) NOT NULL, 
    [DocumentCount] INT NOT NULL,
    [Comment] NVARCHAR(100) NULL,
	[Active] BIT NOT NULL,
	[CreatedUser] NVARCHAR(50) NOT NULL,
	[CreatedDate] DATETIME2(7) NOT NULL,
	[ModifiedUser] NVARCHAR(50) NOT NULL,
	[ModifiedDate] DATETIME2(7) NOT NULL,
	StartDate DATETIME2 GENERATED ALWAYS AS ROW START CONSTRAINT ReceiveShipments_StartDate DEFAULT SYSUTCDATETIME() NOT NULL,
    EndDate DATETIME2 GENERATED ALWAYS AS ROW END CONSTRAINT ReceiveShipments_EndDate DEFAULT CONVERT( DATETIME2, '9999-12-31 23:59:59' ) NOT NULL,
	PERIOD FOR SYSTEM_TIME(StartDate, EndDate),

	CONSTRAINT [PK_ReceiveShipments] PRIMARY KEY CLUSTERED (ReceiveShipmentId ASC),
	CONSTRAINT [FK_ReceiveShipments_Couriers] FOREIGN KEY(CourierId) REFERENCES [shipping].[Couriers] (CourierId),
    CONSTRAINT [UC_ReceiveShipments] UNIQUE NONCLUSTERED ([TrackingNumber] ASC,[CourierId] ASC)
) 
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [shipping].[ReceiveShipmentsHistory]))
GO

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Federal Express')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Federal Express',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'United Parcel Service')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('United Parcel Service',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Priority Mail')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Priority Mail',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END
IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Airborne Express')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Airborne Express',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Courier Pickup - Bradenton')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Courier Pickup - Bradenton',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Dropoff - Bradenton')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Dropoff - Bradenton',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END
IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Courier Pickup - Arizona')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Courier Pickup - Arizona',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END
IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Dropoff - Arizona')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Dropoff - Arizona',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Courier Pickup - Texas')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Courier Pickup - Texas',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

IF NOT EXISTS (Select [Name] FROM [shipping].[Couriers] WHERE [Name] = 'Dropoff - Texas')
BEGIN
	INSERT INTO [shipping].[Couriers]([Name],[Active],[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate])VALUES ('Dropoff - Texas',1,'SEEDDATA',GETDATE(),'SEEDDATA',GETDATE())
END

-- =====================================================================
--                       Table :  Logs - START
-- =====================================================================

CREATE TABLE [shipping].[Logs](
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[ClientCode] [nvarchar](15) NOT NULL,
	[ProcessingLocationCode] [nvarchar](10) NULL,
	[ProcessName] [nvarchar](100) NOT NULL,
	[ProcessType] [nvarchar](100) NOT NULL,
	[Filename] [nvarchar](1000) NULL,
	[TotalCount] [int] NOT NULL,
	[SuccessfulCount] [int] NOT NULL,
	[ErrorCount] [int] NULL,
	[WarningCount] [int] NULL,
	[Status] [nvarchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
	[ProcessStartDate] [datetime2](7) NOT NULL,
	[ProcessEndDate] [datetime2](7) NULL,
	[StartDate] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[EndDate] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
		
 CONSTRAINT [PK_LogId] PRIMARY KEY CLUSTERED 
(
	[LogId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([StartDate], [EndDate])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [shipping].[LogsHistory] )
)
GO

ALTER TABLE [shipping].[Logs] ADD  CONSTRAINT [Logs_StartDate]  DEFAULT (sysdatetime()) FOR [StartDate]
GO

ALTER TABLE [shipping].[Logs] ADD  CONSTRAINT [Logs_EndDate]  DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59')) FOR [EndDate]
GO



CREATE TABLE [shipping].[LogDetails](
	[LogDetailId] [int] IDENTITY(1,1) NOT NULL,
	[LogId] [int] NOT NULL,
	[ErrorType] [nvarchar](100) NOT NULL,
	[ErrorMessage] [nvarchar](max) NULL,
	[ErrorRecord] [nvarchar](1000) NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_LogDetailId] PRIMARY KEY CLUSTERED 
(
	[LogDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [shipping].[LogDetails]  WITH CHECK ADD  CONSTRAINT [FK_LogDetails_Logs] FOREIGN KEY([LogId])
REFERENCES [shipping].[Logs] ([LogId])
GO

ALTER TABLE [shipping].[LogDetails] CHECK CONSTRAINT [FK_LogDetails_Logs]
GO

-- =====================================================================
--                       Table :  Logs - END
-- =====================================================================
-- =====================================================================
--   START : User Story 258881: IDP_RPA: Create Courier Pickup Forms button- Shipping
-- =====================================================================
/****** Object:  StoredProcedure [shipping].[GetSequenceNumbers]    Script Date: 11/10/2022 6:01:41 AM ******/
/****** Object:  StoredProcedure [shipping].[GetSequenceNumbers]    Script Date: 11/10/2022 6:01:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


---------- Get GetSequenceNumbers Stored Procedure----------------
CREATE OR ALTER    Procedure [shipping].[GetSequenceNumbers] -- shipping.GetSequenceNumbers 1,'Shipping.CourierTrackingId' 
 @Sequencesize int,
 @Sequencename nvarchar(50)
As  
Begin  
  
Declare  @FirstSeqNum sql_variant    
, @LastSeqNum sql_variant    
, @CycleCount int    
, @SeqIncr sql_variant    
, @SeqMinVal sql_variant    
, @SeqMaxVal sql_variant

  
  
EXEC sys.sp_sequence_get_range    
@sequence_name = @Sequencename    
, @range_size=@Sequencesize  
, @range_first_value = @FirstSeqNum OUTPUT     
, @range_last_value = @LastSeqNum OUTPUT     
, @range_cycle_count = @CycleCount OUTPUT    
, @sequence_increment = @SeqIncr OUTPUT    
, @sequence_min_value = @SeqMinVal OUTPUT    
, @sequence_max_value = @SeqMaxVal OUTPUT ;    
  

SELECT  Convert(int,@FirstSeqNum)  AS FirstVal,Convert(int,@LastSeqNum) AS LastVal,Convert(int,@CycleCount) AS SeqIncrement 

 End
GO


CREATE SEQUENCE  Shipping.CourierTrackingId 
    START WITH 1000  
    INCREMENT BY 1  
    MINVALUE 1000  
    NO CYCLE 
;  


-- =====================================================================
--   END : User Story 258881: IDP_RPA: Create Courier Pickup Forms button- Shipping
-- =====================================================================
