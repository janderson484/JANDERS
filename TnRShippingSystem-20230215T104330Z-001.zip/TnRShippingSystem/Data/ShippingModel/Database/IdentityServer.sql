PRINT 'Identity server - new client changes start'
GO

DECLARE @env NVARCHAR(10);

SET @env = 'DEV';
--SET @env = 'QA';
--SET @env = 'STG';
--SET @env = 'PROD';


IF NOT EXISTS (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')
BEGIN
	INSERT INTO Clients VALUES (2592000, 3600, 0, 0, 1,	0,	1,	0,	0,	300, 'fstnr.shipping', 'TNR Shipping System', NULL, 1,	1,	300,	0,	NULL,	1,	NULL,1,	'oidc',	1,	1,	1,	0,	0,	1296000,	0)
END
select * from clients where clientId = 'fstnr.shipping'

IF NOT EXISTS (Select Id FROM ClientGrantTypes WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND GrantType = 'hybrid')
BEGIN
	INSERT INTO ClientGrantTypes VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'hybrid')
END

IF NOT EXISTS (Select Id FROM ClientGrantTypes WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND GrantType = 'client_credentials')
BEGIN
	INSERT INTO ClientGrantTypes VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'client_credentials')
END
select * from ClientGrantTypes where ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')

IF(@env = 'DEV')
BEGIN
    PRINT 'DEV'

    IF NOT EXISTS (Select Id FROM ClientPostLogoutRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND PostLogoutRedirectUri = 'https://localhost:37741/signout-callback-oidc')
    BEGIN
	    INSERT INTO ClientPostLogoutRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://localhost:37741/signout-callback-oidc')
    END
    select * from ClientPostLogoutRedirectUris where ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')

    IF NOT EXISTS (Select Id FROM ClientRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND RedirectUri = 'https://localhost:37741/signin-oidc')
    BEGIN
	    INSERT INTO ClientRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://localhost:37741/signin-oidc')
    END

    IF NOT EXISTS (Select Id FROM ClientPostLogoutRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND PostLogoutRedirectUri = 'https://fs-tnr-shipping-dev-web.azurewebsites.net/signout-callback-oidc')
    BEGIN
	    INSERT INTO ClientPostLogoutRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://fs-tnr-shipping-dev-web.azurewebsites.net/signout-callback-oidc')
    END
    select * from ClientPostLogoutRedirectUris where ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')

    IF NOT EXISTS (Select Id FROM ClientRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND RedirectUri = 'https://fs-tnr-shipping-dev-web.azurewebsites.net/signin-oidc')
    BEGIN
	    INSERT INTO ClientRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://fs-tnr-shipping-dev-web.azurewebsites.net/signin-oidc')
    END

END
ELSE IF(@env = 'QA')
BEGIN
    PRINT 'QA'

    IF NOT EXISTS (Select Id FROM ClientPostLogoutRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND PostLogoutRedirectUri = 'https://fs-tnr-shipping-qa-web.azurewebsites.net/signout-callback-oidc')
    BEGIN
	    INSERT INTO ClientPostLogoutRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://fs-tnr-shipping-qa-web.azurewebsites.net/signout-callback-oidc')
    END
    select * from ClientPostLogoutRedirectUris where ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')

    IF NOT EXISTS (Select Id FROM ClientRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND RedirectUri = 'https://fs-tnr-shipping-qa-web.azurewebsites.net/signin-oidc')
    BEGIN
	    INSERT INTO ClientRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://fs-tnr-shipping-qa-web.azurewebsites.net/signin-oidc')
    END

END
--ELSE IF(@env = 'STG')
--BEGIN
--    PRINT 'STG'

--    IF NOT EXISTS (Select Id FROM ClientPostLogoutRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND PostLogoutRedirectUri = 'https://fs-tnr-shipping-stg-web.azurewebsites.net/signout-callback-oidc')
--    BEGIN
--	    INSERT INTO ClientPostLogoutRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://fs-tnr-shipping-stg-web.azurewebsites.net/signout-callback-oidc')
--    END
--    select * from ClientPostLogoutRedirectUris where ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')

--    IF NOT EXISTS (Select Id FROM ClientRedirectUris WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND RedirectUri = 'https://fs-tnr-shipping-stg-web.azurewebsites.net/signin-oidc')
--    BEGIN
--	    INSERT INTO ClientRedirectUris VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'https://fs-tnr-shipping-stg-web.azurewebsites.net/signin-oidc')
--    END

--END
--ELSE IF(@env = 'PROD')
--BEGIN
--    PRINT 'PROD'
--END

select * from ClientRedirectUris where clientid = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping')

IF NOT EXISTS(Select Id FROM ClientScopes WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND Scope = 'fstnrshippingapi')
BEGIN
	INSERT INTO ClientScopes VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'fstnrshippingapi')
END

IF NOT EXISTS(Select Id FROM ClientScopes WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND Scope = 'umid')
BEGIN
	INSERT INTO ClientScopes VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'umid')
END

IF NOT EXISTS(Select Id FROM ClientScopes WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND Scope = 'profile')
BEGIN
	INSERT INTO ClientScopes VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'profile')
END

IF NOT EXISTS(Select Id FROM ClientScopes WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping') AND Scope = 'openid')
BEGIN
	INSERT INTO ClientScopes VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), 'openid')
END
select * from ClientScopes where ClientId = 1009

IF NOT EXISTS (Select Id FROM ClientSecrets WHERE ClientId = (Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'))
BEGIN
	INSERT INTO ClientSecrets VALUES ((Select Id FROM Clients WHERE ClientId = 'fstnr.shipping'), NULL, NULL, 'SharedSecret', 'K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols=')
END
select * from ClientSecrets where ClientId = 1009

IF NOT EXISTS (Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi')
BEGIN
	INSERT INTO ApiResources VALUES (NULL, 'TNR Shipping System API', 1,  'fstnrshippingapi')
END
select * from ApiResources where [Name] = 'fstnrshippingapi'

IF NOT EXISTS (Select * FROM ApiClaims WHERE ApiResourceId = (Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi') AND [Type] = 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress')
BEGIN
	INSERT INTO ApiClaims VALUES ((Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi'), 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress')
END

IF NOT EXISTS (Select * FROM ApiClaims WHERE ApiResourceId = (Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi') AND [Type] = '/ats/usermanager/systemcode')
BEGIN
	INSERT INTO ApiClaims VALUES ((Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi'), '/ats/usermanager/systemcode')
END
select * from ApiClaims where ApiResourceId = (select Id from ApiResources where [Name] = 'fstnrshippingapi')


IF NOT EXISTS (Select * FROM ApiScopes WHERE ApiResourceId = (Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi'))
BEGIN
	INSERT INTO ApiScopes VALUES ((Select Id FROM ApiResources WHERE [Name] = 'fstnrshippingapi'), NULL, 'TNR Shipping System API', 0, 'fstnrshippingapi', 0, 1)
END
select * from ApiScopes where ApiResourceId = (select Id from ApiResources where [Name] = 'fstnrshippingapi')

GO
PRINT 'Identity server - new client changes end'
GO
