using System;
using Ats.FleetServices.Core.Data;
using Microsoft.Extensions.DependencyInjection;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel
{
    public class ShippingModelFactory : IDbModelFactory<IShippingModel>
    {
        private readonly IServiceProvider _serviceProvider;

        public ShippingModelFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        public IShippingModel Create()
        {
            return _serviceProvider.GetService<IShippingModel>();
        }
    }
}
