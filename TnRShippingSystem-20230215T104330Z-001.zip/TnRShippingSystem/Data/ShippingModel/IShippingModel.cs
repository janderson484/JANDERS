using System.ComponentModel.DataAnnotations.Schema;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using DTO = VM.FleetServices.TnR.Shipping.Model.DTO;

namespace VM.FleetServices.TnR.Shipping.Data.ShippingModel
{
    public interface IShippingModel : IDbModelBase
    {     
        DbSet<Courier> Couriers { get; set; }       
        DbSet<ReceiveShipment> ReceiveShipments { get; set; }
        DbSet<Log> Logs { get; set; }
        DbSet<LogDetail> LogDetails { get; set; }
        DbSet<Notification> Notifications { get; set; }
        DbSet<PersonalSetting> PersonalSettings { get; set; }
        DbSet<DTO.CourierPickupDetail> CourierPickupData { get; set; }
    }
}
