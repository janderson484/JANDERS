using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.RetryPolicies;
using VM.FleetServices.TnR.Core.Common.AzureStorage;

namespace VM.FleetServices.TnR.Core.Common.AzureStorage
{
    /// <summary>
    /// Contains the concrete implementation for the blob storage functionality in Windows Azure.
    /// </summary>
    /// <remarks>
    /// TODO: Need to add exception handling.
    /// TODO: Need to handle logging.
    /// TODO: Need to decide on whether status enumerations for returning more detailed status is appropriate.
    /// TODO: Do we need to utilize a virtual directory within a container for further compartmentalization?
    /// TODO: Handle proper validation mechanism.
    /// </remarks>
    public class CloudBlobStorage : IBlobStorage
    {
        /// <summary>
        /// connection string
        /// </summary>
        private string ConnectionString { get; set; }
        /// <summary>
        /// container name
        /// </summary>
        private string ContainerName { get; set; }

        /// <summary>
        /// Instantiates a new instance of the <see cref="CloudBlobStorage"/> class.
        /// </summary>
        /// <param name="options">Options for object initialization.</param>
        public CloudBlobStorage(IOptions<StorageOptions> options)
        {
            ConnectionString = options.Value.StorageConnection;
            ContainerName = options.Value.BlobContainer;
        }

        /// <summary>
        /// Instantiates a new instance of the <see cref="CloudBlobStorage"/> class.
        /// </summary>
        /// <param name="connectionString">azure storage connection string</param>
        /// <param name="container">azure container name</param>
        public CloudBlobStorage(string connectionString, string container)
        {
            ConnectionString = connectionString;
            ContainerName = container;
        }

        /// <summary>
        /// Creates a container compartment for a set of blobs.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <exception cref="ArgumentException">Container name must be between 3 and 63 characters.</exception>
        /// <exception cref="ArgumentException">Container name contains invalid characters.  Name must begin with a letter or number and must contain only letters, numbers, or dashes.  Name must be in all lowercase.</exception>
        public async Task<bool> CreateContainerAsync(string containerName)
        {
            // Validate the container name.
            ValidateContainer(containerName);

            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // Setup a policy for no retries.  This can be evaluated later or even passed in
            // as an option from configuration.
            BlobRequestOptions requestOptions = new BlobRequestOptions()
            {
                RetryPolicy = new NoRetry()
            };

            // TODO: Do we need to do anything with OperationContext?
            return await container.CreateIfNotExistsAsync(requestOptions, null);
        }

        /// <summary>
        /// Deletes a container and all contained blobs from the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<bool> DeleteContainerAsync(string containerName)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // Deleting the container also deletes anything inside, such as blobs and snapshots.
            return await container.DeleteIfExistsAsync();
        }

        /// <summary>
        /// Deletes a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<bool> DeleteBlobAsync(string containerName, string blobName)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // Get the reference to the actual blob
            var blockBlob = container.GetBlockBlobReference(blobName);

            // Deleting the container will also delete the contained blob.
            // TODO: Review delete options to see if any need to be configured options.
            return await blockBlob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, null, null, null);
        }

        /// <summary>
        /// Deletes a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<bool> DeleteBlobAsync(string containerName, string directory, string blobName)
        {
            return await DeleteBlobAsync(containerName, GetFullPathName(directory, blobName));
        }

        /// <summary>
        /// Returns <c>true</c> is the specified container exists within the repository.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<bool> DoesContainerExistAsync(string containerName)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            return await container.ExistsAsync();
        }

        /// <summary>
        /// Returns <c>true</c> is the specified blob exists within the container.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<bool> DoesBlobExistAsync(string containerName, string blobName)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // Get the reference to the actual blob
            var blockBlob = container.GetBlockBlobReference(blobName);

            return await blockBlob.ExistsAsync();
        }

        /// <summary>
        /// Returns <c>true</c> is the specified blob exists within the container.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<bool> DoesBlobExistAsync(string containerName, string directory, string blobName)
        {
            return await DoesBlobExistAsync(containerName, GetFullPathName(directory, blobName));
        }

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="file">Stream to return file data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<Stream> DownloadBlobAsync(string containerName, string blobName, Stream file)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // Get the reference to the actual blob
            var blockBlob = container.GetBlockBlobReference(blobName);

            // Download a blob to your blob system
            // await blockBlob.DownloadToStreamAsync(fileStream, AccessCondition.GenerateIfNotExistsCondition(), null, null);
            await blockBlob.DownloadToStreamAsync(file);

            // TODO: Do we need to handle this differently utilizing a snapshot?
            // CloudBlockBlob blockBlobSnapshot = await blockBlob.CreateSnapshotAsync(null, null, null, null);

            return file;
        }

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="file">Stream to return file data.</param>
        /// <param name="blobType">Type of Blob.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<Stream> DownloadBlobAsync(string containerName, string blobName, Stream file, BlobType blobType)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);
            if (BlobType.AppendBlob == blobType)
            {
                // Get the reference to the actual blob
                var appendBlob = container.GetAppendBlobReference(blobName);
                // Download a blob to your blob system
                await appendBlob.DownloadToStreamAsync(file);
            }
            return file;
        }

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="blobName">Name of the blob</param>
        /// <param name="file">Stream to return file data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<Stream> DownloadBlobAsync(string blobName, Stream file)
        {
            return await DownloadBlobAsync(ContainerName, blobName, file);
        }

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// /// /// <param name="fileStream">Stream to return file data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<Stream> DownloadBlobAsync(string containerName, string directory, string blobName, Stream fileStream)
        {
            return await DownloadBlobAsync(containerName, GetFullPathName(directory, blobName), fileStream);
        }

        public async Task<Stream> DownloadBlobAsync(string containerName, string directory, string blobName, Stream fileStream, BlobType blobType)
        {
            return await DownloadBlobAsync(containerName, GetFullPathName(directory, blobName), fileStream, blobType);
        }

        /// <summary>
        /// Lists the files in the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        /// <remarks>
        /// TODO: Handle continuation token.
        /// TODO: Do we want to handle IListBlobItem rather than string?
        /// </remarks>
        public async Task<IEnumerable<string>> ListBlobsAsync(string containerName)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // As we are not handling continuation tokens
            // yet, start out with an empty one
            BlobContinuationToken continuationToken = null;

            var items = new List<IListBlobItem>();

            // List all the blobs in the container.
            do
            {
                var response = await container.ListBlobsSegmentedAsync(continuationToken);
                continuationToken = response.ContinuationToken;
                items.AddRange(response.Results);
            }
            while (continuationToken != null);

            // For now, just write the uri to the string
            var names = new List<string>();

            foreach (var blob in items)
            {
                // Blob type will be CloudBlockBlob, CloudPageBlob or CloudBlobDirectory
                // Use blob.GetType() and cast to appropriate type to gain access to properties specific to each type
                names.Add(blob.Uri.ToString());
            }

            return names;
        }

        /// <summary>
        /// Lists the files in the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<IEnumerable<string>> ListBlobsAsync(string containerName, string directory)
        {
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // As we are not handling continuation tokens
            // yet, start out with an empty one
            BlobContinuationToken continuationToken = null;

            var items = new List<IListBlobItem>();

            // List all the blobs in the container.
            do
            {
                // var response = await container.ListBlobsSegmentedAsync(directory, continuationToken);

                var dirRef = container.GetDirectoryReference(directory);
                var response = await dirRef.ListBlobsSegmentedAsync(continuationToken);

                continuationToken = response.ContinuationToken;
                items.AddRange(response.Results);
            }
            while (continuationToken != null);

            // For now, just write the uri to the string
            var names = new List<string>();

            foreach (var blob in items)
            {
                // Blob type will be CloudBlockBlob, CloudPageBlob or CloudBlobDirectory
                // Use blob.GetType() and cast to appropriate type to gain access to properties specific to each type
                names.Add(blob.Uri.ToString());
            }

            return names;
        }

        /// <summary>
        /// Uploads a blob to the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="source">Source blob data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        /// <remarks>
        /// TODO: Handle verifying the blob has been uploaded.
        /// </remarks>
        /// <exception cref="ArgumentException">Blob name must be between 1 and 1024 characters.</exception>
        public async Task<CloudBlockBlob> UploadBlobAsync(string containerName, string blobName, Stream source)
        {
            // Validate the blob name.
            ValidateBlob(blobName);

            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            // Get the reference to the actual blob
            var blockBlob = container.GetBlockBlobReference(blobName);

            // Set the blob's content type so that the browser knows to treat it as an image.
            //blockBlob.Properties.ContentType = "image/png";
            await blockBlob.UploadFromStreamAsync(source);

            return blockBlob;
        }

        /// <summary>
        /// Uploads a blob to the specified container within the storage management system.
        /// </summary>
        /// <param name="blobName">Name of the blob</param>
        /// <param name="source">Source blob data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<CloudBlockBlob> UploadBlobAsync(string blobName, Stream source)
        {
            return await UploadBlobAsync(ContainerName, blobName, source);
        }


        /// <summary>
        /// Uploads a blob to the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="source">Source blob data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        public async Task<CloudBlockBlob> UploadBlobAsync(string containerName, string directory, string blobName, Stream source)
        {
            CloudBlockBlob blob = await UploadBlobAsync(containerName, GetFullPathName(directory, blobName), source);

            return blob;
        }

        /// <summary>
        /// Append to blob to the specified container
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="source">Source blob data.</param>
        /// <returns>The reference of append blob.</returns>
        public async Task<CloudAppendBlob> AppendBlobAsync(string containerName, string directory, string blobName, byte[] source)
        {
            blobName = GetFullPathName(directory, blobName);
            // Validate the blob names.
            ValidateBlob(blobName);

            var container = GetCloudBlobContainerReference(ConnectionString, containerName);

            //// Get the reference to the actual blob
            var blob = container.GetAppendBlobReference(blobName);
            if (!await blob.ExistsAsync())
                await blob.CreateOrReplaceAsync();
            using (var stream = new MemoryStream(source))
            {
                await blob.AppendFromStreamAsync(stream);
            }

            return blob;
        }
        /// <summary>
        /// Copies a blob to new blob and deletes the old blob
        /// </summary>
        /// <param name="containerName"></param>
        /// <param name="blobName"></param>
        /// <param name="blobNameNew"></param>
        /// <returns></returns>
        public async Task<CloudBlockBlob> RenameBlobAsync(string containerName, string blobName, string blobNameNew)
        {
            // Validate the blob names.
            ValidateBlob(blobName);
            ValidateBlob(blobNameNew);
            var container = GetCloudBlobContainerReference(ConnectionString, containerName);
            //Get the reference to the new blob
            var blockBlobNew = container.GetBlockBlobReference(blobNameNew);

            if (!await blockBlobNew.ExistsAsync())
            {
                // Get the reference to the actual blob
                var blockBlob = container.GetBlockBlobReference(blobName);

                if (await blockBlob.ExistsAsync())
                {
                    // copy old blob to new blob
                    await blockBlobNew.StartCopyAsync(blockBlob);

                    //delete the old blob
                    await blockBlob.DeleteIfExistsAsync();
                }
            }


            return blockBlobNew;
        }
        /// <summary>
        /// Method to generate SASToken
        /// </summary>
        /// <returns>returns token</returns>
        public string GetBlobReadSasToken()
        {
            var container = GetCloudBlobContainerReference(ConnectionString, ContainerName);

            //Get the container's existing permissions.
            var sasConstraints = new SharedAccessBlobPolicy
            {
                SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddHours(24),
                Permissions = SharedAccessBlobPermissions.Read
            };

            //Generate the shared access signature on the container, setting the constraints directly on the signature.
            return container.GetSharedAccessSignature(sasConstraints);
        }

        /// <summary>
        /// Handles blob name validation.
        /// </summary>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <exception cref="ArgumentException">Blob name must be between 1 and 1024 characters.</exception>
        private void ValidateBlob(string blobName)
        {
            if (String.IsNullOrEmpty(blobName))
            {
                throw new ArgumentException("Blob name must be between 1 and 1024 characters.");
            }

            if (blobName.Length > 1024)
            {
                throw new ArgumentException("Container name must be between 1 and 1024 characters.");
            }
        }

        /// <summary>
        /// Handles container name validation.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <exception cref="ArgumentException">Container name must be between 3 and 63 characters.</exception>
        /// <exception cref="ArgumentException">Container name contains invalid characters.  Name must begin with a letter or number and must contain only letters, numbers, or dashes.  Name must be in all lowercase.</exception>
        private void ValidateContainer(string containerName)
        {
            if (String.IsNullOrEmpty(containerName))
            {
                throw new ArgumentException("Container name must be between 3 and 63 characters.");
            }

            if (containerName.Length < 3 || containerName.Length > 63)
            {
                throw new ArgumentException("Container name must be between 3 and 63 characters.");
            }

            Regex r = new Regex(@"^[a-z0-9][a-z0-9\-]*$");
            if (!r.IsMatch(containerName))
            {
                throw new ArgumentException("Container name contains invalid characters.  Name must begin with a letter or number and must contain only letters, numbers, or dashes.  Name must be in all lowercase.");
            }
        }

        /// <summary>
        /// Utilizes the connection string information in the config and creates a <see cref="CloudStorageAccount"/>.
        /// </summary>
        /// <returns><see cref="CloudStorageAccount"/> object</returns>
        private static CloudStorageAccount CreateStorageAccountFromConnectionString(string connectionString)
        {
            return CloudStorageAccount.Parse(connectionString);
        }

        /// <summary>
        /// Utilizes the connection string and container name information to get a reference to a <see cref="CloudBlobContainer"/>. 
        /// </summary>
        /// <param name="connectionString">Connection string.</param>
        /// <param name="containerName">Name of the container to reference.</param>
        /// <returns><see cref="CloudBlobContainer"/> object</returns>
        private static CloudBlobContainer GetCloudBlobContainerReference(string connectionString, string containerName)
        {
            containerName = containerName ?? Guid.NewGuid().ToString();

            // Retrieve storage account information from connection string
            var storageAccount = CreateStorageAccountFromConnectionString(connectionString);

            // Create a blob client for interacting with the blob service.
            var client = storageAccount.CreateCloudBlobClient();

            // Reference a container for organizing blobs within the storage account.
            return client.GetContainerReference(containerName);
        }

        /// <summary>
        /// Returns the full path for teh blob given a virtual directory.
        /// </summary>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>String of the full path of the blob.</returns>
        private string GetFullPathName(string directory, string blobName)
        {
            if (String.IsNullOrEmpty(directory))
            {
                return blobName;
            }

            if (directory.EndsWith(@"\") || directory.EndsWith(@"/"))
            {
                directory += blobName;
            }
            else
            {
                directory += @"\" + blobName;
            }

            return directory;
        }

        public Task AppendBlobAsync(string blobName, byte[] data)
        {
            throw new NotImplementedException();
        }
    }
}
