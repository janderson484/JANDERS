using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Core.Common.AzureStorage
{
    public class StorageOptions
    {
        /// <summary>
        /// Gets or sets the connection string for the blob storage.
        /// </summary>
        public string StorageConnection { get; set; }

        /// <summary>
        /// Gets or sets the container for the blob storage.
        /// </summary>
        public string BlobContainer { get; set; }

    }
}
