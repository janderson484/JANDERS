using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace VM.FleetServices.TnR.Core.Common.Mvc
{
    public class ApiClientService : IApiClientService
    {
        private string _clientCode;
        private readonly Dictionary<string, string> _customHeaders;
        private readonly OpenIdSettings _openIdSettings;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private int _timeOut = 0;

        public ApiClientService(IHttpContextAccessor httpContextAccessor, IOptions<OpenIdSettings> openIdSettings)
        {
            _httpContextAccessor = httpContextAccessor;
            _openIdSettings = openIdSettings.Value;
            _customHeaders = new Dictionary<string, string>();
        }

        public void SetClientCode(string value)
        {
            _clientCode = value;
        }

        /// <summary>
        /// Set Custom Header 
        ///   if the key already exist, updating the value otherwise adding the key and value. 
        /// </summary>
        /// <param name="key">Custom Key</param>
        /// <param name="value">Value</param>
        public void SetCustomHeader(string key, string value)
        {
            var lowerKey = key.ToLower();
            if (_customHeaders.ContainsKey(lowerKey))
            {
                // If exist key then update the value
                _customHeaders[lowerKey] = value;
            }
            else
            {
                // Adding key and value 
                _customHeaders.Add(lowerKey, value);
            }
        }

        /// <summary>
        /// Try Remove 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool TryRemoveCustomHeader(string key)
        {
            var lowerKey = key.ToLower();
            if (!_customHeaders.ContainsKey(lowerKey))
                return false;
            _customHeaders.Remove(lowerKey);
            return true;
        }

        /// <summary>
        /// Remove all custom headers
        /// </summary>
        public void ClearCustomHeaders()
        {
            _customHeaders.Clear();
        }

        public void SetTimeOut(int minutes)
        {
            _timeOut = minutes;
        }

        public async Task<HttpResponseMessage> GetResponseAsync(string uri)
        {
            using (var client = new HttpClient())
            {
                // set timeout
                if (_timeOut > 0)
                {
                    client.Timeout = TimeSpan.FromMinutes(_timeOut);
                }

                // set ClientCode
                var selectedClient = _httpContextAccessor.HttpContext.Session.GetString("selectedClientCode");
                if (!string.IsNullOrEmpty(_clientCode))
                {
                    client.DefaultRequestHeaders.Add("x-api-client-code", _clientCode);
                    _clientCode = null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(selectedClient))
                    {
                        client.DefaultRequestHeaders.Add("x-api-client-code", selectedClient);
                    }
                }

                if (_customHeaders.Count > 0)
                {
                    foreach (var customHeader in _customHeaders)
                    {
                        client.DefaultRequestHeaders.Add(customHeader.Key, customHeader.Value);
                    }
                }

                var accessToken = await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                }

                Console.WriteLine($"Executing request {uri}...");

                return await client.GetAsync(uri);
            }
        }

        public async Task<T> GetResponseAsync<T>(string href)
        {
            var response = await GetResponseAsync(href);
            var stringResponse = await response.Content.ReadAsStringAsync();
            var apiresponse = JsonConvert.DeserializeObject<T>(stringResponse);

            return apiresponse;
        }

        public async Task<HttpResponseMessage> GetResponseAsync<T>(string href, T model)
        {
            using (var client = new HttpClient())
            {
                // set timeout
                if (_timeOut > 0)
                {
                    client.Timeout = TimeSpan.FromMinutes(_timeOut);
                }

                // set ClientCode
                var selectedClient = _httpContextAccessor.HttpContext.Session.GetString("selectedClientCode");
                if (!string.IsNullOrEmpty(_clientCode))
                {
                    client.DefaultRequestHeaders.Add("x-api-client-code", _clientCode);
                    _clientCode = null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(selectedClient))
                    {
                        client.DefaultRequestHeaders.Add("x-api-client-code", selectedClient);
                    }
                }

                if (_customHeaders.Count > 0)
                {
                    foreach (var customHeader in _customHeaders)
                    {
                        client.DefaultRequestHeaders.Add(customHeader.Key, customHeader.Value);
                    }
                }

                var accessToken = await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                }

                Console.WriteLine($"Executing request {href}...");
                var jsonObject = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(href, content);

                // TODO: check for expired token.
                // var stringResponse = await response.Content.ReadAsStringAsync();
                // var apiresponse = JsonConvert.DeserializeObject<ApiResponse<T>>(stringResponse);

                return response;
            }
        }

        public async Task<T> GetResponseAsync<T>(string href, string token)
        {

            using (var client = new HttpClient())
            {
                // set timeout
                if (_timeOut > 0)
                {
                    client.Timeout = TimeSpan.FromMinutes(_timeOut);
                }

                // set ClientCode
                var selectedClient = _httpContextAccessor.HttpContext.Session.GetString("selectedClientCode");
                if (!string.IsNullOrEmpty(_clientCode))
                {
                    client.DefaultRequestHeaders.Add("x-api-client-code", _clientCode);
                    _clientCode = null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(selectedClient))
                    {
                        client.DefaultRequestHeaders.Add("x-api-client-code", selectedClient);
                    }
                }

                if (_customHeaders.Count > 0)
                {
                    foreach (var customHeader in _customHeaders)
                    {
                        client.DefaultRequestHeaders.Add(customHeader.Key, customHeader.Value);
                    }
                }

                var accessToken = !string.IsNullOrEmpty(token) ? token : await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                }

                Console.WriteLine($"Executing request {href}...");

                var response = await client.GetAsync(href);

                var stringResponse = await response.Content.ReadAsStringAsync();
                var apiresponse = JsonConvert.DeserializeObject<T>(stringResponse);

                return apiresponse;
            }
        }

        public async Task<HttpResponseMessage> PostRequestAsync<T>(string href, T model)
        {
            using (var client = new HttpClient())
            {
                // set timeout
                if (_timeOut > 0)
                {
                    client.Timeout = TimeSpan.FromMinutes(_timeOut);
                }

                // set ClientCode
                var selectedClient = _httpContextAccessor.HttpContext.Session.GetString("selectedClientCode");
                if (!string.IsNullOrEmpty(_clientCode))
                {
                    client.DefaultRequestHeaders.Add("x-api-client-code", _clientCode);
                    _clientCode = null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(selectedClient))
                    {
                        client.DefaultRequestHeaders.Add("x-api-client-code", selectedClient);
                    }
                }

                if (_customHeaders.Count > 0)
                {
                    foreach (var customHeader in _customHeaders)
                    {
                        client.DefaultRequestHeaders.Add(customHeader.Key, customHeader.Value);
                    }
                }

                var accessToken = await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                }

                Console.WriteLine($"Executing request {href}...");
                var jsonObject = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(href, content);

                // TODO: check for expired token.
                // var stringResponse = await response.Content.ReadAsStringAsync();
                // var apiresponse = JsonConvert.DeserializeObject<ApiResponse<T>>(stringResponse);

                return response;
            }
        }

        public async Task<HttpResponseMessage> PostRequestAsync<T>(string href, T model, string token)
        {
            using (var client = new HttpClient())
            {
                // set timeout
                if (_timeOut > 0)
                {
                    client.Timeout = TimeSpan.FromMinutes(_timeOut);
                }

                // set ClientCode
                var selectedClient = _httpContextAccessor.HttpContext.Session.GetString("selectedClientCode");
                if (!string.IsNullOrEmpty(_clientCode))
                {
                    client.DefaultRequestHeaders.Add("x-api-client-code", _clientCode);
                    _clientCode = null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(selectedClient))
                    {
                        client.DefaultRequestHeaders.Add("x-api-client-code", selectedClient);
                    }
                }

                if (_customHeaders.Count > 0)
                {
                    foreach (var customHeader in _customHeaders)
                    {
                        client.DefaultRequestHeaders.Add(customHeader.Key, customHeader.Value);
                    }
                }

                var accessToken = !string.IsNullOrEmpty(token) ? token : await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
                if (!string.IsNullOrEmpty(accessToken))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                }

                Console.WriteLine($"Executing request {href}...");
                var jsonObject = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(href, content);

                // TODO: check for expired token.
                // var stringResponse = await response.Content.ReadAsStringAsync();
                // var apiresponse = JsonConvert.DeserializeObject<ApiResponse<T>>(stringResponse);

                return response;
            }
        }
    }
}
