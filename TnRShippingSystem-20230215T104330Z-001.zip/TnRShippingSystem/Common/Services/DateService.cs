using System;

namespace VM.FleetServices.TnR.Core.Common.Services
{
    /// <summary>
    /// Class, which implements <see cref="IDateService"/> for date services to 
    /// consolidate all date operations to a single service
    /// for consistency and potential date maintenance issues.
    /// </summary>
    public class DateService : IDateService
    {
        /// <summary>
        /// Retrieves the current date as defined by the system.
        /// </summary>
        /// <returns>Current date.</returns>
        public DateTime GetDate()
        {
            return DateTime.Now.Date;
        }
    }
}
