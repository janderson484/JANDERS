using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using VM.FleetServices.TnR.Core.Common.Data.Repository;

namespace VM.FleetServices.TnR.Core.Common.Data.ExtensionMethods
{
    public static class UnitOfWorkServiceCollectionExtensions
    {
        public static IServiceCollection AddUnitOfWork<TContext>(this IServiceCollection services)
            where TContext : DbContext
        {
            services.AddScoped<IRepositoryFactory, UnitOfWorkService<TContext>>();
            services.AddScoped<IUnitOfWorkService, UnitOfWorkService<TContext>>();
            services.AddScoped<IUnitOfWorkService<TContext>, UnitOfWorkService<TContext>>();
            return services;
        }

        public static IServiceCollection AddUnitOfWork<TContext1, TContext2>(this IServiceCollection services)
            where TContext1 : DbContext
            where TContext2 : DbContext
        {
            services.AddScoped<IUnitOfWorkService<TContext1>, UnitOfWorkService<TContext1>>();
            services.AddScoped<IUnitOfWorkService<TContext2>, UnitOfWorkService<TContext2>>();
            return services;
        }

        public static IServiceCollection AddUnitOfWork<TContext1, TContext2, TContext3>(
            this IServiceCollection services)
            where TContext1 : DbContext
            where TContext2 : DbContext
            where TContext3 : DbContext
        {
            services.AddScoped<IUnitOfWorkService<TContext1>, UnitOfWorkService<TContext1>>();
            services.AddScoped<IUnitOfWorkService<TContext2>, UnitOfWorkService<TContext2>>();
            services.AddScoped<IUnitOfWorkService<TContext3>, UnitOfWorkService<TContext3>>();

            return services;
        }

        public static IServiceCollection AddUnitOfWork<TContext1, TContext2, TContext3, TContext4>(
            this IServiceCollection services)
            where TContext1 : DbContext
            where TContext2 : DbContext
            where TContext3 : DbContext
            where TContext4 : DbContext
        {
            services.AddScoped<IUnitOfWorkService<TContext1>, UnitOfWorkService<TContext1>>();
            services.AddScoped<IUnitOfWorkService<TContext2>, UnitOfWorkService<TContext2>>();
            services.AddScoped<IUnitOfWorkService<TContext3>, UnitOfWorkService<TContext3>>();
            services.AddScoped<IUnitOfWorkService<TContext4>, UnitOfWorkService<TContext4>>();

            return services;
        }
    }
}
