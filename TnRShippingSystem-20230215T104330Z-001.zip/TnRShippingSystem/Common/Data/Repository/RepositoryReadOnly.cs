using Microsoft.EntityFrameworkCore;

namespace VM.FleetServices.TnR.Core.Common.Data.Repository
{
    public class RepositoryReadOnly<T> : BaseRepository<T>, IRepositoryReadOnly<T> where T : class
    {
        public RepositoryReadOnly(DbContext context) : base(context)
        {
        }
    }
}
