namespace VM.FleetServices.TnR.Core.Common.Identity
{
    public static class UserManagerClaimTypes
    {
        public static string Namespace = "/ats/usermanager";

        public static string Client => Namespace + "/client";

        public static string Rights => Namespace + "/rights";

        public static string SystemCode => Namespace + "/systemcode";
    }
}
