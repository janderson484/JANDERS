using System;
using System.Collections.Generic;

namespace VM.FleetServices.TnR.Core.Common.Identity
{
    public class ClientRights
    {
        private string _clientCode;

        public string ClientCode
        {
            get { return _clientCode; }
            set
            {
                if (value != null)
                {
                    _clientCode = value.Trim().ToUpper();
                }
            }
        }

        public List<string> Rights { get; set; }

        public ClientRights()
        {
        }

        public ClientRights(string clientCode)
        {
            if (clientCode == null)
                throw new ArgumentNullException("clientCode");
            ClientCode = clientCode;
        }

    }
}
