using System;

namespace VM.FleetServices.TnR.Core.Common.Identity
{
    public class Right
    {
        private string _name;
        private string _clientCode;

        public string ClientCode
        {
            get { return _clientCode; }
            set
            {
                if (value != null)
                {
                    _clientCode = value.Trim().ToUpper();
                }
            }
        }

        public string Name
        {
            get { return _name; }
            set
            {
                if (value != null)
                {
                    _name = value.Trim().ToUpper();
                }
            }
        }

        public Right()
        {
        }

        public Right(string name)
        {
            if (name == null)
                throw new ArgumentNullException("name");
            Name = name;
        }

        public static bool operator ==(Right a, Right b)
        {
            // If both are null, or both are same instance, return true.
            if (ReferenceEquals(a, b))
            {
                return true;
            }

            // If one is null, but not both, return false.
            if (((object)a == null) || ((object)b == null))
            {
                return false;
            }

            // Return true if the Code field match:
            return a.Name == b.Name;
        }

        public static bool operator !=(Right a, Right b)
        {
            return !(a == b);
        }

        protected bool Equals(Right other)
        {
            // only Name matters..
            return string.Equals(Name, other.Name);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
                return false;
            if (ReferenceEquals(this, obj))
                return true;
            if (obj.GetType() != this.GetType())
                return false;
            return Equals((Right)obj);

        }

        public override int GetHashCode()
        {
            return Name != null ? Name.GetHashCode() : 0;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
