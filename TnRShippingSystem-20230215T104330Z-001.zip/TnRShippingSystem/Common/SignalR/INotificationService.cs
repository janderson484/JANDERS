using System.Collections.Generic;
using System.Threading.Tasks;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;

namespace VM.FleetServices.TnR.Core.Common.SignalR
{
    public interface INotificationService
    {
        Task SendNotificationsAsync(string notification);
        Task SendNotificationsAsync(string userName, string notification);
        Task SendNotificationsAsync(string userName, List<string> notifcations);
        Task SendNotifcationAsync(NotificationViewModel notification);
    }
}

