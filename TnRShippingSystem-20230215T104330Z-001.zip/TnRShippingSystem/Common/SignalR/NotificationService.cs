using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Core.Common.SignalR;

namespace VM.FleetServices.TnR.Core.Common.SignalR
{
    public class NotificationService : INotificationService
    {
        private readonly IHubContext<NotificationHub> _hubContext;

        public NotificationService(IHubContext<NotificationHub> hubContext)
        {
            _hubContext = hubContext;
        }

        /// <summary>
        /// Send Notification to all
        /// </summary>
        /// <param name="notification"></param>
        /// <returns></returns>
        public async Task SendNotificationsAsync(string notification)
        {
            await _hubContext.Clients.All.SendAsync("ReceiveNotifications", notification);
        }

        /// <summary>
        /// Send Notification to user
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="notification"></param>
        /// <returns></returns>
        public async Task SendNotificationsAsync(string userName, string notification)
        {
            await _hubContext.Clients.User(userName).SendAsync("ReceiveNotifications", notification);
        }

        /// <summary>
        /// Send Notification to user
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="notifcations"></param>
        /// <returns></returns>
        public async Task SendNotificationsAsync(string userName, List<string> notifcations)
        {
            await _hubContext.Clients.User(userName).SendAsync("ReceiveNotifications", notifcations);
        }

        public async Task SendNotifcationAsync(NotificationViewModel notification)
        {
            //var userConnection = NotificationHub.UserConnectionMappings.Where(a => a.Value.Equals(notification.UserName)).Select(a => a.Key).ToList();
            await _hubContext.Clients.All.SendAsync("ReceiveNotifications", Newtonsoft.Json.JsonConvert.SerializeObject(notification));
        }

        /// <summary>
        /// Send Notifcations to user
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="notifications"></param>
        /// <returns></returns>
        public async Task SendNotifcationsToUserAsync(List<NotificationViewModel> notifications)
        {
            var userConnections = new List<string>();
            foreach (var notification in notifications)
            {
                var connection = NotificationHub.UserConnectionMappings.Where(a => a.Value.Equals(notification.UserName)).Select(a => a.Key).ToList();

                if (connection != null && connection.Count > 0)
                    userConnections.AddRange(connection);
            }
            await _hubContext.Clients.Clients(userConnections).SendAsync("ReceiveNotifications", notifications);
        }
    }
}
