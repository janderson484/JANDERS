namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="SingleExtensions.cs" company="Verra Mobility.">
    //   Copyright 2010 Verra Mobility.
    // </copyright>
    // <summary>
    //   Common Single extensions for the solution.
    // </summary>
    // --------------------------------------------------------------------------------------------------------------------

    namespace Ats.FleetServices.TitleReg.Common.Extensions
    {
        /// <summary>
        /// This class will contain all common extensions handling extended functionality
        /// when utilizing Single types within code.
        /// </summary>
        public static class SingleExtensions
        {
            /// <summary>
            /// Returns true if the base value is between the range of values.
            /// </summary>
            /// <param name="baseValue">Base value to use as the comparison check</param>
            /// <param name="startValue">Absolute minimum value for the comparison</param>
            /// <param name="endValue">Absolute maximum value for the comparison</param>
            /// <returns>True value indicates the value is between the valid range.</returns>
            public static bool IsBetween(this float baseValue, float startValue, float endValue)
                => (baseValue.CompareTo(startValue) >= 0) && (baseValue.CompareTo(endValue) <= 0);

            /// <summary>
            /// Returns true if the base value is between the range of values.
            /// </summary>
            /// <param name="baseValue">Base value to use as the comparison check</param>
            /// <param name="startValue">Absolute minimum value for the comparison</param>
            /// <param name="endValue">Absolute maximum value for the comparison</param>
            /// <returns>True value indicates the value is between the valid range.</returns>
            public static bool IsBetween(this float? baseValue, float startValue, float endValue)
            {
                if (!baseValue.HasValue)
                {
                    baseValue = default(float);
                }

                return (baseValue.Value.CompareTo(startValue) >= 0) && (baseValue.Value.CompareTo(endValue) <= 0);
            }

            /// <summary>
            /// Returns a value or default value, if null, of a float.
            /// </summary>
            /// <param name="fromValue">Single containing value or null.</param>
            /// <returns>The float value or default.</returns>
            public static float ValueOrDefault(this float? fromValue)
                => fromValue ?? default(float);

            /// <summary>
            /// Returns a value or default value, if null, of a float.
            /// </summary>
            /// <param name="fromValue">Single containing value or null.</param>
            /// <param name="defaultValue">Default float value if the float value is null.</param>
            /// <returns>The float value or default.</returns>
            public static float ValueOrDefault(this float? fromValue, float defaultValue)
                => fromValue ?? defaultValue;
        }
    }

}
