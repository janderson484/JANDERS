using System.Collections.Generic;

namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="DictionaryExtensions.cs" company="Verra Mobility.">
    //   Copyright 2010 Verra Mobility.
    // </copyright>
    // <summary>
    //   Common Dictionary extensions for the solution.
    // </summary>
    // --------------------------------------------------------------------------------------------------------------------

    /// <summary>
    /// This class will contain all common extensions handling extended functionality
    /// when utilizing Dictionary types within code.
    /// </summary>
    public static class DictionaryExtensions
    {
        public static string GetValue(this Dictionary<string, string> data, string key)
        {
            var value = string.Empty;
            if (!data.TryGetValue(key, out value))
            {
                return string.Empty;
            }
            return value;
        }
    }
}
