using System;

namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    /// <summary>
    /// This class will contain all common extensions handling extended functionality
    /// when utilizing DateTime types within code.
    /// </summary>
    public static class DateTimeExtensions
    {
        /// <summary>
        /// The middle day of month
        /// </summary>
        public static readonly int MiddleDayOfMonth;

        static DateTimeExtensions()
        {
            MiddleDayOfMonth = 15;
        }

        /// <summary>
        /// Returns the age in years between two dates
        /// </summary>
        /// <param name="thisDate">Base date</param>
        /// <param name="dateAsOfToday">Future date</param>
        /// <returns>Age in years between two dates</returns>
        public static int GetAgeFromDateExt(this DateTime thisDate, DateTime dateAsOfToday)
        {
            int age = dateAsOfToday.Year - thisDate.Year;

            if (thisDate > dateAsOfToday.AddYears(-age))
            {
                age--;
            }

            return age;
        }

        /// <summary>
        /// Returns the age in years between two dates
        /// </summary>
        /// <param name="thisDate">Base date</param>
        /// <param name="dateAsOfToday">Future date</param>
        /// <returns>Age in years between two dates</returns>
        public static int GetAgeFromDate(this DateTime thisDate, DateTime dateAsOfToday)
        {
            int age = dateAsOfToday.Year - thisDate.Year;

            if (thisDate > dateAsOfToday.AddYears(-age))
            {
                age--;
            }

            return age;
        }

        /// <summary>
        /// Returns the first day of a month provided a DateTime.
        /// </summary>
        /// <param name="fromDate">A valid DateTime.</param>
        /// <returns>The first day of the month</returns>
        public static DateTime GetFirstDayOfMonth(this DateTime fromDate)
            => new DateTime(fromDate.Year, fromDate.Month, 1);

        /// <summary>
        /// Returns the first day of a year provided a DateTime.
        /// </summary>
        /// <param name="fromDate">A valid DateTime.</param>
        /// <returns>The first day of the year</returns>
        public static DateTime GetFirstDayOfYear(this DateTime fromDate)
            => new DateTime(fromDate.Year, 1, 1);

        /// <summary>
        /// Returns the last day of a month provided a DateTime.
        /// </summary>
        /// <param name="fromDate">A valid DateTime.</param>
        /// <returns>The last day of the month</returns>
        public static DateTime GetLastDayOfMonth(this DateTime fromDate)
        {
            var lastDayInMonth = DateTime.DaysInMonth(fromDate.Year, fromDate.Month);
            return new DateTime(fromDate.Year, fromDate.Month, lastDayInMonth);
        }

        /// <summary>
        /// Returns the last day of a year provided a DateTime.
        /// </summary>
        /// <param name="fromDate">A valid DateTime.</param>
        /// <returns>The last day of the year</returns>
        public static DateTime GetLastDayOfYear(this DateTime fromDate)
            => new DateTime(fromDate.Year, 12, 31);

        /// <summary>
        /// Returns the middle of the month provided a DateTime.
        /// </summary>
        /// <param name="fromDate">A valid DateTime value.</param>
        /// <returns>The generally recognized middle of the month.</returns>
        public static DateTime GetMiddleOfMonth(this DateTime fromDate)
            => new DateTime(fromDate.Year, fromDate.Month, MiddleDayOfMonth);

        /// <summary>
        /// Returns the date of the next Friday
        /// </summary>
        /// <param name="fromDate">Base date</param>
        /// <returns>Date of the next Friday</returns>
        public static DateTime GetNextFriday(this DateTime fromDate)
        {
            if (fromDate.DayOfWeek == DayOfWeek.Friday)
            {
                return fromDate;
            }
            else
            {
                int daysUntilFriday = ((int)DayOfWeek.Friday - (int)fromDate.DayOfWeek + 7) % 7;
                return fromDate.AddDays(daysUntilFriday);
            }
        }

        /// <summary>
        /// Returns the specific day of the month in the fromDate's year/month. Accounts for a specific day being greater than the month allows.
        /// For example, if fromDate = Feb 1, 2001 (where Feb has 28 days) and specificDay = 31 then this returns Feb 28, 2001 (the max day allowed)
        /// </summary>
        /// <param name="fromDate">From date.</param>
        /// <param name="specificDay">The specific day.</param>
        /// <returns>The specified day of the month given the date.</returns>
        public static DateTime GetSpecificDayOfMonth(this DateTime fromDate, int specificDay)
        {
            int maxDay = fromDate.GetLastDayOfMonth().Day;

            if (specificDay > maxDay)
            {
                specificDay = maxDay;
            }

            return new DateTime(fromDate.Year, fromDate.Month, specificDay);
        }

        /// <summary>
        /// Returns true if the effectiveDate is between the start and end dates.
        /// </summary>
        /// <param name="effectiveDate">Date to test for effective logic.</param>
        /// <param name="startDate">Date used as the absolute minimum to be effective.</param>
        /// <param name="endDate">Date used as the absolute maximum to be effective.</param>
        /// <returns>True value if the date is within the effective range.</returns>
        public static bool IsEffective(this DateTime effectiveDate, DateTime startDate, DateTime endDate)
        {
            return (startDate.Date.CompareTo(effectiveDate) <= 0) && (endDate.Date.AddHours(23).CompareTo(effectiveDate) >= 0);
        }

        /// <summary>
        /// Maximums the specified first.
        /// </summary>
        /// <param name="first">The first.</param>
        /// <param name="second">The second.</param>
        /// <returns>The Max DateTime</returns>
        public static DateTime Max(this DateTime first, DateTime second)
            => first > second ? first : second;

        /// <summary>
        /// Minimums the specified val1.
        /// </summary>
        /// <param name="val1">The val1.</param>
        /// <param name="val2">The val2.</param>
        /// <returns>The min of the two date times</returns>
        public static DateTime Min(this DateTime val1, DateTime val2)
            => val1 < val2 ? val1 : val2;

        /// <summary>
        /// Returns the date as a Julian Value
        /// </summary>
        /// <param name="fromDate">Base Date</param>
        /// <returns>Julian value of date</returns>
        public static long ToJulian(this DateTime fromDate)
        {
            int day = fromDate.Day;
            int month = fromDate.Month;
            int year = fromDate.Year;

            if (month < 3)
            {
                month = month + 12;
                year = year - 1;
            }

            return day + (((153 * month) - 457) / 5) + (365 * year) + (year / 4) - (year / 100) + (year / 400) + 1721119;
        }
    }
}
