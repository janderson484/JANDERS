using System;

namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="StringExtensions.cs" company="Verra Mobility.">
    //   Copyright 2010 Verra Mobility.
    // </copyright>
    // <summary>
    //   Common String extensions for the solution.
    // </summary>
    // --------------------------------------------------------------------------------------------------------------------

    /// <summary>
    /// This class will contain all common extensions handling extended functionality
    /// when utilizing String types within code.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Returns true if the string value is assigned null or empty
        /// </summary>
        /// <param name="stringValue">Value to determine null or empty</param>
        /// <returns>True if value is null or empty</returns>
        public static bool IsNullOrEmpty(this string stringValue)
            => string.IsNullOrEmpty(stringValue);

        /// <summary>
        /// Returns a decimal value for the string or default
        /// </summary>
        /// <param name="decimalValue">String value of the decimal</param>
        /// <returns>decimal value of the string or the default value</returns>
        public static decimal ToDecimalValue(this string decimalValue)
        {
            decimal testValue = default(decimal);

            // verify not null or empty
            if (!decimalValue.IsNullOrEmpty())
            {
                if (decimal.TryParse(decimalValue, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a decimal value for the string or default
        /// </summary>
        /// <param name="decimalValue">String value of the decimal</param>
        /// <param name="defaultValue">Default decimal value if string is null</param>
        /// <returns>decimal value of the string or the default value</returns>
        public static decimal ToDecimalValue(this string decimalValue, decimal defaultValue)
        {
            decimal testValue = defaultValue;

            // verify not null or empty
            if (!decimalValue.IsNullOrEmpty())
            {
                if (decimal.TryParse(decimalValue, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a float value for the string or default
        /// </summary>
        /// <param name="floatValue">String value of float</param>
        /// <returns>float value of the string or the default value</returns>
        public static float ToFloatValue(this string floatValue)
        {
            float testValue = default(float);

            // verify not null or empty
            if (!floatValue.IsNullOrEmpty())
            {
                if (float.TryParse(floatValue, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a float value for the string or default
        /// </summary>
        /// <param name="floatValue">String value of float</param>
        /// <param name="defaultValue">Default float value if string is null</param>
        /// <returns>float value of the string or the default value</returns>
        public static float ToFloatValue(this string floatValue, float defaultValue)
        {
            float testValue = defaultValue;

            // verify not null or empty
            if (!floatValue.IsNullOrEmpty())
            {
                if (float.TryParse(floatValue, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns an int value for the string or default
        /// </summary>
        /// <param name="int32Value">String value of int32</param>
        /// <returns>int32 value of the string or the default value</returns>
        public static int ToInt32Value(this string int32Value)
        {
            int testValue = default(int);

            // verify not null or empty
            if (!int32Value.IsNullOrEmpty())
            {
                if (int.TryParse(int32Value, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns an int value for the string or default
        /// </summary>
        /// <param name="int32Value">String value of int32</param>
        /// <param name="defaultValue">Default int32 value if string is null</param>
        /// <returns>int32 value of the string or the default value</returns>
        public static int ToInt32Value(this string int32Value, int defaultValue)
        {
            int testValue = defaultValue;

            // verify not null or empty
            if (!int32Value.IsNullOrEmpty())
            {
                if (int.TryParse(int32Value, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a long value for the string or default
        /// </summary>
        /// <param name="int64Value">String value of int64</param>
        /// <returns>int64 value of the string or the default value</returns>
        public static long ToInt64Value(this string int64Value)
        {
            long testValue = default(long);

            // verify not null or empty
            if (!int64Value.IsNullOrEmpty())
            {
                if (long.TryParse(int64Value, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a long value for the string or default
        /// </summary>
        /// <param name="int64Value">String value of int64</param>
        /// <param name="defaultValue">Default int64 value if string is null</param>
        /// <returns>int64 value of the string or the default value</returns>
        public static long ToInt64Value(this string int64Value, long defaultValue)
        {
            long testValue = defaultValue;

            // verify not null or empty
            if (!int64Value.IsNullOrEmpty())
            {
                if (long.TryParse(int64Value, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a DateTime value for the string or default
        /// </summary>
        /// <param name="dateTimeValue">String value of DateTime</param>
        /// <returns>DateTime value of the string or the default value</returns>
        public static DateTime ToDateTimeValue(this string dateTimeValue)
        {
            DateTime testValue = default(DateTime);

            // verify not null or empty
            if (!dateTimeValue.IsNullOrEmpty())
            {
                if (DateTime.TryParse(dateTimeValue, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }

        /// <summary>
        /// Returns a DateTime value for the string or default
        /// </summary>
        /// <param name="dateTimeValue">String value of DateTime</param>
        /// <param name="defaultValue">Default DateTime value if string is null</param>
        /// <returns>DateTime value of the string or the default value</returns>
        public static DateTime ToDateTimeValue(this string dateTimeValue, DateTime defaultValue)
        {
            DateTime testValue = defaultValue;

            // verify not null or empty
            if (!dateTimeValue.IsNullOrEmpty())
            {
                if (DateTime.TryParse(dateTimeValue, out testValue))
                {
                    return testValue;
                }
            }

            return testValue;
        }
    }

}
