namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    /// <summary>
    /// This class will contain all common extensions handling extended functionality
    /// when utilizing Single types within code.
    /// </summary>
    public static class IntegerExtensions
    {
        #region Int32

        /// <summary>
        /// Returns true if the base value is between the range of values.
        /// </summary>
        /// <param name="baseValue">Base value to use as the comparison check</param>
        /// <param name="startValue">Absolute minimum value for the comparison</param>
        /// <param name="endValue">Absolute maximum value for the comparison</param>
        /// <returns>True value indicates the value is between the valid range.</returns>
        public static bool IsBetween(this int baseValue, int startValue, int endValue)
            => (baseValue.CompareTo(startValue) >= 0) && (baseValue.CompareTo(endValue) <= 0);

        /// <summary>
        /// Returns true if the base value is between the range of values.
        /// </summary>
        /// <param name="baseValue">Base value to use as the comparison check</param>
        /// <param name="startValue">Absolute minimum value for the comparison</param>
        /// <param name="endValue">Absolute maximum value for the comparison</param>
        /// <returns>True value indicates the value is between the valid range.</returns>
        public static bool IsBetween(this int? baseValue, int startValue, int endValue)
        {
            if (!baseValue.HasValue)
            {
                baseValue = default(int);
            }

            return (baseValue.Value.CompareTo(startValue) >= 0) && (baseValue.Value.CompareTo(endValue) <= 0);
        }

        /// <summary>
        /// Returns a value or default value, if null, of an integer.
        /// </summary>
        /// <param name="fromValue">Integer containing value or null.</param>
        /// <returns>The integer value or default.</returns>
        public static int ValueOrDefault(this int? fromValue)
            => fromValue ?? default(int);

        /// <summary>
        /// Returns a value or default value, if null, of an integer.
        /// </summary>
        /// <param name="fromValue">Integer containing value or null.</param>
        /// <param name="defaultValue">Default integer value if the integer value is null.</param>
        /// <returns>The integer value or default.</returns>
        public static int ValueOrDefault(this int? fromValue, int defaultValue)
            => fromValue ?? defaultValue;

        #endregion

        #region Int64

        /// <summary>
        /// Returns true if the base value is between the range of values.
        /// </summary>
        /// <param name="baseValue">Base value to use as the comparison check</param>
        /// <param name="startValue">Absolute minimum value for the comparison</param>
        /// <param name="endValue">Absolute maximum value for the comparison</param>
        /// <returns>True value indicates the value is between the valid range.</returns>
        public static bool IsBetween(this long baseValue, long startValue, long endValue)
            => (baseValue.CompareTo(startValue) >= 0) && (baseValue.CompareTo(endValue) <= 0);

        /// <summary>
        /// Returns true if the base value is between the range of values.
        /// </summary>
        /// <param name="baseValue">Base value to use as the comparison check</param>
        /// <param name="startValue">Absolute minimum value for the comparison</param>
        /// <param name="endValue">Absolute maximum value for the comparison</param>
        /// <returns>True value indicates the value is between the valid range.</returns>
        public static bool IsBetween(this long? baseValue, long startValue, long endValue)
        {
            if (!baseValue.HasValue)
            {
                baseValue = default(long);
            }

            return (baseValue.Value.CompareTo(startValue) >= 0) && (baseValue.Value.CompareTo(endValue) <= 0);
        }

        /// <summary>
        /// Returns a value or default value, if null, of an integer.
        /// </summary>
        /// <param name="fromValue">Integer containing value or null.</param>
        /// <returns>The integer value or default.</returns>
        public static long ValueOrDefault(this long? fromValue)
            => fromValue ?? default(long);

        /// <summary>
        /// Returns a value or default value, if null, of an integer.
        /// </summary>
        /// <param name="fromValue">Integer containing value or null.</param>
        /// <param name="defaultValue">Default integer value if the integer value is null.</param>
        /// <returns>The integer value or default.</returns>
        public static long ValueOrDefault(this long? fromValue, long defaultValue)
            => fromValue ?? defaultValue;

        #endregion
    }
}
