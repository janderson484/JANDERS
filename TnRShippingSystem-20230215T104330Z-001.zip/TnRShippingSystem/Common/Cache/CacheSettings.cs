namespace VM.FleetServices.TnR.Core.Common.Cache
{
    public class CacheSettings
    {
        public int CacheExpirationInHours { get; set; }
        public string CacheInstanceName { get; set; }
        public string Environment { get; set; }
        public bool RefreshCache { get; set; }
    }
}
