using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;

namespace VM.FleetServices.TnR.Core.Common.Cache
{
    /// <summary>
    /// The <see cref="ObjectCache" /> class defines the object cache implementation for TnR.   
    /// </summary>             
    public class ObjectCache : IObjectCache
    {
        private IDistributedCache _cache;

        /// <summary>
        /// Instantiates a new instance of the <see cref="ObjectCache" /> class.
        /// </summary>
        /// <param name="cache">Configured distributed cache to use.</param>
        public ObjectCache(IDistributedCache cache)
        {
            _cache = cache;
        }

        /// <summary>
        /// Saves the specified object in the configured cache.
        /// </summary>
        /// <typeparam name="T">Type of object to store.</typeparam>
        /// <param name="key">Key for finding the object.</param>
        /// <param name="item">Object instance to cache.</param>
        /// <param name="expirationInHours">Hours the object will remain in the cache.</param>
        public async Task SaveToCache<T>(string key, T item, int expirationInHours)
        {
            var json = JsonConvert.SerializeObject(item);

            await _cache.SetStringAsync(key, json, new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(expirationInHours)
            });
        }

        /// <summary>
        /// Retrieves the specified object from the configured cache.
        /// </summary>
        /// <typeparam name="T">Type of object to store.</typeparam>
        /// <param name="key">Key for finding the object.</param>
        /// <returns>Object instance to retrieve from cache.</returns>
        public async Task<T> RetrieveFromCache<T>(string key)
        {
            var json = await _cache.GetStringAsync(key);

            if (json == null)
            {
                return default(T);
            }
            else
            {
                return JsonConvert.DeserializeObject<T>(json);
            }
        }       
    }
}
