using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Core.Common.Cache
{
    /// <summary>
    /// The <see cref="IObjectCache" /> interface defines the object cache contract for TnR.
    /// </summary>
    public interface IObjectCache
    {
        /// <summary>
        /// Saves the specified object in the configured cache.
        /// </summary>
        /// <typeparam name="T">Type of object to store.</typeparam>
        /// <param name="key">Key for finding the object.</param>
        /// <param name="item">Object instance to cache.</param>
        /// <param name="expirationInHours">Hours the object will remain in the cache.</param>
        Task SaveToCache<T>(string key, T item, int expirationInHours);

        /// <summary>
        /// Retrieves the specified object from the configured cache.
        /// </summary>
        /// <typeparam name="T">Type of object to store.</typeparam>
        /// <param name="key">Key for finding the object.</param>
        /// <returns>Object instance to retrieve from cache.</returns>
        Task<T> RetrieveFromCache<T>(string key);
    }
}
