namespace VM.FleetServices.TnR.Core.Common.Builders
{
    /// <summary>
    /// Helper framework for building domain entities for tests.
    /// </summary>
    /// <typeparam name="TBuilder">Builder type.</typeparam>
    /// <typeparam name="TObject">Object type.</typeparam>
    public class ObjectBuilder<TBuilder, TObject> where TBuilder : new() where TObject : new()
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectBuilder{TBuilder, TObject}"/> class.
        /// </summary>
        public ObjectBuilder()
        {
            HiddenObject = new TObject();
        }

        /// <summary>
        /// Gets the builder actions.
        /// </summary>
        protected TObject HiddenObject { get; set; }

        /// <summary>
        /// Create and initializes the builder.
        /// </summary>
        /// <returns>The builder object.</returns>
        public static TBuilder CreateBuilder()
        {
            return new TBuilder();
        }

        /// <summary>
        /// Builds and returns the object.
        /// </summary>
        /// <returns>Specified object.</returns>
        public TObject Build()
        {
            return HiddenObject;
        }
    }
}
