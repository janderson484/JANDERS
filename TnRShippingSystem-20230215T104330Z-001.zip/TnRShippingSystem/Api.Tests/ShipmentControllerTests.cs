using System;
using System.Threading.Tasks;
using Azure.Core;
using Microsoft.Extensions.Logging;
using Moq;
using VM.FleetServices.TnR.Shipping.Api.Controllers;
using VM.FleetServices.TnR.Shipping.Business;
using VM.FleetServices.TnR.Shipping.Business.ServiceBus;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using Xunit;

namespace VM.FleetServices.TnR.Shipping.Api.Tests
{
    public class ShipmentControllerTests
    {
        #region Setup

        private readonly ILogger<ShipmentController> _mockILogger;
        private readonly Mock<IShipmentService> _mockIShipmentService;
        private readonly ShipmentController _shipmentController;

        #endregion
        public ShipmentControllerTests()
        {
            _mockILogger = new Mock<ILogger<ShipmentController>>().Object;
            _mockIShipmentService = new Mock<IShipmentService>();
            _shipmentController = new ShipmentController(
                    shipmentService: _mockIShipmentService.Object,
                    logger: _mockILogger);
        }

        #region Create Receive Shipment

        [Fact]
        public async Task ShipmentsControllerTest_CreateReceiveShipmentAsync()
        {
            // Arrange

            var request = new ReceiveShipment
            {
                ReceivedDateTime = DateTime.Now,
                CourierId = 1,
                TrackingNumber = "123",
                Documents = 0,
                Active = true,
                UserName = "Test",
            };

            //Act
            var result = await _shipmentController.CreateReceiveShipmentAsync(request);
            Assert.NotNull(result);
        }

        [Fact]
        public async void Ensure_ShipmentService_Calls_ReceiveShipmentsAsync()
        {
            var model = new CreateReceiveShipmentRequestModel()
            {
                ClientCode = "Hertz",
                UserName = "FSAMSTESTUSER",
                PageNumber = 1,
                RowsPerPage = 25,
                StartDate = DateTime.Now.AddDays(-3),
                EndDate = DateTime.Now.AddDays(1)
            };

            _mockIShipmentService.Setup(expression: svc => svc.GetReceiveShipmentDataAsync(model));
            var results = await _shipmentController.ReceiveShipmentsAsync(model);
            _mockIShipmentService.Verify(expression: m => m.GetReceiveShipmentDataAsync(model), times: Times.Once);
        }



        [Fact]
        public async void Ensure_ShipmentService_Calls_CreateCourierPickupAsync()
        {
            var model = new CourierPickupViewModel()
            {
               CourierId=4,
               CourierName= "Airborne Express",
               NumberofForms=1
            };
            var result = await _shipmentController.CreateCourierPickupAsync(model);
            Assert.NotNull(result);

        }

        [Fact]
        public async void Ensure_ShipmentService_Calls_SubmitExportAllRequestAsync()
        {
            var model = new CreateReceiveShipmentRequestModel()
            {
                UserName = "FSAMSTESTUSER",
                PageNumber = 1,
                RowsPerPage = 25,
                StartDate = DateTime.Now.AddDays(-3),
                EndDate = DateTime.Now.AddDays(1)
            };

            _mockIShipmentService.Setup(expression: svc => svc.SubmitExportAllRequestAsync(model));
            var results = await _shipmentController.SubmitExportAllRequestAsync(model);
            Assert.NotNull(results);
        }


        #endregion
    }
}
