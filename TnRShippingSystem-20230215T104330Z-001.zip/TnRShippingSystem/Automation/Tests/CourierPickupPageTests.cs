using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class CourierPickupPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : RemoteWebDriver, new()
    {
        [TestCase(TestName = "VerifyUnderShipmentsMenuThereWillBeASubmenuTitledCreateCourierPickup")]
        [Category("273765")]

        public void VerifyUnderShipmentsMenuThereWillBeASubmenuTitledCreateCourierPickup()
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            var menuItem = "Shipment";
            var borderPage = new BorderPageObj(Driver);
            var sideMenuItems = borderPage.GetSideMenuItems();

            Assert.IsTrue(sideMenuItems.Contains(menuItem));

            var submenuItem = "Create Courier Pickup";
            var subMenuItems = borderPage.GetSubMenuItems(menuItem);
            Assert.IsTrue(subMenuItems.Contains(submenuItem));            
        }

        [TestCase(TestName = "VerifyOnClickingCreateCourierPickUpOpensCourierPickupFormsModal")]
        [Category("273766")]

        public void VerifyOnClickingCreateCourierPickUpOpensCourierPickupFormsModal()
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            Assert.IsTrue(courierPickupPage.IsCourierPickupFormDisplayed());
        }

        [TestCase(TestName = "VerifyTheFollowingFieldsAreDisplayed")]
        [Category("273767")]

        public void VerifyTheFollowingFieldsAreDisplayed()
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            Assert.IsTrue(courierPickupPage.IsCourierDropdownDispayed());
            Assert.IsTrue(courierPickupPage.IsNumberOfFormsToprintFieldDisplayed());
        }

        [TestCase(CourierPickup.AirborneExpress,"500",TestName = "VerifyIfMoreThan100IsEnteredInNoOFormsToBePrintedItShouldThrowAnError")]
        [Category("276154")]

        public void VerifyIfMoreThan100IsEnteredInNoOFormsToBePrintedItShouldThrowAnError(string courier, string numberOfFormsToPrint)
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            courierPickupPage.SelectCourierValueFromDropdown(courier);
            courierPickupPage.EnterNumberOfFieldsValue(numberOfFormsToPrint);
            courierPickupPage.ClickGenerateFormButton();

            Assert.IsTrue(courierPickupPage.IsNoOfFormsFieldValidationMessageDisplayed());
        }

        [TestCase(TestName = "VerifyErrorMessageIsDisplayedWhenMandatoryFieldsAreNotSpecified")]
        [Category("277367")]

        public void VerifyErrorMessageIsDisplayedWhenMandatoryFieldsAreNotSpecified()
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            courierPickupPage.ClickGenerateFormButton();

            Assert.IsTrue(courierPickupPage.IsCourierFieldValidationMessageDisplayed());
            Assert.IsTrue(courierPickupPage.IsNoOfFormsFieldValidationMessageDisplayed());
        }

        [TestCase(CourierPickup.AirborneExpress, "50", TestName = "VerifyWhenHitOnResetAllThePreviouslySelectedValuesShouldBeRemoved")]
        [Category("276184")]

        public void VerifyWhenHitOnResetAllThePreviouslySelectedValuesShouldBeRemoved(string courier, string numberOfFormsToPrint)
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            courierPickupPage.SelectCourierValueFromDropdown(courier);
            courierPickupPage.EnterNumberOfFieldsValue(numberOfFormsToPrint);
            courierPickupPage.ClickResetButton();

            Assert.AreEqual("", courierPickupPage.GetSelectedCourierDropdownValue());
            Assert.AreEqual("",courierPickupPage.GetNumberOfFiledText());

        }

        [TestCase(CourierPickup.CourierPickupArizona, "1", TestName = "VerifyClickGenerateFormToPrintPdfFormsHaveAUniqueBarcodeOnIt")]
        [Category("273769")]

        public void VerifyClickGenerateFormToPrintPdfFormsHaveAUniqueBarcodeOnIt(string courier, string numberOfFormsToPrint)
        {
            var courierPickupPage = new CourierPickupPageObj(Driver, ShippingBaseUrl);
            courierPickupPage.Navigate();

            courierPickupPage.SelectCourierValueFromDropdown(courier);
            courierPickupPage.EnterNumberOfFieldsValue(numberOfFormsToPrint);
            courierPickupPage.ClickGenerateFormButton();
            courierPickupPage.KendoGrid.WaitForKendoReadyState();

            Assert.IsTrue(courierPickupPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(CourierPickup.CourierPickupFormMessage, courierPickupPage.GetNotificationMessageText(NotificationType.Success));
        }
    }
}
