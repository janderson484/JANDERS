using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ViewShipmentsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : RemoteWebDriver, new()
    {
        [TestCase(TestName = "ViewShipmentsNavigationMenuItemAddedUnderShipments")]
        public void ViewShipmentsNavigationMenuItemAddedUnderShipments()
        {
            var menuItem = "Shipping";
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();

            var borderPage = new BorderPageObj(Driver);
            var sideMenuItems = borderPage.GetSideMenuItems();

            Assert.IsTrue(sideMenuItems.Contains(menuItem));

            var subMenuItems = borderPage.GetSubMenuItems(menuItem);
            Assert.IsTrue(subMenuItems.Contains("View Shipments"));

        }

        [TestCase(TestName = "VerifyNoDataAvailableMessageOnViewShipments")]
        public void VerifyNoDataAvailableMessageOnViewShipments()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();

            if (viewShipmentsPage.KendoGrid.GetNumberOfDataRows(1, true) != 0)
                Assert.Inconclusive("Data is present in the table. make sure table is empty");
            Assert.IsTrue(viewShipmentsPage.KendoGrid.IsNoRecordsAvailableDisplayed());
            Assert.AreEqual("No data available", viewShipmentsPage.KendoGrid.GetNoRecordsAvailableText());
        }

        [TestCase(TestName = "VerifyViewShipmentsTableHeaders")]
        public void VerifyViewShipmentsTableHeaders()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var actualHeaders = viewShipmentsPage.KendoGrid.GetAllHeadersTextList();

            Assert.AreEqual(ViewShipments.Headers.Count, actualHeaders.Count);
            Assert.AreEqual(ViewShipments.Headers, actualHeaders);
        }

        [TestCase(TestName = "VerifyDataShowUpOnViewShipments")]
        public void VerifyDataShowUpOnViewShipments()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var startDate = new DateTime(2022, 10, 1);
            var endDate = DateTime.Now;

            viewShipmentsPage.SetStartDate(startDate);
            viewShipmentsPage.SetEndDate(endDate);

            viewShipmentsPage.ClickSearchButton();

            Assert.IsTrue(viewShipmentsPage.KendoGrid.GetNumberOfDataRows(1, true) > 0, "Data missing in view shipments table.");
            Assert.IsTrue(viewShipmentsPage.ValidateViewShipmentsGridHeader());
            Assert.IsTrue(viewShipmentsPage.SortingViewShipmentsGrid());
        }

        [TestCase(TestName = "VerifyStartDateAndEndDateShowUpOnViewShipments")]
        public void VerifyStartDateAndEndDateShowUpOnViewShipments()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();

            Assert.AreEqual(0, viewShipmentsPage.KendoGrid.GetNumberOfDataRows(1, true));
            Assert.IsTrue(viewShipmentsPage.KendoGrid.IsNoRecordsAvailableDisplayed());
            Assert.AreEqual("No data available", viewShipmentsPage.KendoGrid.GetNoRecordsAvailableText());
        }

        [TestCase(TestName = "VerifyExportButtonIsDisplayedInViewShipmentsPage")]
        [Category("274205")]

        public void VerifyExportButtonIsDisplayedInViewShipmentsPage()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();

            Assert.IsTrue(viewShipmentsPage.IsExportButtonDisplayed());
        }

        [TestCase(TestName = "VerifyThatExportAllExportSelectedOptionsIsDisplayedWhenExportButtonIsClicked")]
        [Category("274207")]

        public void VerifyThatExportAllExportSelectedOptionsIsDisplayedWhenExportButtonIsClicked()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var startDate = new DateTime(2022, 10, 1);
            var endDate = DateTime.Now;

            viewShipmentsPage.SetStartDate(startDate);
            viewShipmentsPage.SetEndDate(endDate);
            viewShipmentsPage.ClickSearchButton();
            viewShipmentsPage.KendoGrid.WaitForKendoReadyState();

            viewShipmentsPage.ClickExportButton();
            var expectedList = new List<string> { "Export All", "Export Selected" };
            Assert.AreEqual(expectedList, viewShipmentsPage.ExportDropDownValuesList());
        }

        [TestCase(TestName = "VerifyExportAllButtonFunctionality")]
        [Category("274209")]

        public void VerifyExportAllButtonFunctionality()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var startDate = new DateTime(2022, 11, 1);
            var endDate = DateTime.Now;

            viewShipmentsPage.SetStartDate(startDate);
            viewShipmentsPage.SetEndDate(endDate);
            viewShipmentsPage.ClickSearchButton();
            viewShipmentsPage.KendoGrid.WaitForKendoReadyState();

            viewShipmentsPage.ClickExportAllButtonFlow();
            Assert.IsTrue(viewShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ViewShipments.ExportAll_Successmessage, viewShipmentsPage.GetNotificationMessageText(NotificationType.Success));

            var logPage = new LogPageObj(Driver, ShippingBaseUrl);
            logPage.Navigate();
            logPage.KendoGrid.WaitForKendoReadyState();
            logPage.ClickRefreshButton();

            Assert.AreEqual("Export Shipments", logPage.KendoGrid.GetDataCellText(1, 2));
            Assert.AreEqual("Export", logPage.KendoGrid.GetDataCellText(1, 3));
            Assert.AreEqual("Completed", logPage.KendoGrid.GetDataCellText(1, 9));

            viewShipmentsPage.KendoGrid.ClickCellHyperlinkByRowAndColumnNumber(1, 4);
            Assert.IsTrue(logPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ViewShipments.ExcelFileDownloadRequest, logPage.GetNotificationMessageText(NotificationType.Success));

            Assert.IsTrue(viewShipmentsPage.FileDownloadPathExists());
            viewShipmentsPage.DeleteIfExportedFileExists();

            viewShipmentsPage.ExportedFileExists();
            if (viewShipmentsPage.ExportedFileExists())
            {
                Assert.IsTrue(viewShipmentsPage.HeadingCellsMatchWithGrid());
            }
        }

        [TestCase(1, new int[] {1,2,3,4,5}, TestName = "VerifyExportSelectedButtonFunctionalityBySelectingRecords")]
        [Category("274211")]

        public void VerifyExportSelectedButtonFunctionalityBySelectingRecords(int pageNumber,int[] rowNumbers)
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var startDate = new DateTime(2022, 10, 1);
            var endDate = DateTime.Now;

            viewShipmentsPage.SetStartDate(startDate);
            viewShipmentsPage.SetEndDate(endDate);
            viewShipmentsPage.ClickSearchButton();
            viewShipmentsPage.KendoGrid.WaitForKendoReadyState();

           while(viewShipmentsPage.KendoGrid.GetCurrentPageNumberSelection() < pageNumber)
           {
                viewShipmentsPage.KendoGrid.ClickNextPageArrow();
           }
           foreach(var rowNumber in rowNumbers)
            {
                viewShipmentsPage.ClickDataCheckByRowNumber(rowNumber);
            }
            viewShipmentsPage.ClickExportSelectedButtonFlow();
            Assert.IsTrue(viewShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ViewShipments.ExportSelected_SuccessMessage, viewShipmentsPage.GetNotificationMessageText(NotificationType.Success));

            Assert.IsTrue(viewShipmentsPage.FileDownloadPathExists());
            viewShipmentsPage.DeleteIfExportedFileExists();

            viewShipmentsPage.ExportedFileExists();
            if (viewShipmentsPage.ExportedFileExists())
            {
                Assert.IsTrue(viewShipmentsPage.HeadingCellsMatchWithGrid());
            }

        }

        [TestCase(TestName = "VerifyExportSelectedButtonFunctionalityWithoutSelectingRecords")]
        [Category("274212")]

        public void VerifyExportSelectedButtonFunctionalityWithoutSelectingRecords()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var startDate = new DateTime(2022, 10, 1);
            var endDate = DateTime.Now;

            viewShipmentsPage.SetStartDate(startDate);
            viewShipmentsPage.SetEndDate(endDate);
            viewShipmentsPage.ClickSearchButton();
            viewShipmentsPage.KendoGrid.WaitForKendoReadyState();

            viewShipmentsPage.ClickExportSelectedButton();
            Assert.IsTrue(viewShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ViewShipments.ExportSelectedWithoutSelectingRecord_SuccessMessage,viewShipmentsPage.GetNotificationMessageText(NotificationType.Success));

            Assert.IsTrue(viewShipmentsPage.FileDownloadPathExists());
            viewShipmentsPage.DeleteIfExportedFileExists();

            viewShipmentsPage.ExportedFileExists();
            if(viewShipmentsPage.ExportedFileExists())
            {
                Assert.IsTrue(viewShipmentsPage.HeadingCellsMatchWithGrid());
            }
        }

        [TestCase(TestName ="VerifyErrorMessageisDisplayedWhenExportButtonIsClicked_NoDataAvailable")]
        [Category("276698")]

        public void VerifyErrorMessageisDisplayedWhenExportButtonIsClicked_NoDataAvailable()
        {
            var viewShipmentsPage = new ViewShipmentsPageObj(Driver, ShippingBaseUrl);
            viewShipmentsPage.Navigate();
            var startDate = new DateTime(2022, 10, 1);
            var endDate = DateTime.Now;

            viewShipmentsPage.SetStartDate(startDate);
            viewShipmentsPage.SetEndDate(endDate);
            viewShipmentsPage.ClickSearchButton();
            viewShipmentsPage.KendoGrid.WaitForKendoReadyState();
            viewShipmentsPage.ClickClearButton();
            viewShipmentsPage.KendoGrid.WaitForKendoReadyState();
            viewShipmentsPage.ClickExportAllButtonFlow();

            Assert.IsTrue(Driver.WaitForAndRemoveErrorPopup());
        }

    }
}
