using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    class UserRoleTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
    }
}
