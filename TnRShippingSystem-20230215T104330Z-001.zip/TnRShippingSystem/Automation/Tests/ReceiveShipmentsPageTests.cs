using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;


namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ReceiveShipmentsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : RemoteWebDriver, new()
    {
        [TestCase(TestName = "VerifyThatAllTheFieldsAreDisplayedInReceiveShipmentsPage")]
        [Category("272170")]

        public void VerifyThatAllTheFieldsAreDisplayedInReceiveShipmentsPage()
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            Assert.IsTrue(receiveShipmentsPage.IsDateReceivedFieldDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsProcessingLocationDropdownDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsTrackingNumberDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsCourierDropdownDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsCommentDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsCreateButtonDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsCancelButtonDisplayed());
        }

        [TestCase(TestName = "VerifyThatDateReceivedFieldIsDefaultedToCurrentDate")]
        [Category("272175")]

        public void VerifyThatDateReceivedFieldIsDefaultedToCurrentDate()
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var currentSystem = receiveShipmentsPage.GetCurrentSystemDate();
            var dateReceived = receiveShipmentsPage.GetDateReceivedField();
            Assert.AreEqual(currentSystem, dateReceived);
        }

        [TestCase(ReceiveShipments.SanAntonio, ReceiveShipments.AirborneExpress, TestName = "VerifyCreateButtonFunctionality")]
        [Category("272179")]

        public void VerifyCreateButtonFunctionality(string processingLocation, string courier)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "AUTO" + Extensions.GetRandomNumber(4, 50);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.SelectCourier(courier);
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
    
        [TestCase(ReceiveShipments.SunCity, ReceiveShipments.CourierPickupTexas, TestName = "VerifyCancelButtonFunctionality")]
        [Category("272198")]

        public void VerifyCancelButtonFunctionality(string processingLocation, string courier)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "AUTO";
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.SelectCourier(courier);
            receiveShipmentsPage.ClickClearButton();

            Assert.AreEqual("", receiveShipmentsPage.GetSelectedProcessingLocationTypeValue());
            Assert.AreEqual("", receiveShipmentsPage.GetSelectedCourierTypeValue());
        }

        [TestCase(TestName = "VerifyErrorMessageIsDisplayedWhenMandatoryFieldsIsNotSpecified")]
        [Category("272199")]

        public void VerifyErrorMessageIsDisplayedWhenMandatoryFieldsIsNotSpecified()
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsProcessingLocationFieldValidationMessageDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsTrackingNumberFieldValidationMessageDisplayed());
            Assert.IsTrue(receiveShipmentsPage.IsCourierFieldValidationMessageDisplayed());
        }
       
        [TestCase(ReceiveShipments.SunshineBradenton, TestName = "VerifyIfTrackingNumberIsSpecifiedWith1ZCourierTypeShouldBeDeterminedAsUPS")]
        [Category("272201")]

        public void VerifyIfTrackingNumberIsSpecifiedWith1ZCourierTypeShouldBeDeterminedAsUPS(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "1Z567YTUIBNH789V7" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("United Parcel Service", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }


        [Category("272203")]
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs22CourierTypeShouldBeDeterminedAsUSPS")]

        public void VerifyIfTrackingNumberLengthIs22CourierTypeShouldBeDeterminedAsUSPS(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "940010989864254066417" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Priority Mail", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [Category("272203")]
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs30CourierTypeShouldBeDeterminedAsUSPS")]

        public void VerifyIfTrackingNumberLengthIs30CourierTypeShouldBeDeterminedAsUSPS(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "940010989864254066417VGT67TGY" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Priority Mail", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
       
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs13CourierTypeShouldBeDeterminedAsUSPS")]
        [Category("272203")]

        public void VerifyIfTrackingNumberLengthIs13CourierTypeShouldBeDeterminedAsUSPS(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "940010989864" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Priority Mail", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
        
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs14CourierTypeShouldBeDeterminedAsFedex")]
        [Category("272205")]

        public void VerifyIfTrackingNumberLengthIs14CourierTypeShouldBeDeterminedAsFedex(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "567YTUIBNH789" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Federal Express", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
       
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs12CourierTypeShouldBeDeterminedAsFedex")]
        [Category("272205")]

        public void VerifyIfTrackingNumberLengthIs12CourierTypeShouldBeDeterminedAsFedex(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "A67YTUIBNH7" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Federal Express", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
     
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs26CourierTypeShouldBeDeterminedAsFedex")]
        [Category("272205")]

        public void VerifyIfTrackingNumberLengthIs26CourierTypeShouldBeDeterminedAsFedex( string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "567YTUIBNH78978UHBI890NJH" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Federal Express", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
      
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs32CourierTypeShouldBeDeterminedAsFedex")]
        [Category("272205")]

        public void VerifyIfTrackingNumberLengthIs32CourierTypeShouldBeDeterminedAsFedex(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "SAN56IBNH789AHIESM456AWSQA56AWE" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Federal Express", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
       
        [TestCase(ReceiveShipments.SanAntonio, TestName = "VerifyIfTrackingNumberLengthIs34CourierTypeShouldBeDeterminedAsFedex")]
        [Category("272205")]

        public void VerifyIfTrackingNumberLengthIs34CourierTypeShouldBeDeterminedAsFedex(string processingLocation)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "567YTUIBNH789AQWEIU6789IONM789543" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.EnterNotes();
            Assert.AreEqual("Federal Express", receiveShipmentsPage.GetSelectedCourierTypeValue());
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
      
        [TestCase(ReceiveShipments.SanAntonio, ReceiveShipments.CourierPickupBradenton, TestName = "VerifyIfTrackingNumberLengthIs10CourierShouldBeManuallySelected")]
        [Category("272287")]

        public void VerifyIfTrackingNumberLengthIs10CourierShouldBeManuallySelected(string processingLocation, string courier)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "A89TYB567" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.SelectCourier(courier);
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
      
        [TestCase(TestName = "VerifyThatCommentsTextareaShouldAllowMaximumOf100Characters")]
        [Category("272435")]

        public void VerifyThatCommentsTextareaShouldAllowMaximumOf100Characters()
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            Assert.AreEqual("100", receiveShipmentsPage.GetMaxLength());
        }

        [TestCase(ReceiveShipments.SunCity, ReceiveShipments.CourierPickupTexas, TestName = "VerifyThatErrorMessageIsDisplayedWhenDuplicateTrackingNumberIsSpecified")]
        [Category("272718")]

        public void VerifyThatErrorMessageIsDisplayedWhenDuplicateTrackingNumberIsSpecified(string processingLocation, string courier)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate(); 

            var trackingNumber = "AUTOMATION" + Extensions.GetRandomString(1);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.SelectCourier(courier);
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));

            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.SelectCourier(courier);
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(ReceiveShipments.DuplicateTrackingNumber_Error, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyThatDateReceivedShouldNotExceedMoreThanOneDayFromTheCurrentDate")]
        [Category("272719")]

        public void VerifyThatDateReceivedShouldNotExceedMoreThanOneDayFromTheCurrentDate()
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            receiveShipmentsPage.EnterDateReceived(2);
            var dateReceived = receiveShipmentsPage.GetDateReceivedField();
            Assert.AreEqual(dateReceived, DateTime.Now.AddDays(1).ToString("MM/dd/yyyy"));
        }

        [TestCase(ReceiveShipments.SunCity, ReceiveShipments.CourierPickupTexas, TestName = "VerifyTrackingNumberDisplaysErrorMessageIfTrackingNumberIsSpecifiedWithSpecialCharacters")]
        [Category("273158")]

        public void VerifyTrackingNumberDisplaysErrorMessageIfTrackingNumberIsSpecifiedWithSpecialCharacters(string processingLocation, string courier)
        {
            var receiveShipmentsPage = new ReceiveShipmentsPageObj(Driver, ShippingBaseUrl);
            receiveShipmentsPage.Navigate();

            var trackingNumber = "AUTO&^%#" + Extensions.GetRandomString(3);
            receiveShipmentsPage.SelectProcessingLocation(processingLocation);
            receiveShipmentsPage.EnterTrackingNumber(trackingNumber);
            receiveShipmentsPage.SelectCourier(courier);
            var trackingNumberInForm = receiveShipmentsPage.GetTrackingNumber();
            Assert.AreNotEqual(trackingNumber, trackingNumberInForm);
            receiveShipmentsPage.ClickCreateButton();

            Assert.IsTrue(receiveShipmentsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(ReceiveShipments.AddReceiveShipments_Success, receiveShipmentsPage.GetNotificationMessageText(NotificationType.Success));
        }
    }
}
