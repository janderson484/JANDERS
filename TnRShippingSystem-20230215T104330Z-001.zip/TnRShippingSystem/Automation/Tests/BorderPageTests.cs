using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;
using Assert = NUnit.Framework.Assert;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class BorderPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "BorderPage_VerifyPageAccess_Admin")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "BorderPage_VerifyPageAccess_Supervisor")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "BorderPage_VerifyPageAccess_Internal")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "BorderPage_VerifyPageAccess_External")]
        public void BorderPage_VerifyPageAccess_ManualNavigate(string user, string pass)
        {
            var dashboardPage = new DashboardPageObj(Driver, ShippingBaseUrl);  

            dashboardPage.Navigate(user, pass);
            //dashboardPage.Border.EnsureCorrectUser(user);

            //User-dependent elements, also validates if page exists for user
            if (user.Equals(UserCredentials.AdminUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                //Assert.IsTrue(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
            else if (user.Equals(UserCredentials.SupervisorUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                Assert.IsFalse(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
            else if (user.Equals(UserCredentials.InternalUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                Assert.IsFalse(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
            else if (user.Equals(UserCredentials.ExternalUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                Assert.IsFalse(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
        }
    }
}
