using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using Aspose.Pdf;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    public class TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        //protected const string ShippingBaseUrl = @"https://fs-tnr-shipping-dev-web.azurewebsites.net/";
        protected const string ShippingBaseUrl = @"https://fs-tnr-shipping-qa-web.azurewebsites.net/";
        protected const string IdentityServerBaseUrl = @"https://sts-lle.atsol.com";

        private string resultsPath = @"";

       // protected TWebDriver Driver;
        protected IWebDriver Driver;
        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            string driverPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

            resultsPath = Directory.GetDirectoryRoot(driverPath) + @"Shipping_Results\" + DateTime.Now.ToString("MMddyy_HHmmss");
            Directory.CreateDirectory(resultsPath);
            resultsPath += @"\";

            var chromeOptions = new ChromeOptions();
            chromeOptions.AddArgument("test-type");
            chromeOptions.AddArgument("--no-sandbox");
            chromeOptions.AddArguments("--disable-extensions");
            chromeOptions.AddUserProfilePreference("credentials_enable_service", false);
            chromeOptions.AddUserProfilePreference("profile.password_manager_enabled", false);
            Driver = new ChromeDriver(driverPath, chromeOptions);

            //Load Aspose License
            // Initialize license object
            var license = new License();
            // Set license
            license.SetLicense("Properties/Aspose.Total.lic");
        }

        [SetUp]
        public void SetUp()
        {
            CaptureScreenshot(TestContext.CurrentContext.Test.Name+"_before");

            // Driver = new TWebDriver();

            try
            {
                // In case previous case failed with modal open
                var action = new Actions(Driver);
                action.SendKeys(Keys.Escape).Perform();
            }
            catch
            {
                // Previous test failed hard, crashing Driver instance
               // Driver = new TWebDriver();
            }
        }

        [TearDown]
        public void CleanUpTestCase()
        {
            if (TestContext.CurrentContext.Result.Outcome != NUnit.Framework.Interfaces.ResultState.Success)
            {
                CaptureScreenshot(TestContext.CurrentContext.Test.Name);
            }
        }

        public void CaptureScreenshot(string fileName)
        {
            Screenshot screenPrint = ((ITakesScreenshot)Driver).GetScreenshot();
            screenPrint.SaveAsFile($"{resultsPath}{fileName}.png", ScreenshotImageFormat.Png);
        }

        [OneTimeTearDown]
        public void OneTimeTearDown()
        {
            Thread.Sleep(3000);
            Driver.Close();
            Driver.Quit();
            Driver.Dispose();

            var chromeDriverProcesses = Process.GetProcessesByName("chromedriver");
            foreach (var chromeDriverProcess in chromeDriverProcesses)
            {
                chromeDriverProcess.Kill();
            }
        }
    }
}
