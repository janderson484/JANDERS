using System;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;
using VM.FleetServices.TnR.Shipping.Web.Automation.Tests;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class LogsDetailsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : RemoteWebDriver, new()
    {
        [TestCase(TestName = "Test_Sample")]
        [Category("XXXXXX")]
        public void Test_Sample()
        {
            
        }
    }
}
