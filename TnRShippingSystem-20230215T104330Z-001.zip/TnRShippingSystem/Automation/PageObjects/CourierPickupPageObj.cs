using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using System.Threading;
using System.Linq;
using VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects
{
    public class CourierPickupPageObj : TnrPageObjBase
    {
        public CourierPickupPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path ="/Shipment/CourierPickup";
            KendoGrid = new KendoGridPageObj(driver);
        }
        public KendoGridPageObj KendoGrid { get; }

        #region WebElements
        private IWebElement CourierPickupForm => Driver.FindElement(By.Id("CourierPickupForm"));
        private IWebElement CourierDropdown => Driver.FindElement(By.Id("courierName"));
        private IWebElement NumberOfFormsToPrintField => Driver.FindElement(By.Id("NoOfForms"));
        private IWebElement GenerateFormButton => Driver.FindElement(By.Id("btnGenerateForm"));
        private IWebElement NoOfFormsErrorValidationMessage => Driver.FindElement(By.Id("NoOfForms-error"));
        private IWebElement CourierFieldValidationMessage => Driver.FindElement(By.Id("courierName-error"));
        private IWebElement ResetButton => Driver.FindElement(By.XPath("//form[@id='CourierPickupForm']/div[3]/div/a"));
        #endregion

        #region Private Methods
        public bool IsCourierPickupFormDisplayed()
        {
            return IsElementDisplayedAfterWait(CourierPickupForm);
        }

        public bool IsCourierDropdownDispayed()
        {
            return IsElementDisplayedAfterWait(CourierDropdown);
        }

        public bool IsNumberOfFormsToprintFieldDisplayed()
        {
            return IsElementDisplayedAfterWait(NumberOfFormsToPrintField);
        }

        public void SelectCourierValueFromDropdown(string courier)
        {
            CourierDropdown.SelectDropdownByText(courier);
        }

        public void EnterNumberOfFieldsValue(string value)
        {
            NumberOfFormsToPrintField.SendKeys(value);
        }

        public void ClickGenerateFormButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, GenerateFormButton);
        }

        public bool IsNoOfFormsFieldValidationMessageDisplayed()
        {
            return IsElementDisplayedAfterWait(NoOfFormsErrorValidationMessage);
        }

        public bool IsCourierFieldValidationMessageDisplayed()
        {
            return IsElementDisplayedAfterWait(CourierFieldValidationMessage);
        }

        public void ClickResetButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ResetButton);
        }

        public string GetSelectedCourierDropdownValue()
        {
            return CourierDropdown.GetSelectDropDownCurrentText();
        }

        public string GetNumberOfFiledText()
        {
            return NumberOfFormsToPrintField.Text;
        }
        #endregion

    }
}
