using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects
{
    public class LogPageObj : TnrPageObjBase
    {
        public LogPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Logs";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public KendoGridPageObj KendoGrid { get; }

        #region WebElements

        private IWebElement LogsGrid => Driver.FindElement(By.XPath("//*[@id='Logs']/div[2]/table"));
        private IWebElement LogsGridHeader => Driver.FindElement(By.XPath("//*[@id='Logs']/div[1]/div/table/thead/tr"));
        private IEnumerable<IWebElement> LogsGridTableRows => Driver.FindElements(By.XPath("//*[@id='Logs']/div[2]/table/tbody/tr"));
        private IWebElement StartDatePicker => Driver.FindElement(By.XPath("//input[@id='startDate']"));
        private IWebElement LogSearchButton => Driver.FindElement(By.XPath("//button[@id='logSearch']"));
        private IWebElement FilterByProcess => Driver.FindElement(By.Id("filterByProcess"));
        private IWebElement RefreshButton => Driver.FindElement(By.XPath("//div[@id='grdViewLogsSummary']/div[3]/a[5]/span"));
        #endregion

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon(5);
        }

        public bool LogsGridExists()
        {
            return LogsGrid != null;
        }

        public void ClickLogIdToNavigateToLogDetails(int rowNumber = 1)
        {
            KendoGrid.ClickCellHyperlinkByRowAndColumnNumber( rowNumber, GetIdColumnNumber());
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public void ClickLogSearchButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, LogSearchButton);
        }

        public bool ValidateLogsGridHeader()
        {
            var headers = LogsGridHeader.FindElements(By.TagName("th"));
            for (var i = 0; i < headers.Count; i++)
            {
                var headerText = headers[i].Text;
                if (!string.IsNullOrWhiteSpace(headerText) && headers[i].Text != LogsPage.Headers[i])
                {
                    return false;
                }
            }
            return true;
        }

        public void SortingLogsGrid()
        {
            var headers = LogsGridHeader.FindElements(By.TagName("th"));
            foreach (var header in headers)
            {
                header.Click();
            }
        }

        public bool ValidateTransactionStatus()
        {
            var tableRows = LogsGridTableRows;
            foreach (var row in tableRows)
            {
                var statusObj = row.FindElements(By.TagName("td"))[8];
                var statusText = statusObj.Text;
                var statusClass = statusObj.FindElement(By.TagName("div")).GetAttribute("class");
                if (statusClass != ((statusText == "Completed") ? LogsPage.SuccessTransaction : LogsPage.FailedTransaction))
                {
                    return false;
                }

            }
            return true;
        }

        public List<string> GetFilterByProcessValues()
        {
            SelectElement filterByProcess = new SelectElement(FilterByProcess);
            return filterByProcess.Options.Select(i => i.Text).ToList();
        }

        public int GetIdColumnNumber()
        {
            return 1;
        }

        public int GetProcessNameColumnNumber()
        {
            return 2;
        }

        public int GetProcessTypeColumnNumber()
        {
            return 3;
        }

        public int GetFileNameColumnNumber()
        {
            return 4;
        }

        public int GetTotalCountColumnNumber()
        {
            return 5;
        }

        public int GetSuccessCountColumnNumber()
        {
            return 6;
        }

        public int GetErrorCountColumnNumber()
        {
            return 7;
        }

        public int GetWarningCountColumnNumber()
        {
            return 8;
        }

        public int GetStatusColumnNumber()
        {
            return 9;
        }

        public int GetUserNameColumnNumber()
        {
            return 10;
        }

        public int GetStartTimeColumnNumber()
        {
            return 11;
        }

        public int GetEndTimeColumnNumber()
        {
            return 12;
        }

        public void SetStartDateTimeYear(string year = "2000")
        {
            Extensions.JavaScriptExicuterClick(Driver, StartDatePicker);
            StartDatePicker.SendKeys(year);
            StartDatePicker.SendKeys(Keys.Tab);
            ClickLogSearchButton();
        }

        public void ClickRefreshButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, RefreshButton);
        }
    }
}
