using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects
{
    class LogDetailsPageObj : TnrPageObjBase
    {
        public LogDetailsPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Label/Logs";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public KendoGridPageObj KendoGrid { get; }

        #region WebElements

        private IWebElement SortingLogsPageTableProcessIdColumn => Driver.FindElement(By.XPath("//*[@data-title='Id']"));
        private IWebElement LogPageHyperlinkProcessId => Driver.FindElement(By.XPath("//*[@id='Logs']/div[2]/table/tbody/tr/td/a"));
        IWebElement LogPageHyperlinkFileName => Driver.FindElement(By.XPath("//*[@id='Logs']/div[2]/table/tbody"));

        private IWebElement HeaderProcessId => Driver.FindElement(By.XPath("//label[contains(text(),'Process Id')]/../following-sibling::div/span"));
        private IWebElement HeaderProcessName => Driver.FindElement(By.XPath("//label[contains(text(),'Process Name')]/../following-sibling::div/span"));
        private IWebElement HeaderProcessType => Driver.FindElement(By.XPath("//label[contains(text(),'Process Type')]/../following-sibling::div/span"));
        IWebElement HeaderFileName => Driver.FindElement(By.XPath("//label[contains(text(),'File Name')]/../following-sibling::div/span"));

        private IWebElement HeaderTotalCount => Driver.FindElement(By.XPath("//label[contains(text(),'Total Count')]/../following-sibling::div/span"));
        private IWebElement HeaderSuccessfulCount => Driver.FindElement(By.XPath("//label[contains(text(),'Successful Count')]/../following-sibling::div/span"));
        private IWebElement HeaderErrorCount => Driver.FindElement(By.XPath("//label[contains(text(),'Error Count')]/../following-sibling::div/span"));
        private IWebElement HeaderWarningCount => Driver.FindElement(By.XPath("//label[contains(text(),'Warning Count')]/../following-sibling::div/span"));

        private IWebElement HeaderStatus => Driver.FindElement(By.XPath("//label[contains(text(),'Status')]/../following-sibling::div/span"));
        private IWebElement HeaderUser => Driver.FindElement(By.XPath("//label[contains(text(),'User')]/../following-sibling::div/span"));
        private IWebElement HeaderStartTime => Driver.FindElement(By.XPath("//label[contains(text(),'Start Time')]/../following-sibling::div/span"));
        private IWebElement HeaderEndTime => Driver.FindElement(By.XPath("//label[contains(text(),'End Time')]/../following-sibling::div/span"));

        IWebElement TableHeaderElement => Driver.FindElement(By.XPath("//*[@id='LogDetails']/div[1]/div/table/thead"));

        #endregion

        #region Public Method
        
        public bool TableHeaderElementValidation()
        {
            IList<IWebElement> TableRow = TableHeaderElement.FindElements(By.TagName("tr"));
            IList<IWebElement> ThCell = TableRow[0].FindElements(By.TagName("th"));

            return !ThCell.Where((t, i) => t.Text != LogDetailsPageTableHeader.Title[i]).Any();
        }

        public string GetHeaderProcessIdValue()
        {
            return HeaderProcessId.Text;
        }

        public string GetHeaderProcessNameValue()
        {
            return HeaderProcessName.Text;
        }

        public string GetHeaderProcessTypeValue()
        {
            return HeaderProcessType.Text;
        }

        public string GetHeaderFileNameValue()
        {
            return HeaderFileName.Text;
        }

        public string GetHeaderTotalCountValue()
        {
            return HeaderTotalCount.Text;
        }

        public string GetHeaderSuccessfulCountValue()
        {
            return HeaderSuccessfulCount.Text;
        }

        public string GetHeaderErrorCountValue()
        {
            return HeaderErrorCount.Text;
        }

        public string GetHeaderWarningCountValue()
        {
            return HeaderWarningCount.Text;
        }

        public string GetHeaderStatusValue()
        {
            return HeaderStatus.Text;
        }

        public string GetHeaderUserValue()
        {
            return HeaderUser.Text;
        }

        public string GetHeaderStartTimeValue()
        {
            return Convert.ToDateTime(HeaderStartTime.Text).ToString("g");
        }

        public string GetHeaderEndTimeValue()
        {
            return Convert.ToDateTime(HeaderEndTime.Text).ToString("g");
        }

        #endregion

    }
}
