using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using System.IO;
using System.Threading;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using VM.FleetServices.TnR.Shipping.Web.Automation.Model;
using System.Runtime.InteropServices;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects
{
    public class ViewShipmentsPageObj : TnrPageObjBase
    {
        public ViewShipmentsPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Shipment/ViewShipments";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public KendoGridPageObj KendoGrid { get; }

        private List<GridColumn> _gridColumnList;

        private List<string> _columnsToIgnore;

        #region WebElements

        private IWebElement ViewShipmentsGrid => Driver.FindElement(By.XPath("//*[@id='grdViewShipment']/div[2]/table"));
        private IWebElement ViewShipmentsGridHeader => Driver.FindElement(By.XPath("//*[@id='grdViewShipment']/div[1]/div/table/thead/tr"));
        private IEnumerable<IWebElement> LogsGridTableRows => Driver.FindElements(By.XPath("//*[@id='grdViewShipment']/div[2]/table/tbody/tr"));

        private IWebElement StartDatePicker => Driver.FindElement(By.Id("StartDate"));
        private IWebElement EndDatePicker => Driver.FindElement(By.Id("EndDate"));
        private IWebElement SearchButton => Driver.FindElement(By.Id("searchButton"));
        private IWebElement ClearButton => Driver.FindElement(By.Id("clearButton"));
        private IWebElement FilterByProcess => Driver.FindElement(By.Id("filterByProcess"));
        private IWebElement FileExportNotification => Driver.FindElement(By.XPath("//span[contains(text(), 'Request to download the document initiated')]"));
        private IWebElement LogsRefreshButton => Driver.FindElement(By.XPath("//div[@id='grdViewLogsSummary']/div[3]/a[@class='k-pager-refresh k-link']"));
        private IWebElement ExportButton => Driver.FindElement(By.XPath("//button[@class='btn dropdown-toggle']"));
        private IList<IWebElement> ExportOptions => Driver.FindElements(By.XPath("//*[@id='ExportOptions']/ul/li")).ToList();
        private IWebElement ExportAllButton => Driver.FindElement(By.XPath("//ul/li/a[@id='exportAll']"));
        private IWebElement ExportSelected => Driver.FindElement(By.XPath("//ul/li/a[@id='export']"));
        private IReadOnlyCollection<IWebElement> GridHeadingNames => Driver.FindElements(By.XPath(headerColumnListXpath));
        #endregion

        #region
        private string ExportOptionsXpath = "//ul[@class='dropdown-menu dropdown-menu-right']/li";
        private string dataRowBeforeXpath = "//div[@id='ViewShipments']//tbody/tr[";
        private string dataRowMiddleXpath = "]/td[";
        private string dataRowEndXpath = "]";
        private string headerColumnListXpath = "//thead/tr[1]/th[not(input)]";
        private readonly string ErrorNotification = "//span[contains(text(),'No data available to export')]";
        #endregion

        public void SetStartDate(DateTime startDate)
        {
            StartDatePicker.SendIndividualKeys(startDate.ToString("MM/dd/yyyy"));
        }
        public string GetStartDateText()
        {
            return StartDatePicker.GetAttribute("value");
        }

        public void SetEndDate(DateTime endDate)
        {
            EndDatePicker.SendIndividualKeys(endDate.ToString("MM/dd/yyyy"));
        }

        public string GetEndDateText()
        {
            return EndDatePicker.GetAttribute("value");
        }

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon(5);
        }

        public void ClickSearchButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, SearchButton);
        }

        public void ClickClearButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ClearButton);
        }

        public bool ValidateViewShipmentsGridHeader()
        {
            var headers = ViewShipmentsGridHeader.FindElements(By.TagName("th"));
            for (var i = 0; i < headers.Count; i++)
            {
                var headerText = headers[i].Text;
                if (!string.IsNullOrWhiteSpace(headerText) && headers[i].Text != ViewShipments.Headers[i])
                {
                    return false;
                }
            }
            return true;
        }

        public bool SortingViewShipmentsGrid()
        {
            var headers = ViewShipmentsGridHeader.FindElements(By.TagName("th"));
            foreach (var header in headers)
            {
                header.Click();
            }

            return true;
        }

        public bool ValidateTransactionStatus()
        {
            var tableRows = LogsGridTableRows;
            foreach (var row in tableRows)
            {
                var statusObj = row.FindElements(By.TagName("td"))[8];
                var statusText = statusObj.Text;
                var statusClass = statusObj.FindElement(By.TagName("div")).GetAttribute("class");
                if (statusClass != ((statusText == "Completed") ? LogsPage.SuccessTransaction : LogsPage.FailedTransaction))
                {
                    return false;
                }

            }
            return true;
        }

        public List<string> GetFilterByProcessValues()
        {
            SelectElement filterByProcess = new SelectElement(FilterByProcess);
            return filterByProcess.Options.Select(i => i.Text).ToList();
        }

        public string GetDataFromTable(int rowNumber = 1, ViewShipmentsGridHeaders headerName = ViewShipmentsGridHeaders.TrackingNumber)
        {
            return KendoGrid.GetDataCellText(rowNumber, (int)headerName);
        }

        public void WaitForKendoReadyState(int seconds = 15)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(seconds));
            wait.Until(driver =>
            {
                var isAjaxFinished = (bool)((IJavaScriptExecutor)driver).
                    ExecuteScript("return jQuery.active == 0");
                var isLoaderHidden = (bool)((IJavaScriptExecutor)driver).
                    ExecuteScript("return $('.k-loading-image').is(':visible') == false");
                return isAjaxFinished & isLoaderHidden;
            });
        }

        public bool IsExportButtonDisplayed()
        {
            return ExportButton.Enabled;
        }

        public void ClickExportButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportButton);
        }

        public void ClickExportAllButton()
        {
            Extensions.JavaScriptExicuterClick(Driver,ExportAllButton);
        }

        public void ClickExportSelectedButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportSelected);
        }
        public string getLocationTex()


       
        {
            return KendoGrid.GetDataCellText(1, 2);
        }


    public void ClickExportAllButtonFlow()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportButton);
            Extensions.JavaScriptExicuterClick(Driver, ExportAllButton);
        }

        public void ClickExportSelectedButtonFlow()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportButton);
            Extensions.JavaScriptExicuterClick(Driver, ExportSelected);
        }

        public void ClickDataCheckByRowNumber(int rowNumber, bool ? tickCheckbox = null)
        {
            if (rowNumber < 1)
            {
                throw new ArgumentException($"{nameof(rowNumber)} cannot be less than 1.");
            }
            else if (rowNumber > KendoGrid.GetNumberOfDataRows(1, true))
            {
                throw new ArgumentException("Insufficient rows in the table.");
            }
            KendoGrid.WaitForKendoReadyState();
            var fullXPath = dataRowBeforeXpath + rowNumber + dataRowMiddleXpath + "1" + dataRowEndXpath + "/input";
            var checkboxElement = Driver.FindElement(By.XPath(fullXPath));

            if(tickCheckbox == null)
            {
                Extensions.JavaScriptExicuterClick(Driver, checkboxElement);
            }
            else
            {
                Extensions.SetCheckbox(checkboxElement, tickCheckbox.GetValueOrDefault());
            }
        }

        public List<string> ExportDropDownValuesList()
        {
            string xpathProcessingLocations = "//div[@id='ExportOptions']/ul[@class='dropdown-menu dropdown-menu-right']/li";
            List<string> validations = new List<string>();

            Driver.WaitUntilElementExists(xpathProcessingLocations, 20);
            var allValues = Driver.FindElements(By.XPath(xpathProcessingLocations));

            foreach (IWebElement element in allValues)
            {
                validations.Add(element.Text);
            }

            return validations;
        }

        public bool FileDownloadPathExists()
        {
            try
            {
                var test = GridExport.DownloadPath;
                return Directory.Exists(GridExport.DownloadPath);
            }
            catch(Exception)
            {
                return false;
            }
        }

        public void DeleteIfExportedFileExists()
        {
            try
            {
                File.Delete(GridExport.DownloadedFile);
                Thread.Sleep(3000);
            }
            catch(Exception)
            {
                throw;
            }
        }

        public bool ExportedFileExists()
        {
            try
            {
                return File.Exists(GridExport.DownloadedFile);
            }
            catch(Exception)
            {
                return false;
            }
        }

        private void SetGridHeadingNames()
        {
            var columnIndex = 1;
            _gridColumnList = new List<GridColumn>();

            foreach(var webElement in GridHeadingNames)
            {
                if(string.IsNullOrWhiteSpace(webElement.Text))
                {
                    //The column header was out of view when the grid headings were obtained
                    webElement.ScrollToElement(Driver);
                }
                var isIgnored = _columnsToIgnore != null && _columnsToIgnore.Contains(webElement.Text);
                if (!isIgnored)
                {
                    _gridColumnList.Add(new GridColumn()
                    {
                        ColumnIndex = columnIndex++,
                        ColumnText = webElement.Text.ToUpper(),
                        Id = webElement.GetAttribute("Id")
                    });
                }
                else
                {
                    columnIndex++;
                }
            }
        }

        public bool HeadingCellsMatchWithGrid()
        {
            IWorkbook book = new HSSFWorkbook();
            if(_gridColumnList == null || !_gridColumnList.Any())
            {
                SetGridHeadingNames();
            }
            var result = false;
            try
            {
                using (var fs= new FileStream(GridExport.DownloadedFile, FileMode.OpenOrCreate,FileAccess.Read, FileShare.ReadWrite))
                {
                    book = new HSSFWorkbook(fs);
                    var headingRow = book.GetSheetAt(0).GetRow(0);
                    foreach(var headingCell in headingRow)
                    {
                        var CellValueColumnHeader = headingCell.StringCellValue;
                        var existingGridColumn = _gridColumnList.Find(gridColumn => gridColumn.ColumnText == CellValueColumnHeader.ToUpper());

                        //check total columns are same
                        if(headingRow.Cells.Count != _gridColumnList.Count || existingGridColumn == null ||
                        CellValueColumnHeader.ToUpper() != existingGridColumn.ColumnText)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        public bool IsErrorNotificationDisplayed()
        {
            return IsElementDisplayedAfterWait(ErrorNotification, 5);
        }
    }

    public enum ViewShipmentsGridHeaders
    {
        DateTimeReceived =1,
        Location = 2,
        User = 3,
        Courier =4,
        Customer =5,
        TrackingNumber =6,
        Documents=7
    }
}
