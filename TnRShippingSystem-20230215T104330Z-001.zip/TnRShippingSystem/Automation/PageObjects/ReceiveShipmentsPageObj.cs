using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.Shipping.Web.Automation.PageObjects
{
    public class ReceiveShipmentsPageObj : TnrPageObjBase
    {
        public ReceiveShipmentsPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Shipment/ReceiveShipment";
            KendoGrid = new KendoGridPageObj(driver);
        }
        public KendoGridPageObj KendoGrid { get; }

        #region WebElements
        private IWebElement DateReceivedField => Driver.FindElement(By.Id("receivedDateTime"));
        private IWebElement ProcessingLocationDropdown => Driver.FindElement(By.Id("location"));
        private IWebElement TrackingNumber => Driver.FindElement(By.Id("trackingNumber"));
        private IWebElement CourierDropdown => Driver.FindElement(By.Id("courierName"));
        private IWebElement Comment => Driver.FindElement(By.Id("Comment"));
        private IWebElement CreateButton => Driver.FindElement(By.Id("btnFormSubmit"));
        private IWebElement CancelButton => Driver.FindElement(By.XPath("//a[contains(text(),'Cancel')]"));
        private IWebElement ProcessingLocationValidationMessage => Driver.FindElement(By.Id("location-error"));
        private IWebElement TrackingNumberValidationMessage => Driver.FindElement(By.Id("trackingNumber-error"));
        private IWebElement CourierFieldValidationMessage => Driver.FindElement(By.Id("courierName-error"));
        private IWebElement ReceiveShipmentForm => Driver.FindElement(By.Id("receiveShipmentForm"));
        private IWebElement Notes => Driver.FindElement(By.Id("Comment"));

        #endregion

        #region Private Methods
        public bool IsDateReceivedFieldDisplayed()
        {
            return DateReceivedField.Displayed;
        }

        public bool IsProcessingLocationDropdownDisplayed()
        {
            return ProcessingLocationDropdown.Displayed;
        }

        public bool IsTrackingNumberDisplayed()
        {
            return TrackingNumber.Displayed;
        }

        public bool IsCourierDropdownDisplayed()
        {
            return CourierDropdown.Displayed;
        }

        public bool IsCommentDisplayed()
        {
            return Comment.Displayed;
        }

        public bool IsCreateButtonDisplayed()
        {
            return CreateButton.Displayed;
        }

        public bool IsCancelButtonDisplayed()
        {
            return CancelButton.Displayed;
        }

        public void SelectProcessingLocation(string processingLocation)
        {
            ProcessingLocationDropdown.SelectDropdownByText(processingLocation);
        }

        public void EnterTrackingNumber(string trackingNumber)
        {
            TrackingNumber.SendKeys(trackingNumber);
        }

        public void SelectCourier(string courier)
        {
            CourierDropdown.SelectDropdownByText(courier);
        }

        public void ClickCreateButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CreateButton);
        }

        public bool IsProcessingLocationFieldValidationMessageDisplayed()
        {
            return IsElementDisplayedAfterWait(ProcessingLocationValidationMessage);
        }

        public bool IsTrackingNumberFieldValidationMessageDisplayed()
        {
            return IsElementDisplayedAfterWait(TrackingNumberValidationMessage);
        }

        public bool IsCourierFieldValidationMessageDisplayed()
        {
            return IsElementDisplayedAfterWait(CourierFieldValidationMessage);
        }

        public string GetSelectedCourierTypeValue()
        {
            return CourierDropdown.GetSelectDropDownCurrentText();
        }

        public string GetSelectedProcessingLocationTypeValue()
        {
            return ProcessingLocationDropdown.GetSelectDropDownCurrentText();
        }

        public void EnterNotes()
        {
            Notes.SendKeys("Receive Shipments");
        }

        public void ClickClearButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CancelButton);
        }
        public string GetCurrentSystemDate()
        {
            return DateTime.Now.ToString("MM/dd/yyyy");
        }

        public string GetDateReceivedField()
        {
            return DateReceivedField.GetAttribute("value");
        }

        public void EnterDateReceived(int daysAway)
        {
            DateReceivedField.Clear();
            DateReceivedField.SendIndividualKeys(DateTime.Now.AddDays(daysAway).ToString("MM/dd/yyyy"));
        }

        public string GetMaxLength()
        {
            return Notes.GetAttribute("maxlength");
        }

        public string GetTrackingNumber()
        {
            return TrackingNumber.GetAttribute("value");
        }
        #endregion
    }
}
