using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using VM.FleetServices.TnR.Shipping.Web.Automation.Model;

namespace VM.FleetServices.TnR.Shipping.Web.Automation
{
    public class DataHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string GetRandomVin()
        {
            return $"{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(4)}{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(2)}{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(3)}{Extensions.GetRandomNumber(10000, 99999)}".ToUpper();
        }

        //private static int ConvertLabelTypeEnumToInt(LabelStatusTypeEnum statusType)
        //{
        //    switch (statusType)
        //    {
        //        case LabelStatusTypeEnum.Active:
        //            return LabelStatusType.Active;
        //        case LabelStatusTypeEnum.Pending:
        //            return LabelStatusType.Pending;
        //        case LabelStatusTypeEnum.Closed:
        //            return LabelStatusType.Closed;
        //        case LabelStatusTypeEnum.Void:
        //            return LabelStatusType.Void ;
        //        case LabelStatusTypeEnum.Duplicate:
        //            return LabelStatusType.Duplicate;
        //        default:
        //            return LabelStatusType.Active;
        //    }
        //}            

        /// <summary>
        /// Gets the latest log entry for a client code, process name, start date and optional log id
        /// </summary>
        /// <param name="clientCode">The required client code</param>
        /// <param name="processName">The required process name ie: Import Labels</param>
        /// <param name="startDate">The required start date</param>
        /// <param name="logId">An optional log id</param>
        /// <returns>Log Entry</returns>
        public static List<LogData> GetLatestLog(string clientCode, string processName, DateTime startDate, int logId = 0)
        {
            if (string.IsNullOrWhiteSpace(clientCode))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(clientCode));

            if (string.IsNullOrWhiteSpace(processName))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(processName));

            List<LogData> logDataList = null;
            for (var i = 0; i < 10; i++)
            {
                // Wait for up to 10 iterations for job status to become completed
                var sqlQuery = @"TBD";

                sqlQuery = $"{sqlQuery} WHERE UPPER([ClientCode]) = '{clientCode.ToUpper()}' ";
                sqlQuery = $"{sqlQuery} AND UPPER([ProcessName]) = '{processName.ToUpper()}' ";
                sqlQuery = $"{sqlQuery} AND [ProcessStartDate] >= '{startDate.ToShortDateString()}' ";

                if (logId > 0)
                    sqlQuery = $"{sqlQuery} AND [LogId] = {logId} ";

                sqlQuery = $"{sqlQuery} ORDER BY [LogId] DESC ";

                var dataTable = new DataTable();

                using (var connection = new SqlConnection(SQLHelper.Shipping_ConnectionString))
                {
                    var adapter = new SqlDataAdapter { SelectCommand = new SqlCommand(sqlQuery, connection) };
                    adapter.Fill(dataTable);
                    logDataList = ConvertDataTable<LogData>(dataTable);
                }

                var log = logDataList.First();
                if (string.Equals(log.Status, LogDetailsPageStatus.Failed, StringComparison.CurrentCultureIgnoreCase) ||
                    string.Equals(log.Status, LogDetailsPageStatus.Completed, StringComparison.CurrentCultureIgnoreCase))
                {
                    break;
                }
            }
            return logDataList;
        }       

        #region SQL Helpers

        private static List<T> ConvertDataTable<T>(DataTable dt)
        {
            var data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                var item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }

        private static T GetItem<T>(DataRow dr)
        {
            var temp = typeof(T);
            var obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (var pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)

                        if (dr[column.ColumnName] == DBNull.Value)
                        {
                            pro.SetValue(obj, null, null);
                        }
                        else
                        {
                            pro.SetValue(obj, dr[column.ColumnName], null);
                        }
                    else
                        continue;
                }
            }
            return obj;
        }        

        #endregion
    }

    public static class StandardQueries
    {
        

    }
}
