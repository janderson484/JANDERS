using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.Web.Automation
{
    public static class DashboardPageMessages
    {
        public const string ComingSoon = "Coming Soon...";
    }
}
