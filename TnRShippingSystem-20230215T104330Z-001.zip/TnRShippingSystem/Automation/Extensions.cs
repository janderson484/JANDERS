using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.Shipping.Web.Automation
{
    public static class Extensions
    {

        #region StandardExtensions

        //If select call NonKendo, if Ul call Kendo
        //public static IList<string> GetDropdownOptionsText(this IWebElement dropdownElement, IWebDriver driver){
        //}

        //public static IList<string> GetNonKendoDropdownOptionsText(this IWebElement dropdownElementSelectTag, IWebDriver driver)
        //{
            
        //}

        //public static IList<string> GetDropdownOptions(this IEnumerable<IWebElement> dropdownElementOptions, IWebDriver driver)
        //{
        //    return dropdownElementOptions.Select(x => x.Text).ToList();
        //}

        /// <summary>
        /// Select single value via Customer ClientCode/DMVState abbr
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="value"></param>
        /// <param name="toUpper"></param>
        public static bool SelectDropdownByValue(this IWebElement dropdownElement, string value, bool toUpper = true)
        {
            var dropdown = new SelectElement(dropdownElement);

            try
            {
                dropdown.SelectByValue(toUpper ? value.ToUpper().Trim() : value.Trim());
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        /// <summary>
        /// Select multiple values via Customer ClientCode/DMVState abbr list
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="valueList"></param>
        /// <param name="toUpper"></param>
        public static bool SelectDropdownByValue(this IWebElement dropdownElement, List<string> valueList, bool toUpper = true)
        {
            var dropdown = new SelectElement(dropdownElement);

            dropdown.DeselectAll();

            return valueList.All(value => SelectDropdownByValue(dropdownElement, value, toUpper));
        }

        /// <summary>
        /// Select single value via text displayed
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="value"></param>
        public static bool SelectDropdownByText(this IWebElement dropdownElement, string value)
        {
            var dropdown = new SelectElement(dropdownElement);

            foreach (var option in dropdown.Options)
            {
                if (option.Text.Equals(value, StringComparison.InvariantCultureIgnoreCase))
                {
                    option.Click();
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="index">0 Based index</param>
        /// <returns></returns>
        public static bool SelectDropdownByIndex(this IWebElement dropdownElement, int index)
        {
            var dropdown = new SelectElement(dropdownElement);

            dropdown.Options[index].Click();
            return true;
        }



        /// <summary>
        /// Select single value via text displayed
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="valueList"></param>
        public static bool SelectDropdownByText(this IWebElement dropdownElement, List<string> valueList)
        {
            var dropdown = new SelectElement(dropdownElement);

            dropdown.DeselectAll();

            return valueList.All(value => SelectDropdownByText(dropdownElement, value));
        }

        public static bool IsKendoDropdownExpanded(this IWebDriver driver)
        {
            try
            {

                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1);
                var isDropdownExpanded = driver.FindElement(By.XPath("//div[@class='k-animation-container' and @aria-hidden = 'false']")).Displayed;
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);

                return isDropdownExpanded;
            }
            catch
            {
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                return false;
            }
        }

        /// <summary>
        /// Set date (MM/dd/yyyy)
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="date">Format: MM/dd/yyyy </param>
        public static bool SelectDateFieldByText(this IWebElement dropdownElement, string date = "today")
        {
            if (date.Equals("today"))
            {
                date = DateTime.Now.ToString("MM/dd/yyyy");
            }

            dropdownElement.Click();
            dropdownElement.Clear();

            SendIndividualKeys(dropdownElement, date, true);

            string enteredTextboxDigits;

            try
            {
                enteredTextboxDigits = dropdownElement.GetElementText().Substring(0, date.Length);
            }
            catch (ArgumentOutOfRangeException)
            {
                return false;
            }

            return date.Equals(enteredTextboxDigits);
        }

        /// <summary>
        /// Set date by days away (0 = today, -1 = yesterday, 1 = tomorrow)
        /// </summary>
        /// <param name="dateTextFieldElement"></param>
        /// <param name="daysAway"></param>
        public static bool SelectDateFieldByDaysAway(this IWebElement dateTextFieldElement, int daysAway = 0)
        {
            var date = DateTime.Now.AddDays(daysAway).ToString("MM/dd/yyyy");

            return SelectDateFieldByText(dateTextFieldElement, date);
        }

        public static IWebElement FindElement(this IWebDriver driver, By by, int timeoutInSeconds)
        {
            if (timeoutInSeconds > 0)
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                return wait.Until(drv => drv.FindElement(by));
            }
            return driver.FindElement(by);
        }


        /// <summary>
        /// Sends strings individually by character. Sending entire strings becomes jumbled.
        /// </summary>
        /// <param name="textFieldElement"></param>
        /// <param name="keys"></param>
        /// <param name="tabAtEnd"></param>
        public static void SendIndividualKeys(this IWebElement textFieldElement, string keys, bool tabAtEnd = true, bool clearField = true)
        {
            if (clearField)
            {
                textFieldElement.Clear();
            }
            foreach (var k in keys)
            {
                textFieldElement.SendKeys(k.ToString());
            }
            if (tabAtEnd)
            {
                textFieldElement.SendKeys(Keys.Tab);
            }
        }

        /// <summary>
        /// Get text from textbox
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static string GetElementText(this IWebElement element)
        {
            return element.GetAttribute("value");
        }

        /// <summary>
        /// Get css class value from element
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static string GetElementClass(this IWebElement element)
        {
            return element.GetAttribute("class");
        }

        /// <summary>
        /// Get css id value from element
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static string GetElementId(this IWebElement element)
        {
            return element.GetAttribute("id");
        }

        public static bool WaitAndClickElement(this IWebElement element, IWebDriver driver)
        {
            try
            {
                WaitUntilElementExists(driver, element);
                element.Click();
                Thread.Sleep(500);
                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool IsElementNotDisplayed(this IWebElement element, IWebDriver driver)
        {
            if(element.Displayed == true)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Checks if a select element contains atleast 1 valid item
        /// </summary>
        /// <param name="element"></param>
        /// <returns>true for valid items, false for no valid items</returns>
        public static bool DropdownContainsValidItems(this IWebElement element)
        {
            try
            {
                var dropDown = new SelectElement(element);
                var itemCount = dropDown.Options.Count;
                for (var i = 0; i < itemCount; i++)
                {
                    var currentValue = dropDown.Options.ElementAt(i).Text;
                    if (!string.IsNullOrWhiteSpace(currentValue))
                        return true;
                }

                return false;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
            catch (InvalidCastException)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the selected item from a select (dropdown) element
        /// </summary>
        /// <param name="dropDownWebElement"></param>
        /// <returns>The selected item text, otherwise empty</returns>
        public static string GetSelectDropDownCurrentText(this IWebElement dropDownWebElement)
        {
            try
            {
                var dropDownControl = new SelectElement(dropDownWebElement);
                return (dropDownControl.SelectedOption.Text);
            }
            catch (InvalidCastException)
            {
                return string.Empty;
            }
        }

        public static IEnumerable<IWebElement> GetSelectDropDownOptions(this IWebElement dropDownWebElement)
        {
            Thread.Sleep(500);
            var dropDownControl = new SelectElement(dropDownWebElement);
            return dropDownControl.Options.Where(x => !x.Text.Equals(""));
        }


        public static void SetCheckbox(this IWebElement checkboxElement, bool tickCheckBox)
        {
            if (checkboxElement.Selected != tickCheckBox)
            {
                checkboxElement.Click();
            }
        }

        public static bool HoverOverElement(this IWebDriver driver, string xpath)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(.5));
                var element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(xpath)));

                var action = new Actions(driver);
                action.MoveToElement(element).Perform();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitForAndRemoveSuccessPopup(this IWebDriver driver, string popupPartialText = null, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            const string xpath = "//div[@class='notifyjs-bootstrap-base notifyjs-bootstrap-success']";

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(xpath)));

                Thread.Sleep(500);  // without this sleep, text is read as null
                var popupText = driver.FindElement(By.XPath(xpath + "/span")).Text;

                // If popup is not removed, if following test tries to logout, will be unable since the popup will block the button
                var js = (IJavaScriptExecutor)driver;
                js.ExecuteScript($"document.evaluate(\"{xpath}\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.remove();");

                if (!string.IsNullOrWhiteSpace(popupPartialText))
                {
                    return popupText.IndexOf(popupPartialText, StringComparison.OrdinalIgnoreCase) >= 0;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitForAndRemoveErrorPopup(this IWebDriver driver, string popupPartialText = null, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            const string xpath = "//div[@class='notifyjs-bootstrap-base notifyjs-bootstrap-error']";

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(xpath)));

                Thread.Sleep(500);  // without this sleep, text is read as null
                var popupText = driver.FindElement(By.XPath(xpath + "/span")).Text;

                // If popup is not removed, if following test tries to logout, will be unable since the popup will block the button
                var js = (IJavaScriptExecutor)driver;
                js.ExecuteScript($"document.evaluate(\"{xpath}\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.remove();");

                if (!string.IsNullOrWhiteSpace(popupPartialText))
                {
                    return popupText.IndexOf(popupPartialText, StringComparison.OrdinalIgnoreCase) >= 0;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitForAndRemoveInfoPopup(this IWebDriver driver, string popupPartialText = null, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            const string xpath = "//div[@class='notifyjs-bootstrap-base notifyjs-bootstrap-info']";

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(xpath)));

                Thread.Sleep(500);  // without this sleep, text is read as null
                var popupText = driver.FindElement(By.XPath(xpath + "/span")).Text;

                // If popup is not removed, if following test tries to logout, will be unable since the popup will block the button
                var js = (IJavaScriptExecutor)driver;
                js.ExecuteScript($"document.evaluate(\"{xpath}\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.remove();");

                if (!string.IsNullOrWhiteSpace(popupPartialText))
                {
                    return popupText.IndexOf(popupPartialText, StringComparison.OrdinalIgnoreCase) >= 0;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitForAndRemoveWarningPopup(this IWebDriver driver, string popupPartialText = null, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            const string xpath = "//div[@class='notifyjs-bootstrap-base notifyjs-bootstrap-warn']";

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(xpath)));

                Thread.Sleep(500);  // without this sleep, text is read as null
                var popupText = driver.FindElement(By.XPath(xpath + "/span")).Text;

                // If popup is not removed, if following test tries to logout, will be unable since the popup will block the button
                var js = (IJavaScriptExecutor)driver;
                js.ExecuteScript($"document.evaluate(\"{xpath}\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.remove();");

                if (!string.IsNullOrWhiteSpace(popupPartialText))
                {
                    return popupText.IndexOf(popupPartialText, StringComparison.OrdinalIgnoreCase) >= 0;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitUntilElementExists(this IWebDriver driver, string xpath, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(xpath)));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitUntilElementExists(this IWebDriver driver, IWebElement element, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(element.GetAbsoluteXPath(driver))));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitUntilElementIsRemoved(this IWebDriver driver, string xpath, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(By.XPath(xpath)));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool WaitUntilElementIsRemoved(this IWebDriver driver, IWebElement element, int seconds = 5)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(By.XPath(element.GetAbsoluteXPath(driver))));

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static string GetAbsoluteXPath(this IWebElement element, IWebDriver driver)
        {
            return (string)((IJavaScriptExecutor)driver).ExecuteScript(
                "function absoluteXPath(element) {" +
                "var comp, comps = [];" +
                "var parent = null;" +
                "var xpath = '';" +
                "var getPos = function(element) {" +
                "var position = 1, curNode;" +
                "if (element.nodeType == Node.ATTRIBUTE_NODE) {" +
                "return null;" +
                "}" +
                "for (curNode = element.previousSibling; curNode; curNode = curNode.previousSibling){ " +
                "if (curNode.nodeName == element.nodeName) {" +
                "++position;" +
                "}" +
                "}" +
                "return position;" +
                "};" +

                "if (element instanceof Document) {" +
                "return '/';" +
                "}" +

                "for (; element && !(element instanceof Document); element = element.nodeType == " +
                "Node.ATTRIBUTE_NODE? element.ownerElement : element.parentNode) { " +
                "comp = comps[comps.length] = {};" +
                "switch (element.nodeType) {" +
                "case Node.TEXT_NODE:" +
                "comp.name = 'text()';" +
                "break;" +
                "case Node.ATTRIBUTE_NODE:" +
                "comp.name = '@' + element.nodeName;" +
                "break;" +
                "case Node.PROCESSING_INSTRUCTION_NODE:" +
                "comp.name = 'processing-instruction()';" +
                "break;" +
                "case Node.COMMENT_NODE:" +
                "comp.name = 'comment()';" +
                "break;" +
                "case Node.ELEMENT_NODE:" +
                "comp.name = element.nodeName;" +
                "break;" +
                "}" +
                "comp.position = getPos(element);" +
                "}" +

                "for (var i = comps.length - 1; i >= 0; i--) {" +
                "comp = comps[i];" +
                "xpath += '/' + comp.name.toLowerCase();" +
                "if (comp.position !== null) {" +
                "xpath += '[' + comp.position + ']';" +
                "}" +
                "}" +

                "return xpath;" +
                "} return absoluteXPath(arguments[0]);", element);
        }

        /// <summary>
        /// Scrolls an element into view using javascript
        /// </summary>
        /// <param name="element"></param>
        /// <param name="driver"></param>
        public static void ScrollToElement(this IWebElement element, IWebDriver driver)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true)", element);
        }

        public static void ScrollToTop(this IWebDriver driver)
        {
            var js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(0, 0)");
        }

        public static void ScrollToBottom(this IWebDriver driver)
        {
            var js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollTo(0, 925)");
        }

        public static void SetSlider(this IWebElement element, IWebElement slider, IWebDriver driver, int sliderValue)
        {
            var action = new Actions(driver);
            action.ClickAndHold(slider);
            action.MoveByOffset(sliderValue, 0).Build().Perform();
        }

        public static string GetDateTimeStamp(string format="")
        {
            return DateTime.Now.ToString("MMddhhmmss");
        }

        public static string GetRandomString(int length)
        {
            var ran = new Random();
            const string expected = "abcdefghjklmnpqrstuvwxyz";
            var random = "";

            for (var i = 0; i < length; i++)
            {
                var a = ran.Next(24);
                random = random + expected.ElementAt(a);
            }
            return random;
        }

        public static int GetRandomNumber(int min, int max)
        {
            var random = new Random();
            return random.Next(min, max);
        }

        public static void JavaScriptExicuterClick(IWebDriver driver, IWebElement elemnt)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].click();", elemnt);
        }

        #endregion

        #region EnumExtensions

        public static string GetDescription(this Enum value)
        {
            var enumType = value.GetType();
            var field = enumType.GetField(value.ToString());
            var attributes = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return attributes.Length == 0 ? value.ToString() : ((DescriptionAttribute)attributes[0]).Description;
        }

        public static IEnumerable<string> GetDescriptions(this Type type)
        {
            var descs = new List<string>();
            var names = Enum.GetNames(type);
            foreach (var name in names)
            {
                var field = type.GetField(name);
                var fds = field.GetCustomAttributes(typeof(DescriptionAttribute), true);
                foreach (DescriptionAttribute fd in fds)
                {
                    descs.Add(fd.Description);
                }
            }
            return descs;
        }


        #endregion
    }
}
