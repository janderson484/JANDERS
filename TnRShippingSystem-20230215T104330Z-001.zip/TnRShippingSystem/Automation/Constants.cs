using System;
using System.Collections.Generic;

namespace VM.FleetServices.TnR.Shipping.Web.Automation
{
    public static class DefaultSettings
    {
        public const int ImplicitWait = 10;
    }

    public static class UserCredentials
    {
        public const string AdminUsername = "FSAMSTESTUSER";
        public const string AdminPassword = "P@ssw0rd";

        public const string SupervisorUsername = "FSAMSTESTUSER2";
        public const string SupervisorPassword = "P@ssw0rd";

        public const string InternalUsername = "FSAMSTESTUSER3";
        public const string InternalPassword = "P@ssw0rd";

        public const string ExternalUsername = "FSAMSTESTUSER4";
        public const string ExternalPassword = "P@ssw0rd";
    }

    public static class Clients
    {
        public const string Hertz = "HERTZ";
        public const string Ehi = "EHI";
    }

    public static class ClientLocationCode
    {
        // Originating Locations
        public const string HertzOrlando = "HERTZ-ORLANDO";

        // Processing Locations
        public const string Bradenton = "FL-BRADENTON";

        public const string Miami = "HERTZ-MIAMI";
    }

    public static class DmvStates
    {
        public const string Florida = "FL";
        public const string Arizona = "AZ";
    }

    public static class Inventories
    {
        public const string FloridaInventory = "FL-INV";
        public const string ArizonaInventory = "AZ-INV";
        public const string UtahInventory = "UT-INV";
    }


    public static class Notes
    {
        public const string NotesDefault = "Some test comments";
    }

    public static class GridExport
    {
        public static readonly string DownloadPath = $"C:\\Users\\{Environment.UserName}\\Downloads";
        public static readonly string DownloadedFile = $"C:\\Users\\{Environment.UserName}\\Downloads\\Export.xlsx";
        public static readonly string ExportedInvoiceFile = $"C:\\Users\\{Environment.UserName}\\Downloads\\Invoice.xlsx";
        public const int DateIndex = 14;
        public const string ColumnDataType = "System.String";
        public const int AutoSelectRowCount = 3;
        public const int AutoSelectFirstRow = 1;
       
    }

    public static class LogDetailsPageTableHeader
    {
        public static readonly string[] Title = { "Id", "Error Type", "Error Message", "Actual Record", "Created Time" };
        public static readonly string[] Section = {
            "Process Id","Process Name","Process Type",  "File Name",
            "Total Count",  "Successful Count","Error Count","Warning Count",
            "Status","User","Start Time","End Time" };
    }

    public static class LogDetailsPageStatus
    {
        public const string Completed = "Completed";
        public const string CompletedStatusColorClassName = "process-success";
        public const string InProgress = "In Progress";
        public const string Failed = "Failed";
    }

    public static class LogsPage
    {
        public static readonly string[] Headers = {
            "Id","Process Name","Process Type",  "File Name",
            "Total Count",  "Success Count","Error Count","Warning Count",
            "Status","User Name","Start Time","End Time", "Customer",
            "Processing Location", "Inventory Code" };

        public const string SuccessTransaction = "Completed";
        public const string FailedTransaction = "Failed";

        public static List<string> FilterProcessNames = new List<string>()
        {"All Processes" };
    }

    public static class ProcessingLocations
    {
        public const string SunshineBradenton = "FL-BRADENTON";
        public const string SunCityAz = "AZ-SUN_CITY";
        public const string SanAntonioTx = "TX-SAN_ANTONIO";
    }



    public static class SQL
    {
        public const string PM_SqlDevConnection = "Data Source=tcp:fs-shared-dev-sql.database.windows.net,1433;Initial Catalog=fs-tnrmgmt-dev-db;User Id=TnrMgmtApp;Password=8!wbVCb398Mz2Rge4hU2qtrB;";
        public const string Shipping_SqlDevConnection = "Data Source=tcp:: fs-shared-dev-sql.database.windows.net,1433;Initial Catalog=fs-tnr-tps-dev-db;User Id=TnrMgmtTpsApp;Password=8!wbVCb398Mz2Rge4hU2qtrB;";

        public const string PM_SqlQAConnection = "Data Source=tcp:fs-shared-qa-sql.database.windows.net,1433;Initial Catalog=fs-tnrmgmt-pm-qa-db;User Id=TnrMgmtPMApp;Password=ZKCF#ynxF5$9HJ4FQdCw5Pna;";
        public const string Shipping_SqlQAConnection = "Data Source=tcp:: fs-shared-qa-sql.database.windows.net,1433;Initial Catalog=fs-tnr-tps-qa-db;User Id=TnrMgmtTpsApp;Password=Fmj9v$CHfkbJP7q99DmWe7UC;";
    }

    public enum NotificationType
    {
        Success,
        Error,
        Info,
        Warn
    }

    public static class TimeOuts
    {
        public const int AppTimeOut = 240000;
        public const int CountDownTimer = 60000;
        
    }

    public static class ViewShipments
    {
        public static List<string> Headers = new List<string>() { "","Date/Time Received", "Location", "User", "Courier", "Customer", "Tracking Number", "Documents"};
        public const string ExportAll_Successmessage = "Request to export shipment submitted";
        public const string ExportSelected_SuccessMessage = "All selected rows will be exported to Excel:";
        public const string ExportSelectedWithoutSelectingRecord_SuccessMessage = "All visible rows will be exported to Excel:";
        public const string ExcelFileDownloadRequest = "Request to download the document initiated";
    }

    public static class ReceiveShipments
    {
        public const string SanAntonio = "San Antonio TX";
        public const string SunCity = "Sun City, AZ";
        public const string SunshineBradenton = "Sunshine Bradenton, FL";
        public const string AirborneExpress = "Airborne Express";
        public const string CourierPickupArizona = "Courier Pickup - Arizona";
        public const string CourierPickupBradenton = "Courier Pickup - Bradenton";
        public const string CourierPickupTexas = "Courier Pickup - Texas";
        public const string AddReceiveShipments_Success = "Received Shipment successfully";
        public const string DuplicateTrackingNumber_Error = "Cannot insert duplicate key of tracking number and courier";
    }

    public static class CourierPickup
    {
        public const string AirborneExpress = "Airborne Express";
        public const string CourierPickupArizona = "Courier Pickup - Arizona";
        public const string CourierPickupBradenton = "Courier Pickup - Bradenton";
        public const string CourierPickupTexas = "Courier Pickup - Texas";
        public const string CourierPickupFormMessage = "Courier Pickup Form created successfully!"; 
    }

}
