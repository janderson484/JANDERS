using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;

namespace VM.FleetServices.TnR.Shipping.BackendJob.Services
{
    public class BulkProcessService : IBulkProcessService
    {
        private readonly ILogger<BulkProcessService> _logger;

        public BulkProcessService(ILogger<BulkProcessService> logger)
        {
            _logger = logger;
        }
    }
}
