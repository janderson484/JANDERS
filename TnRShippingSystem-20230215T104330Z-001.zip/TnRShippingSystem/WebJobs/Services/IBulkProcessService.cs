using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.BackendJob.Services
{
    public class IBulkProcessService
    {
    }
}
