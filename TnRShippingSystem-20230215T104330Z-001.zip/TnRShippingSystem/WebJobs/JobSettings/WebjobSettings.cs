namespace VM.FleetServices.TnR.Shipping.BackendJob.JobSettings
{
    public class WebjobSettings
    {       
        public int BatchCount { get; set; }
        public string AppUserName { get; set; }
        public int ExportReportRequestCount { get; set; }
    }
}
