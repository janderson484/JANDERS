using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using VM.FleetServices.TnR.Shipping.BackendJob.Components;

namespace VM.FleetServices.TnR.Shipping.BackendJob
{
    public static class WebjobConfig
    {
        public static IServiceCollection AddMessagePipelineComponents(this IServiceCollection services)
        {
            // register pipeline components            
            var loadAssembly = typeof(IPipelineComponent).Assembly;

            var pipelineComponentTypes = loadAssembly.GetTypes().Where(t => t.IsClass && !t.IsAbstract && typeof(IPipelineComponent).IsAssignableFrom(t)).ToList();
            foreach (var pipelineComponentType in pipelineComponentTypes)
            {
                services.AddScoped(pipelineComponentType);
            }

            return services;
        }
    }
}
