using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using CsvHelper.Configuration;
using CsvHelper;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.AzureStorage;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Shipping.BackendJob.JobSettings;
using VM.FleetServices.TnR.Shipping.Business;
using VM.FleetServices.TnR.Shipping.Business.Integrations;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel.Entities;
using VM.FleetServices.TnR.Shipping.Model.ServiceBus;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.BackendJob.Models;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using OfficeOpenXml.Table.PivotTable;
using VM.FleetServices.TnR.Shipping.Model.Enums;
using static Aspose.Pdf.Operator;
using ApiRouteConstants = VM.FleetServices.TnR.Shipping.BackendJob.Models.ApiRouteConstants;

namespace VM.FleetServices.TnR.Shipping.BackendJob.Components
{
    public class ExportShipmentsPipelineComponent : PipelineComponent, IPipelineComponent
    {
        private readonly ILogger<ExportShipmentsPipelineComponent> _logger;
        private readonly IMapper _mapper;
        private readonly ApiSettings _apiSettings;
        private readonly IBlobStorage _blobStorage;
        private readonly WebjobSettings _settings;
        private readonly StorageOptions _storageOptions;
        private readonly IShipmentService _shipmentService;
        private readonly ILogService _logService;


        public ExportShipmentsPipelineComponent(ILogger<ExportShipmentsPipelineComponent> logger,  IAuthService authenticationService, IOptions<WebjobSettings> settings,  IOptions<ApiSettings> apiSettings, IShipmentService shipmentService, IBlobStorage blobStorage, IOptions<StorageOptions> storageOptions, IMapper mapper, ILogService logService) : base(logger, authenticationService)
        {
            _logger = logger;
            _shipmentService = shipmentService;    
            _settings = settings.Value;
            _apiSettings = apiSettings.Value;
            _blobStorage = blobStorage;
            _storageOptions = storageOptions.Value;
            _mapper = mapper;
            _logService = logService;
        }

        /// <summary> 
        /// Verifies job in message can be ran
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>//
        public override bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {           
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);
           
            return  actionCode != null && logId != null;
        }

        public override async Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues)
        {

            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);            
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);
            messageValues.TryGetValue(ServiceBusMessageProperties.SearchCriteria, out var searchCriteria);
            messageValues.TryGetValue(ServiceBusMessageProperties.UserName, out var userName);
            messageValues.TryGetValue(ServiceBusMessageProperties.ReportType, out var reportType);

            var blobDirectory = BlobContainerDirectories.ExportShipments.ToString();

            var logDetails = new List<Model.DTO.LogDetail>();

            var result = new PipelineResult(this);
            
            if (!logId.IsNullOrEmpty())
            {
                var log = await _logService.GetLogStatusAsync(Convert.ToInt32(logId));

                var shipmentInputData = new List<Dictionary<string, string>>();
                var filePath = string.Empty;
                var fileName = $"{userName?.Trim()}_{reportType.Replace(' ', '_')}_{DateTime.Now:MMddyyyyHHmmss}.csv";
                var totalCount = 0;
                var processedCount = 0;

                try
                {
                    var currentBatch = 1;
                    var countPerRequest = _settings.ExportReportRequestCount;
                    var processCompletionStatus = false;
                    
                    // Update the log status to In-Progress for specific LogId
                    log = await _logService.UpdateLogStatusByIdAsync(log.LogId, JobLogStatus.InProgress.GetDescription()); 

                    var exportSearchCriteria = JsonConvert.DeserializeObject<CreateReceiveShipmentRequestModel>(searchCriteria);

                    log.TotalCount = await _shipmentService.GetReceiveShipmentDataCountAsync(exportSearchCriteria);

                    totalCount = log.TotalCount;

                    do
                    {                        
                        exportSearchCriteria.DefaultRowsPerPage = countPerRequest;
                        exportSearchCriteria.PageNumber = currentBatch;

                        //Gets the shipment data
                        var results = await _shipmentService.GetReceiveShipmentDataAsync(exportSearchCriteria);

                        //Create CSV and appened to blob
                        filePath = await GenerateCSVAsync(results.ToList(), fileName, blobDirectory, currentBatch == 1 ? true : false);
                        processedCount += results.Count;
                        currentBatch++;
                         
                        //update the log count
                        await UpdateLogCountAsync(processedCount, log);

                        processCompletionStatus = totalCount == processedCount ? true : false;
                    }

                    while (!processCompletionStatus);

                    log.Status = JobLogStatus.Completed.ToString();
                    log.Filename = filePath;
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error processing component {nameof(ExportShipmentsPipelineComponent)}: {ex.Message}");
                    log.Status = JobLogStatus.Failed.GetDescription();
                    log.ErrorCount = totalCount - processedCount;

                    var currentLogDate = DateTime.Now;

                    logDetails.Add(new Model.DTO.LogDetail()
                    {
                        Active = true,
                        ErrorType = LogDetailTypeConstants.Error,
                        LogId = log.LogId,
                        CreatedDate = currentLogDate,
                        CreatedUser = log.CreatedUser,
                        ModifiedDate = currentLogDate,
                        ModifiedUser = log.CreatedUser,
                        ErrorMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message,
                        ErrorRecord = reportType,
                    });
                }
                finally
                {
                    log = await UpdateLogStatusAsync(log, logDetails);                                      
                }
            }               
                return await Task.FromResult(result);
        }

        /// <summary>
        /// Generates the Csv file and upload to blob.
        /// </summary>
        /// <typeparam name="T">Type of result object for which we need to generate excel.</typeparam>
        /// <param name="results">The results list.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="addHeader">Bit field to add header or not.</param>
        public async Task<string> GenerateCSVAsync<T>(List<T> results, string fileName, string blobDirectory, bool addHeader = true)
        {
            try
            {
                var csvConfig = new CsvConfiguration(CultureInfo.CurrentCulture)
                {
                    HasHeaderRecord = addHeader,
                };

                using (var memoryStream = new MemoryStream())
                {
                    using (var streamWriter = new StreamWriter(memoryStream))
                    {
                        using (var csvWriter = new CsvWriter(streamWriter, csvConfig))
                        {
                            if (results is List<CreateReceiveShipmentsViewModel>)
                            {
                                csvWriter.Context.RegisterClassMap<ShipmentViewModelExportHeader>();
                            }
                            csvWriter.WriteRecords(results);
                            streamWriter.Flush();
                        }
                    }

                    var blob = await _blobStorage.AppendBlobAsync(_storageOptions.BlobContainer, blobDirectory, fileName, memoryStream.ToArray());

                    blob.Properties.ContentType = "text/csv";
                    blob.SetPropertiesAsync().Wait();
                    var filePath = blob.StorageUri.PrimaryUri.ToString();
                    return filePath;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing {nameof(GenerateCSVAsync)}: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// Private method to update log count
        /// </summary>
        /// <param name="processed"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        private async Task<Model.DTO.Log> UpdateLogCountAsync(int processed, Model.DTO.Log log)
        {
            log.SuccessfulCount = processed;
            return await _logService.UpdateLogStatusAsync(log, new List<Model.DTO.LogDetail>());
        }

        /// <summary>
        /// Private method to update log status
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        private async Task<Model.DTO.Log> UpdateLogStatusAsync(Model.DTO.Log log, List<Model.DTO.LogDetail> logDetails)
        {
            log.ProcessEndDate = DateTime.Now;
            return await _logService.UpdateLogStatusAsync(log, logDetails);
        }

    }
}
