using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Shipping.Business.Integrations;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;

namespace VM.FleetServices.TnR.Shipping.BackendJob.Components
{
    public interface IPipelineComponent
    {
        bool CanProcess(IReadOnlyDictionary<string, string> messageValues);

        Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues);
    }

    public abstract class PipelineComponent : IPipelineComponent
    {
        protected readonly ILogger Logger;
        private readonly IAuthService _authenticationService;

        protected PipelineComponent(ILogger logger, IAuthService authenticationService)
        {
            Logger = logger;
            _authenticationService = authenticationService;
        }

        public virtual bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {
            return true;
        }

        /// <summary>
        /// Send Notifications using api
        /// </summary>
        /// <param name="notificationViewModel"></param>
        /// <param name="notificationUri"></param>
        /// <returns></returns>
        public async Task SendNotificationsAsync(NotificationViewModel notificationViewModel, string notificationUri)
        {
            try
            {
                using var httpClient = new HttpClient();
                var tokenResponse = _authenticationService.GetAccessToken();
                httpClient.DefaultRequestHeaders.Add("Authorization", $"{tokenResponse.TokenType} {tokenResponse.AccessToken}");
                httpClient.BaseAddress = new Uri(notificationUri);
                await httpClient.PostAsJsonAsync(notificationUri, notificationViewModel);
            }
            catch (Exception e)
            {
                Logger.LogError($"Method: {nameof(SendNotificationsAsync)} - A critical error occurred while sending a request to the notifications api\r\nMessage: {e.Message} ");
                throw;
            }
            
        }

        public abstract Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues);
    }

    public class PipelineResult
    {
        public PipelineResult(IPipelineComponent component)
        {
            Component = component.GetType().Name;
        }

        public bool Processed { get; set; } = true;

        public string Component { get; }

        public IList<IDictionary<string, string>> ActionResults { get; } = new List<IDictionary<string, string>>();

        public bool RequeueMessage { get; private set; }

        public TimeSpan ScheduleMessageIn { get; private set; }

        public void RescheduleMessage(TimeSpan fromMinutes)
        {
            RequeueMessage = true;
            ScheduleMessageIn = fromMinutes;
        }
    }
}
