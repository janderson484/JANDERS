using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.Shipping.BackendJob.Models
{
    public static class ApiRouteConstants
    {
        public static string SendNotification() => "api/Notification/SendNotification";
    }
   
    public static class LogDetailTypeConstants
    {
        public const string Error = "Error";
        public const string Warn = "Warning";
    }
}
