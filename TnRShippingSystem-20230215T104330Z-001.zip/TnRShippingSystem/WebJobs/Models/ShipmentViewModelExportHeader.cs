using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;

namespace VM.FleetServices.TnR.Shipping.BackendJob.Models
{
    public class ShipmentViewModelExportHeader : ClassMap<CreateReceiveShipmentsViewModel>
    {
        public ShipmentViewModelExportHeader()
        {
            AutoMap(CultureInfo.InvariantCulture);
            Map(m => m.ReceiveShipmentId).Ignore();
            Map(m => m.ReceivedDateTime).Name("Date/Time Received");
            Map(m => m.Location).Name("Location");
            Map(m => m.UserName).Name("User");
            Map(m => m.CourierName).Name("Courier");
            Map(m => m.Customer).Name("Customer");
            Map(m => m.TrackingNumber).Name("Tracking Number");
            Map(m => m.Documents).Name("Documents");      
            Map(m => m.CourierId).Ignore();
            Map(m => m.Active).Ignore();
            Map(m => m.Comment).Ignore();
            Map(m => m.ClientCode).Ignore();
            Map(m => m.DefaultRowsPerPage).Ignore();
            Map(m => m.RowsPerPage).Ignore();
            Map(m => m.PageNumber).Ignore();
            Map(m => m.TotalResultCount).Ignore();
        }
    }
}
