using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Shipping.BackendJob.Components;
using VM.FleetServices.TnR.Shipping.BackendJob.JobSettings;

namespace VM.FleetServices.TnR.Shipping.BackendJob
{
    public class WebjobFunctions
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IScrubMessageService _messageService;
        private readonly ILogger<WebjobFunctions> _logger;

        public WebjobFunctions(IServiceProvider serviceProvider, IScrubMessageService messageService, ILogger<WebjobFunctions> logger)
        {
            _serviceProvider = serviceProvider;
            _messageService = messageService;
            _logger = logger;
        }

        public async Task BackEndJob_OnMessageReceived([ServiceBusTrigger("%ServiceBusOptions:QueueName%", "%ServiceBusOptions:SubscriptionName%", Connection = "ServiceBusOptions:ConnectionString")] Message message, ILogger log, CancellationToken cancellationToken)
        {
            await OnMessageReceivedAsync(message, cancellationToken);
        }

        private async Task OnMessageReceivedAsync(Message message, CancellationToken cancellationToken)
        {
            try
            {
                var body = Encoding.UTF8.GetString(message.Body);
                _logger.LogInformation($"{nameof(OnMessageReceivedAsync)} - Message Data: {body}");
                var messageProperties = _messageService.ConvertRawMessageToDictionary(body);
                var internalQueue = new Queue<IDictionary<string, string>>();
                internalQueue.Enqueue(messageProperties);

                using (var scope = _serviceProvider.CreateScope())
                {
                    var pipeline = new Pipeline(internalQueue);

                    pipeline.AddComponent<ExportShipmentsPipelineComponent>();

                    while (internalQueue.Count > 0)
                    {
                        var messageValues = new ReadOnlyDictionary<string, string>(internalQueue.Dequeue());

                        await pipeline.RunAsync(scope.ServiceProvider, messageValues);
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"{nameof(OnMessageReceivedAsync)} - Error: {e.Message}");
                throw;
            }

            await Task.CompletedTask;
        }
    }
}
