using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.Shipping.Business.Tests.Mapping;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;

namespace VM.FleetServices.TnR.Shipping.Business.Tests
{
    public class ShipmentTestDataFixture : IDisposable
    {
        public ShippingModel InMemoryShippingContext => GetInMemoryShippingContext();

        public void Dispose()
        {
        }
        public static object ThisLock = new object();
        private static ShippingModel GetInMemoryShippingContext()
        {
            // This will ensure one thread can access to this static initialize call
            // and ensure the mapper is reset before initialized
            lock (ThisLock)
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile<ShippingTestMappingProfile>();
                });
                var mapper = config.CreateMapper();
                //Mapper.Reset();
            }

            return new ShippingModel(new DbContextOptionsBuilder<ShippingModel>().UseInMemoryDatabase("Shipping")
                .EnableSensitiveDataLogging().Options);
        }
    }
}

