using AutoMapper;

namespace VM.FleetServices.TnR.Shipping.Business.Tests.Mapping
{
    public class ShippingTestMappingProfile : Profile
    {
        public ShippingTestMappingProfile()
        {
           
        }
    }
}
