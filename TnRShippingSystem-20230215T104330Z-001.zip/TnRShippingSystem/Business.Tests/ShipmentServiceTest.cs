using System;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Shipping.Business.ServiceBus;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using Xunit;
namespace VM.FleetServices.TnR.Shipping.Business.Tests
{
    public class ShipmentServiceTest : IClassFixture<ShipmentTestDataFixture>
    {
        private ShippingModel _shipmentContext;
        private readonly ShipmentTestDataFixture _fixture;
        private IServiceScopeFactory _serviceScopeFactory;
        private ILogger<ShipmentService> _logger;
        private readonly ShipmentService _inMemoryShipmentService;
        private readonly Mock<IObjectCache> _mockObjectCache;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<IOptions<CacheSettings>> _cacheSettingOptions;
        // private readonly Mock<DbContext> _Context;
        private readonly ILogService _mockLogService;
        private readonly IServiceBusService _mockServiceBusService;

        public ShipmentServiceTest(ShipmentTestDataFixture fixture)
        {
            _fixture = fixture;

            _shipmentContext = _fixture.InMemoryShippingContext;

            var serviceProvider = new ServiceCollection().AddLogging().BuildServiceProvider();

            var sProvider = new Mock<IServiceProvider>();
            sProvider.Setup(x => x.GetService(typeof(IShippingModel))).Returns(_shipmentContext);
      

            var sscope = new Mock<IServiceScope>();
            sscope.Setup(x => x.ServiceProvider).Returns(sProvider.Object);

            var ssFactory = new Mock<IServiceScopeFactory>();
            ssFactory.Setup(x => x.CreateScope()).Returns(sscope.Object);

            _mockObjectCache = new Mock<IObjectCache>();
            _cacheSettingOptions = new Mock<IOptions<CacheSettings>>();
            _mockMapper = new Mock<IMapper>();
            _mockLogService = new Mock<ILogService>().Object;
           _mockServiceBusService = new Mock<IServiceBusService>().Object;

            _inMemoryShipmentService = new ShipmentService(
                ssFactory.Object,
                serviceProvider.GetService<ILoggerFactory>().CreateLogger<ShipmentService>(), _mockObjectCache.Object, _cacheSettingOptions.Object, _mockMapper.Object, _mockLogService, _mockServiceBusService);


        }
        #region Create Receive Shipment

        [Fact]
        public async void ShipmentsServiceTest_CreateReceiveShipmentAsync()
        {
            var result = await _inMemoryShipmentService.CreateReceiveShipmentAsync(new ReceiveShipment
            {
                ReceivedDateTime = DateTime.Now,
                CourierId = 1,
                TrackingNumber = "123",
                Documents = 0,
                Active = true,
                UserName = "Test",
            });

            Assert.NotNull(result);
        }

        [Fact]
        public async Task ShipmentService_GetReceiveShipmentDataAsync_TestAsync()
        {
            var searchCriteria = new CreateReceiveShipmentRequestModel()
            {
                ClientCode = "Hertz",
                UserName = "FSAMSTESTUSER",
                PageNumber = 1,
                RowsPerPage = 25,
                StartDate = DateTime.Now.AddDays(-3),
                EndDate = DateTime.Now.AddDays(1)
            };

            var data = await _inMemoryShipmentService.GetReceiveShipmentDataAsync(searchCriteria);

            Assert.NotNull(data);
        }

        [Fact]
        public async Task ShipmentService_SubmitExportAllRequestAsync_TestAsync()
        {
            var searchCriteria = new CreateReceiveShipmentRequestModel()
            {
                UserName = "FSAMSTESTUSER",
                PageNumber = 1,
                RowsPerPage = 25,
                StartDate = DateTime.Now.AddDays(-3),
                EndDate = DateTime.Now.AddDays(1)
            };

            var data = await _inMemoryShipmentService.SubmitExportAllRequestAsync(searchCriteria);

            Assert.NotNull(data);
        }


        [Fact]
        public async Task ShipmentService_GetTrackingNumberAsync()
        {
            var model = new CourierPickupViewModel()
            {
                CourierId = 4,
                CourierName = "Airborne Express",
                NumberofForms = 1
            };

            var data = await _inMemoryShipmentService.GetTrackingNumber(model);

            Assert.NotNull(data);
        }

        #endregion
    }
}
