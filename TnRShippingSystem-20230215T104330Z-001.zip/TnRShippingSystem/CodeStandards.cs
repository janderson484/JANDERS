// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CodingStandards.cs" company="American Traffic Solutions, Inc.">
//   Copyright 2017 American Traffic Solutions, Inc.
// </copyright>
// <summary>
//   Code Standards sample class.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.IO;
//using System.Linq;
//using System.Web.UI;
//using System.Windows.Forms;

namespace VM.FleetServices.TnR.CodingStandards
{
    /// <summary>
    /// Formatting sample class.
    /// </summary>
    /// <remarks>
    /// Type declarations in a class must be ordered as follows:
    /// fields, Constructors, Events, enums, interfaces, properties, Methods, structs and classes.
    /// and from public to private. (public, internal, protected, private)
    /// </remarks>
    public class FormattingSamples
    {
        #region Resharper and Code Style
        // All code files must follow Resharper and EditorConfig rules. 
        // There should be no resharper errors or warnings. This is easily identified by a green resharper status bar.
        // Resharper and EditorConfig suggestions should be evaluated by the developer and decide if it make sense to follow or not.
        //
        // Resharper settings file: "Settings.Resharper.xml" 
        // EditorConfig settings file: ".editorconfig"
        //
        // Make sure you have the latest version of these two settings files.
        //
        // To import the settings files for resharper, go to ReSharper -> Options -> Code Style Sharing -> 
        // Select "Not Shared, applies to all solutions opened by current user". then Click "Import..." and select the resharper settings file.
        //
        // EditorConfig settings will be applied automatically on build.
        #endregion

        #region Assemblies & Files

        #region Assembly

        // The following assembly properties should be set: 
        // - AssemblyCopyright 
        // - AssemblyCompany 
        // - AssemblyTitle 
        // - AssemblyProduct

        // Assemblies should be named in the pattern<Company>.<Project>.<Component> where <Company> can be a set of dot separated names
        // - UpperCamelCase
        // - Example: Ats.FleetServices.TitleReg.Services

        // Common assembly name suffixes are:
        // - .Web - Web based project
        // - .Client - Non web related UI forms or controls
        // - .Services - Exposed services, orchestration for bsuiness logic
        // - .Domain or .Business - Business object models
        // - .Data or .DataAccess - Data access functionality
        // - .Tests or .UnitTests - Unit tests

        #endregion

        #region File Header

        // File must contain a file header with the Copyright notice as well as a summary of the file contents.

        // --------------------------------------------------------------------------------------------------------------------
        // <copyright file="FormattingSamples.cs" company="American Traffic Solutions, Inc.">
        //   Copyright 2010 American Traffic Solutions, Inc.
        // </copyright>
        // <summary>
        //   Formatting sample class.
        // </summary>
        // --------------------------------------------------------------------------------------------------------------------

        // File header must be followed by a single blank line.

        #endregion

        #region Files

        // Namespaces should be named consistently within the Assembly in the pattern<Company>.<Project>.<Component>.<Feature>.<Subfeature>
        // - UpperCamelCase
        // - Single Namespace per file.
        // - Must match file location.
        // - Example: Ats.FleetServices.TitleReg.Services.Vehicle...

        // Do not have more than one public type per file unless one is nested within the other.

        // Do not reference libraries unnecessarily

        // using statements to go at the top of the codefile right after the File header but outside (before) of the namespace
        // Order alphabetically, but with .NET BCL namespaces first:
        // - using System;
        // - using System.Collections.Generic;
        // - using System.Data;
        // - using Ats.Framework.Data;
        // - using SomeThirdPartyApplication;
        // followed by a single blank line.

        #endregion

        #endregion

        #region Format & Style

        #region Code Style

        // Each indentation should be 4 spaces (do not use tabs)

        // Use one blank line to separate groups of related statements

        // No space should exist between function name and parenthesis or between parenthesis and first parameter

        // A single space should be used after a comma

        // Do NOT put more than one statement on a single line

        // No lines should exist inside of brackets unless separating unrelated code

        // Single space should be used to separate operators

        // ANSI style braces should be used for control statements, methods, etc. (The brace should be on the following line and indented at the same level as the statement).

        // Use braces around single lines of code within a conditional statement

        #region Curly Braces/Code Blocks

        /// <summary>
        /// Always use curly braces, even when code block contains a single line.
        /// Opening brace starts at same position as previous line starts.
        /// curly braces appear on their own 
        /// closing curly brace must be followed by another closing brace or a blank space.
        /// </summary>
        public void CurlyBraces()
        {
            if (Go())
            {
                // Do something.
            }
            else
            {
                Go();
            }

            using (var reader = new StreamReader("some path"))
            {
                if (!reader.EndOfStream)
                {
                    // Do something.
                    Go();
                }
            }

            var counter = 0;
            do
            {
                // Do something.
                Go();
            }
            while (++counter < 100);
        }

        /// <summary>
        /// Go and do something.
        /// </summary>
        /// <returns>Returns a boolean value.</returns>
        public bool Go()
        {
            return true;
        }

        #endregion

        #region Comment Exmaple

        /// <summary>
        /// All classes and their members must be documented.
        /// </summary>
        public class Comments
        {
            #region XML comments

            /// <summary>
            /// Xml comemnts must be formatted as follows: 
            /// The summary tags should be on separate lines.
            /// </summary>
            /// <typeparam name="T">The typeparam tags should be single line.</typeparam>
            /// <param name="someInt">The param should be a single line.</param>
            /// <returns>The return method should be a single line.</returns>
            public T MyMethod<T>(T someInt)
            {
                return someInt;
            }

            /// <summary>
            /// Validates the format of a text line, and populates the data fields based on the pre-defined record format.
            /// </summary>
            /// <param name="inputRecord">The input record to process</param>
            public void ParseRecord(string inputRecord)
            {
                if (inputRecord.Length != 75)
                {
                    throw new ApplicationException(string.Format("Input record must be 75 chars, actual {0}", inputRecord.Length));
                }

                // Continue parsing and populating data
            }
            #endregion

            #region inline comments

            /// <summary>
            /// Two slashes, followed by one space, then the actual comment.  If broken out over
            /// multiple lines, then the start of the next line is still one space after the slashes.
            /// </summary>
            public void InLineComments()
            {
                var firstValue = 123;
                var secondValue = 492;

                firstValue *= 2;  // If short, can put at the end of a line
                secondValue /= 2;  // If short, can put at the end of a line

                var compare = firstValue.CompareTo(secondValue);

                switch (compare)
                {
                    case -1: // firstValue is less than secondValue
                        DoSomething();
                        break;

                    case 0: // firstValue is equal to secondValue
                        DoThat();
                        break;
                    case 1: // firstValue is greater than secondValue
                        DoThis();
                        break;
                }

                // If long, or commenting on an entire block of code (not just one line), 
                // then put it on the line before the start of the block followed by an empty line.

                // If the vehicle already exists, then we return it. If it doesn't exist, then we need to create it.
                if (VehicleExists())
                {
                    DoThis();
                }
                else
                {
                    DoThat();
                }
            }

            /// <summary>
            /// Do  this ..
            /// </summary>
            private static void DoThis()
            {
            }

            /// <summary>
            /// Do  that..
            /// </summary>
            private static void DoThat()
            {
            }

            /// <summary>
            /// Do something...
            /// </summary>
            private static void DoSomething()
            {
            }

            /// <summary>
            /// Check if vehicle exists.
            /// </summary>
            /// <returns>Returns a value indicating whether the vehicle exists.</returns>
            private static bool VehicleExists()
            {
                return true;
            }

            #endregion

            #region Block comments
            // Do not use in production code - if you have multi-line comments, then use the inline-comment syntax.
            #endregion
        }

        #endregion

        #endregion

        #region Naming Guidelines

        #region General Guidelines

        // Guidelines for naming types will typically fall under the rules of using PascalCasing or camelCasing.PascalCasing states that each word making up the type name 
        // must begin with a capital letter.On the other hand camelCasing states that the first word making up the type name is lowercase with each word thereafter beginning 
        // with an upper case.  If we take the variable name “ThisIsMyOnlyVariable”.  PascalCasing would be written simply as ThisIsMyOnlyVariable whereas camelCasing would 
        // be written as thisIsMyOnlyVariable.

        // Use meaningful English-readable names for identifiers

        // Use PascalCasing for all Class, Structure, Namespace, Enumeration, Enumeration Keys, Method, Public Property, Event, Delegate, Interface (prefixed with I), 
        // Public Constants, Generic Type Parameter and Resource Keys

        // Use camelCasing for Parameter, Non-Public Field and Variable

        // Do NOT use underscores, hyphens, or any other nonalphanumeric characters.

        // Do NOT use abbreviations or Acronyms for identifiers with the exception of the list following in the next section

        // Acceptable abbreviation and capitalization list.
        // - ID => as a suffix use "Id" (e.g.CustomerId)
        // - XML => as a suffix use "Xml" (e.g.CustomerDataXml)
        // - SQL => as a suffix use "Sql" (e.g.insertCustomerSql)
        // - DataSet => as a suffix(e.g.customerDataSet)

        // Do NOT use language specific names within code.

        // Exception Message resources should be the exception type followed by the identifier

        // Common name suffixes include:
        // - List => use on List<T>(e.g.List<Account> accountList =...)

        #endregion

        #region Classes and Structs

        // Name classes and structs with nouns or noun phrases, using PascalCasing

        // Name interfaces with adjective phrases or nouns or noun phrases

        // Do NOT give class names a prefix such as “C”

        // End the name of derived classes with the name of the base class

        // Prefix Interfaces with an “I” to indicate an interface

        // Generic Type parameters should be a “T” if a single parameter exists or if multiple exist, each should be prefixed with a “T”

        // Use a singular type name for an enumeration unless its values are bit fields, then pluralize the name

        // Do NOT use “Enum” or “Flag” as the suffix of the enumeration name

        /// <summary>
        /// Classes should be UpperCamelCase with no underscores in the name.
        /// Classes may begin with an "I" only if the letter following the I is not capitalized, otherwise it looks like an Interface. 
        /// Classes should not have the same name as the namespace in which they reside. 
        /// Any acronyms should be UpperCamelCase case, not all caps. Try to avoid abbreviations, and try to always use nouns.
        /// </summary>
        /// <remarks>
        /// All class members (fields, properties, methods, events, delegates, inner types, etc.) must declare visibility (public,
        /// private, protected, internal, protected internal) - never use the "default" visibility
        /// </remarks>
        public class ClassNamingRules
        {
            /// <summary>
            /// Structs must be named UpperCamelCase
            /// </summary>
            public struct Player
            {
                /// <summary>
                /// Gets or sets player's age.
                /// </summary>
                public int Age { get; set; }
            }

            /// <summary>
            /// Defines the BaseballTeam type.
            /// </summary>
            public class BaseballTeam
            {
                /// <summary>
                /// Gets or sets the Team name.
                /// </summary>
                public string TeamName { get; set; }
            }

            #region Acronyms/Abbreviations
            /// <summary>
            /// Acronyms always capitalize first letter, the rest are lowercase.
            /// Try to Avoid abbreviations when possible.
            /// This class should be named FleetVehicleOwner and not Fvo
            /// </summary>
            public class FleetVehicleOwner
            {
                /// <summary>
                /// Acronyms/abbreviations always capitalize first letter, the rest are lowercase.
                /// </summary>
                /// <param name="fvoId">The fvo Id.</param>
                public void GetFvo(long fvoId)
                {
                }
            }
            #endregion
        }

        #endregion

        #region Type Members

        // Name methods and Events with verb or verb phrases, using PascalCasing.

        // Name properties with nouns or noun phrases, using PascalCasing.

        // Name Boolean properties with an affirmative phrase.

        // Common affirmative prefixes for Booleans include:
        // - is => for bools (e.g.isActive)
        // - has => for bools (e.g.hasChildren)
        // - can => for bools (e.g.canWithdrawFunds)
        // - use => for bools (e.g.useAllAccounts)
        // - numberOf => for ints (e.g.numberOfChildren)

        // Name events with the concept of before and after.

        // Name event handlers with the “EventHandler” suffix.

        // Use two parameters in event handlers, which are “sender” (object) and “e” (EventArgs)

        #endregion

        #endregion

        #region Formatting Rules Sample

        /// <summary>
        /// Code Formatting rules.
        /// </summary>
        /// <remarks>
        /// Set code editor to use spaces, not tabs, for all file types (C#, HTML, CSS, etc.)
        /// Indenting must be set to 4 spaces.
        /// </remarks>
        public class CodeFormattingRules
        {
            #region Object Initializers
            /// <summary>
            /// When possible use object initializers. 
            /// Object initializers must apper all in the same line or each on it's own line.
            /// </summary>
            public void ObjectInitializers()
            {
                // Simple ones can go on the same line
                var team = new ClassNamingRules.BaseballTeam { TeamName = "DiamondBacks" };

                int[] someInts = { 1, 2, 3, 4, 5 };

                // Complex or long ones put opening curly brace indented 4 spaces from start of previous line, with items indented 4 more spaces
                ClassNamingRules.BaseballTeam[] teams =
                {
                    new ClassNamingRules.BaseballTeam { TeamName = "DiamondBacks" },
                    new ClassNamingRules.BaseballTeam { TeamName = "Yankees" },
                    new ClassNamingRules.BaseballTeam { TeamName = "Padres" }
                };

                var playersByTeam = new Dictionary<ClassNamingRules.BaseballTeam, int>
                {
                    { teams[0], 25 },
                    { teams[1], 24 },
                    { teams[2], 26 }
                };

                Console.WriteLine(team.TeamName);

                foreach (var i in someInts)
                {
                    Console.WriteLine(i);
                }

                foreach (var players in playersByTeam)
                {
                    Console.WriteLine("Team: {0} Players: {1}", players.Key.TeamName, players.Value);
                }
            }
            #endregion

            #region LINQ queries
            /// <summary>
            /// Line up keywords (from/where/select/etc.)
            /// </summary>
            public void LinqQueries()
            {
                int[] someInts = { 1, 2, 3, 4, 5 };
                var teams = new List<ClassNamingRules.BaseballTeam>();

                // Line up keywords (from/where/select/etc.)
                var q = from t in teams
                        where t.TeamName == "DiamondBacks"
                        select t;

                foreach (var baseballTeam in q)
                {
                    Console.WriteLine(baseballTeam.TeamName);
                }

                // Line up keywords (from/where/select/etc.)
                var q1 = (from i in someInts
                          where i < 4
                          select i).ToList();

                foreach (var number in q1)
                {
                    Console.WriteLine(number);
                }
            }
            #endregion

            #region Long code lines
            /// <summary>
            /// If line is too long and needs to be broken up, indent code 4 spaces from start of previous line
            /// Do not line up parameters vertically
            /// </summary>
            /// <param name="firstParameter">the first Parameter</param>
            /// <param name="secondParameter">the second Parameter</param>
            /// <param name="thirdParameter">the third Parameter</param>
            /// <param name="firstName">the firstName</param>
            /// <param name="lastname">the lastname</param>
            /// <param name="middleName">the middleName</param>
            /// <param name="dateOfBirth">the dateOfBirth</param>
            /// <param name="height">the height</param>
            /// <param name="addressLine1">the addressLine1</param>
            /// <param name="addressLine2">the addressLine2</param>
            /// <param name="city">the city parameter</param>
            /// <param name="state">the state parameter</param>
            /// <param name="country">the country parameter</param>
            /// <param name="zipCode">the zipCode</param>
            /// <param name="phoneNumber">the phoneNumber</param>
            /// <param name="socialSecurityNumber">the socialSecurityNumber</param>
            public void ThisMethodHasAnAwfulLotOfParameters(
                int firstParameter,
                string secondParameter,
                double thirdParameter,
                string firstName,
                string lastname,
                string middleName,
                DateTime dateOfBirth,
                int height,
                string addressLine1,
                string addressLine2,
                string city,
                string state,
                string country,
                string zipCode,
                string phoneNumber,
                string socialSecurityNumber)
            {
            }

            /// <summary>
            /// method calls must have all parameters in one line, or each parameter on a separate line
            /// </summary>
            public void CallThatRidiculouslyLongMethod()
            {
                // either all parameters appear on one line
                ThisMethodHasAnAwfulLotOfParameters(1, "abc", 3.14, "John", "Doe", "Quincy", new DateTime(1950, 1, 1), 72, "1234 West East Street", null, "Phoenix", "AZ", "USA", "85001", "6025551212", "123-45-6789");

                // or each parameter on one line:
                ThisMethodHasAnAwfulLotOfParameters(
                    1,
                    "abc",
                    3.14,
                    "John",
                    "Doe",
                    "Quincy",
                    new DateTime(1950, 1, 1),
                    72,
                    "1234 West East Street",
                    null,
                    "Phoenix",
                    "AZ",
                    "USA",
                    "85001",
                    "6025551212",
                    "123-45-6789");
            }
            #endregion

            #region C# keywords/types
            // use C# keywords instead of type names on built-in data types
            // byte, short, int, long, float, double, decimal, char, string, bool
            // instead of
            // Byte, Int16, Int32, Int64, Single, Double, Decimal, Char, String, Boolean
            #endregion

            #region var
            /// <summary>
            /// Use var when possible.
            /// </summary>
            public void UseVar()
            {
                var i = 123;
                i *= 2;
                Console.WriteLine("New value of i = {0}", i);

                var homeTeam = new ClassNamingRules.BaseballTeam();
                Console.WriteLine(homeTeam.TeamName);

                var teams = new List<ClassNamingRules.BaseballTeam>();
                foreach (var team in teams)
                {
                    Console.WriteLine(team.TeamName);
                }
            }
            #endregion

            #region this
            // Never call this.Anything  
            // If members are named properly, then there will never be any conflict with names.
            #endregion

            #region strings
            // Use string.Empty instead of ""
            // Use StringBuilder instead of +=
            // Use string.IsNullOrEmpty or string.IsNullOrWhiteSpace (.NET 4.0) instead of ((s == null) || (s == string.Empty))
            // Use string.Format instead of "Hello, my name is " + myName + ", how are you?"
            #endregion

            #region DateTime
            // Never call simple ToString() (with no parameters), ToShortDateString(), ToLongDateString(), etc.
            // When formatting a DateTime, always provide the specific format you want to output, since not all machines are set up the same.
            #endregion

            #region Inheritance/Implementation/Generic constraints
            /// <summary>
            /// Put base class/interface/constraint on new line, indented 4 spaces from start of previous line
            /// Separate multiple base class/interfaces, or multiple type constraints for the same type parameters, with commas on same line
            /// Separate multiple generic constraints for different type parameters on new lines
            /// </summary>
            /// <typeparam name="TKey">typeparameter TKey</typeparam>
            /// <typeparam name="TValue">typeparameter TValue</typeparam>
            public class SomeChildClass<TKey, TValue>
                : TextBox, InterfaceRules.ITeam
                where TKey : class, new()
                where TValue : InterfaceRules.ITeam
            {
                /// <summary>
                /// Some method that uses TKey and TValue.
                /// </summary>
                /// <param name="key">The Key parameter</param>
                /// <param name="value">The value parameter.</param>
                public void SomeMethod(TKey key, TValue value)
                {
                }
            }
            #endregion

            #region Properties
            /// <summary>
            /// Use AutoProperties when possible. 
            /// AutoProperties all on the same line
            /// Simple getters/setters on one line
            /// Complex/long getters/setters fully formatted
            /// </summary>
            public class Properties
            {
                /// <summary>
                /// some private field for a property
                /// </summary>
                private string _someField;

                /// <summary>
                /// Gets or sets the value of the private field.
                /// </summary>
                public string SomeOtherProperty
                {
                    // Simple getters/setters on one line
                    get { return _someField.Trim(); }
                    set { _someField = value ?? string.Empty; }
                }

                /// <summary>
                /// Gets or sets some property value..
                /// Auto properties on a single line.
                /// </summary>
                public int SomeProperty { get; set; }

                /// <summary>
                /// Gets or sets a property value.
                /// </summary>
                public int SomeInteger
                {
                    // Complex/long getters/setters fully formatted
                    get
                    {
                        // do something
                        return 0;
                    }

                    set
                    {
                        if (value < 0)
                        {
                            throw new ApplicationException("BLAH");
                        }

                        Console.WriteLine(value);
                    }
                }
            }
            #endregion
        }

        #endregion

        #endregion

        #region Delegates

        /// <summary>
        /// Follow class naming conventions <seealso cref="ClassNamingRules"/>, but add Delegate or EventHandler to the end of the name.
        /// </summary>
        public class DelegateNamingRules
        {
            /// <summary>
            /// All delagetes not used as Event Handlers should end in Delegate.
            /// </summary>
            public delegate void CalculateStatisticDelegate();

            /// <summary>
            /// all delegate used for event handling should have a name ending on 'EventHandler' and should be of type void. <seealso cref="EventNamingRules"/>
            /// Delegates that are not of type void are not suitable for multicasting and therefore not suitable for event handling.
            /// </summary>
            /// <param name="sender">always named sender</param>
            /// <param name="e">always named e</param>
            public delegate void StartGameEventHandler(object sender, EventArgs e);
        }

        #endregion

        #region Exceptions
        /// <summary>
        /// Follow class naming conventions <seealso cref="ClassNamingRules"/>, but add Exception to the end of the name.
        /// </summary>
        public class ExceptionNamingRules
        {
            /// <summary>
            /// Custom Exception.
            /// </summary>
            public class InvalidArgumentException : Exception
            {
                /// <summary>
                /// Initializes a new instance of the <see cref="InvalidArgumentException"/> class. 
                /// </summary>
                /// <param name="argumentName">name of invalid argument</param>
                public InvalidArgumentException(string argumentName)
                    : base(string.Format("Invalid argument {0}", argumentName))
                {
                }
            }

            /// <summary>
            /// When catching exceptionsm always name the exception ex inside the catch clause.
            /// </summary>
            public class ExeptionHandlingRules
            {
                /// <summary>
                /// To re-throw an exception use throw; do not use throw ex;
                /// </summary>
                public void HowToReThrowExceptions()
                {
                    try
                    {
                        // do something.
                        var x = string.Format("do something");
                        Console.WriteLine(x);
                    }
                    catch (Exception ex)
                    {
                        // do something with exception, such as logging/tracing.
                        Debug.Write(ex);

                        throw; // this is the right way to rethrow exception. Do not use throw ex;
                    }
                }
            }
        }
        #endregion

        #region Attributes
        /// <summary>
        /// Follow class naming conventions <seealso cref="ClassNamingRules"/>, but add Attribute to the end of the name.
        /// </summary>
        public class AttributeNamingRules
        {
            /// <summary>
            /// Team color attribute.
            /// </summary>
            public class TeamColorsAttribute : Attribute
            {
            }

            /// <summary>
            /// When applying an attribute to a class/method/property/etc. leave off the "Attribute" portion of the attribute name.
            /// So for the above attribute use [TeamColors] and not [TeamColorsAttribute]
            /// </summary>
            /// <remarks>
            /// this applies to system attributes as well, for example, [Serializable] instead of [SerializableAttribute]
            /// </remarks>
            [TeamColors]
            public class UsingTheAttribute
            {
            }
        }

        #endregion

        #region Interfaces
        /// <summary>
        /// Follow class naming conventions <seealso cref="ClassNamingRules"/>, but start the name with "I" and capitalize the letter following the "I"
        /// </summary>
        /// <remarks>
        /// A well-designed interface defines a very specific range of functionality. Split up interfaces that contain unrelated functionality.
        /// </remarks>
        public class InterfaceRules
        {
            /// <summary>
            /// Interfaces must be named UpperCameCase preceded by I.
            /// </summary>
            public interface ITeam
            {
            }
        }
        #endregion

        #region Enums
        /// <summary>
        /// Follow class naming conventions <seealso cref="ClassNamingRules"/>. Do not add "Enum" to the end of the enumeration name. 
        /// If the enumeration represents a set of bitwise flags, end the name with a plural (and the Attribute [Flags].) otherwise it should be singular.
        /// </summary>
        public class EnumRules
        {
            /// <summary>
            /// Team player position. 
            /// </summary>
            public enum Position
            {
                FirstBase,
                SecondBase,
                ShortStop
            }

            /// <summary>
            /// Enums for flags bitwise should be plural and have the [Flags] attribute.
            /// </summary>
            [Flags]
            public enum GameDays
            {
                None = 0,
                Sunday = 1,
                Monday = 2,
                Tuesday = 4,
                Wednesday = 8,
                Thursday = 16,
                Friday = 32,
                Saturday = 64
            }

            /// <summary>
            /// When using enums to define bit flags, the enum must be decorated with the [Flags] attribute.
            /// </summary>
            public void TestFlags()
            {
                var days = GameDays.Monday | GameDays.Wednesday | GameDays.Friday;
                Console.WriteLine(days);

                days = GameDays.None;
                Console.WriteLine(days);
            }

            /// <summary>
            /// Don't assume that enums can only have defined values and that the set of defined values will never change.
            /// When using in a switch statement you must check for an invalid or unexpected enum value.
            /// </summary>
            /// <param name="position">position enum value.</param>
            public void UsingEnumsInSwitchStatement(Position position)
            {
                switch (position)
                {
                    case Position.FirstBase:
                        break;

                    case Position.SecondBase:
                        break;

                    case Position.ShortStop:
                        break;

                    default:
                        // always check for an invalid or unexpected enum value.
                        throw new ExceptionNamingRules.InvalidArgumentException("position");
                }
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// UpperCamelCase with no underscores except for event handlers <seealso cref="EventNamingRules"/>.
        /// Parameters are lowerCaseCamel, no underscores.
        /// </summary>
        public class MethodNamingRules
        {
            /// <summary>
            /// Methods are UpperCaseCamel. 
            /// Parameters are lowerCaseCamel
            /// </summary>
            /// <param name="numberOfTeamsPlaying">Number of teams playing</param>
            /// <param name="homeTeam">The hometeam</param>
            /// <param name="awayTeam">The visiting team.</param>
            public void PlayBall(int numberOfTeamsPlaying, ClassNamingRules.BaseballTeam homeTeam, ClassNamingRules.BaseballTeam awayTeam)
            {
                // play ball!
            }
        }
        #endregion

        #region Events, EventHandlers and EventArgs
        /// <summary>
        /// Events must be UperCamelCase.
        /// Event handlers must be named as "{object}_{Event}"
        /// </summary>
        public class EventNamingRules
        {
            /// <summary>
            /// all delegate used for event handling should have a name ending on 'EventHandler' and should be of type void. <seealso cref="DelegateNamingRules"/>
            /// </summary>
            /// <param name="sender">always named sender</param>
            /// <param name="e">always named e. The type of e can be the be the system EventArgs or a custom EventArg class <seealso cref="StartGameEventArgs"/>.</param>
            public delegate void StartGameEventHandler(object sender, StartGameEventArgs e);

            /// <summary>
            /// Events must be UperCamelCase. The type for the event must be the system "EventHandler" delegate or a custom EventHandler delegate.
            /// </summary>
            public event StartGameEventHandler GameStart;

            /// <summary>
            /// To add a handler to an event, use the += assignment operator:
            /// </summary>
            /// <remarks>
            /// Do not include the explicit delegate creation, so instead of this:
            /// <code>GameStart += new StartGameEventHandler(EventRules_GameStarted);</code>
            /// do this:
            /// <code>GameStart += EventRules_GameStarted;</code>
            /// </remarks>
            public void AddHandler()
            {
                GameStart += EventRules_GameStarted;
            }

            /// <summary>
            /// To remove a handler from an event, use the -= assignement operator:
            /// </summary>
            public void RemoveHandler()
            {
                GameStart -= EventRules_GameStarted;
            }

            /// <summary>
            /// Although not required, it is a good practice to create a protected virtual On{EventName} method for your events:
            /// </summary>
            /// <remarks>
            /// You then call this method whenever you want to trigger the event: <code>OnGameStart(new StartGameEventArgs());</code>
            /// </remarks>
            /// <param name="e">EventArgs param is always named e</param>
            protected virtual void OnGameStart(StartGameEventArgs e)
            {
                // check if event was subscribed to..
                if (GameStart != null)
                {
                    // call eventhandler(s).
                    GameStart(this, e);
                }
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="EventNamingRules"/> class. 
            /// </summary>
            protected void StartGame()
            {
                // trigger game start event.
                OnGameStart(new StartGameEventArgs());

                // Do Game stuff...

                // trigger game end event.
                // OnGameEnd(new EndGameEventArgs());
            }

            /// <summary>
            /// The event handler must be named {object}_{event}
            /// </summary>
            /// <param name="sender">always named sender</param>
            /// <param name="e">always named e</param>
            private static void EventRules_GameStarted(object sender, StartGameEventArgs e)
            {
                var value = e.SomeValue;
                Console.WriteLine(value);
            }

            /// <summary>
            /// Event Arg classes must be containt the sufix EventArgs
            /// </summary>
            public class StartGameEventArgs : EventArgs
            {
                // Provide one or more constructors, as well as fields and
                // accessors for the arguments.

                /// <summary>
                /// Gets or sets this value.
                /// </summary>
                public int SomeValue { get; set; }
            }
        }
        #endregion

        #region Constants
        /// <summary>
        /// All constant fields must be UPPER_CASE. These can be either be public or private.
        /// Constants should only be used for strings, dates and numbers (including enum values).
        /// static readonly can be used instead of const but only for dates.
        /// static readonly references to any other type should not be considered a constant.
        /// </summary>
        /// <remarks>
        /// Consider using only private Constants, and expose them as Properties if needed.
        /// </remarks>
        public class ConstantNamingRules
        {
            /// <summary>
            /// String constant.
            /// </summary>
            public const string FENWAY_PARK = "Fenway Park";

            /// <summary>
            /// Date constant. 
            /// </summary>
            /// <remarks>DateConstnats should use static readonly instead of const.</remarks>
            public static readonly DateTime STADIUM_COMPLETED_DATE = new DateTime(2004, 3, 14);

            /// <summary>
            /// Constant number. 
            /// </summary>
            private const int NUMBER_OF_POSITION_PLAYERS = 9;

            /// <summary>
            /// Constant to an enum value.
            /// </summary>
            private const EnumRules.Position DEFAULT_POSITION = EnumRules.Position.FirstBase;

            /// <summary>
            /// Gets the number of positions from private constant.
            /// </summary>
            public int NumberOfPositionPlayers
            {
                get { return NUMBER_OF_POSITION_PLAYERS; }
            }

            /// <summary>
            /// Gets the number of positions from private constant.
            /// </summary>
            public EnumRules.Position DefaultPosition
            {
                get { return DEFAULT_POSITION; }
            }
        }
        #endregion

        #region Fields
        /// <summary>
        /// Private Fields must be named _lowerCamelCase.
        /// All Fields must be private (or protected). Use Public properties to expose them if needed.
        /// </summary>
        public class FieldRules
        {
            /// <summary>
            /// Public ReadOnly should be UpperCaseCamel.
            /// </summary>
            /// <remarks>You should consider using a Private ReadOnly and expose it with a Public property.</remarks>
            private readonly int _numberOfPlayers;

            /// <summary>
            /// Private Static Fields should be _lowerCamelCase.
            /// </summary>
            private static readonly TraceSource _trace = new TraceSource("test");

            /// <summary>
            /// Private Fields should be _lowerCamelCase.
            /// </summary>
            private int _fansInAttendance;

            /// <summary>
            /// Initializes a new instance of the <see cref="FieldRules"/> class. 
            /// </summary>
            public FieldRules()
            {
                _numberOfPlayers = 9;
            }

            /// <summary>
            /// Use some private fields.
            /// </summary>
            public void UsePrivateFields()
            {
                _fansInAttendance = 12000;
                Console.WriteLine(_fansInAttendance);
                Console.WriteLine(_numberOfPlayers);

                _trace.TraceInformation("Hello");
            }
        }
        #endregion

        #region Properties
        /// <summary>
        /// Properties must be UpperCaseCamel. No underscores.
        /// </summary>
        /// <remarks>
        /// Use AutoProperties when possible. 
        /// </remarks>
        public class PropertyNamingRules
        {
            /// <summary>
            /// Gets or sets the property's value.
            /// </summary>
            public ClassNamingRules.BaseballTeam HomeTeam { get; set; }
        }
        #endregion

        #region Local variables
        /// <summary>
        /// Local Fields should all be loweCamelCase except local constants that should follow <seealso cref="ConstantNamingRules"/>.
        /// </summary>
        public class LocalVariablesNamingRules
        {
            /// <summary>
            /// Define some local variables.
            /// </summary>
            public void Go()
            {
                var playerCount = 0;
                var homeTeam = new ClassNamingRules.BaseballTeam();

                // Constants still UPPER_WITH_UNDERSCORES
                const int NUMBER_ONE = 1;

                // use local variables.
                playerCount++;
                Console.WriteLine("{0}, {1}, {2}", playerCount, homeTeam.TeamName, NUMBER_ONE);
            }

            #region Simple LINQ/Lambda queries/loops
            /// <summary>
            /// Can use (1-or-2)-letter variables only when it is short and clear what it is, and the scope is very small
            /// If not straightforward, or if scope is not small, use more descriptive name
            /// </summary>
            protected void DoThis()
            {
                Action<int> someAction = i => Console.WriteLine(i);

                int[] someInts = { 1, 2, 3, 4 };

                // Notice that "i" is only alive in the scope of this LINQ query
                var someLinqQuery = from i in someInts
                                    where i < 3
                                    select i;

                // Notice that "i" is only alive in the scope of this loop
                foreach (var i in someLinqQuery)
                {
                    someAction(i);
                }

                const int NUM_DAYS_IN_MARCH = 31;

                // This is not a straightforward for-loop counter, so using more descriptive name
                for (var dayOfMonth = 1; dayOfMonth <= NUM_DAYS_IN_MARCH; dayOfMonth++)
                {
                    var dt = new DateTime(2010, 3, dayOfMonth);
                    Console.WriteLine(dt.ToString("yyyy\\-MM\\-dd"));
                }
            }
            #endregion
        }
        #endregion

        #region Type Parameters
        /// <summary>
        /// Typeparameters must always start with the letter T followed by the UpperCamelCase name for the type..
        /// When a class uses a single typeparameter, using simply T is acceptable.
        /// </summary>
        public class TypeParameterNamingRules
        {
            /// <summary>
            /// For single type parameters, "T" is acceptable
            /// </summary>
            /// <typeparam name="T">TypeParameters must start with T</typeparam>
            public class DoThat<T>
            {
                /// <summary>
                /// Use T from class in method.
                /// </summary>
                /// <param name="a">So something with a.</param>
                /// <returns>Returns a.</returns>
                public T Now(T a)
                {
                    return a;
                }
            }

            /// <summary>
            /// When more than one type, then always use T followed by more descriptive name
            /// </summary>
            /// <typeparam name="TKey">TypeParameters must start with T: TKey</typeparam>
            /// <typeparam name="TValue">TypeParameters must start with T: TValue</typeparam>
            public class CustomDictionary<TKey, TValue>
            {
                /// <summary>
                /// Use TKey and TValue in a method.
                /// </summary>
                /// <param name="key">the key parameter.</param>
                /// <param name="value">the value parameter.</param>
                public void Add(TKey key, TValue value)
                {
                    // save key and value..
                }
            }
        }
        #endregion
    }
}
