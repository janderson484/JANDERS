using Ats.FleetServices.Core.Data;
using AutoMapper;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Net.Http;
using VM.FleetServices.TnR.Core.Common.Cache;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Core.Common.SignalR;
using VM.FleetServices.TnR.Shipping.Api.Security;
using VM.FleetServices.TnR.Shipping.Business;
using VM.FleetServices.TnR.Shipping.Business.Integrations;
using VM.FleetServices.TnR.Shipping.Business.Mapping;
using VM.FleetServices.TnR.Shipping.Business.ServiceBus;
using VM.FleetServices.TnR.Shipping.Data.ShippingModel;

namespace VM.FleetServices.TnR.Shipping.Api
{
    public class Startup
    {
        private readonly IConfiguration _config;
        private readonly IWebHostEnvironment _env;
        private readonly ILoggerFactory _loggerFactory;


        public Startup(IWebHostEnvironment env, IConfiguration config, ILoggerFactory loggerFactory)
        {
            _config = config;
            _env = env;
            _loggerFactory = loggerFactory;
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddRazorPages();

            services.Configure<IISOptions>(options =>
            {
                options.AutomaticAuthentication = false;
                options.ForwardClientCertificate = false;
            });
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddHttpClient();

            services.AddSingleton<IDiscoveryCache>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();
                return new DiscoveryCache(
                    Configuration.GetSection("OpenIdSettings")["Authority"],
                    () => factory.CreateClient());
            });

            // Auto Mapper Configurations
            var mapperConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new ShippingMappingProfile());
            });

            IMapper mapper = mapperConfig.CreateMapper();
            services.AddSingleton(mapper);
            services.AddAutoMapper(typeof(Startup));

            // claims transformer will load claims from UserInfo endpoint if not provided in Access Token.
            services.AddSingleton<IClaimsTransformation, UserManagerClaimsTransformer>();

            // Register the IConfiguration instance which MyOptions binds against.
            services.Configure<OpenIdSettings>(options => _config.GetSection("OpenIdSettings").Bind(options));
            services.AddSendServiceBusService(_config.GetSection("ServiceBusOptions"));
            services.Configure<CacheSettings>(options => _config.GetSection("CacheSettings").Bind(options));           

            // Configure DbContext & EF cache service.. (All items accessing DbContext must be 'Scoped'                  
            services.AddDbContext<ShippingModel>(options =>
            {
                options.UseSqlServer(_config.GetConnectionString("ShippingModel"));
                //.EnableQueryCache(settings => _config.GetSection("EFQueryCacheSettings").Bind(settings));
                if (_env.EnvironmentName.Equals("Development"))
                    options.EnableSensitiveDataLogging();
            });

            services.AddScoped<IApiClientService, ApiClientService>();


            

            services.AddScoped<IShippingModel>(provider => provider.GetService<ShippingModel>());
            services.AddScoped<IDbModelFactory<IShippingModel>, ShippingModelFactory>();
            services.AddScoped<INotificationService, NotificationService>();
            services.AddScoped<IShipmentService, ShipmentService>();
            services.AddScoped<ILogService, LogService>();


            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddSingleton<IServiceBusService, ServiceBusService>();          

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30);
            });

            // cache in memory
            services.AddMemoryCache();
            // caching response for middlewares
            services.AddResponseCaching();

            services.AddDistributedRedisCache(option =>
            {
                option.Configuration = _config.GetConnectionString("TnrDistributedCache");
                option.InstanceName = "TnrSharedRedisCache";
            });

            services.AddTransient<IObjectCache, ObjectCache>();

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
           .AddJwtBearer(o =>
           {
               o.Authority = _config.GetSection("OpenIdSettings").GetValue<string>("Authority");
               o.Audience = "fstnrshippingapi"; // TODO: Audience needs to be updated
               o.RequireHttpsMetadata = false;
           });

            // Configure security policies
            services.ConfigureSecurityPolicies();
            services.AddApplicationInsightsTelemetry(_config);

            //Configure SignalR
            services.AddSignalR();

            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
                builder
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                .WithOrigins("https://localhost:3015");
            }));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.EnvironmentName.Equals("Development"))
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseSession();

            app.UseAuthentication();
            app.UseRouting();
            app.UseAuthorization();
            // caching response for middlewares
            app.UseResponseCaching();
            app.UseHttpsRedirection();
            app.UseCors("CorsPolicy");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<NotificationHub>("/notificationHub");
                endpoints.MapControllerRoute("default", "{controller=Api}/{action=Index}/{id?}");
            });
        }
    }
}
