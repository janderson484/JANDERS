namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    public class ClientApplicationAccessResource
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="role"></param>
        /// <param name="applicationType"></param>
        /// <param name="clientCode"></param>
        public ClientApplicationAccessResource(string role, string applicationType, string clientCode)
        {
            Role = role;
            ApplicationType = applicationType;
            ClientCode = clientCode;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ApplicationType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ClientCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Role { get; set; }
    }
}
