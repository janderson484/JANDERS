// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApplicationAccessRouteAuthorizationHandler.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//   Checks for a valid ClientCode, role to be present for the controller name in the Request.
// </summary>
// --------------------------------------------------------------------------------------------------------------------


using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    public class ApplicationAccessRouteAuthorizationHandler : AuthorizationHandler<ApplicationAccessRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        /// <summary>
        /// TNR Processing
        /// </summary>
        private const string TNRROLE = "TNR-SHIPPING";

        public ApplicationAccessRouteAuthorizationHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ApplicationAccessRequirement requirement)
        {
            var clientCode = _httpContextAccessor.HttpContext.Request.GetClientCode();
            if (string.IsNullOrEmpty(clientCode))
                return Task.CompletedTask;

            var path = _httpContextAccessor.HttpContext.Request.Path.Value;

            if (string.IsNullOrEmpty(path))
                return Task.CompletedTask;

            var pathSplit = path.Split("/");

            if (pathSplit == null || pathSplit.Length < 2)
                return Task.CompletedTask;

            //Commenting the below code and hardcoding the controller name 
            var applicationType = pathSplit[2]; // get the controller name from httpcontext request.           

            //if (string.IsNullOrEmpty(applicationType))
            //    return Task.CompletedTask;

            var roles = requirement.Role.Split(",");

            for (var i = 0; i < roles.Length; i++)
            {
                var role = roles[i].ToUpper();
                roles[i] = (role == "SUPERVISOR" || role == "ADMIN") ? $"{TNRROLE}-{role}".ToUpper() : $"{applicationType}-{roles[i]}".ToUpper();
            }                        

            // non-admin client
            if (roles.Select(role => context.User.GetClientRight(clientCode, role)).Any(right => right != null))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;

        }
    }
}
