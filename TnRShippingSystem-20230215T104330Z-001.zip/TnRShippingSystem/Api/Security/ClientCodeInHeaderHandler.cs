// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClientCodeInHeaderHandler.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//  Checks for a valid ClientCode to be present in Request Headers.
// </summary>
// --------------------------------------------------------------------------------------------------------------------


using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    /// <summary>
    /// Checks for a valid ClientCode to be present in Request Headers. 
    /// </summary>
    public class ClientCodeInHeaderHandler : AuthorizationHandler<ClientCodeRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// Creates a new instance of ClientCodeInHeaderHandler
        /// </summary>
        /// <param name="httpContextAccessor">provides access to HttpContext to get request headers.</param>
        public ClientCodeInHeaderHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Checks for a valid ClientCode to be present in Request Headers. 
        /// ClientCode from Header is checked against user's ClientList claim.
        /// </summary>
        /// <param name="context">authorization context</param>
        /// <param name="requirement">ClientCodeRequirement object</param>
        /// <returns>Task</returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ClientCodeRequirement requirement)
        {          
            var clientCode = _httpContextAccessor.HttpContext.Request.GetClientCode();
            if (!string.IsNullOrEmpty(clientCode))
            {
                var clientList = context.User.GetClientList();
                if (clientList.Any(t => t.Code.Equals(clientCode)))
                {
                    context.Succeed(requirement);
                }
            }
            return Task.CompletedTask;
        }
    }
}
