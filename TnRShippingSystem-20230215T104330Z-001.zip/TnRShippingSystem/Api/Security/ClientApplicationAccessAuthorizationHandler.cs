// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClientApplicationAccessAuthorizationHandler.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//   Checks for a valid ClientCode, application, role to be present in the Request.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    public class ClientApplicationAccessAuthorizationHandler : AuthorizationHandler<ClientApplicationAccessRequirement, ClientApplicationAccessResource>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// Creates a new instance of AssetActionAuthorizationHandler
        /// </summary>
        /// <param name="httpContextAccessor">provides access to HttpContext to get request headers.</param>
        public ClientApplicationAccessAuthorizationHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Checks for a valid Client Role in users Claims. 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ClientApplicationAccessRequirement requirement, ClientApplicationAccessResource resource)
        {
            var clientCode = _httpContextAccessor.HttpContext.Request.GetClientCode();           

            if (string.IsNullOrEmpty(clientCode))
                return Task.CompletedTask;

            var roles = resource.Role.Split(",");

            foreach (var role in roles)
            {
                var rightName = $"{resource.ApplicationType}-{resource.Role}".ToUpper();
                var right = context.User.GetClientRight(clientCode, rightName);
                if (right != null)
                {
                    context.Succeed(requirement);
                    break;
                }
            }
            
            return Task.CompletedTask;
        }

    }
}
