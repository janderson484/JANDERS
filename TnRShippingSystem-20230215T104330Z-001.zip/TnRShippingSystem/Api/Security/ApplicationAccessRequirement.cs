// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApplicationAccessRequirement.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//   This class contains valid role/right for current application  
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{

    /// <summary>
    /// Requires a valid role/right for current Application.
    /// </summary>
    public class ApplicationAccessRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="role"></param>
        public ApplicationAccessRequirement(string role)
        {
            Role = role;
        }

        /// <summary>
        /// 
        /// </summary>
        public string Role { get; set; }
    }
}
