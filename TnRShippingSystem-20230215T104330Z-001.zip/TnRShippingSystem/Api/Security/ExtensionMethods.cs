// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ExtensionMethods.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//   Get current ClientCode from Request Headers..
// </summary>
// --------------------------------------------------------------------------------------------------------------------


using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    /// <summary>
    /// Extension Methods
    /// </summary>
    public static class ExtensionMethods
    {
        /// <summary>
        /// Get current ClientCode from Request Headers..
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string GetClientCode(this HttpRequest source)
        {
            return source.Headers["x-api-client-code"].ToString();
        }

        /// <summary>
        /// Get Custom Search Value from the header
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static bool GetAssetEntityValueOnly(this HttpRequest source)
        {
            bool.TryParse(source.Headers["x-api-AssetEntityValueOnly"].ToString(), out bool itemsOnly);
            return itemsOnly;
        }

        /// <summary>
        /// Get Max Items Per Collection from the header
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static int GetMaxItemsPerCollection(this HttpRequest source)
        {
            var maxItemsPerCollection = 10; // Default value is 10
            if (!source.Headers.ContainsKey("x-api-max-items-per-collection"))
                return maxItemsPerCollection;

            var maxItems = source.Headers["x-api-max-items-per-collection"].ToString();
            if (string.IsNullOrEmpty(maxItems))
                return maxItemsPerCollection;
            if (int.TryParse(maxItems, out int newMaxItemsPerCollection))
            {
                maxItemsPerCollection = newMaxItemsPerCollection;
            }
            return maxItemsPerCollection;
        }

        /// <summary>
        /// Get Items Only bool
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static bool GetItemsOnly(this HttpRequest source)
        {
            bool.TryParse(source.Headers["x-api-items-only"].ToString(), out bool itemsOnly);
            return itemsOnly;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection ConfigureSecurityPolicies(this IServiceCollection services)
        {
            services.AddAuthorization(options =>
            {
                options.AddPolicy(AuthorizationPolicyNames.ClientAccessPolicy,
                    policy => policy.Requirements.Add(new ClientCodeRequirement()));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationReadPolicy,
                    policy => policy.Requirements.Add(new ApplicationAccessRequirement("external,internal,supervisor,admin")));               
                options.AddPolicy(AuthorizationPolicyNames.ApplicationAddModifyPolicy,
                   policy => policy.Requirements.Add(new ApplicationAccessRequirement("internal,supervisor,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationInvoicePolicy,
                    policy => policy.Requirements.Add(new ApplicationAccessRequirement("supervisor,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationAccessPolicy,
                    policy => policy.Requirements.Add(new ApplicationAccessRequirement("internal,admin")));
                options.AddPolicy(AuthorizationPolicyNames.ApplicationConfigSettingPolicy,
                 policy => policy.Requirements.Add(new ApplicationAccessRequirement("admin")));
                options.AddPolicy(AuthorizationPolicyNames.ClientApplicationAccessPolicy,
                    policy => policy.Requirements.Add(new ClientApplicationAccessRequirement()));
            });

            services.AddSingleton<IAuthorizationHandler, ClientCodeInHeaderHandler>();
            services.AddSingleton<IAuthorizationHandler, ApplicationAccessResourceAuthorizationHandler>();
            services.AddSingleton<IAuthorizationHandler, ApplicationAccessRouteAuthorizationHandler>();
            services.AddSingleton<IAuthorizationHandler, ClientApplicationAccessAuthorizationHandler>();

            return services;
        }

        /// <summary>
        /// Get current locationcode from Request Header...
        /// </summary>
        /// <param name="source">input parameter</param>
        /// <returns>returns location code</returns>
        public static string GetLocationCode(this HttpRequest source)
        {
            var locationCode = source.Headers["x-api-location-code"].ToString();

            // TODO: Validation for location code header.

            return locationCode;
        }

        /// <summary>
        /// Get current device properties from Request Header
        /// </summary>
        /// <param name="source">input parameter</param>
        /// <returns>returns device prroperties</returns>
        public static string GetDeviceProperties(this HttpRequest source)
        {
            if (!source.Headers.ContainsKey("x-api-action-properties") ||
                string.IsNullOrEmpty(source.Headers["x-api-action-properties"]))
            {
                return null;
            }

            return source.Headers["x-api-action-properties"].ToString();
        }

        /// <summary>
        /// Get Items Only bool
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static bool GetAllPropertiesFlag(this HttpRequest source)
        {
            bool.TryParse(source.Headers["x-api-all-properties"].ToString(), out bool allProperties);
            return allProperties;
        }
    }
}
