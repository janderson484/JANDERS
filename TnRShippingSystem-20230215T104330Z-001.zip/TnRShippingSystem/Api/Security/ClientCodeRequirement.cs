
// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClientCodeRequirement.cs" company="American Traffic Solutions, Inc.">
//   Copyright 2017 American Traffic Solutions, Inc.
// </copyright>
// <summary>
//   Requires a valid ClientCode..
// </summary>
// --------------------------------------------------------------------------------------------------------------------
using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    /// <summary>
    /// Requires a valid ClientCode..
    /// </summary>
    public class ClientCodeRequirement : IAuthorizationRequirement
    {
    }

}
