// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AuthorizationPolicyNames.cs" company="American Traffic Solutions, Inc.">
//   Copyright 2017 American Traffic Solutions, Inc.
// </copyright>
// <summary>
//   This class contains list of security policy names   
// </summary>
// --------------------------------------------------------------------------------------------------------------------
using System;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    /// <summary>
    /// Transform Claims to remove all level protocol claims that are not needed 
    /// </summary>
    /// <returns></returns>
    public class UserManagerClaimsTransformer : IClaimsTransformation
    {

        private readonly IOptions<OpenIdSettings> openIdOptions;
        private readonly IMemoryCache memoryCache;
        private readonly ILogger<UserManagerClaimsTransformer> _logger;
        private static EventId ClaimsLookupEvent = new EventId(1000, "Claims Lookup Event");
        private readonly IHttpContextAccessor _httpContext;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IDiscoveryCache _discoveryCache;

        public UserManagerClaimsTransformer(
            IOptions<OpenIdSettings> options,
            IMemoryCache memoryCache,
            ILogger<UserManagerClaimsTransformer> claimsLogger,
            IHttpContextAccessor httpContext, IHttpClientFactory httpClientFactory,
            IDiscoveryCache discoveryCache)
        {
            openIdOptions = options;
            this.memoryCache = memoryCache;
            _logger = claimsLogger;
            _httpContext = httpContext;
            _httpClientFactory = httpClientFactory;
            _discoveryCache = discoveryCache;
        }
        /// <summary>
        /// Transform claims by loading claims from UserInfo endpoint.
        /// </summary>
        /// <param name="principal"></param>
        /// <returns></returns>
        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var context = _httpContext.HttpContext;
            var authorizationHeader = context.Request.Headers["Authorization"].SingleOrDefault();
            _logger.LogInformation(ClaimsLookupEvent,
                $"Entering Claims Transformer with auth header: {authorizationHeader ?? "{Authorization header empty}"}");

            if (string.IsNullOrEmpty(authorizationHeader))
            {
                // no token found..
                return principal;
            }

            if (principal.Claims.Any(t => t.Type.StartsWith(UserManagerClaimTypes.Client)))
            {
                // UserManager claims already loaded..
                return principal;
            }

            var token = authorizationHeader.Substring(7);

            _logger.LogInformation(ClaimsLookupEvent, $"No claims found on existing principal. Checking cache for user info.");

            if (memoryCache.TryGetValue<ClaimsPrincipal>(token, out var cachedResult))
            {
                return cachedResult;
            }

            var result = await memoryCache.GetOrCreateAsync(token, async entry =>
            {
                _logger.LogInformation(ClaimsLookupEvent, $"No cached result found. Creating new cached entry.");
                try
                {
                    var identity =
                        await GetClaimsPrincipalFromIdentityServerAsync(token,
                            principal.Identity.AuthenticationType);
                    entry.SetValue(identity);
                    entry.SetAbsoluteExpiration(
                        TimeSpan.FromSeconds(openIdOptions?.Value?.CacheExpirationSeconds ?? 0));
                    return identity;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ClaimsLookupEvent, $"Error while trying to get user claims. {ex.Message}");
                    entry.SetAbsoluteExpiration(DateTimeOffset.MinValue);
                    entry.SetValue(principal);
                    return principal;
                }
            });

            return result ?? principal;
        }       

        private async Task<ClaimsPrincipal> GetClaimsPrincipalFromIdentityServerAsync(string token, string authenticationType)
        {
            // Get UserManager claims from UserInfo Endpoint
            HttpClient client = _httpClientFactory.CreateClient();
            DiscoveryDocumentResponse disco = await _discoveryCache.GetAsync();
            //var discoClient = new DiscoveryClient(openIdOptions.Value.Authority);
            //var disco = await discoClient.GetAsync();
            if (disco.IsError)
            {
                _logger.LogError($"Error while getting discovery client for token. {disco.Error}");
                throw new Exception(disco.Error);
            }


            //var userInfoClient = new UserInfoClient(disco.UserInfoEndpoint);
            //var userInfo = await userInfoClient.GetAsync(token);

            var userInfo = await client.GetUserInfoAsync(new UserInfoRequest
            {
                Address = disco.UserInfoEndpoint,
                Token = token
            });

            if (userInfo.IsError || !userInfo.Claims.Any())
            {
                _logger.LogWarning(
                    ClaimsLookupEvent,
                    userInfo.Claims.Any()
                        ? $"Error getting claims for token: {userInfo.Error}"
                        : "No user claims retried for token.");

                if (userInfo.Exception == null)
                    throw new Exception("No user claims retrieved for token.");

                _logger.LogInformation(ClaimsLookupEvent, userInfo.Exception,
                    $"Exception while getting user info. Raw results: {userInfo.Raw}");

                throw userInfo.Exception;
            }


            var nid = new ClaimsIdentity(
                authenticationType,
                ClaimTypes.GivenName,
                ClaimTypes.Role);

            // add claims from UserInfo
            nid.AddClaims(userInfo.Claims);
            return new ClaimsPrincipal(nid);
            
        }

    }
}
