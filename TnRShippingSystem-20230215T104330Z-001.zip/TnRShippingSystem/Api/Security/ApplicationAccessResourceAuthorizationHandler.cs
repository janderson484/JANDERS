// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApplicationAccessResourceAuthorizationHandler.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//   Handler to grant access to application based on application and role (right in UM)
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    public class ApplicationAccessResourceAuthorizationHandler : AuthorizationHandler<ApplicationAccessRequirement, string>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private const string TNRROLE = "TNR-SHIPPING";

        /// <summary>
        /// Creates a new instance of AssetActionAuthorizationHandler
        /// </summary>
        /// <param name="httpContextAccessor">provides access to HttpContext to get request headers.</param>
        public ApplicationAccessResourceAuthorizationHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Checks for a valid Client Role in users Claims. 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <param name="applicationType"></param>
        /// <returns></returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ApplicationAccessRequirement requirement, string applicationType)
        {
            var clientCode = _httpContextAccessor.HttpContext.Request.GetClientCode();

            if (string.IsNullOrEmpty(clientCode))
                return Task.CompletedTask;

            var roles = requirement.Role.Split(",");

            for (var i = 0; i < roles.Length; i++)
            {
                var role = roles[i].ToUpper();
                roles[i] = (role == "SUPERVISOR" || role == "ADMIN") ? $"{TNRROLE}-{role}".ToUpper() : $"{applicationType}-{roles[i]}".ToUpper();
            }            

            // non-admin client
            if (roles.Select(role => context.User.GetClientRight(clientCode, role)).Any(right => right != null))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
