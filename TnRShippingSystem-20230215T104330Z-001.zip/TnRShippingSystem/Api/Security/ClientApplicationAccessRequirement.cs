using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.Shipping.Api.Security
{
    /// <summary>
    /// Requires a valid role for current client.
    /// </summary>
    public class ClientApplicationAccessRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="clientCode"></param>
        public ClientApplicationAccessRequirement()
        {
        }

    }
}
