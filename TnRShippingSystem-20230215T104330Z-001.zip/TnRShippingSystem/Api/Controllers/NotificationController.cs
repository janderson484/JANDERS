using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VM.FleetServices.TnR.Shipping.Model;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Core.Common.SignalR;

namespace VM.FleetServices.TnR.Shipping.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : Controller
    {
        private readonly INotificationService _notificationService;

        public NotificationController(INotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        /// <summary>
        /// send notification 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("SendNotification")]
        public async Task SendNotificationAsync(NotificationViewModel model)
        {
            /*
            if (model.NotificationType == ProcessNames.SendToScheduling)
            {
                model.NotificationType = $"{model.NotificationType} - Batch: {model.Message}";
            }
            await _notificationService.SendNotifcationAsync(model);
            */
            throw new NotImplementedException();
        }
    }
}
