using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Shipping.Api.Security;
using VM.FleetServices.TnR.Shipping.Business;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Business.ServiceBus;
using Newtonsoft.Json;

namespace VM.FleetServices.TnR.Shipping.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ShipmentController : ControllerBase
    {        
        private readonly ILogger<ShipmentController> _logger;
        private readonly IShipmentService _shipmentService;

        public ShipmentController(ILogger<ShipmentController> logger,
            IShipmentService shipmentService)
        {
            _shipmentService = shipmentService;
            _logger = logger;
        }

        #region Create Receive Shipment

        /// <summary>
        /// load shipment common lookups
        /// </summary>
        /// <returns></returns>
        [HttpGet("LoadShipmentCommonLookups")]
        public async Task<ActionResult<Dictionary<string, object>>> LoadShipmentCommonLookupsAsync()
        {
            _logger.LogInformation($"API Contoller method: {nameof(LoadShipmentCommonLookupsAsync)} - loading Common lookups for shipment application.");

            var response = new ServiceResponse<Dictionary<string, object>>();
            var dataLoaded = false;

            try
            {
                dataLoaded = await _shipmentService.LoadShipmentCommonLookupsAsync();
            }
            catch (Exception e)
            {
                _logger.LogInformation($"API Contoller action method: {nameof(LoadShipmentCommonLookupsAsync)} - Error loading Shipment common lookup data. Error Message: {e.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.Data = null;
                response.ErrorMessage = e.Message;
                return new JsonResult(response);
            }

            if (dataLoaded)
            {
                response.ResponseCode = HttpStatusCode.OK;
                _logger.LogInformation($"API Contoller action method: {nameof(LoadShipmentCommonLookupsAsync)} - Shipment Common lookup data loaded successfully.");
            }
            else
            {
                response.ResponseCode = HttpStatusCode.NoContent;
                response.Data = null;
                _logger.LogInformation($"API Contoller action method: {nameof(LoadShipmentCommonLookupsAsync)} - Not able to load Shipment common lookup data to cache.");
            }

            return new JsonResult(response);
        }

        /// <summary>
        /// add receive shipment
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        [HttpPost, Route("CreateReceiveShipment")]
        public async Task<IActionResult> CreateReceiveShipmentAsync([FromBody] ReceiveShipment model)
        {
            var response = new ServiceResponse<ReceiveShipment>();

            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(CreateReceiveShipmentAsync)} to create receive shipment");
                var result = await _shipmentService.CreateReceiveShipmentAsync(model);
                _logger.LogInformation($"Perform service request {nameof(CreateReceiveShipmentAsync)} end");
                response.ResponseCode = HttpStatusCode.Accepted;
                response.Data = result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Shipment API: {nameof(CreateReceiveShipmentAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.InnerException.ToString().IndexOf("UNIQUE KEY") > 0 ? "Cannot insert duplicate key of tracking number and courier" : ex.Message;
            }
            return new JsonResult(response);
        }

        /// <summary>
        /// API controller action to get shipment data
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("ReceiveShipments")]
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> ReceiveShipmentsAsync([FromBody]CreateReceiveShipmentRequestModel model)
        {
            var response = new ServiceResponse<List<CreateReceiveShipmentsViewModel>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(ReceiveShipmentsAsync)}");
                var shipments = await _shipmentService.GetReceiveShipmentDataAsync(model);
                _logger.LogInformation($"Perform service request {nameof(ReceiveShipmentsAsync)} end");
                response.Data = shipments;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Shipment API: {nameof(ReceiveShipmentsAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }
            return new JsonResult(response);
        }

        /// <summary>
        /// API controller action to get GetShipmentData
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetShipmentData")]
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> GetShipmentDataAsync([FromBody] string key)
        {
            var response = new ServiceResponse<List<ShipmentDataViewModel>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetShipmentDataAsync)}");
                var shipmentData = await _shipmentService.GetShipmentDataAsync(key);
                _logger.LogInformation($"Perform service request {nameof(GetShipmentDataAsync)} end");
                response.Data = shipmentData;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Shipment API: {nameof(GetShipmentDataAsync)} error message - {ex.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }
            return new JsonResult(response);
        }

        /// <summary>
        /// API controller action to get GetShipmentDate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetShipmentReceivedDate")]
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> GetShipmentReceivedDateAsync([FromBody] List<string> trackingNumber)
        {
            var response = new ServiceResponse<Dictionary<string, string>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetShipmentReceivedDateAsync)}");
                var shipmentData = await _shipmentService.GetShipmentReceivedDateAsync(trackingNumber);
                _logger.LogInformation($"Perform service request {nameof(GetShipmentReceivedDateAsync)} end");
                response.Data = shipmentData;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Shipment API: {nameof(GetShipmentReceivedDateAsync)} error message - {ex.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }
            return new JsonResult(response);
        }

        #endregion

        #region Export Shipments
        /// <summary>
        /// API action to submit export shipment request
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SubmitExportAllRequest")]
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> SubmitExportAllRequestAsync([FromBody] CreateReceiveShipmentRequestModel model)
        {
            var response = new ServiceResponse<CreateReceiveShipmentRequestModel>();
            try
            {
                var exportSearch = new ExportSearchCriteriaViewModel();

                _logger.LogInformation($"Starting Web Api method {nameof(SubmitExportAllRequestAsync)}");

                 var log = await _shipmentService.SubmitExportAllRequestAsync(model);

                _logger.LogInformation($"Perform service request {nameof(SubmitExportAllRequestAsync)} end");
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Renewals API: {nameof(SubmitExportAllRequestAsync)} error message - {ex.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }
            return new JsonResult(response);
        }

        #endregion


        #region Create pickup Sequence 
        /// <summary>
        /// API controller action to create courier pickup sequence 
        /// </summary>
        /// <param name="model"></param>
        /// <returns>returns Tracking Sequence</returns>
        [HttpPost, Route("CreateCourierPickup")]
       // [Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        
        public async Task<IActionResult> CreateCourierPickupAsync([FromBody]CourierPickupViewModel CourierPickupmodel)
        {
            var response = new ServiceResponse<List<CourierPickupViewModel>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(CreateCourierPickupAsync)} to create Courier Pickup");
                var result = await _shipmentService.GetTrackingNumber(CourierPickupmodel);
                _logger.LogInformation($"Perform service request {nameof(CreateCourierPickupAsync)} end");
                response.ResponseCode = HttpStatusCode.Accepted;
                response.Data = result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Shipment API: {nameof(CreateCourierPickupAsync)} error message - {ex.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }
            return new JsonResult(response);
        }
        #endregion

    }
}
