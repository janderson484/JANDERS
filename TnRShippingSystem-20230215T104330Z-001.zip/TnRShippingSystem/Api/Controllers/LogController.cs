using System.Net;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Mvc;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Shipping.Model.ViewModel;
using VM.FleetServices.TnR.Shipping.Model.DTO;
using Microsoft.Extensions.Caching.Memory;
using VM.FleetServices.TnR.Shipping.Business.ServiceBus;
using VM.FleetServices.TnR.Shipping.Business;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using VM.FleetServices.TnR.Shipping.Api.Security;

namespace VM.FleetServices.TnR.Shipping.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class LogController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly ILogService _logService;

        public LogController(ILogService logService, ILogger<LogController> logger)
        {
            _logger = logger;
            _logService = logService;
        }

        #region Logs

        /// <summary>
        /// Api end point to get Logs data based on search criteria
        /// </summary>
        /// <param name="model">model contains search criteria</param>
        /// <returns>returns input model with list of log records</returns>
        [HttpPost, Route("GetLogs")]
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationReadPolicy)]
        public async Task<IActionResult> GetLogsAsync([FromBody] LogSummaryViewModel model)
        {
            var response = new ServiceResponse<LogSummaryViewModel>();

            if (model == null || string.IsNullOrEmpty(model.ClientCode))
            {
                response.Data = null;
                response.ErrorMessage = "Invalid Input";
                response.ResponseCode = HttpStatusCode.BadRequest;

                _logger.LogError($"{nameof(GetLogsAsync)} : Invalid request payload to get Logs data.");

                return new JsonResult(response);
            }

            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetLogsAsync)} to get Logs data");
                var logsResult = await _logService.GetLogsAsync(model);
                _logger.LogInformation($"Perform service request perform {nameof(GetLogsAsync)} end");

                response.Data = logsResult;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception)
            {
                response.Data = null;
                response.ErrorMessage = "An error has occurred.\r\nPlease contact your support representative.";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        /// <summary>
        /// API end point to return log details based on log
        /// </summary>
        /// <param name="model">model contains search criteria</param>
        /// <returns>returns model with log and log details</returns>
        [HttpPost("GetLogDetails")]
        public async Task<IActionResult> GetLogDetailsAsync([FromBody] LogDetailViewModel model)
        {
            var response = new ServiceResponse<LogDetailViewModel>();

            if (model == null || model.LogId == 0)
            {
                response.Data = null;
                response.ErrorMessage = "Invalid input request";
                response.ResponseCode = HttpStatusCode.BadRequest;

                _logger.LogError($"{nameof(GetLogDetailsAsync)} : Invalid request payload to get Log details.");

                return new JsonResult(response);
            }

            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetLogDetailsAsync)} to get Logs data");
                var logDetails = await _logService.GetLogDetailsAsync(model);
                _logger.LogInformation($"Perform service request perform {nameof(GetLogDetailsAsync)} end");

                response.Data = logDetails;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception)
            {
                response.Data = null;
                response.ErrorMessage = "A renewal service error has occurred.\r\nPlease contact your support representative.";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        [Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        [HttpPost, Route("UpdateJobStatusById")]
        public async Task<IActionResult> UpdateLogStatusByIdAsync(Log model)
        {
            _logger.LogInformation($"API Controller method: {nameof(UpdateLogStatusByIdAsync)} - Updating Job Log status by Id");

            var response = new ServiceResponse<Log>();

            try
            {
                _logger.LogInformation($"Starting Web API method {nameof(UpdateLogStatusByIdAsync)} to update Job Log by Id");
                var responseData = await _logService.UpdateLogStatusByIdAsync(model.LogId, model.Status);
                _logger.LogInformation($"Perform service request {nameof(UpdateLogStatusByIdAsync)} end.");

                response.Data = responseData;
                response.ResponseCode = HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"API Contoller action method: {nameof(UpdateLogStatusByIdAsync)} - Error Updating Job Log by Id. Error Message: {ex.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }


        #endregion
    }
}
