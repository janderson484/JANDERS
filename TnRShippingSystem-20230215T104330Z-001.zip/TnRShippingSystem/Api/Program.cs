using System;
using System.IO;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace VM.FleetServices.TnR.Shipping.Api
{
    public class Program
    {
        public static void Main(string[] args)
     {
            Console.Title = "API";
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                   .ConfigureAppConfiguration((context, config) =>
                   {
                       var builtConfig = config.Build();
                       var kvUrl = builtConfig["KeyVaultConfiguration:KVUrl"];

                       if (!string.IsNullOrEmpty(kvUrl) && context.HostingEnvironment.EnvironmentName.Equals("Development"))
                       {
                           var tenantId = builtConfig["KeyVaultConfiguration:TenantId"];
                           var clientId = builtConfig["KeyVaultConfiguration:ClientId"];
                           var clientSecret = builtConfig["KeyVaultConfiguration:ClientSecretId"];

                           var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
                           var client = new SecretClient(new Uri(kvUrl), credential);
                           config.AddAzureKeyVault(client, new AzureKeyVaultConfigurationOptions());
                       }
                   })
                   //.UseKestrel()
                   .ConfigureKestrel(serverOptions => { })
                   .UseContentRoot(Directory.GetCurrentDirectory())
                   .UseIISIntegration()
                   .UseStartup<Startup>();
        //.UseApplicationInsights(); // TODO: Need to update this              
    }
}
