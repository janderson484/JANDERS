using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class ConfigurationPageObj : TnrPageObjBase
    {
        public KendoGridPageObj KendoGrid { get; }
        public ConfigurationPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Configuration";
            KendoGrid = new KendoGridPageObj(driver);
        }

        #region Elements

        private IWebElement ConfigurationGear => Driver.FindElement(By.XPath("//*[@id='config - settings']/div/a/svg/path"));
        private IWebElement ImportLayoutMenuItem => Driver.FindElement(By.XPath("//*[@id='config - settings']/div/ul/li/a"));
        private IWebElement OnOffToggleButton => Driver.FindElement(By.XPath("//*[@id='ImportLayoutTypes']/div[2]/table/tbody/tr[1]/td[1]/div/div/div/span"));
        private IWebElement NotificationWindow => Driver.FindElement(By.XPath("/html/body/div[10]"));
        private IWebElement ImportLayoutGrid => Driver.FindElement(By.XPath("//*[@id='ImportLayoutTypes']/div[2]/table/tbody/tr[1]/td[3]"));
        private IWebElement AddImportLayoutButton => Driver.FindElement(By.XPath("//*[@id='content']/div/div/div/button"));
        private IWebElement ModalSaveButton => Driver.FindElement(By.Id("saveButton"));
        private IWebElement EditImportLayoutButton => Driver.FindElement(By.Id("select"));
        private IWebElement ModalCancelButton => Driver.FindElement(By.XPath("//*[@id='AddEditPlateHoldType']/div[7]/div/div/button[1]"));
        private IWebElement GridFirstRow => Driver.FindElement(By.XPath("//*[@id='ImportLayoutTypes']/div[2]/table/tbody/tr[1]/td[2]"));
        private IWebElement IsSelected => Driver.FindElement(By.XPath("//input[@type='checkbox']"));
        private IWebElement ModalDescription => Driver.FindElement(By.Id("description"));
        private IWebElement ModalFieldDescriptionDropDown => Driver.FindElement(By.Id("importField_0"));
        private string ModalFieldDescriptionIdFormat => "importField_";

        private IWebElement ModalAddNewElement => Driver.FindElement(By.Id("addNewField"));
        private IWebElement ModalLabelType => Driver.FindElement(By.Id("labeltypes"));
        private IWebElement ModalProcessingLocationCodeDropDown => Driver.FindElement(By.Id("ProcessingLocationCode"));
        private IWebElement ModalClientCodeDropDown => Driver.FindElement(By.Id("ClientCode"));

        private IWebElement ModalProcessingLocationDropDownButton => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[3]/div/div/span/div/button"));
        private IWebElement ModalProcessingLocation_SelectAll => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[3]/div/div/span/div/ul/li/a/label"));
        private IWebElement ModalProcessingLocation_SunShine => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[3]/div/div/span/div/ul/li[2]/a/label"));
        private IWebElement ModalProcessingLocation_Suncity => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[3]/div/div/span/div/ul/li[3]/a/label"));


        private IWebElement ModalClientCodeDropDownButton => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[2]/div[2]/div/span/div/button"));
        private IWebElement ModalClientCode_SelectAll => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[2]/div[2]/div/span/div/ul/li/a/label"));
        private IWebElement ModalClientCode_Hertz => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[2]/div[2]/div/span/div/ul/li[2]"));
        private IWebElement ModalClientCode_Enterprise => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[2]/div[2]/div/span/div/ul/li[3]"));

        //"//div[@id='AddEditPlateHoldType']/Div[3]/div/div/span/div/ul/li/a/label";

        private IWebElement RefreshButton => Driver.FindElement(By.XPath("//div[@id='ImportLayoutTypes']/div[3]/a[@title='Refresh']"));
        private IWebElement ModalImportLayoutOnOffButton => Driver.FindElement(By.XPath("//*[@id='AddEditPlateHoldType']/div[6]/div/div[2]/div/div/label[2]"));
        private IWebElement ShowDisabledConfigurations => Driver.FindElement(By.Id("Disabled"));

        private IWebElement NoVinErrorNotification => Driver.FindElement(By.XPath("//span[contains(text(),'VIN is required to save import layout')]"));

        private IWebElement ShowDisabledConfigurationCheckbox => Driver.FindElement(By.ClassName("k-checkbox-label"));
        private const string OnOffToggleInputXPath = "//*[@id='ImportLayoutTypes']//tr[{0}]//td[1]//div[1]//input";
        #endregion

        #region Helpers

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public new void Navigate(string user, string pass)
        {
            base.Navigate(user, pass);
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public void ClickAddNewImportLayoutButton()
        {
            //AddImportLayoutButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, AddImportLayoutButton);
            Extensions.WaitUntilElementExists(Driver, ModalSaveButton.GetAbsoluteXPath(Driver));
        }

        public void ClickEditSelectedRowButton()
        {
            //GridFirstRow.Click();
            //EditImportLayoutButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, EditImportLayoutButton);
            Extensions.WaitUntilElementExists(Driver, ModalSaveButton.GetAbsoluteXPath(Driver));
            KendoGrid.WaitForKendoReadyState();
        }

        public void CheckShowDisabledConfigs(bool expectedState = true)
        {
            Extensions.SetCheckbox(ShowDisabledConfigurations, expectedState);
        }

        public bool IsPageLoaded()
        {
            if (ImportLayoutGrid.Displayed)
            {
                return true;
            }
            return false;
        }

        public bool IsNoVinErrorNotificationDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, NoVinErrorNotification);
        }

        public void CloseModal()
        {
            //ModalCancelButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalCancelButton);
        }

        public bool ToggleImportLayoutRecords()
        {
            var startStatus = GetRecordActiveStatus();
            Extensions.JavaScriptExicuterClick(Driver, OnOffToggleButton);
            //OnOffToggleButton().Click();
            KendoGrid.WaitForSpinningLoadIcon();
            Extensions.WaitUntilElementExists(Driver, NotificationWindow.GetAbsoluteXPath(Driver));
            var endStatus = GetRecordActiveStatus();
            if (startStatus == endStatus)
            {
                return true;
            }
            return false;
        }

        public bool GetRecordActiveStatus()
        {
            // is it checked? 
            var isChecked = IsSelected.GetAttribute("selected");
            if (isChecked == null)
            {
                return false;
            }
            return true;
        }

        public bool EditImportLayoutConfigurationRecord()
        {
            KendoGrid.ClickDataCellByRowAndColumnNumber(1, 3, 1);
            Extensions.JavaScriptExicuterClick(Driver, EditImportLayoutButton);
            //GridFirstRow.Click();
            //EditImportLayoutButton().Click();
            var originalDescription = GetLayoutDescription();
            var updatedText = originalDescription + $"_{DateTime.Now.ToString("yyyyMMddHHmmss")}";

            // Update the description & then save
            ModalDescription.SendKeys(Keys.Control + "a");
            ModalDescription.SendKeys(Keys.Backspace);
            ModalDescription.SendKeys(updatedText);
            //ModalSaveButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalSaveButton);
            KendoGrid.WaitForKendoReadyState();

            // Read updated description from the grid
            var gridDescription = KendoGrid.GetDataCellText(1, 3);

            // If update was successful
            if (gridDescription != originalDescription)
            {
                //EditImportLayoutButton.Click();
                KendoGrid.ClickDataCellByRowAndColumnNumber(1, 3, 1);
                Extensions.JavaScriptExicuterClick(Driver, EditImportLayoutButton);

                // Update the description back to original
                ModalDescription.SendKeys(Keys.Control + "a");
                ModalDescription.SendKeys(Keys.Backspace);
                ModalDescription.SendKeys(originalDescription);
                Extensions.JavaScriptExicuterClick(Driver, ModalSaveButton);
                return true;
            }

            KendoGrid.ClickDataCellByRowAndColumnNumber(1, 3, 1);
            Extensions.JavaScriptExicuterClick(Driver, EditImportLayoutButton);

            // Update the description back to original
            ModalDescription.SendKeys(Keys.Control + "a");
            ModalDescription.SendKeys(Keys.Backspace);
            ModalDescription.SendKeys(originalDescription);
            ModalSaveButton.Click();
            return false;
        }

        public string GetLayoutDescription(string text = "")
        {
            var descriptionText = ModalDescription.GetAttribute("value");
            return descriptionText;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        public bool IsSelectedProcessingLocation(string location)
        {
            bool val = false;
            string classname = string.Empty;

            switch (location)
            {
                case "Select All":
                    classname = ModalProcessingLocation_SelectAll.GetAttribute("class");
                    break;
                case "Sunshine Bradenton, FL":
                    classname = ModalProcessingLocation_SunShine.GetAttribute("class");
                    break;
                case "Sun City, AZ":
                    classname = ModalProcessingLocation_Suncity.GetAttribute("class");
                    break;
                default: break;
            }
            if (!string.IsNullOrEmpty(classname))
            {
                val = classname.Contains("Active");
            }

            return val;
        }

        public List<string> GetSelectedProcessingLocations()
        {
            SelectElement processingLocations = new SelectElement(ModalProcessingLocationCodeDropDown);
            return processingLocations.AllSelectedOptions.Select(i => i.Text).ToList();
        }

        public List<string> GetSelectedClientCodes()
        {
            SelectElement clientCodes = new SelectElement(ModalClientCodeDropDown);
            return clientCodes.AllSelectedOptions.Select(i => i.Text).ToList();
        }

        public void ClickProcessingLocationOption(string location)
        {
            IWebElement element = null;

            switch (location)
            {
                case "Select All":
                    element = ModalProcessingLocation_SelectAll;
                    break;
                case "Sunshine Bradenton, FL":
                    element = ModalProcessingLocation_SunShine;
                    break;
                case "Sun City, AZ":
                    element = ModalProcessingLocation_Suncity;
                    break;
                default:
                    break;
            }

            if (element != null)
            {
                //element.Click();
                Extensions.JavaScriptExicuterClick(Driver, element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="index">1- All, 2-Hertz, 3- Enterprise</param>
        /// <returns></returns>
        public bool IsSelectedClientCode(string client)
        {
            bool val = false;
            string classname = string.Empty;
            
            switch (client)
            {
                case "Select All":
                    classname = ModalClientCode_SelectAll.GetAttribute("class");
                    break;
                case "Hertz":
                    classname = ModalClientCode_Hertz.GetAttribute("class");
                    break;
                case "Enterprise":
                    classname = ModalClientCode_Enterprise.GetAttribute("class");
                    break;
                default:
                    break;
            }

            if (!string.IsNullOrEmpty(classname))
            {
                val = classname.Contains("Active");
            }

            return val;
        }

        public void ClickClientCodeOption(string city)
        {
            IWebElement element = null;

            switch (city)
            {
                case "Select All":
                    element = ModalClientCode_SelectAll;
                    break;
                case "Hertz":
                    element = ModalClientCode_Hertz;
                    break;
                case "Enterprise":
                    element = ModalClientCode_Enterprise;
                    break;
                default:
                    break;
            }

            if (element != null)
            {
                //element.Click();
                Extensions.JavaScriptExicuterClick(Driver, element);
            }
        }

        public void ClearAllProcessingLocations()
        {
            if (!IsSelectedProcessingLocation("Select All"))
            {
                ClickProcessingLocationOption("Select All");
            }

            ClickProcessingLocationOption("Select All");
        }
        public void ClearAllClientCodes()
        {
            if (!IsSelectedClientCode("Select All"))
            {
                ClickClientCodeOption("Select All");
            }

            ClickClientCodeOption("Select All");
        }

        public void SelectProcessingLocationOptions(List<string> locations)
        {
            //ModalProcessingLocationDropDownButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalProcessingLocationDropDownButton);
                
            ClearAllProcessingLocations();

            foreach (string location in locations)
                ClickProcessingLocationOption(location);

            //ModalProcessingLocationDropDownButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalProcessingLocationDropDownButton);
        }

        public void SelectClientCodeOptions(List<string> clients)
        {
            //ModalClientCodeDropDownButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropDownButton);

            ClearAllClientCodes();

            foreach (string client in clients)
                ClickClientCodeOption(client);

            //ModalClientCodeDropDownButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropDownButton);
        }

        public void AddFieldDescriptions(List<string> fields)
        {
            if (fields == null || fields.Count == 0)
                return;

            ModalFieldDescriptionDropDown.SelectDropdownByText(fields[0]);
            string identifier;
            for (int i = 1; i < fields.Count; i++)
            {
                //ModalAddNewElement.Click();
                Extensions.JavaScriptExicuterClick(Driver, ModalAddNewElement);
                identifier = ModalFieldDescriptionIdFormat + i;
                Driver.FindElement(By.Id(identifier)).SelectDropdownByText(fields[i]);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="description"></param>
        /// <param name="labelType">1 - Unit, 2 - Bag</param>
        /// <param name="clients"></param>
        /// <param name="processingLocations"></param>
        /// <param name="fieldDescription"></param>
        /// <returns></returns>
        public void AddImportLayoutConfigurationRecord(string description, int labelType, List<string> clients, List<string> processingLocations, string fieldDescription)
        {
            AddImportLayoutConfigurationRecord(description, labelType, clients, processingLocations, new List<string> { fieldDescription });
        }

        public void AddImportLayoutConfigurationRecord(string description, int labelType, List<string> clients, List<string> processingLocations, List<string> fields)
        {
            ClickAddNewImportLayoutButton();

            // add configuration data and save
            ModalDescription.SendKeys(description);

            ModalLabelType.SelectDropdownByValue(labelType.ToString());
            SelectClientCodeOptions(clients);
            SelectProcessingLocationOptions(processingLocations);
            AddFieldDescriptions(fields);

            //ModalImportLayoutOnOffButton.Click();
            //ModalSaveButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalSaveButton);
            KendoGrid.WaitForKendoReadyState();

            // sort grid by Id Descending
            KendoGrid.SelectItemsPerPageByString("150");
            KendoGrid.ClickSortColumnByColumnNumber(2, 1, 10);
            KendoGrid.ClickSortColumnByColumnNumber(2, 1, 10);
        }

        public void FillDataInAddLayoutConfigModal(string description, int labelType, List<string> clients, List<string> processingLocations, List<string> fields ,  bool clickSaveButton)
        {
            // add configuration data
            ModalDescription.SendKeys(description);

            ModalLabelType.SelectDropdownByValue(labelType.ToString());
            SelectClientCodeOptions(clients);
            SelectProcessingLocationOptions(processingLocations);
            AddFieldDescriptions(fields);

            if (clickSaveButton)
            {
                Extensions.JavaScriptExicuterClick(Driver, ModalSaveButton);
                KendoGrid.WaitForKendoReadyState();
            }
        }

        public bool AddImportLayoutConfigurationRecord()
        {
            // open the modal
            //AddImportLayoutButton.Click();
            Extensions.JavaScriptExicuterClick(Driver,AddImportLayoutButton);

            // add configuration data and save
            ModalDescription.SendKeys(DescriptionText.AutomationConfigurationTest);
            //ModalFieldDescriptionDropDown.Click();
            Extensions.SelectDropdownByText(ModalProcessingLocationCodeDropDown, "Sunshine Bradenton, FL");
            Extensions.SelectDropdownByText(ModalClientCodeDropDown, "Hertz");
            Extensions.JavaScriptExicuterClick(Driver, ModalFieldDescriptionDropDown);
            ModalFieldDescriptionDropDown.SendKeys("VIN");
            //ModalImportLayoutOnOffButton.Click();
            //Extensions.JavaScriptExicuterClick(Driver, ModalImportLayoutOnOffButton);
            //ModalSaveButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalSaveButton);
            IsNotificationMessageDisplayed(NotificationType.Success);
            KendoGrid.WaitForKendoReadyState();
            Extensions.JavaScriptExicuterClick(Driver, RefreshButton);
            

            // sort grid by description
            //KendoGrid.SelectItemsPerPageByString("150");
            //KendoGrid.ClickSortColumnByColumnNumber(3, 1, 10);

            // Read updated description from the grid
            var gridDescription = KendoGrid.GetDataCellText(1, 3);
            gridDescription = (" " + gridDescription);
            if (gridDescription.Equals(DescriptionText.AutomationConfigurationTest))
            {
                // Delete configuration via sql script
                RemoveLabelImport();
                return true;
            }
            return false;
        }

        public bool AddImportLayoutConfigurationRecordWithNoVin()
        {
            // open the modal
            //AddImportLayoutButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, AddImportLayoutButton);

            // add configuration data and save
            ModalDescription.SendKeys(DescriptionText.AutomationConfigurationTest);
            Extensions.JavaScriptExicuterClick(Driver, ModalFieldDescriptionDropDown);
            //ModalFieldDescriptionDropDown.Click();
            ModalFieldDescriptionDropDown.SendKeys("Unit");
            //ModalImportLayoutOnOffButton.Click();
            //ModalSaveButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ModalImportLayoutOnOffButton);
            Extensions.JavaScriptExicuterClick(Driver, ModalSaveButton);
            KendoGrid.WaitForKendoReadyState();

            return true;
        }

        public bool VerifyProcessingLocationCodeDropdownValues()
        {
            var expectedList = new List<string>() { "Sunshine Bradenton, FL", "Sun City, AZ", "San Antonio TX" };
            SelectElement clientCode = new SelectElement(ModalProcessingLocationCodeDropDown);
            var options = clientCode.Options.Select(i => i.Text).ToList();

            return expectedList.SequenceEqual(options);
        }

        public bool VerifyClientCodeDropdownValues()
        {
            var expectedList = new List<string>() { "Hertz", "Enterprise" };
            SelectElement clientCode = new SelectElement(ModalClientCodeDropDown);
            var options = clientCode.Options.Select(i => i.Text).ToList();

            return expectedList.SequenceEqual(options);
        }

        public void WaitForPageLoad()
        {
            KendoGrid.WaitForKendoReadyState();
        }

        #endregion

        #region SQL

        /// <summary>
        /// Removes added ImportLayout test record
        /// </summary>
        public void RemoveLabelImport(string settingName = "")
        {
            string query = string.Empty;
            if (string.IsNullOrEmpty(settingName))
            {
                query = SqlStatement.DeleteLabelImportRecord;
            }
            else
            {
                query = string.Format(SqlStatement.DeleteSpecificLabelImportRecord, settingName);
            }

            SQLHelper.ExecuteNonQuery(SqlStatement.DeleteLabelImportRecord);
        }

        public bool IsShowDisabledConfigurationCheckboxDisplayed()
        {
            return ShowDisabledConfigurationCheckbox.Displayed;
        }

        public void ClickShowDisabledConfigurationCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, ShowDisabledConfigurationCheckbox);
        }

        public bool IsOnOffInputChecked(int rownumber)
        {
            var onOffInputElementXPath = string.Format(OnOffToggleInputXPath, rownumber);
            var onOffInputElement = Driver.FindElement(By.XPath(onOffInputElementXPath));
            return onOffInputElement.GetAttribute("checked") == "true" ? true : false;
        }


        #endregion
    }
}
