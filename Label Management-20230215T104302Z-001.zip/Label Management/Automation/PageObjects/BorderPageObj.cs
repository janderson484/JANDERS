using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class BorderPageObj : BorderObjBase
    {
        public BorderPageObj(IWebDriver driver) : base(driver)
        {
        }

        #region WebElements

        /// <summary>
        /// Verra Mobility image, also operates as homepage button
        /// </summary>
        private IWebElement HeaderHomePageImage => Driver.FindElement(By.XPath("//span[@id='logo']"));
        /// <summary>
        /// Functions identical to "F11" key fullscreen functionality
        /// </summary>
        private IWebElement HeaderFullScreenButton => Driver.FindElement(By.XPath("//div[@id='fullscreen']"));
        /// <summary>
        /// Toggles between completely hidden/shown sidebar menu 
        /// </summary>
        private IWebElement HeaderHideSidebarToggle => Driver.FindElement(By.XPath("//div[@id='hide-menu']"));
        /// <summary>
        /// User image dropdown with access to profile/logout options
        /// </summary>
        private IWebElement HeaderUserMenuDropdown => Driver.FindElement(By.XPath("//ul[@id='mobile-profile-img']"));
        /// <summary>
        /// Opens Profile page within new tab. Located within User Menu Button element
        /// </summary>
        private IWebElement HeaderUserMenuProfileButton => Driver.FindElement(By.XPath("//a[@data-action='userProfile']"));
        /// <summary>
        /// cogIcon - Personal Settings
        /// </summary>
        private IWebElement CogSettingsIcon => Driver.FindElement(By.Id("config-settings"));
        private IWebElement ApplicationSettingsHoverMenuOption => Driver.FindElement(By.XPath("//a[text()='Application Settings']"));
        /// <summary>
        /// Personal Settings page option
        /// </summary>
        //private IWebElement PersonalSettingsMenuOption => Driver.FindElement(By.XPath("//a[@data-action='personalSettings']"));
        private IWebElement PersonalSettingsMenuOption => Driver.FindElement(By.XPath("//a[@title='Personael Settings']"));
        /// <summary>
        /// Client Locations page option 
        /// </summary>
        private IWebElement ClientLocationsConfigMenuOption => Driver.FindElement(By.XPath("//a[@data-action='clientLocations']"));
        

        private IWebElement ContinueButtonPopup => Driver.FindElement(By.Id("Continue"));
        private IWebElement ClientDropDownPopup => Driver.FindElement(By.XPath(".//*[@aria-owns='ClientCode_listbox']"));
        private IWebElement ClientDropDownPopUp => Driver.FindElement(By.XPath("(.//*[@aria-label='select'])[1]//span"));

        
        private IWebElement HeaderClientDropdown => Driver.FindElement(By.XPath("//select[@id='HeaderClientCode']"));
        /// <summary>
        /// Header Inventory
        /// </summary>
        private IWebElement HeaderInventoryDropdown => Driver.FindElement(By.XPath("//*[@id='HeaderInventory']"));
        /// <summary>
        ///  Header Processing Location dropdown box
        /// </summary>
        private IWebElement HeaderProcessingLocationDropdown => Driver.FindElement(By.XPath("//*[@id='HeaderProcessingLocationCode']"));
        /// <summary>
        /// Header Apply button for applying dropdown selections
        /// </summary>
        private IWebElement HeaderApplyButton => Driver.FindElement(By.XPath("//button[@id='HeaderApplySelection']"));
        /// <summary>
        /// Logs user out of site. Located within User Menu Button element
        /// </summary>
        private IWebElement HeaderUserMenuLogoutButton => Driver.FindElement(By.XPath("//a[@data-action='userLogout']"));
        private IWebElement LogoutNoOption => Driver.FindElement(By.XPath("//button[@id='bot1-Msg1']"));
        private IWebElement LogoutYesOption => Driver.FindElement(By.XPath("//button[@id='bot2-Msg1']"));
        /// <summary>
        /// Displays dialog with ability to reset saved widgets and clear LocalStorage
        /// </summary>
        private IWebElement HeaderClearLocalStorageButton => Driver.FindElement(By.XPath("//span[@id='refresh']"));
        /// <summary>
        /// "Yes" button option with ClearStorage dialog
        /// </summary>
        private IWebElement ClearLocalStorageYesButton => Driver.FindElement(By.XPath("//button[contains(text(),'Yes')]"));
        /// <summary>
        /// "No" button option with ClearStorage dialog
        /// </summary>
        private IWebElement ClearLocalStorageNoButton => Driver.FindElement(By.XPath("//button[contains(text(),'No')]"));
        /// <summary>
        /// Navigates to Dashboard page
        /// </summary>
        private IWebElement SidebarDashboardRibbon => Driver.FindElement(By.XPath("//a[contains(text(),'Dashboard')]"));
        
        /// <summary>
        /// Expands/Condenses sidebar menu items
        /// </summary>
        private IWebElement SidebarToggleButton => Driver.FindElement(By.XPath("//span[@class='minifyme']"));
        /// <summary>
        /// Text displaying VM copyright
        /// </summary>
        private IWebElement FooterCopyrightText => Driver.FindElement(By.XPath("//div[@class='page-footer']//span[contains(text(), 'Verra Mobility')]"));

        private IWebElement NotificationBellIcon => Driver.FindElement(By.XPath("//i[@class='fa fa-bell']"));
        private IWebElement NotificationBulkProcessSection => Driver.FindElement(By.XPath("//div[@class='panel-heading']//a[contains(text(), 'Bulk') and contains(text(), 'Process')]"));
        private IWebElement NotificationImportLogsSection => Driver.FindElement(By.XPath("//div[@class='panel-heading']//a[contains(text(), 'Import Logs')]"));
        private IWebElement NotificationExportLogsSection => Driver.FindElement(By.XPath("//div[@class='panel-heading']//a[contains(text(), 'Export Logs')]"));
        private IList<IWebElement> NotificationBulkProcessRowsList => Driver.FindElements(By.XPath("//div[@id='BulkProcessLogs']/div[@class='panel panel-default']"));
        private IWebElement BulkProcessNotificationsLatestLogs => Driver.FindElement(By.XPath("//*[@id='BulkProcessLogs']/div[1]/div[1]/h4"));
        private IWebElement TotalFilesProcessed => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[1]/td[1]/strong[contains(text(),'Total')]"));
        private IWebElement SuccessFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[1]/td[2]/strong[contains(text(),'Success')]"));
        private IWebElement WarningFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[2]/td[1]/strong[contains(text(),'Warning')]"));
        private IWebElement ErrorFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[2]/td[2]/strong[contains(text(),'Errors')]"));
        //TODO: There is not yet any rows for ImportLogs/ExportLogs, once completed, then we can create automation for these sections
        //private IWebElement NotificationImportLogsRows => Driver.FindElement(By.XPath("//div[@id='Import']/div[@class='panel panel-default']"));
        //private IWebElement NotificationExportLogsRows => Driver.FindElement(By.XPath("//div[@id='Export']/div[@class='panel panel-default']"));
        private IList<IWebElement> LogNames_ManualNotification => Driver.FindElements(By.XPath("//div[@class='panel-heading']/h3/a"));
        private IList<IWebElement> EndTimeText_ManualNotification => Driver.FindElements(By.XPath("//div[@class='panel-heading']/h3/span"));
        private IList<IWebElement> BulkProcessEndTimeText_ManualNotification => Driver.FindElements(By.XPath("//div[@class='panel-heading']/h4/a/span"));

        private IWebElement NoImportLogsMsg => Driver.FindElement(By.XPath("//div[@id='Import']//div[@class='well info text-center']"));
        private IWebElement NoExportLogsMsg => Driver.FindElement(By.XPath("//div[@id='Export']//div[@class='well info text-center']"));
        #endregion

        #region Private Xpath helpers

        private string headerDropdownPopulated = "//select[@id='HeaderClientCode']/option[@selected='selected']";
        private string headerMenuApplicationSettingsHover = "//a[text()='Application Settings']";

        #endregion

        public void Logout()
        {
            HeaderUserMenuDropdown.WaitAndClickElement(Driver);
            Thread.Sleep(500);
            HeaderUserMenuLogoutButton.WaitAndClickElement(Driver);
            LogoutYesOption.WaitAndClickElement(Driver);
        }

        public void SelectHeaderDropdownProfilePage()
        {
            HeaderUserMenuDropdown.WaitAndClickElement(Driver);
            HeaderUserMenuProfileButton.WaitAndClickElement(Driver);
        }
        public void HeaderClearLocalStorage(bool clearStorage = false)
        {
            HeaderClearLocalStorageButton.Click();

            if(clearStorage)
                ClearLocalStorageYesButton.Click();
            else
                ClearLocalStorageNoButton.Click();
        }

        public bool HeaderImageDisplayed()
        {
            return HeaderHomePageImage.Displayed;
        }

        public void SelectHeaderFullScreenButton()
        {
            HeaderFullScreenButton.WaitAndClickElement(Driver);
        }
        
        public void SelectHeaderHideSidebarToggle()
        {
            HeaderHideSidebarToggle.WaitAndClickElement(Driver);
        }

        public void GotoDashboardPage()
        {
            SidebarDashboardRibbon.WaitAndClickElement(Driver);
        }
        
        public bool GotoPersonalSettingsPage()
        {
            try
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(.5);

                ClickCogIcon();
                PersonalSettingsMenuOption.WaitAndClickElement(Driver);
                Extensions.WaitForAndRemoveInfoPopup(Driver, seconds: 1);

                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);

                return true;
            }
            catch (NoSuchElementException)
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                //CogSettingsIcon.Click();
                Extensions.JavaScriptExicuterClick(Driver, CogSettingsIcon);
                return false;
            }
        }

        public bool GotoClientLocationsConfigPage()
        {
            try
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(.5);

                ClickCogIcon();
                Extensions.HoverOverElement(Driver, headerMenuApplicationSettingsHover);
                ClientLocationsConfigMenuOption.WaitAndClickElement(Driver);

                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);

                return true;
            }
            catch (NoSuchElementException)
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                //CogSettingsIcon.Click();
                Extensions.JavaScriptExicuterClick(Driver, CogSettingsIcon);
                return false;
            }
        }
        
        public void SelectSidebarToggleButton()
        {
            SidebarToggleButton.Click();
        }

        public bool FooterTextDisplayed()
        {
            return FooterCopyrightText.Displayed;
        }

        public void WaitUntilHeaderDropdownsPopulated()
        {
            var wait = new WebDriverWait(Driver, new TimeSpan(0, 0, 15));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(headerDropdownPopulated)));
        }

        public void ClickHeaderApplyButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, HeaderApplyButton);
        }

        public string GetHeaderClientCurrentText()
        {
            return HeaderClientDropdown.GetSelectDropDownCurrentText();
        }

        public string GetCurrentHeaderClientValue()
        {
            var clientSelect = new SelectElement(HeaderClientDropdown);
            return clientSelect.SelectedOption.GetAttribute("value");
        }

        public void SelectHeaderClientByValue(string clientCode)
        {
            var value = new SelectElement(HeaderClientDropdown);
            value.SelectByValue(clientCode);
        }

        public void ChangeClientAndProcessingLocation(string clientCode, string processingLocation)
        {
            bool changed = false;
            var abd = GetCurrentProcessingLocationValue();
            if (clientCode != GetCurrentHeaderClientValue())
            {
                SelectHeaderClientByValue(clientCode);
                changed = true;
            }

            if (processingLocation != GetCurrentProcessingLocationValue())
            {
                SelectHeaderProcessingLocationByValue(processingLocation);
                changed = true;
            }

            if (changed)
                ClickHeaderApplyButton();
        }

        public string GetHeaderProcessingLocationCurrentText()
        {
            return HeaderProcessingLocationDropdown.GetSelectDropDownCurrentText();
        }

        public string GetCurrentProcessingLocationValue()
        {
            var processingLocationSelect = new SelectElement(HeaderProcessingLocationDropdown);
            return processingLocationSelect.SelectedOption.GetAttribute("value");
        }

        public void SelectHeaderProcessingLocationByValue(string processingLocationValue)
        {
            HeaderProcessingLocationDropdown.SelectDropdownByValue(processingLocationValue);
        }

        public string GetCurrentHeaderInventoryText()
        {
            return HeaderInventoryDropdown.GetSelectDropDownCurrentText();
        }

        public string GetCurrentHeaderInventoryValue()
        {
            var inventorySelect = new SelectElement(HeaderInventoryDropdown);
            return inventorySelect.SelectedOption.GetAttribute("value");
        }

        public List<string> GetHeaderInventoryOptionsValuesList()
        {
            var options = HeaderInventoryDropdown.GetSelectDropDownOptions();
            return options.Select(option => option.GetAttribute("value")).ToList();
        }

        public void SelectHeaderInventoryByValue(string inventoryValue)
        {
            HeaderInventoryDropdown.SelectDropdownByValue(inventoryValue);
        }
        
        internal void SelectHeaderDmvState(string dvmStateName)
        {
            SelectElement value = new SelectElement(HeaderClientDropdown);

            value.SelectByText(dvmStateName);
        }

        internal void ClickonPopupContinueButton()
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(10));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(ClientDropDownPopup));
            Thread.Sleep(1000);
            ContinueButtonPopup.Click();
        }

        public void SelectClientfromPopup(string client)
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromMinutes(10));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(ClientDropDownPopup));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(".//*[@aria-owns='ClientCode_listbox']")));

            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(ContinueButtonPopup));

            Actions ac = new Actions(Driver);
            ac.MoveToElement(ClientDropDownPopUp).Click().Build().Perform();
            Thread.Sleep(100);
            Driver.FindElement(By.XPath(".//li[contains(text(),'" + client + "')]")).Click();
            Thread.Sleep(1500);
        }

        #region Notification Methods

        public void ClickNotificationBellIcon()
        {
            NotificationBellIcon.WaitAndClickElement(Driver);
            Driver.WaitUntilElementExists(NotificationBulkProcessSection);
        }

        public void ToggleNotificationBulkProcessLogsSection(bool wantExpanded)
        {
            ToggleNotificationSection(NotificationBulkProcessSection, wantExpanded);
        }

        public void ToggleNotificationImportLogsSection(bool wantExpanded)
        {
            ToggleNotificationSection(NotificationImportLogsSection, wantExpanded);
        }

        public void ToggleNotificationExportLogsSection(bool wantExpanded)
        {
            ToggleNotificationSection(NotificationExportLogsSection, wantExpanded);
        }

        /// <summary>
        /// Manual Notification test Case helpers
        /// </summary>
        public void VerifyLogNamesDisplayed()
        {
            var logNames = LogNames_ManualNotification;
            var expValues = new List<string> { "Bulk Process Logs", "Import Logs", "Export Logs" };
            var color = new List<string>();
            var values = logNames.Select(wb => wb.Text).ToList();

            for (var i = 0; i < values.Count; i++)
            {
                Assert.AreEqual(expValues[i], values[i]);
                //Since a bug has been raised for verifying the color, the below line of code is commented out
                //Assert.AreEqual("rgba(51, 51, 51, 1)", color[i]);
            }
        }

        public void VerifyEndTimeTextDisplayed()
        {
            var logNames = EndTimeText_ManualNotification;
            var values = new List<string>();
            var color = new List<string>();
            foreach (var wb in logNames)
            {
                values.Add(wb.Text);
                color.Add(wb.GetCssValue("color"));
            }
            for (var i = 0; i < values.Count; i++)
            {
                Assert.AreEqual("End Time", values[i]);
                Assert.AreEqual("rgba(51, 51, 51, 1)", color[i]);
            }
        }

        public void VerifyBulkProcessLogsLatestNotification(string expectedText)
        {
            Thread.Sleep(1000);
            Assert.IsTrue(NotificationBulkProcessRowsList[0].Text.Contains(expectedText));
        }

        #endregion

        #region Private Methods

        private void ClickCogIcon()
        {
            //CogSettingsIcon.Click();
            Extensions.JavaScriptExicuterClick(Driver, CogSettingsIcon);
            Thread.Sleep(500);
        }

        private IWebElement LogNamePanel_ByIndex(int index)
        {
            return Driver.FindElement(By.XPath("//div[" + index + "]/div[@class='panel-heading']/h3/a"));
        }

        private void ToggleNotificationSection(IWebElement notificationSection, bool wantExpanded)
        {
            var isExpanded = !notificationSection.GetAttribute("class").Contains("collapsed");
            if (!isExpanded && wantExpanded)
            {
                notificationSection.WaitAndClickElement(Driver);
            }
            else if (isExpanded && !wantExpanded)
            {
                notificationSection.WaitAndClickElement(Driver);
            }
        }

        public bool VerifyPrintLabelsInNotifications()
        {
            Extensions.JavaScriptExicuterClick(Driver, BulkProcessNotificationsLatestLogs);
            return TotalFilesProcessed.Displayed && SuccessFiles.Displayed && WarningFiles.Displayed && ErrorFiles.Displayed;
        }
        #endregion
    }
}
