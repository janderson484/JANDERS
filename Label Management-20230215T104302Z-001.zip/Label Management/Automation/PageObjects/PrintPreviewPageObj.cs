using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class PrintPreviewPageObj : TnrPageObjBase
    {
        private IWebElement PrintFirstUnitLabel => Driver.FindElement(By.Id("printFirstLabel"));
        private IWebElement PrintFirstBagLabel => Driver.FindElement(By.Id("printFirstSheet"));
        private IWebElement PrintRemainingBagLabels => Driver.FindElement(By.Id("printRemainingSheets"));
        private IWebElement PrintRemainingUnitLabels => Driver.FindElement(By.Id("printRemainingLabels"));
        private IWebElement PrintAllBagLabels => Driver.FindElement(By.Id("printAllLabels"));
        private IWebElement PrintAllUnitLabels => Driver.FindElement(By.Id("printAllLabels"));
        private IWebElement PrinterDropdown => Driver.FindElement(By.XPath("//div[@id='printerList']/span/span/span"));
        private IWebElement PrinterListDownArrow => Driver.FindElement(By.XPath("//div[@id='printerList']/span/span/span[2]/span"));
        private string AvailablePrintersXPath = "//ul[@id='dropdownlist_listbox']/li";
        private IWebElement SaveButtonBagLabel => Driver.FindElement(By.Id("saveButton"));
        private IWebElement SaveButtonUnitLabel => Driver.FindElement(By.Id("saveButton"));
        private IWebElement GoBackButtonBagLabel => Driver.FindElement(By.XPath("//button[normalize-space()='Go Back']"));
        private IWebElement GoBackButtonUnitLabel => Driver.FindElement(By.Id("cancelButton"));
        private IWebElement UpArrow => Driver.FindElement(By.XPath("//div[@id='arrowUp']/button[@id='upArrowButton']/*[local-name()='svg']/*[local-name()='path']"));
        private IWebElement PrintPreviewVINInGrid => Driver.FindElement(By.XPath("//div[@id='content']//div[@id='gridViewLabels']//table/tbody/tr[1]/td[2]"));
        
        private IWebElement ConfirmPrintBox => Driver.FindElement(By.ClassName("modal-dialog"));
        private IWebElement CancelButton => Driver.FindElement(By.Id("CancelPrintAction"));
        private IWebElement Continuebutton => Driver.FindElement(By.Id("PerformPrintAction"));

        private string GoBackButtonBagLabelXpath = "//div[@id='printAlignment']//button[contains(text(),'Go Back')]";
        private IWebElement PrintAllButton => Driver.FindElement(By.Id("printAllLabels"));
        private IWebElement PrinterDropdownPrintPreviewPage => Driver.FindElement(By.XPath("//div[@id='printerList']//span[@class='k-dropdown-wrap k-state-default']/span[@class='k-input']"));

        public KendoGridPageObj KendoGrid { get; }

        public PrintPreviewPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Label/PrintPreview";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public void ClickPrintFirstUnitLabel()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintFirstUnitLabel);
        }

        public void ClickPrintFirstBagLabel()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintFirstBagLabel);
        }

        public void ClickPrintRemainingBagLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintRemainingBagLabels);
        }

        public void ClickPrintRemainingUnitLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintRemainingUnitLabels);
        }

        public void ClickPrintAllBagLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintAllBagLabels);
        }

        public void ClickPrintAllUnitLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintAllUnitLabels);
        }

        public void ClickPrintAllButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintAllButton);
        }

        public bool IsPrintFirstBagLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintFirstBagLabel);
        }

        public bool IsPrintFirstRemaningBagLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintRemainingBagLabels);
        }

        public bool IsPrintAllBagLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintAllBagLabels);
        }

        public bool IsPrintFirstUnitLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintFirstUnitLabel);
        }

        public bool IsPrintFirstRemaningUnitLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintRemainingUnitLabels);
        }

        public bool IsPrintAllUnitLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintAllUnitLabels);
        }

        public void SelectValueInPrinterDropdown(string printerName)
        {   
            Extensions.JavaScriptExicuterClick(Driver, PrinterListDownArrow);
            var allPrinters = Driver.FindElements(By.XPath(AvailablePrintersXPath));

            foreach (var printer in allPrinters)
            {
                if (printer.Text.Equals(printerName))
                {
                    Extensions.JavaScriptExicuterClick(Driver, printer);
                }
            }

            Extensions.JavaScriptExicuterClick(Driver, PrinterListDownArrow);
        }

        public string GetPrinterSelected()
        {
            return PrinterDropdown.Text;
        }

        public List<string> GetAvailablePrinters()
        {
            Extensions.JavaScriptExicuterClick(Driver, Driver.FindElement(By.XPath("//div[@id='printerList']/span/span/span[2]/span")));
            var allPrinters = Driver.FindElements(By.XPath(AvailablePrintersXPath));

            List<string> allNames = new List<string>();

            for (int i = 0; i < allPrinters.Count; i++)
            {
                var a = allPrinters[i];
                allNames.Add(a.Text);
            }

            // var allPrinterNames = allPrinters.Select(i => i.Text).ToList<string>();

            Extensions.JavaScriptExicuterClick(Driver, Driver.FindElement(By.XPath("//div[@id='printerList']/span/span/span[2]/span")));
              
            return allNames;
        }

        public void VerifyPrinterExists(string printerOptionsViewPage)
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterDropdownPrintPreviewPage);
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var status = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("dropdownlist_listbox")));
            Extensions.JavaScriptExicuterClick(Driver, status);
            var value = "//li[contains(text(),'" + printerOptionsViewPage + "')]";
            var printerValue = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(value)));
            Extensions.JavaScriptExicuterClick(Driver, printerValue);
        }

        public void ClickContinueButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, Continuebutton);
        }

        public void ClickCancelButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CancelButton);
        }

        public bool IsSaveBagLabelButtonDisplayed()
        {
            //return IsElementDisplayedAfterWait(SaveButtonBagLabel);
            return SaveButtonBagLabel.Displayed;
        }

        public bool IsSaveUnitLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(SaveButtonUnitLabel);
        }

        public bool IsGoBackBagLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(GoBackButtonBagLabel);
            //return GoBackButtonBagLabel.Displayed;
        }

        public bool IsGoBackUnitLabelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(GoBackButtonUnitLabel);
        }

        public void ClickGoBackBagLabelButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, GoBackButtonBagLabel);
        }

        public void ClickGoBackUnitLabelButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, GoBackButtonUnitLabel);
        }

        public void ClickUpArrow()
        {
            //var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            //wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[@id='arrowUp']/button[@id='upArrowButton']/*[local-name()='svg']/*[local-name()='path']")));

            //Extensions.JavaScriptExicuterClick(Driver, UpArrow);
            Extensions.HoverOverElement(Driver, "//div[@id='arrowUp']/button[@id='upArrowButton']/*[local-name()='svg']/*[local-name()='path']");

        }

        public string PrintPreviewPageIdValue()
        {
            //return PrintPreviewVINInGrid.Text;
            return KendoGrid.GetDataCellText(1,1,1);
        }

    }
}
