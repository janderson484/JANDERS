using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class BillingFeeconfigurationPageObj : TnrPageObjBase
    {
        #region Messages
        public string Error_SelectRecordToEdit = "Edit billing type error\r\nPlease select a record to edit";
        public string Success_ConfigStatusChanged = "Billing Fee status updated successfully.";


        #endregion Messages

        public KendoGridPageObj KendoGrid { get; }

        public BillingFeeconfigurationPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/BillingFees";
            KendoGrid = new KendoGridPageObj(driver);
        }

        #region Elements
        private IWebElement AddNewBillingFeeConfigButton => Driver.FindElement(By.Id("btnAddFee"));
        private IWebElement EditBillingFeeConfigButton => Driver.FindElement(By.Id("select"));
        private IWebElement ModalSaveButton => Driver.FindElement(By.XPath("//*[@id='AddEditBillingFeeType']/div[5]/div/div/button[2]"));
        private IWebElement ModalCancelButton => Driver.FindElement(By.XPath("//*[@id='AddEditBillingFeeType']/div[5]/div/div/button"));
        private IWebElement ShowDisabledConfigurations => Driver.FindElement(By.Id("Disabled"));
        private const string OnOffToggleButtonUI = "//*[@id='BillingFeeTypes']//tr[{0}]/td/div/div/div/span";
        private const string OnOffToggleInputStatusXPath = "//*[@id='BillingFeeTypes']//tr[{0}]/td[1]/div/div/input";
        
        #endregion

        #region Helpers

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public new void Navigate(string user, string pass)
        {
            base.Navigate(user, pass);
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public void ClickAddBillingFeeConfigurationButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, AddNewBillingFeeConfigButton);
            Extensions.WaitUntilElementExists(Driver, ModalSaveButton.GetAbsoluteXPath(Driver));
        }

        public bool IsAddBillingFeeButtonDisplayed()
        {
            return AddNewBillingFeeConfigButton.Displayed;
        }

        public void ClickEditSelectedRowButton(bool showModal = true)
        {
            Extensions.JavaScriptExicuterClick(Driver, EditBillingFeeConfigButton);
            if (showModal)
            {
                Extensions.WaitUntilElementExists(Driver, ModalSaveButton.GetAbsoluteXPath(Driver));
                KendoGrid.WaitForKendoReadyState();
            }
        }

        public bool IsEditBillingFeeButtonDisplayed()
        {
            return EditBillingFeeConfigButton.Displayed;
        }

        public void CheckShowDisabledConfigs(bool expectedState = true)
        {
            if (ShowDisabledConfigurations.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, ShowDisabledConfigurations);
                WaitForPageLoad();
            }
        }

        public bool IsShowDisabledConfigurationsDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, ShowDisabledConfigurations);
        }

        public bool IsModalSaveButtonDisplayed()
        {
            var abcd = ModalSaveButton.Displayed;
            return ModalSaveButton.Displayed;
        }

        public bool IsModalCancelButtonDisplayed()
        {
            return ModalCancelButton.Displayed;
        }

        public void CloseModal()
        {
            Extensions.JavaScriptExicuterClick(Driver, ModalCancelButton);
            Extensions.WaitUntilElementIsRemoved(Driver, ModalCancelButton);
        }

        public int GetRowNumberForBillingFeeConfig(string configName)
        {
            int totalRows = KendoGrid.GetNumberOfDataRows(1, true);

            for (int i = 1; i <= totalRows; i++)
            {
                
                if (configName == GetBillingFeeConfigName(i))
                {
                    return i;
                }
            }
            return -1; // 
        }

        public string GetBillingFeeConfigName(int rowNumber)
        {
            return KendoGrid.GetDataCellText(rowNumber, 2);
        }

        public bool IsOnOffInputChecked(int rownumber)
        {
            var onOffInputElement = Driver.FindElement(By.XPath(string.Format(OnOffToggleInputStatusXPath, rownumber)));
            return onOffInputElement.GetAttribute("checked") == "true" ? true : false;
        }

        public void TurnOnOffConfigurationbyRowNumber(int rowNumber, bool turnOn, bool waitPageload = true)
        {
            if (IsOnOffInputChecked(rowNumber) != turnOn)
            {
                var tgBtn = Driver.FindElement(By.XPath(string.Format(OnOffToggleButtonUI, rowNumber)));
                Extensions.JavaScriptExicuterClick(Driver, tgBtn);

                if (waitPageload)
                    WaitForPageLoad();
            }
        }

        public List<string> GetAllBillingFeesForSortOrderVerification()
        {
            List<string> values = new List<string>();

            int totalRows = KendoGrid.GetNumberOfDataRows(1, true);
            for (int i = 1; i <= totalRows; i++)
            {
                values.Add((IsOnOffInputChecked(i) ? "A" : "D") + KendoGrid.GetDataCellText(i, 2));
            }

            return values;
        }

        public void WaitForPageLoad()
        {
            KendoGrid.WaitForKendoReadyState();
        }

        #endregion Helpers

        #region SQL

        #endregion
    }
}
