using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using Assert = NUnit.Framework.Assert;
using VM.FleetServices.TnR.LM.Web.Automation.Model;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class PrintSortOrderPageObj : TnrPageObjBase
    {
        public KendoGridPageObj KendoGrid { get; }
        public PrintSortOrderPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Configuration/CreateSortOrder";
            KendoGrid = new KendoGridPageObj(driver);
        }

        private List<GridColumn> _gridColumnList { get; set; }
        private List<string> _columnsToIgnore { get; }

        #region WebElements
        private IWebElement SettingsMenu => Driver.FindElement(By.XPath("//*[@id='config-settings']/div/a"));
        private IWebElement PersonalSettings => Driver.FindElement(By.XPath("//div[@id='config-settings']/div/ul/li[1]/a"));
        private IWebElement PrintSortOrderOption => Driver.FindElement(By.XPath("//a[@href='/Configuration/CreateSortOrder']"));
        private IWebElement GridPagination => Driver.FindElement(By.XPath("//div[@data-role='pager']"));

        private IReadOnlyCollection<IWebElement> GridHeadingNames => Driver.FindElements(By.XPath(headerColumnListXpath));
        private IWebElement ActiveColumnHeader => Driver.FindElement(By.XPath("//th[@data-field='Active']"));
        private IWebElement DescriptionColumnHeader => Driver.FindElement(By.XPath("//th[@data-field='Description']"));
        private IWebElement ClientColumnHeader => Driver.FindElement(By.XPath("//th[@data-field='ClientCode']"));
        private IWebElement OrderColumnHeader => Driver.FindElement(By.XPath("//th[@data-field='Order']"));
        private IWebElement AddNewSortOrderButton => Driver.FindElement(By.XPath("//button[@class='btn btn-primary pull-left']"));
        private IWebElement Description => Driver.FindElement(By.Id("description"));
        private IWebElement SelectFieldDropdown => Driver.FindElement(By.Id("importField_0"));
        private IWebElement SelectSortOrderDropdown => Driver.FindElement(By.Id("fieldSortOrder_0"));
        private IWebElement SaveButton => Driver.FindElement(By.Id("saveButton"));
        private IWebElement EditSortOrder => Driver.FindElement(By.Id("select"));
        private IWebElement DeleteButton => Driver.FindElement(By.Id("deleteButton"));
        private IWebElement ViewSortOrderAddEditWindow => Driver.FindElement(By.Id("ViewSortOrderAddEditWindow"));
        private IWebElement DescriptionElement => Driver.FindElement(By.XPath("//div[@id='ImportLayoutTypes']//table/tbody/tr[1]"));
        private IWebElement ShowDisabledConfigurationsCheckbox => Driver.FindElement(By.ClassName("k-checkbox-label"));
        private IWebElement ConfigurationCheckbox => Driver.FindElement(By.Id("Disabled"));
        private IWebElement ModalProcessingLocationDropdown => Driver.FindElement(By.Id("ProcessingLocationCode"));
        private IWebElement ModalClientDropdown => Driver.FindElement(By.Id("ClientCode"));
        private IWebElement ModalCancelButton => Driver.FindElement(By.XPath("//button[contains(text(),'  Cancel')]"));
        private IWebElement ModalClientCodeDropdownButton => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[1]/div/span/div/button"));
        private IWebElement ModalClientCode_SelectAll => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[1]/div/span/div/ul/li/a/label"));
        private IWebElement ModalClientCode_Hertz => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[1]/div/span/div/ul/li[2]/a/label"));
        private IWebElement ModalClientCode_Enterprise => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[2]/div[1]/div/span/div/ul/li[3]/a/label"));
        private IWebElement ModalProcessingLocationtDropdownButton => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/button"));
        private IWebElement ModalProcessingLocation_SelectAll => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/ul/li/a/label"));
        private IWebElement ModalProcessingLocation_SunShine => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/ul/li[2]/a/label"));
        private IWebElement ModalProcessingLocation_Suncity => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/ul/li[3]/a/label"));
        private IWebElement ModalAddNewElement => Driver.FindElement(By.Id("addNewField"));
        private string ModalFieldDescriptionIdFormat => "importField_";
        private IWebElement RefreshButton => Driver.FindElement(By.XPath("//div[@id='ImportLayoutTypes']/div[3]/a[@class='k-pager-refresh k-link']"));
        #endregion


        #region
        private const string SettingsMenuXPath = "//*[@id='config-settings']/div/a";
        private const string GridPaginationXpath = "//div[@data-role='pager']";
        private string headerColumnListXpath = "//thead/tr/th[@role='columnheader']";
        private const string ViewPrintOrderGrid = "//div[@id='ImportLayoutTypes']";
        private const string OnOffToggleInputXPath = "//*[@id='ImportLayoutTypes']//tr[{0}]//td[1]//div[1]//input";
        private const string OnOffToggleButtonXPath = "//*[@id='ImportLayoutTypes']//tbody//tr[{0}]//td[1]//div[1]//div";
        #endregion

        #region Element IsDisplayedMethods
        public bool IsPrintSortOrderGridDisplayed()
        {
            return IsElementDisplayedAfterWait(ViewPrintOrderGrid, 10);
        }

        public bool IsGridPaginationExists()
        {
            KendoGrid.WaitForKendoReadyState(50);

            var wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(60));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(GridPaginationXpath)));

            //return GridPagination.Displayed;
            return IsElementDisplayedAfterWait(GridPagination, 40);
        }
        #endregion

        #region
        public void NavigateToSortOrderUI()
        {
            Extensions.JavaScriptExicuterClick(Driver, SettingsMenu);

            Actions act = new Actions(Driver);
            //act.MoveToElement(SettingsMenu).Click().Build().Perform();
            //SettingsMenu.Click();
            IsElementDisplayedAfterWait(PersonalSettings);

            act.MoveToElement(PersonalSettings).Perform();
            Extensions.JavaScriptExicuterClick(Driver, PrintSortOrderOption);
        }

        /// <summary>
        /// Sets a list of the kendo grids columns containing the name and index
        /// </summary>
        /// <returns>void</returns>
        private void SetGridHeadingNames()
        {
            var columnIndex = 1;
            _gridColumnList = new List<GridColumn>();

            foreach (var webElement in GridHeadingNames)
            {
                if (string.IsNullOrWhiteSpace(webElement.Text))
                {
                    //The column header was out of view when the grid headings were obtained
                    webElement.ScrollToElement(Driver);
                }

                var isIgnored = _columnsToIgnore != null && _columnsToIgnore.Contains(webElement.Text);
                if (!isIgnored)
                {
                    _gridColumnList.Add(new GridColumn()
                    {
                        ColumnIndex = columnIndex++,
                        ColumnText = webElement.Text.ToUpper(),
                        Id = webElement.GetAttribute("id")
                    });
                }
                else
                {
                    columnIndex++;
                }
            }
        }


        private bool IsHeaderElementSortedAscending(IWebElement headerElement)
        {
            var wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(15));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-icon k-i-sort-asc-sm']")));
            return headerElement.GetAttribute("aria-sort") == "ascending";
        }

        private bool IsHeaderElementSortedDescending(IWebElement headerElement)
        {
            var wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(15));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-icon k-i-sort-desc-sm']")));
            return headerElement.GetAttribute("aria-sort") == "descending";
        }

        private bool IsColumnHeaderSortable(IWebElement headerElement)
        {
            //headerElement.ScrollToElement(Driver);
            Extensions.ScrollToElement(headerElement, Driver);
            //headerElement.Click();
            Extensions.JavaScriptExicuterClick(Driver, headerElement);

            //Thread.Sleep(3000);
            var sortableAscending = IsHeaderElementSortedAscending(headerElement);
            //headerElement.Click();
            Extensions.JavaScriptExicuterClick(Driver, headerElement);
            //Thread.Sleep(3000);
            var sortableDescending = IsHeaderElementSortedDescending(headerElement);

            return sortableAscending && sortableDescending;
        }
        private bool IsColumnHeaderSortable(string gridColumnName)
        {
            if (_gridColumnList == null)
            {
                SetGridHeadingNames();
            }

            var gridColumn = _gridColumnList.FirstOrDefault(col => col.ColumnText == gridColumnName.ToUpper());
            var column = Driver.FindElement(By.Id(gridColumn.Id));
            var result = IsColumnHeaderSortable(column);
            return result;

        }
        public bool IsViewSortOrderAddEditWindowDisplayed()
        {

            return IsElementDisplayedAfterWait(ViewSortOrderAddEditWindow, 10);
        }

        public bool IsActiveSortable()
        {
            return IsColumnHeaderSortable(PrintSortOrderColumnheadings.Active);
        }

        public bool IsDescriptionSortable()
        {
            return IsColumnHeaderSortable(PrintSortOrderColumnheadings.Description);
        }

        public List<string> SortOrderDropDownValuesList()
        {
            var options = SelectSortOrderDropdown.GetSelectDropDownOptions();
            return options.Select(option => option.GetAttribute("text")).ToList();
        }

        public bool IsSortOrderDisplayed()
        {
            return IsElementDisplayedAfterWait(SelectSortOrderDropdown, 3);
        }
        public bool IsClientSortable()
        {
            return IsColumnHeaderSortable(PrintSortOrderColumnheadings.Client);
        }

        public bool IsOrderSortable()
        {
            return IsColumnHeaderSortable(PrintSortOrderColumnheadings.Order);
        }

        public void ClickAddNewSortOrderButton()
        {
            //AddNewSortOrderButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, AddNewSortOrderButton);
        }

        public void AddNewSortOrderRecord()
        {
            ChangeBrowserTab(0);
            Description.SendKeys("PrintNewOrder" + Extensions.GetRandomString(3));
            Extensions.SelectDropdownByText(SelectFieldDropdown, "VIN");
            Extensions.SelectDropdownByText(ModalProcessingLocationDropdown, "Sunshine Bradenton, FL");
            Extensions.SelectDropdownByText(ModalClientDropdown, "Hertz");
        }

        public List<string> GetAvailableFields()
        {
            SelectElement fields = new SelectElement(SelectFieldDropdown);
            var abcd = fields.Options.Select(i => i.Text).ToList<string>();

            return fields.Options.Select(i => i.Text).ToList<string>();
        }

        /// <summary>
        /// It clicks on add new sort order and will complete the addition of new sort order record.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="field"></param>
        /// <param name="sortOrder"></param>
        public void AddNewSortOrderRecord(string description, string field, string sortOrder)
        {
            ClickAddNewSortOrderButton();
            Description.SendKeys(description);

            Extensions.SelectDropdownByText(SelectFieldDropdown, field);
            Extensions.SelectDropdownByText(SelectSortOrderDropdown, sortOrder);
            ClickSaveButton();
        }

        public void ClickSaveButton()
        {
            //AddNewSortOrderButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, SaveButton);
        }

        public void ClickDescriptionElement()
        {
            KendoGrid.ClickDataCellByRowAndColumnNumber(2, 2, 1);
        }

        public void ClickEditSortOrderButton()
        {
            //EditSortOrder.Click();
            Extensions.JavaScriptExicuterClick(Driver, EditSortOrder);
        }

        public void EditSortOrderRecord()
        {
            ChangeBrowserTab(0);
            Description.SendKeys("PrintNewOrder5");
        }

        public void ClickDeleteButton()
        {
            //DeleteButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, DeleteButton);
        }

        public bool IsShowDisabledConfigurationsCheckboxDisplayed()
        {
            return IsElementDisplayedAfterWait(ShowDisabledConfigurationsCheckbox, 5);
        }

        public void CheckShowDisabledConfigurations()
        {
            Extensions.JavaScriptExicuterClick(Driver, ShowDisabledConfigurationsCheckbox);
        }

        public bool VerifyShowDisabledConfigurationsChecked()
        {
            return ConfigurationCheckbox.Selected;
        }

        public bool VerifyProcessingLocationDropdownValues()
        {
            var expectedList = new List<string>() { "Sunshine Bradenton, FL", "Sun City, AZ", "San Antonio TX" };
            SelectElement ProcessingLocation = new SelectElement(ModalProcessingLocationDropdown);
            var options = ProcessingLocation.Options.Select(i => i.Text).ToList();

            return expectedList.SequenceEqual(options);
        }

        public bool VerifyClientDropdownValues()
        {
            var expectedList = new List<string>() { "Hertz", "Enterprise" };
            SelectElement Client = new SelectElement(ModalClientDropdown);
            var options = Client.Options.Select(i => i.Text).ToList();

            return expectedList.SequenceEqual(options);
        }

        public void ClickCloseModal()
        {
            Extensions.JavaScriptExicuterClick(Driver, ModalCancelButton);
        }

        public void AddNewSortOrderRecordDescription(string description, List<string> clients, List<string> processingLocations, string fieldDescription)
        {
            AddNewSortOrderRecordDescription(description, clients, processingLocations, new List<string> { fieldDescription });
        }

        public void AddNewSortOrderRecordDescription(string description, List<string> clients, List<string> processingLocations, List<string> fields)
        {
            Extensions.JavaScriptExicuterClick(Driver, AddNewSortOrderButton);
            Description.SendKeys(description);

            SelectClientCodeOptions(clients);
            SelectProcessingLocationOptions(processingLocations);
            AddFieldDescriptions(fields);

            Extensions.JavaScriptExicuterClick(Driver, SaveButton);
            IsNotificationMessageDisplayed(NotificationType.Success);
            ClickRefreshButton();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="index">1- All, 2-Hertz, 3- Enterprise</param>
        /// <returns></returns>
        public bool IsSelectedClientCode(string client)
        {
            bool val = false;
            string classname = string.Empty;

            switch (client)
            {
                case "Select All":
                    classname = ModalClientCode_SelectAll.GetAttribute("class");
                    break;
                case "Hertz":
                    classname = ModalClientCode_Hertz.GetAttribute("class");
                    break;
                case "Enterprise":
                    classname = ModalClientCode_Enterprise.GetAttribute("class");
                    break;
                default:
                    break;
            }

            if (!string.IsNullOrEmpty(classname))
            {
                val = classname.Contains("Active");
            }

            return val;
        }

        public void ClickClientCodeOption(string client)
        {
            IWebElement element = null;

            switch (client)
            {
                case "Select All":
                    element = ModalClientCode_SelectAll;
                    break;
                case "Hertz":
                    element = ModalClientCode_Hertz;
                    break;
                case "Enterprise":
                    element = ModalClientCode_Enterprise;
                    break;
                default:
                    break;
            }

            if (element != null)
            {
                Extensions.JavaScriptExicuterClick(Driver, element);
            }
        }


        public void ClearAllClientCodes()
        {
            if (!IsSelectedClientCode("Select All"))
            {
                ClickClientCodeOption("Select All");
            }

            ClickClientCodeOption("Select All");
        }

        public void SelectClientCodeOptions(List<string> clients)
        {
            Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropdownButton);

            ClearAllClientCodes();

            foreach (string client in clients)
                ClickClientCodeOption(client);

            Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropdownButton);
        }

        public void SelectProcessingLocationOptions(List<string> locations)
        {
            Extensions.JavaScriptExicuterClick(Driver, ModalProcessingLocationtDropdownButton);

            ClearAllProcessingLocations();

            foreach (string location in locations)
                ClickProcessingLocationOption(location);

            Extensions.JavaScriptExicuterClick(Driver, ModalProcessingLocationtDropdownButton);
        }

        public void ClearAllProcessingLocations()
        {
            if (!IsSelectedProcessingLocation("Select All"))
            {
                ClickProcessingLocationOption("Select All");
            }

            ClickProcessingLocationOption("Select All");
        }

        public void ClickProcessingLocationOption(string location)
        {
            IWebElement element = null;

            switch (location)
            {
                case "Select All":
                    element = ModalProcessingLocation_SelectAll;
                    break;
                case "Sunshine Bradenton, FL":
                    element = ModalProcessingLocation_SunShine;
                    break;
                case "Sun City, AZ":
                    element = ModalProcessingLocation_Suncity;
                    break;
                default:
                    break;
            }

            if (element != null)
            {
                Extensions.JavaScriptExicuterClick(Driver, element);
            }
        }

        public bool IsSelectedProcessingLocation(string location)
        {
            bool val = false;
            string classname = string.Empty;

            switch (location)
            {
                case "Select All":
                    classname = ModalProcessingLocation_SelectAll.GetAttribute("class");
                    break;
                case "Sunshine Bradenton, FL":
                    classname = ModalProcessingLocation_SunShine.GetAttribute("class");
                    break;
                case "Sun City, AZ":
                    classname = ModalProcessingLocation_Suncity.GetAttribute("class");
                    break;
                default:
                    break;
            }
            if (!string.IsNullOrEmpty(classname))
            {
                val = classname.Contains("Active");
            }

            return val;
        }

        public void AddFieldDescriptions(List<string> fields)
        {
            if (fields == null || fields.Count == 0)
                return;

            SelectFieldDropdown.SelectDropdownByText(fields[0]);
            string identifier;
            for (int i = 1; i < fields.Count; i++)
            {
                Extensions.JavaScriptExicuterClick(Driver, ModalAddNewElement);
                identifier = ModalFieldDescriptionIdFormat + i;
                Driver.FindElement(By.Id(identifier)).SelectDropdownByText(fields[i]);
            }
        }

        public List<string> GetAllPrintSortOrderconfigsForOrderVerification()
        {   
            List<string> values = new List<string>();

            int totalRows = KendoGrid.GetNumberOfDataRows(1, true);
            for (int i = 1; i <= totalRows; i++)
            {
                values.Add((IsOnOffInputChecked(i) ? "A" : "D") + KendoGrid.GetDataCellText(i, 2));
            }

            return values;
        }

        public bool IsOnOffInputChecked(int rownumber)
        {
            var onOffInputElementXPath = string.Format(OnOffToggleInputXPath, rownumber);
            var onOffInputElement = Driver.FindElement(By.XPath(onOffInputElementXPath));
            return onOffInputElement.GetAttribute("checked") == "true" ? true : false;
        }

        public void ToggleOnOffToggleByRowNumber(int rownumber)
        {
            var onOffElementXPath = string.Format(OnOffToggleButtonXPath, rownumber);
            var onOffElement = Driver.FindElement(By.XPath(onOffElementXPath));
            Extensions.JavaScriptExicuterClick(Driver, onOffElement);
        }

        public void ClickRefreshButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, RefreshButton);
        }

        #endregion

    }
}
