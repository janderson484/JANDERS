using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class LogPageObj : TnrPageObjBase
    {
        public LogPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Label/Logs";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public KendoGridPageObj KendoGrid { get; }

        #region WebElements

        private IWebElement LogsGrid => Driver.FindElement(By.XPath("//*[@id='Logs']/div[2]/table"));
        private IWebElement LogsGridHeader => Driver.FindElement(By.XPath("//*[@id='Logs']/div[1]/div/table/thead/tr"));
        private IEnumerable<IWebElement> LogsGridTableRows => Driver.FindElements(By.XPath("//*[@id='Logs']/div[2]/table/tbody/tr"));
        private IWebElement StartDatePicker => Driver.FindElement(By.XPath("//input[@id='startDate']"));
        private IWebElement LogSearchButton => Driver.FindElement(By.XPath("//button[@id='logSearch']"));
        private IWebElement FilterByProcess => Driver.FindElement(By.Id("filterByProcess"));

        private IWebElement Logs => Driver.FindElement(By.XPath("//span[contains(text(),'Logs')]"));
        private IWebElement ProcessName => Driver.FindElement(By.XPath("//div[@id='grdViewLogsSummary']//table//tbody/tr[1]/td[2]"));
        private string ProcessNameByRowNumberXpath = "//div[@id='grdViewLogsSummary']//table//tbody/tr[{0}]/td[2]";
        private IWebElement LogTotalCount => Driver.FindElement(By.XPath("//div[@id='grdViewLogsSummary']//table//tbody/tr[1]/td[5]"));
        private IWebElement FileName => Driver.FindElement(By.XPath("//div[@id='grdViewLogsSummary']//table//tbody/tr[1]/td[4]/a"));
        private string FileNameByRowNumXpath = "//div[@id='grdViewLogsSummary']//table//tbody/tr[{0}]/td[4]";
        private string LogStatusByRowNumXpath = "//div[@id='grdViewLogsSummary']//table//tbody/tr[{0}]/td[9]";
        private IWebElement FileExportNotification => Driver.FindElement(By.XPath("//span[contains(text(), 'Request to download the document initiated')]"));
        private IWebElement LogsRefreshButton => Driver.FindElement(By.XPath("//div[@id='grdViewLogsSummary']/div[3]/a[@class='k-pager-refresh k-link']"));


        #endregion

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon(5);
        }

        public bool LogsGridExists()
        {
            return LogsGrid != null;
        }

        public void ClickLogIdToNavigateToLogDetails(int rowNumber = 1)
        {
            KendoGrid.ClickCellHyperlinkByRowAndColumnNumber( rowNumber, GetIdColumnNumber());
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public void ClickLogSearchButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, LogSearchButton);
        }

        public bool ValidateLogsGridHeader()
        {
            var headers = LogsGridHeader.FindElements(By.TagName("th"));
            for (var i = 0; i < headers.Count; i++)
            {
                var headerText = headers[i].Text;
                if (!string.IsNullOrWhiteSpace(headerText) && headers[i].Text != LogsPage.Headers[i])
                {
                    return false;
                }
            }
            return true;
        }

        public void SortingLogsGrid()
        {
            var headers = LogsGridHeader.FindElements(By.TagName("th"));
            foreach (var header in headers)
            {
                header.Click();
            }
        }

        public bool ValidateTransactionStatus()
        {
            var tableRows = LogsGridTableRows;
            foreach (var row in tableRows)
            {
                var statusObj = row.FindElements(By.TagName("td"))[8];
                var statusText = statusObj.Text;
                var statusClass = statusObj.FindElement(By.TagName("div")).GetAttribute("class");
                if (statusClass != ((statusText == "Completed") ? LogsPage.SuccessTransaction : LogsPage.FailedTransaction))
                {
                    return false;
                }

            }
            return true;
        }

        public List<string> GetFilterByProcessValues()
        {
            SelectElement filterByProcess = new SelectElement(FilterByProcess);
            return filterByProcess.Options.Select(i => i.Text).ToList();
        }

        public int GetIdColumnNumber()
        {
            return 1;
        }

        public int GetProcessNameColumnNumber()
        {
            return 2;
        }

        public int GetProcessTypeColumnNumber()
        {
            return 3;
        }

        public int GetFileNameColumnNumber()
        {
            return 4;
        }

        public int GetTotalCountColumnNumber()
        {
            return 5;
        }

        public int GetSuccessCountColumnNumber()
        {
            return 6;
        }

        public int GetErrorCountColumnNumber()
        {
            return 7;
        }

        public int GetWarningCountColumnNumber()
        {
            return 8;
        }

        public int GetStatusColumnNumber()
        {
            return 9;
        }

        public int GetUserNameColumnNumber()
        {
            return 10;
        }

        public int GetStartTimeColumnNumber()
        {
            return 11;
        }

        public int GetEndTimeColumnNumber()
        {
            return 12;
        }

        public void SetStartDateTimeYear(string year = "2000")
        {
            Extensions.JavaScriptExicuterClick(Driver, StartDatePicker);
            StartDatePicker.SendKeys(year);
            StartDatePicker.SendKeys(Keys.Tab);
            ClickLogSearchButton();
        }

        public void ClickOnLogsRefreshButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, LogsRefreshButton);
        }

        public string GetProcessName(int rowNumber = 1)
        {
            var element = Driver.FindElement(By.XPath(string.Format(ProcessNameByRowNumberXpath, rowNumber)));
            return element.Text;
        }

        public string GetFileNameInLogs(int rowNumber = 1)
        {
            var element = Driver.FindElement(By.XPath(string.Format(FileNameByRowNumXpath, rowNumber)));
            return element.Text;
        }

        public void ClickFileNameInLogs(int rowNumber = 1)
        {
            var element = Driver.FindElement(By.XPath(string.Format(FileNameByRowNumXpath, rowNumber)));
            Extensions.JavaScriptExicuterClick(Driver, element);
        }

        public string StatusInLogs(int rowNumber = 1) 
        {
            var element = Driver.FindElement(By.XPath(string.Format(LogStatusByRowNumXpath, rowNumber)));
            return element.Text;
        }

        public void VerifyFileExportValidationDisplayed(string expectedText)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(180));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath($"//span[contains(text(), '{expectedText}')]")));
            Assert.True(expectedText.Contains(expectedText));
        }

        public void WaitForKendoReadyState(int seconds = 15)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(seconds));
            wait.Until(driver =>
            {
                var isAjaxFinished = (bool)((IJavaScriptExecutor)driver).
                    ExecuteScript("return jQuery.active == 0");
                var isLoaderHidden = (bool)((IJavaScriptExecutor)driver).
                    ExecuteScript("return $('.k-loading-image').is(':visible') == false");
                return isAjaxFinished & isLoaderHidden;
            });
        }

    }
}
