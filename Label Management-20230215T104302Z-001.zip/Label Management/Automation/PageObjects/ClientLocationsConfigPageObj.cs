using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class ClientLocationsConfigPageObj : TnrPageObjBase
    {
        public ClientLocationsConfigPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/ApplicationSettings/ClientLocations";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public KendoGridPageObj KendoGrid { get; }

        #region WebElements

        private IWebElement AddNewClientLocationButton => Driver.FindElement(By.Id("addClientLocation"));
        private IWebElement EditClientLocationButton() => Driver.FindElement(By.Id("selectClientLocation"));
        private IWebElement IdFieldReadonly() => Driver.FindElement(By.Id("ClientLocationId"));
        private IWebElement DescriptionField() => Driver.FindElement(By.Id("DisplayName"));
        private IWebElement DescriptionErrorMessage() => Driver.FindElement(By.Id("DisplayName_validationMessage"));
        private IWebElement ClientDropdown() => Driver.FindElement(By.XPath("//span[@aria-owns='Client_listbox']"));
        private IEnumerable<IWebElement> ClientDropdownOptions() => Driver.FindElements(By.XPath("//ul[@id='Client_listbox']/li"));
        private IWebElement ClientErrorMessage() => Driver.FindElement(By.Id("Client_validationMessage"));
        private IWebElement Address1Field() => Driver.FindElement(By.Id("Address1"));
        private IWebElement Address1ErrorMessage() => Driver.FindElement(By.Id("Address1_validationMessage"));
        private IWebElement Address2Field() => Driver.FindElement(By.Id("Address2"));
        private IWebElement CityField() => Driver.FindElement(By.Id("City"));
        private IWebElement CityErrorMessage() => Driver.FindElement(By.Id("City_validationMessage"));
        private IWebElement StateProvinceDropdown() => Driver.FindElement(By.XPath("//span[@aria-owns='State_listbox']"));
        private IEnumerable<IWebElement> StateProvinceDropdownOptions() => Driver.FindElements(By.XPath("//ul[@id='State_listbox']/li"));
        private IWebElement StateProvinceErrorMessage() => Driver.FindElement(By.Id("State_validationMessage"));
        private IWebElement DisabledCheckbox() => Driver.FindElement(By.Id("IsDisabled"));
        private IWebElement ModalExitButton() => Driver.FindElement(By.Id("ExitButton"));
        private IWebElement ModalSaveButton() => Driver.FindElement(By.Id("SaveButton"));
        private IWebElement UpdateFailedErrorPopup() => Driver.FindElement(By.XPath("//span[@data-notify-text and contains(text(), 'Client Location Update Failed')]"));
        private IWebElement UpdateSuccessfulPopup() => Driver.FindElement(By.XPath("//span[@data-notify-text and contains(text(), 'Client Location Updated Successfully')]"));
        private IWebElement EditSelectionErrorPopup() => Driver.FindElement(By.XPath("//span[@data-notify-text and contains(text(), 'Client Location Selection Error')]"));

        #endregion

        #region XPath Helpers

        private readonly string _modalWindowDescriptionLabelXpath = "//label[@for='DisplayName']";

        #endregion

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public new void Navigate(string user, string pass)
        {
            base.Navigate(user, pass);
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public void ClickAddNewLocationButton()
        {
            AddNewClientLocationButton.Click();
            Extensions.WaitUntilElementExists(Driver, ModalSaveButton().GetAbsoluteXPath(Driver));
        }

        public void ClickEditSelectedRowButton(bool expectError = false)
        {
            EditClientLocationButton().Click();

            if (!expectError)
                Extensions.WaitUntilElementExists(Driver, ModalSaveButton().GetAbsoluteXPath(Driver));
        }

        public void AddNewClientLocation(
            string description = "desc",
            string client = "Hertz",
            string address1 = "address1",
            string address2 = "address2",
            string city = "city",
            string stateProvince = "Florida",
            bool disabled = true)
        {
            EnterDescriptionField(description);
            SelectClientDropdown(client);
            EnterAddress1Field(address1);
            EnterAddress2Field(address2);
            EnterCityField(city);
            SelectStateProvinceDropdown(stateProvince);
            SelectDisabledCheckbox(disabled);
        }

        public void EditExistingClientLocation(
            string description = "",
            string client = "",
            string address1 = "",
            string address2 = "",
            string city = "",
            string stateProvince = "",
            bool? disabled = null)
        {

            if (!description.Equals(""))
                EnterDescriptionField(description);

            if (!client.Equals(""))
                SelectClientDropdown(client);

            if (!address1.Equals(""))
                EnterAddress1Field(address1);

            if (!address2.Equals(""))
                EnterAddress2Field(address2);

            if (!city.Equals(""))
                EnterCityField(city);

            if (!stateProvince.Equals(""))
                SelectStateProvinceDropdown(stateProvince);

            if (disabled.HasValue)
                SelectDisabledCheckbox((bool)disabled);
        }

        public void EnterDescriptionField(string description)
        {
            DescriptionField().SendIndividualKeys(description);
        }

        public void SelectClientDropdown(string clientCode)
        {
            ClientDropdown().Click();
            Thread.Sleep(500);
            ClientDropdownOptions().First(x => x.Text.Equals(clientCode)).Click();
        }

        public string GetClientDropdownSelectedText()
        {
            return Driver.FindElement(By.XPath(ClientDropdown().GetAbsoluteXPath(Driver) + "//span[@class='k-input']")).Text;
        }

        public List<string> GetClientDropdownTextOptions()
        {
            ClientDropdown().Click();
            Thread.Sleep(500);
            var options =  ClientDropdownOptions().Select(x => x.Text).ToList();
            ClientDropdown().SendKeys(Keys.Tab);
            ClientDropdown().SendKeys(Keys.Tab);
            return options;
        }

        public void EnterAddress1Field(string address1)
        {
            Address1Field().SendIndividualKeys(address1);
        }

        public void EnterAddress2Field(string address2)
        {
            Address2Field().SendIndividualKeys(address2);
        }

        public void EnterCityField(string city)
        {
            CityField().SendIndividualKeys(city);
        }

        public void SelectStateProvinceDropdown(string stateProvince)
        {
            StateProvinceDropdown().Click();
            Thread.Sleep(500);
            StateProvinceDropdownOptions().First(x => x.Text.Equals(stateProvince)).Click();
        }

        public string GetStateProvinceDropdownSelectedText()
        {
            return Driver.FindElement(By.XPath(StateProvinceDropdown().GetAbsoluteXPath(Driver) + "//span[@class='k-input']")).Text;
        }

        public void SelectDisabledCheckbox(bool ticked)
        {
            DisabledCheckbox().SetCheckbox(ticked);
        }

        public void ClickSaveButton(bool expectFail = false)
        {
            ModalSaveButton().Click();

            if (!expectFail)
            {
                Extensions.WaitUntilElementExists(Driver, UpdateSuccessfulPopup().GetAbsoluteXPath(Driver));
            }
        }

        public void ClickExitButton()
        {
            ModalExitButton().Click();
            KendoGrid.WaitForSpinningLoadIcon();
        }

        public bool AllModalErrorsDisplayed()
        {
            Assert.IsTrue(DescriptionErrorDisplayed());
            Assert.IsTrue(ClientErrorDisplayed());
            Assert.IsTrue(Address1ErrorDisplayed());
            Assert.IsTrue(CityErrorDisplayed());
            Assert.IsTrue(StateProvinceErrorDisplayed());

            return true;
        }

        public bool DescriptionErrorDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, DescriptionErrorMessage());
        }

        public bool ClientErrorDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, ClientErrorMessage());
        }

        public bool Address1ErrorDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, Address1ErrorMessage());
        }

        public bool CityErrorDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, CityErrorMessage());
        }

        public bool StateProvinceErrorDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, StateProvinceErrorMessage());
        }

        public bool UpdateFailedErrorPopupDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, UpdateFailedErrorPopup());
        }

        public bool EditSelectionErrorPopupDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, EditSelectionErrorPopup());
        }

        public int GetDescriptionColumnNumber()
        {
            return 1;
        }

        public int GetClientColumnNumber()
        {
            return 2;
        }

        public int GetDmvStateColumnNumber()
        {
            return 3;
        }
        public int GetDisabledColumnNumber()
        {
            return 4;
        }

        public void SendEscapeKeyToModal()
        {
            DescriptionField().SendKeys(Keys.Escape);
            Thread.Sleep(500);
            Extensions.WaitUntilElementExists(Driver, AddNewClientLocationButton);
        }
    }
}
