using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    class UserRolesObj : TnrPageObjBase
    {
        public UserRolesObj(IWebDriver driver,string url): base(driver, url)
        {
            Path = "";
        }


        #region WebElements

        IWebElement AddLabel => Driver.FindElement(By.XPath("//span[normalize-space()='Add Labels']"));

        IWebElement ViewBagLabesl => Driver.FindElement(By.XPath("//span[normalize-space()='View Bag Labels']"));

        IWebElement ViewBagLabelsPageHeader => Driver.FindElement(By.XPath("//h1[normalize-space()='View Bag Labels']"));

        IWebElement SaveChangesButton => Driver.FindElement(By.XPath("//a[normalize-space()='Save changes']"));

        IWebElement CancelChangesBtn => Driver.FindElement(By.XPath("//a[normalize-space()='Cancel changes']"));

        IWebElement ExportButton => Driver.FindElement(By.XPath("//button[normalize-space()='Export']"));

        IWebElement BulkUpdate => Driver.FindElement(By.XPath("//button[@id='bulkUpdate']"));

        IWebElement PrintSelected => Driver.FindElement(By.XPath("//button[@id='printSelected']"));

        IWebElement InvoiceAndClose => Driver.FindElement(By.XPath("//button[@id='invoiceSelected']"));

        IWebElement Credit => Driver.FindElement(By.XPath("//button[@id='creditSelected']"));

        IWebElement MoveSelected => Driver.FindElement(By.Id("moveSelected"));

        IWebElement CopySelected => Driver.FindElement(By.Id("copySelected"));

        IWebElement ViewUnitLabels => Driver.FindElement(By.XPath("//span[normalize-space()='View Unit Labels']"));

        IWebElement ViewUnitLabelsPageHeader => Driver.FindElement(By.XPath("//h1[normalize-space()='View Unit Labels']"));

        IWebElement BulkProcessing => Driver.FindElement(By.XPath("//span[normalize-space()='Bulk Processing']"));

        IWebElement ActivePendingLabelsRunButton => Driver.FindElement(By.XPath("//button[@id='PendingNonActiveBagLabelBulkProcess']"));

        IWebElement Reports => Driver.FindElement(By.XPath("//span[normalize-space()='Reports']"));

        IWebElement ReportsHeader => Driver.FindElement(By.XPath("//h1[normalize-space()='Reports']"));

        IWebElement Invoices => Driver.FindElement(By.XPath("//span[normalize-space()='Invoices']"));

        IWebElement ViewInvoice => Driver.FindElement(By.XPath("//a[normalize-space()='View Invoices']"));

        IWebElement ViewInvoicePageHeader => Driver.FindElement(By.XPath("//h1[normalize-space()='Invoices']"));

        IWebElement BillingSetUp => Driver.FindElement(By.XPath("//a[normalize-space()='Billing Setup']"));

        IWebElement BillingSetupPageHeader => Driver.FindElement(By.XPath("//h2[normalize-space()='Billing Fee Configuration']"));

        IWebElement Logs => Driver.FindElement(By.XPath("//a[@href='/Label/Logs']"));

        IWebElement jobId => Driver.FindElement(By.XPath("//*[@id='grdViewLogsSummary']/div[2]/table/tbody/tr[1]/td[1]/a"));

        IWebElement LogDetails => Driver.FindElement(By.XPath("//li[normalize-space()='LogDetails']"));

        IWebElement AddLabelHeader => Driver.FindElement(By.XPath("//h1[normalize-space()='Add Labels']"));

        IWebElement ImportProfileDropDown => Driver.FindElement(By.XPath("//select[@id='labelDescription']"));

        IWebElement AddLableSaveButton => Driver.FindElement(By.XPath("//button[@id='SubmitImport']"));

        private IWebElement SettingsMenu => Driver.FindElement(By.XPath("//*[@id='config-settings']/div/a"));

        IWebElement SortOrders => Driver.FindElement(By.XPath("//a[normalize-space()='Sort Orders']"));

        IWebElement SortOrderPageHeader => Driver.FindElement(By.XPath("//h2[normalize-space()='Create Sort Order']"));

        IWebElement LayOutPage => Driver.FindElement(By.XPath("//a[normalize-space()='Import Layouts']"));

        IWebElement LayoutPageHeader => Driver.FindElement(By.XPath("//h2[normalize-space()='Import Layouts']"));

        IWebElement Notifications => Driver.FindElement(By.XPath("//span[@id='activity']//a"));

        IWebElement BulkProcessLogsInNotification => Driver.FindElement(By.XPath("//div[@id='BulkProcess']"));

        IWebElement AccessDenied => Driver.FindElement(By.XPath("//h1[normalize-space()='Access Denied']"));

        IWebElement personalSettings => Driver.FindElement(By.XPath("//a[normalize-space()='Personal Settings']"));

        IWebElement PersonalSeetingsPageHeader => Driver.FindElement(By.XPath("//h2[normalize-space()='Personal Settings']"));

        private string ExpectedLayoutXpath = "//h2[normalize-space()='Expected Layout']";

        private string SaveChangesButtonXpath = "//a[normalize-space()='Save changes']";

        private string CancelChangesButtonXpath = "//a[normalize-space()='Cancel changes']";

        private string ExportButtonXpath ="//button[normalize-space()='Export']";

        private string BulkUpdateButtonXpath ="//button[@id='bulkUpdate']";

        private string PrintSelectedButtonXpath = "//button[@id='printSelected']";

        private string InvoiceAndCloseButtonXpath = "//button[@id='invoiceSelected']";

        private string CreditButtonXpath = "//button[@id='creditSelected']";

        private string MoveSelectedButtonXpath = "//button[@id='moveSelected']";

        private string CopySelectedButtonXpath = "//button[@id='copySelected']";

        private string ImportLayoutAddXpath = "//button[contains(text(),' Add')]";
        private string ImportLayoutEditXpath = "//button[@id='select']";

        #endregion


        #region Methods

        public bool VerifyIsAddLabelsIsDisplayed()
        {
            return IsElementDisplayedAfterWait(AddLabel);
        }
       

        public void ClickOnAddLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, AddLabel);
            //AddLabel.Click();
        }

       public string VerifyAddLabelsHeader()
        {
            return AddLabelHeader.Text;
        }

        public void SelectImportProfile()
        {
            Extensions.SelectDropdownByText(ImportProfileDropDown, "BagLabeldata");

            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var reportsDropdown = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(ExpectedLayoutXpath)));
        }

        public bool VerifyIsSaveButtonEnable()
        {
            return AddLableSaveButton.Enabled;
        }

        public bool ClickOnViewBagLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewBagLabesl);

            return IsElementDisplayedAfterWait(ViewBagLabelsPageHeader);
        }

        public bool ViewBagLabelsButtons()
        {
            return IsElementDisplayedAfterWait(SaveChangesButton);
            return IsElementDisplayedAfterWait (CancelChangesBtn);
            return IsElementDisplayedAfterWait (ExportButton);
            return IsElementDisplayedAfterWait (BulkUpdate);
            return IsElementDisplayedAfterWait (PrintSelected);
            return  IsElementDisplayedAfterWait(Credit);
            return IsElementDisplayedAfterWait(MoveSelected);
            return IsElementDisplayedAfterWait(CopySelected);
        }

        public bool ViewBagUnitButtons()
        {
            return IsElementDisplayedAfterWait(SaveChangesButtonXpath);
            return IsElementDisplayedAfterWait(CancelChangesButtonXpath);
            return IsElementDisplayedAfterWait (ExportButtonXpath);
            return IsElementDisplayedAfterWait (BulkUpdateButtonXpath);
            return IsElementDisplayedAfterWait (PrintSelectedButtonXpath);
            return IsElementDisplayedAfterWait(CreditButtonXpath);
            return IsElementDisplayedAfterWait(MoveSelectedButtonXpath);
            return IsElementDisplayedAfterWait(CopySelectedButtonXpath);
        }

        public bool ClickOnViewUnitLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewUnitLabels);

            return IsElementDisplayedAfterWait(ViewUnitLabelsPageHeader);
        }

        public bool ClickOnBulkProcessAndVerifyRunButtons()
        {
            Extensions.JavaScriptExicuterClick(Driver, BulkProcessing);

            return ActivePendingLabelsRunButton.Enabled;
        }

        public bool ClickOnViewInvoiceAndVerifyViewInvoice()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewInvoice);

            return ViewInvoicePageHeader.Displayed;
        }

        public bool ClickOnBillingSetUpAndVerifyBillingSetUp()
        {
            Extensions.JavaScriptExicuterClick(Driver, BillingSetUp);

            return BillingSetupPageHeader.Displayed;
        }

        public bool ClickOnReportAndVerifyReportPage()
        {
            Extensions.JavaScriptExicuterClick(Driver, Reports);

            return IsElementDisplayedAfterWait(ReportsHeader);
        }

        public void ClickOnLogs()
        {
            Extensions.JavaScriptExicuterClick(Driver, Logs);
        }

        public bool VerifyLogDetails()
        {
            Extensions.JavaScriptExicuterClick(Driver, jobId);

           return IsElementDisplayedAfterWait(LogDetails);
        }

        public void ClickOnSettingsMenu()
        {
            Extensions.JavaScriptExicuterClick(Driver, SettingsMenu);
        }

        public bool VerifySortOrders()
        {
            Extensions.JavaScriptExicuterClick(Driver, SortOrders);

           return  IsElementDisplayedAfterWait(SortOrderPageHeader);
        }

        public bool VerifyLayoutPage()
        {
            Extensions.JavaScriptExicuterClick(Driver, LayOutPage);

            return IsElementDisplayedAfterWait(ImportLayoutAddXpath);

            //return IsElementDisplayedAfterWait(LayoutPageHeader);
        }

      
        public bool VerifyNotificationsAccess()
        {

            Extensions.JavaScriptExicuterClick(Driver, Notifications);

            return IsElementDisplayedAfterWait(BulkProcessLogsInNotification);
        }

        public bool VerifyAccessDeniedForSortOredrPage()
        {
            Driver.Navigate().GoToUrl("https://fs-tnrmgmt-lm-qa-web.azurewebsites.net/Configuration/CreateSortOrder");

            return IsElementDisplayedAfterWait(AccessDenied);

        }

        public bool VerifyAccessDeniedForImportLayout()
        {
            Driver.Navigate().GoToUrl("https://fs-tnrmgmt-lm-qa-web.azurewebsites.net/Configuration");

            return IsElementDisplayedAfterWait(AccessDenied);

        }

        public bool VerifyAccessDeniedForAddLabel()
        {
            Driver.Navigate().GoToUrl("https://fs-tnrmgmt-lm-qa-web.azurewebsites.net/AddLabels/IndexAsync");

            return IsElementDisplayedAfterWait(AccessDenied);
        }

        public bool VerifyAccessDeniedForBulkProcess()
        {
            Driver.Navigate().GoToUrl("https://fs-tnrmgmt-lm-qa-web.azurewebsites.net/BulkProcessing");

            return IsElementDisplayedAfterWait(AccessDenied);
        }

        public bool VerifyAccessDeniedForLogs()
        {
            Driver.Navigate().GoToUrl("https://fs-tnrmgmt-lm-qa-web.azurewebsites.net/Label/Logs");

            return IsElementDisplayedAfterWait(AccessDenied);
        }
        public bool VerifyAccessDeniedForLogDetails()
        {
            Driver.Navigate().GoToUrl("https://fs-tnrmgmt-lm-qa-web.azurewebsites.net/Label/LogDetails");

            return IsElementDisplayedAfterWait(AccessDenied);
        }

        public bool VerifyAccessForPersonalSettingsPage()
        {
            Extensions.JavaScriptExicuterClick(Driver, personalSettings);

           return IsElementDisplayedAfterWait(PersonalSeetingsPageHeader);
        }

        #endregion






    }
}
