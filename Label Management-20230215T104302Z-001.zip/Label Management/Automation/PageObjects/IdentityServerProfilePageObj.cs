using System.Linq;
using OpenQA.Selenium;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class IdentityServerProfilePageObj : TnrPageObjBase
    {
        public IdentityServerProfilePageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Account/UserProfile";
        }

        #region WebElements

        //private IWebElement TitleText => Driver.FindElement(By.XPath("//h1[@class='title']"));
        private IWebElement TitleText => Driver.FindElement(By.XPath("//h1[contains(text(),'Welcome to Label Management')]"));

        #endregion

        public string ChangeFocusToNewTab()
        {
            var parentWindowHandler = Driver.CurrentWindowHandle;
            var newWindowHandler = Driver.WindowHandles.Last(); 
            
            Driver.SwitchTo().Window(newWindowHandler);

            return parentWindowHandler;
        }

        public bool TitleDisplayed()
        {
            return TitleText.Displayed;
        }
    }
}
