using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using VM.FleetServices.TnR.LM.Web.Automation.Model;
using VM.FleetServices.TnR.LM.Web.Automation.Tests;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class AddLabelsPageObj : TnrPageObjBase
    {
        public AddLabelsPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/AddLabels/IndexAsync";
        }

        #region Elements

        private IWebElement ImportProfileDropdown => Driver.FindElement(By.XPath("//select[@id='labelDescription']"));
        private IWebElement LabelTypeDropdown => Driver.FindElement(By.XPath("//select[@id='labelType']"));
        private IWebElement ProcessingOfficeDropdown => Driver.FindElement(By.XPath("//select[@id='processingOffice']"));
        private IWebElement LabelDataTextarea => Driver.FindElement(By.XPath("//textarea[@id='LabelData']"));
        private IWebElement GenerateBagLabelsCheckbox => Driver.FindElement(By.XPath("//input[@id='generateBagLabels']"));
        //private IWebElement ClearButton => Driver.FindElement(By.XPath("//input[@id='Reset']"));
        private IWebElement ClearButton => Driver.FindElement(By.Id("Reset"));
        private IWebElement SubmitLabelsButton => Driver.FindElement(By.XPath("//button[@id='SubmitImport']"));
        private IWebElement ExpectedLayoutResults => Driver.FindElement(By.XPath("//ul[@id='ImportOrder']"));
        private IEnumerable<IWebElement> ExpectedLayoutColumns => Driver.FindElements(By.XPath("//ul[@id='ImportOrder']/li"));
        private IWebElement WarningPopupWindow => Driver.FindElement(By.XPath("//div[@id='officeChangeWarning']"));
        private IWebElement AcknowledgeWarningButton => Driver.FindElement(By.XPath("//button[contains(text(),'Acknowledge')]"));
        private IWebElement ErrorNotificationPopupWindow => Driver.FindElement(By.XPath("//div[@id='errorModal']"));
        private IWebElement ErrorNotificationOkButton => Driver.FindElement(By.XPath("//button[contains(text(),'Okay')]"));
        private IWebElement ErrorNoficationMessageText => Driver.FindElement(By.XPath("//div[@id='errorModal']/div[1]/div[1]/div[2]"));

        #endregion

        #region XPath Strings

        private string ExpectedLayoutColumnsXPath = "//ul[@id='ImportOrder']/li";
        private string LabelTypeDropdownXPath = "//select[@id='labelType']";
        private string ProcessingOfficeDropdownXPath = "//select[@id='processingOffice']";
        private string NotificationPopupWindowMessageXPath = "//p[contains(text(),'@')]"; //Replace @ with your message
        private string ClearButtonXpath = "//input[@id='Reset']";


        #endregion

        #region Helpers
        public void Navigate()
        {
            base.Navigate();
        }

        public void Navigate(string user, string pass)
        {
            base.Navigate(user, pass);
        }

        public void ClickClearButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ClearButton);
        }

        public void ClickSubmitLabelsButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, SubmitLabelsButton);
        }

        public bool IsGenerateBagLabelsCheckboxChecked()
        {
            return GenerateBagLabelsCheckbox.Selected;
        }

        public void ClickGenerateBagLabelsCheckbox()
        {
            GenerateBagLabelsCheckbox.Click();
        }

        public void ClickAcknowledgeWarningButton()
        {
            AcknowledgeWarningButton.Click();
        }

        public void ClickErrorNotificationOkButton()
        {
            //ErrorNotificationOkButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, ErrorNotificationOkButton);
        }

        public string GetErrorNotificationMessage()
        {
            return ErrorNoficationMessageText.Text;
        }

        public string GetLabelTypeSelectionDescription()
        {
            var labelTypeSelect = new SelectElement(Driver.FindElement(By.XPath(LabelTypeDropdownXPath)));
            return labelTypeSelect.SelectedOption.Text.Trim();
        }

        public string GetProcessingOfficeSelectionDescription()
        {

            var processingOfficeSelect = new SelectElement(Driver.FindElement(By.XPath(ProcessingOfficeDropdownXPath)));
            return processingOfficeSelect.SelectedOption.Text.Trim();
        }

        public int GetNumberImportProfileColumns()
        {
            var importProfileColumns = Driver.FindElements(By.XPath(ExpectedLayoutColumnsXPath));
            return importProfileColumns.Count;
        }

        public bool IsLabelDataTextAreaEmpty()
        {
            return string.IsNullOrEmpty(LabelDataTextarea.GetAttribute("value"));
        }

        public void WaitForPageRefresh()
        {
            Extensions.WaitUntilElementIsRemoved(Driver, ImportProfileDropdown);
        }
        #endregion

        #region Element Displayed Helpers

        public bool IsImportProfileDropdownDisplayed()
        {
            return ImportProfileDropdown.Displayed;
        }

        public bool IsImportProfileDropdownContainsProfile(string profileName)
        {
            SelectElement importProfile = new SelectElement(ImportProfileDropdown);

            return importProfile.Options.Select(i => i.Text).ToList().Contains(profileName);            
        }

        public List<string> GetImportProfileDropdownValues()
        {
            SelectElement importProfile = new SelectElement(ImportProfileDropdown);
            var allProfiles = importProfile.Options.Select(i => i.Text).ToList<string>();
            return allProfiles;
        }

        public bool IsLabelTypeDropdownDisplayed()
        {
            return LabelTypeDropdown.Displayed;
        }

        public bool IsProcessingOfficeDropdownDisplayed()
        {
            return ProcessingOfficeDropdown.Displayed;
        }

        public bool IsLabelDataTextareaDisplayed()
        {
            return LabelDataTextarea.Displayed;
        }

        public bool IsGenerateBagLabelsCheckboxDisplayed()
        {
            return GenerateBagLabelsCheckbox.Displayed;
        }

        public bool IsClearButtonDisplayed()
        {
            return ClearButton.Displayed;
        }

        public bool IsSubmitLabelsButtonDisplayed()
        {
            return SubmitLabelsButton.Displayed;
        }

        public bool IsExpectedLayoutResultsDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, ExpectedLayoutResults);
        }

        public bool IsWarningPopupWindowDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, WarningPopupWindow);
        }

        public bool IsAcknowledgeWarningButtonDisplayed()
        {
            return AcknowledgeWarningButton.Displayed;
        }

        public bool IsErrorNotificationPopupWindowDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, ErrorNotificationPopupWindow);
        }
        public bool IsNotificationPopupWindowVisible()
        {
            var wait = new WebDriverWait(Driver, new TimeSpan(0, 0, 20));

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(ErrorNotificationPopupWindow.GetAbsoluteXPath(Driver))));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool IsErrorNotificationOkButtonDisplayed()
        {
            return ErrorNotificationOkButton.Displayed;
        }

        /// <summary>
        /// Determines if your message is displayed inside the popup notification window
        /// </summary>
        /// <param name="expectedMessage">Your expected message</param>
        /// <param name="timeToWait">Time to wait in seconds</param>
        /// <returns>Result</returns>
        public bool IsPopupWindowMessageDisplayed(string expectedMessage, double timeToWait = 15)
        {
            if (string.IsNullOrWhiteSpace(expectedMessage))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(expectedMessage));

            var replacedMessageXpath = NotificationPopupWindowMessageXPath.Replace("@", expectedMessage);

            IWebElement messagePopup = null;
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(timeToWait));

            messagePopup = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(replacedMessageXpath)));

            if (messagePopup == null)
                return false;

            Thread.Sleep(1000);
            var popupMessage = messagePopup.Text.Trim();
            return popupMessage.ToUpper().Contains(expectedMessage.ToUpper());
        }

        #endregion

        #region Form Interaction Helpers

        public bool SelectImportProfileByText(string importProfile)
        {
            return Extensions.SelectDropdownByText(ImportProfileDropdown, importProfile);
        }

        public bool SelectProcessingOfficeByText(string processingOffice)
        {
            return Extensions.SelectDropdownByText(ProcessingOfficeDropdown, processingOffice);
        }
        public bool SelectImportProfileByValue(string importProfile)
        {
            return Extensions.SelectDropdownByValue(ImportProfileDropdown, importProfile);
        }
        public bool SelectLabelTypeByValue(string labelType)
        {
            return Extensions.SelectDropdownByValue(LabelTypeDropdown, labelType);
        }
        public bool SelectProcessingOfficeByValue(string processingOffice)
        {
            return Extensions.SelectDropdownByValue(ProcessingOfficeDropdown, processingOffice);
        }
        public bool AddLabelData(string textValue, bool tabAtEnd = false)
        {
            try
            {
                LabelDataTextarea.SendIndividualKeys(textValue, tabAtEnd);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public string GetSelectedProcessingLocationValue()
        {
            return Extensions.GetSelectDropDownCurrentText(ProcessingOfficeDropdown);
        }

        public List<string> GetAllOptionsOfProcessingLocationValues()
        {
            var options = ProcessingOfficeDropdown.GetSelectDropDownOptions();
            return options.Select(option => option.GetAttribute("text")).ToList();
        }
        #endregion

        private string GetRandomVin()
        {
            return $"{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(4)}{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(2)}{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(3)}{Extensions.GetRandomNumber(10000, 99999)}".ToUpper();
        }


    }
}
