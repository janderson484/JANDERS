using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class ViewInvoicesPageObj : TnrPageObjBase
    {
        public KendoGridPageObj KendoGrid { get; }
        public ViewInvoicesPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Invoice";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public string Success_PrintReqCreated = "Request to print invoice created successfully!";
        public string Success_AllRowsExported = "All visible rows will be exported to Excel.";

        #region Static Methods
        #endregion

        #region WebElements

        private IWebElement InvoiceStatusDropdown => Driver.FindElement(By.XPath("//span[@class='multiselect-selected-text']"));
        private IWebElement InvoiceStatus_SelectAll => Driver.FindElement(By.XPath("//div[@id='invoiceSearch']/div/div[1]/div/span/div/ul/li[1]/a/label"));
        private IWebElement InvoiceStatus_Open => Driver.FindElement(By.XPath("//div[@id='invoiceSearch']/div/div[1]/div/span/div/ul/li[2]/a/label"));
        private IWebElement InvoiceStatus_Closed => Driver.FindElement(By.XPath("//div[@id='invoiceSearch']/div/div[1]/div/span/div/ul/li[3]/a/label"));
        private IWebElement InvoiceStatus_Void => Driver.FindElement(By.XPath("//div[@id='invoiceSearch']/div/div[1]/div/span/div/ul/li[4]/a/label"));
        private IWebElement SelectInvoiceDropDown => Driver.FindElement(By.XPath("//select[@id='Invoice']"));
        private IWebElement SelectInvoiceDropDownButton => Driver.FindElement(By.XPath("//div[@id='invoiceSearch']/div/div[2]/div/span"));
        private string SelectInvoiceDropDownListXpath = "//div[@id='Invoice-list']/div/ul/li";

        private IWebElement ViewInvoiceDetailsButton => Driver.FindElement(By.XPath("//div[@id='invoiceSearch']/div/div[3]/button"));

        private IWebElement CloseInvoiceButton => Driver.FindElement(By.Id("closeInvoice"));
        private string CloseInvoiceButtonXpath = "//*[@id='closeInvoice']";
        private IWebElement ConfirmCloseInvoiceButton => Driver.FindElement(By.Id("continueClose"));
        private IWebElement CancelCloseInvoiceButton => Driver.FindElement(By.Id("cancelClose"));

        private IWebElement PrintInvoiceButton => Driver.FindElement(By.Id("printInvoice"));
        private IWebElement ExportInvoiceButton => Driver.FindElement(By.XPath("//div[@id='grdInvoiceDetails']/div/a"));

        //continueClose

        /// //div[@id='invoiceSearch']/div/div[1]/div/span/div/ul/li[1]

        #endregion

        public void ClickCloseInvoiceButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CloseInvoiceButton);


        }

        public bool IsCloseInvoiceButtonDisplayed()
        {
            return Extensions.WaitUntilElementExists(Driver, CloseInvoiceButtonXpath);
        }

        public void DeleteExportedFile()
        {
            if (File.Exists(GridExport.ExportedInvoiceFile))
            {
                File.Delete(GridExport.ExportedInvoiceFile);
            }
        }

        public bool ExportDownloadFileExists()
        {
            if (File.Exists(GridExport.DownloadedFile))
            {
                return true;
            }

            return false;
        }

        public void ClickOnPrintInvoiceButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintInvoiceButton);
        }

        public void ClickOnExportInvoiceButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportInvoiceButton);
        }

        public void ClickConfirmCloseInvoiceButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ConfirmCloseInvoiceButton);
        }

        public void ClickCancelCloseInvoiceButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CancelCloseInvoiceButton);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectAll"></param>
        /// <param name="open"></param>
        /// <param name="closed"></param>
        /// <param name="voided"></param>
        public void SelectInvoiceStatus(bool selectAll, bool open, bool closed, bool voided)
        {   
            Extensions.JavaScriptExicuterClick(Driver, InvoiceStatusDropdown);
            if (selectAll)
            {
                Extensions.JavaScriptExicuterClick(Driver, InvoiceStatus_SelectAll);
            }
            else
            {
                if (open)
                    Extensions.JavaScriptExicuterClick(Driver, InvoiceStatus_Open);

                if (closed)
                    Extensions.JavaScriptExicuterClick(Driver, InvoiceStatus_Closed);

                if (voided)
                    Extensions.JavaScriptExicuterClick(Driver, InvoiceStatus_Void);
            }

            Extensions.JavaScriptExicuterClick(Driver, InvoiceStatusDropdown);
        }

        public bool SelectInvoiceByText(string invoiceName)
        {
            return Extensions.SelectDropdownByText(SelectInvoiceDropDown, invoiceName);
        }

        public bool SelectInvoiceByindex(int index)
        {
            var xpath = SelectInvoiceDropDownListXpath + "[" + index + "]";
            
            for (int attempt = 1; attempt < 5; attempt++)
            {
                Extensions.JavaScriptExicuterClick(Driver, SelectInvoiceDropDownButton);

                if (Extensions.WaitUntilElementExists(Driver, xpath, 2))
                {
                    break; //we found the list updated. So moving on! 
                }
                Extensions.JavaScriptExicuterClick(Driver, SelectInvoiceDropDownButton);
            }
            
            Extensions.JavaScriptExicuterClick(Driver, Driver.FindElement(By.XPath(xpath)));
            return true;
        }

        public List<string> GetAllAvailableInvoices()
        {
            Extensions.JavaScriptExicuterClick(Driver, SelectInvoiceDropDownButton);
            var liItems = Driver.FindElements(By.XPath(SelectInvoiceDropDownListXpath));
            var list = new List<string>();
            foreach (var li in liItems)
            {
                list.Add(li.Text);
            }
            Extensions.JavaScriptExicuterClick(Driver, SelectInvoiceDropDownButton);

            return list;
        }

        public void ClickViewInvoiceDetailsButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewInvoiceDetailsButton);
            KendoGrid.WaitForKendoReadyState();
        }
    }
}
