using System;
using System.Data;
using System.Data.SqlClient;
using OpenQA.Selenium;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class LoginPageObj : PageObjBase
    {
        protected IWebDriver Driver;
        public LoginPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Driver = driver;
            Path = "";
        }

        #region WebElements

        /// <summary>
        /// Username text field
        /// </summary>
        private IWebElement UsernameField => Driver.FindElement(By.Id("Username"));

        /// <summary>
        /// Password text field
        /// </summary>
        private IWebElement PasswordField => Driver.FindElement(By.Id("password"));

        /// <summary>
        /// Login button
        /// </summary>
        private IWebElement LoginBtn => Driver.FindElement(By.XPath("//input[@value = 'Login']"));

        /// <summary>
        /// Username is required error
        /// </summary>
        private IWebElement UsernameRequiredError => Driver.FindElement(By.XPath("//li[text() = 'The Username field is required']"));
        
        /// <summary>
        /// Password is required error
        /// </summary>
        private IWebElement PasswordRequiredError => Driver.FindElement(By.XPath("//li[text() = 'The Password field is required']"));

        /// <summary>
        /// Invalid username or password error
        /// </summary>
        private IWebElement InvalidLoginError => Driver.FindElement(By.XPath("//li[text() = 'Invalid username or password']"));

        #endregion

        #region Private Methods

        /// <summary>
        /// Attempts login with given arguments. Will take long time if DTUs are not increased.
        /// </summary>
        /// <param name="username">username value to attempt login</param>
        /// <param name="password">password value to attempt login</param>
        public void AttemptLogin(string username = UserCredentials.AdminUsername, string password = UserCredentials.AdminPassword)
        {
            UsernameField.SendKeys(username);
            PasswordField.SendKeys(password);
            LoginBtn.Click();
        }

        public void NavigateToInitialClientStateForm(string username = UserCredentials.AdminUsername, string password = UserCredentials.AdminPassword)
        {
            var dashboardPage = new DashboardPageObj(Driver, BaseUrl);

            if (Driver.Url.Contains(BaseUrl))
            {
                if (dashboardPage.IsInitialCustomerListWindowDisplayed())
                {
                    dashboardPage.ClickInitialCustomerListCancelButton();
                }
                else
                {
                    dashboardPage.Border.Logout();
                }
            }

            Navigate();
            UsernameField.SendKeys(username);
            PasswordField.SendKeys(password);
            LoginBtn.Click();
         }

        public bool UsernameRequiredErrorDisplayed()
        {
            try
            {
                return UsernameRequiredError.Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public bool PasswordRequiredErrorDisplayed()
        {
            try
            {
                return PasswordRequiredError.Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public bool InvalidLoginErrorDisplayed()
        {
            try
            {
                return InvalidLoginError.Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public new void Navigate()
        {
            Driver.Navigate().GoToUrl(FullPath);

            if (Driver.Url.Contains(BaseUrl))
            {
                var dashboardPage = new DashboardPageObj(Driver, BaseUrl);
                
                dashboardPage.Border.Logout();
            }
        }

        public bool IsUsernameFieldDisplayed()
        {
            return IsElementDisplayedAfterWait(UsernameField);
        }

        public bool IsPasswordFieldDisplayed()
        {
            return IsElementDisplayedAfterWait(PasswordField);
        }

        public bool IsLoginButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(LoginBtn);
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Reset User Preferences for new TestUser
        /// </summary>
        /// <param name="userId"></param>
        public void RemoveTestUserPreferences(string userId)
        {
            if (userId == null)
                throw new ArgumentOutOfRangeException(nameof(userId));
                                    
            var sqlQuery = $"Delete From [dbo].[UserPreferences] Where UserId = '{userId}' and ActionCode = 'HeaderSelection_LM'";
            SQLHelper.ExecuteNonQuery(sqlQuery,SQLHelper.PMConnectionString);
        }
        #endregion
    }
}
