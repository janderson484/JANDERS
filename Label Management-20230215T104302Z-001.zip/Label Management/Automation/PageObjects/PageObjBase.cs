using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Collections.ObjectModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Threading;
using NPOI.SS.Formula.Functions;
using VM.FleetServices.TnR.LM.Web.Automation.Model;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public abstract class PageObjBase
    {
        private readonly IWebDriver _driver;
        protected readonly string BaseUrl;

        protected static string LoggedInUser;
        protected string Path;
        private IWebElement pageTitle => _driver.FindElement(By.ClassName("page-title"));
        private string pageTileXpath = "//div[@class='flex-page-header']/*";

        public string FullPath => BaseUrl + Path;

        #region
        protected PageObjBase(IWebDriver driver, string url)
        {
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
            _driver = driver;
            BaseUrl = url;
        }

        private string CustomerListModal => "//*[@id='CustomerListModal']/div/div/div[1]/h4";
        private readonly string notificationSuccessPopupCss = ".notifyjs-bootstrap-base.notifyjs-bootstrap-success>span";
        private readonly string notificationErrorPopupCss = ".notifyjs-bootstrap-base.notifyjs-bootstrap-error>span";
        private readonly string notificationInfoPopupCss = ".notifyjs-bootstrap-base.notifyjs-bootstrap-info>span";
        private readonly string notificationWarnPopupCss = ".notifyjs-bootstrap-base.notifyjs-bootstrap-warn>span";

        public void Navigate(string user = UserCredentials.AdminUsername, string pass = UserCredentials.AdminPassword)
        {
            bool isChangeUser = LoggedInUser != user;
            bool isApplicationOpen = _driver.Url.Contains(BaseUrl);

            if (!isApplicationOpen)
            {
                _driver.Navigate().GoToUrl(BaseUrl);

                var loginPage = new LoginPageObj(_driver, BaseUrl);

                loginPage.AttemptLogin(user, pass);

                if (IsElementDisplayedAfterWait(CustomerListModal, 3))
                {
                    var dashboardPage = new DashboardPageObj(_driver, BaseUrl);

                    //dashboardPage.SetInitialCustomerListDropdownsAndSubmit(Clients.Hertz, Inventories.FloridaInventory);
                    dashboardPage.SetInitialInventoryClientAndSubmit(1, 1);
                    dashboardPage.Border.WaitUntilHeaderDropdownsPopulated();
                    dashboardPage.Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunshineBradenton);
                }

                LoggedInUser = user;
            }
            else if (isApplicationOpen && isChangeUser)
            {
                LoginToCorrectUser(user, pass);
                LoggedInUser = user;
            }
            else
            {
                // Do nothing; As app is open & correct user is logged in.
            }

            //TODO: Remove this after direct navigation issue is resolved
            _driver.Navigate().GoToUrl(FullPath);
        }

        public bool PersistedNavigation(string user = UserCredentials.AdminUsername, string pass = UserCredentials.AdminPassword)
        {
            try
            {
                _driver.Navigate().GoToUrl(BaseUrl);

                var loginPage = new LoginPageObj(_driver, BaseUrl);

                loginPage.AttemptLogin(user, pass);
            }
            catch (Exception e)
            {
                //LoginToCorrectUser(user, pass);
            }
            _driver.Navigate().GoToUrl(FullPath);
            return true;
        }

        public void Navigate(string user, string pass, string client = Clients.Hertz, string inventory = Inventories.FloridaInventory)
        {
            if (!_driver.Url.Contains(BaseUrl))
            {
                _driver.Navigate().GoToUrl(BaseUrl);

                var loginPage = new LoginPageObj(_driver, BaseUrl);

                loginPage.AttemptLogin(user, pass);
            }
            else
            {
                //LoginToCorrectUser(user, pass);
            }

            SelectInitialInventoryClient();

            //TODO: Remove this after direct navigation issue is resolved
            _driver.Navigate().GoToUrl(FullPath);
        }

        /// <summary>
        /// Assumes driver already logged in. Does no validations, purely navigates.
        /// </summary>
        public void DirectNavigate()
        {
            _driver.Navigate().GoToUrl(FullPath);
        }

        public bool ErrorMessage403Displayed()
        {
            try
            {
                _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(.5);
                _driver.FindElement(By.XPath("//div[@class='error-code' and @jscontent='errorCode']"));
                _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                return true;
            }
            catch (NoSuchElementException)
            {
                _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                return false;
            }
        }

        private void LoginToCorrectUser(string user, string pass)
        {
            _driver.Navigate().GoToUrl(BaseUrl);
            var borderPage = new BorderPageObj(_driver);
            borderPage.Logout();
            var loginPage = new LoginPageObj(_driver, BaseUrl);
            loginPage.AttemptLogin(user, pass);
            SelectInitialInventoryClient();
        }

        public void ZoomBrowser(int percent = 100)
        {
            ((IJavaScriptExecutor)_driver).ExecuteScript($"document.body.style.zoom = '{percent}%';");
        }

        public void ChangeBrowserTab(int tabNumber)
        {
            _driver.SwitchTo().Window(_driver.WindowHandles[tabNumber]);
        }

        /// <summary>
        /// Gets the current Page title
        /// </summary>
        /// <returns></returns>
        public string PageTitle
        {
            get
            {
                var potentialHeader = _driver.FindElements(By.XPath(pageTileXpath))[0];
                var pageUrl = _driver.Url;

                if (potentialHeader.TagName.ToUpper().StartsWith("H"))
                    return potentialHeader.Text.Trim();
                else if (pageUrl.Contains("account/login"))
                    return "Login";
                else if (pageUrl.Equals(BaseUrl))
                    return "Welcome to Label Management";
                else
                {
                    return "NO TITLE ON PAGE";
                }
            }
        }

        /// <summary>
        /// Will look for a WebElement to be displayed after a period of time needed for loading to the page
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        protected bool IsElementDisplayedAfterWait(IWebElement element, int timeToWait = 5)
        {
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(timeToWait));
            try
            {
                wait.Until(condition =>
                {
                    try
                    {
                        return element.Displayed;
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                });
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        protected string GetElementTextAfterWait(string elementXpath, string attribute = "text", int timeToWait = 5)
        {
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(timeToWait));
            try
            {
                wait.Until(condition =>
                {
                    try
                    {
                        var element = _driver.FindElement(By.XPath(elementXpath));
                        var abc = element.Text;
                        return element.Text;
                    }
                    catch (NoSuchElementException)
                    {
                        return "NoElementFound";
                    }
                });
                return "NoElementFound";
            }
            catch (WebDriverTimeoutException)
            {
                return "NoElementFound";
            }
        }

        /// <summary>
        /// Will look for a WebElement by XPath to be displayed after a period of time needed for loading to the page
        /// </summary>
        /// <param name="elementXPath"></param>
        /// <param name="timeToWait"></param>
        /// <returns></returns>
        protected bool IsElementDisplayedAfterWait(string elementXPath, int timeToWait = 4)
        {
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(timeToWait));
            try
            {
                wait.Until(condition =>
                {
                    try
                    {
                        var element = _driver.FindElement(By.XPath(elementXPath));
                        return element.Displayed;
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                });
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="elementCSS"></param>
        /// <param name="timeToWait"></param>
        /// <returns></returns>
        protected bool IsElementDisplayedAfterWaitByCSS(string elementCSS, int timeToWait = 4)
        {
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(timeToWait));
            try
            {
                wait.Until(condition =>
                {
                    try
                    {
                        var element = _driver.FindElement(By.CssSelector(elementCSS));
                        return element.Displayed;
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                });
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        protected string GetElementTextAfterWaitByCSS(string elementCSS, string userFriendlyObjectname, int timeToWait = 10)
        {
            try
            {
                var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(15));
                var testElement = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(elementCSS)));

                return testElement.Text;
            }
            catch (Exception)
            {
            }

            return $"{userFriendlyObjectname} object not found";
        }

        private string GetNotificationCss(NotificationType notification)
        {
            string elementCss = string.Empty;

            switch (notification)
            {
                case NotificationType.Error:
                    elementCss = notificationErrorPopupCss;
                    break;
                case NotificationType.Success:
                    elementCss = notificationSuccessPopupCss;
                    break;
                case NotificationType.Info:
                    elementCss = notificationInfoPopupCss;
                    break;
                case NotificationType.Warn:
                    elementCss = notificationWarnPopupCss;
                    break;
            }

            return elementCss;
        }

        public bool IsNotificationMessageDisplayed(NotificationType notification, int timeToWait = 10)
        {
            return IsElementDisplayedAfterWaitByCSS(GetNotificationCss(notification), timeToWait);
        }

        public string GetNotificationMessageText(NotificationType notification, int timeToWait = 10)
        {
            return GetElementTextAfterWaitByCSS(GetNotificationCss(notification), "Notification message ", timeToWait);
        }

        public bool WaitForSpecificNotificationMessage(NotificationType notification, string message, int timeToWait = 15)
        {
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(timeToWait));

            try
            {
                wait.Until(condition =>
                {
                    try
                    {
                        if (GetNotificationMessageText(notification, 2).Contains(message))
                            return true;
                        else
                            return false;
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                });
                return true;
            }
            catch (WebDriverTimeoutException)
            {
            }

            return false;
        }

        /// <summary>
        /// Selects an item from a kendo dropdown list control by index
        /// </summary>
        /// <param name="driver">The chrome web driver</param>
        /// <param name="jqueryId">The string id that was used on the kendo dropdown list control</param>
        /// <param name="optionIndex">The index of the item to select</param>
        public static void SelectKendoDropDownListItemByIndex(IWebDriver driver, string jqueryId, int optionIndex)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript($"$('#{jqueryId}').data('kendoDropDownList').select({optionIndex});");
        }

        private void SelectInitialInventoryClient()
        {
            if (IsElementDisplayedAfterWait(CustomerListModal, 5))
            {
                var dashboardPage = new DashboardPageObj(_driver, BaseUrl);

                dashboardPage.SetInitialInventoryClientAndSubmit(1, 1);
                dashboardPage.Border.WaitUntilHeaderDropdownsPopulated();
                dashboardPage.Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunshineBradenton);
            }
        }

        /// <summary>
        /// Check if given header element is sorted in ascending order
        /// </summary>
        /// <param name="headerElement"></param>
        /// <returns></returns>
        /*protected bool IsHeaderElementSortedAscending(IWebElement headerElement)
        {
            IWebDriver _driver = null;
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-icon k-i-sort-asc-sm']")));
            return headerElement.GetAttribute("aria-sort") == "ascending";
        }

        /// <summary>
        /// Check if given header element is sorted in descending order
        /// </summary>
        /// <param name="headerElement"></param>
        /// <returns></returns>
        protected bool IsHeaderElementSortedDescending(IWebElement headerElement)
        {
            IWebDriver _driver = null;
            var wait = new WebDriverWait(_driver, System.TimeSpan.FromSeconds(30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-icon k-i-sort-desc-sm']")));
            return headerElement.GetAttribute("aria-sort") == "descending";
        }

        /// <summary>
        /// Checks if given header element can be sorted in both ascending and descending orders
        /// </summary>
        /// <param name="headerElement"></param>
        /// <returns></returns>
        protected bool IsColumnHeaderSortable(IWebElement headerElement)
        {

            //headerElement.ScrollToElement(_driver);
            Extensions.ScrollToElement(headerElement, _driver);
            //headerElement.Click();
            Extensions.JavaScriptExicuterClick(_driver, headerElement);
            var sortableAscending = IsHeaderElementSortedAscending(headerElement);
            //headerElement.Click();
           
            Extensions.JavaScriptExicuterClick(_driver, headerElement);

            var sortableDescending = IsHeaderElementSortedDescending(headerElement);

            return sortableAscending && sortableDescending;
        }*/

        public void SendEscKey()
        {
            var action = new Actions(_driver);
            action.SendKeys(Keys.Escape).Perform();
        }

    }
    public abstract class KendoGridObjBase
    {
        protected readonly IWebDriver Driver;

        protected KendoGridObjBase(IWebDriver driver) => Driver = driver;
    }

    public abstract class BorderObjBase
    {
        protected readonly IWebDriver Driver;

        protected BorderObjBase(IWebDriver driver) => Driver = driver;
    }

    public abstract class TnrPageObjBase : PageObjBase
    {
        protected readonly IWebDriver Driver;
        public BorderPageObj Border { get; }

        protected TnrPageObjBase(IWebDriver driver, string url) : base(driver, url)
        {
            Driver = driver;
            Border = new BorderPageObj(driver);
        }

        private IWebElement AutoLogoutStayLoggedIn => Driver.FindElement(By.Id("stay-logged-in-button"));
        private IWebElement AutoLogoutSignOut => Driver.FindElement(By.Id("signout-button"));

        private IWebElement AutoLogoutDialog => Driver.FindElement(By.Id("SessionExpireNotification"));

        /// <summary>
        /// Will return whether the Timeout CountDown Timer is showing up or not.
        /// </summary>
        /// <returns></returns>
        public bool IsTimeOutDialogVisible(int timeToWait = 2)
        {
            return IsElementDisplayedAfterWait(AutoLogoutDialog, timeToWait);
        }

      
        /// <summary>
        /// Clicks 'Stay Logged In' on the Auto logout dialog
        /// </summary>
        public void ClickStayLoggedInOnAutoLogout()
        {
            Extensions.JavaScriptExicuterClick(Driver, AutoLogoutStayLoggedIn);
        }

        /// <summary>
        /// Clicks 'Continue Logout' on the Auto logout dialog
        /// </summary>
        public void ClickSignOutOnAutoLogOut()
        {
            Extensions.JavaScriptExicuterClick(Driver, AutoLogoutSignOut);
        }

    }
    #endregion   
}
