using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using Assert = NUnit.Framework.Assert;
using System.Data.SqlClient;
using VM.FleetServices.TnR.LM.Web.Automation.Model;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class BulkProcessingPageObj : TnrPageObjBase
    {
        public KendoGridPageObj KendoGrid { get; }
        public BulkProcessingPageObj(IWebDriver driver, string url) : base(driver,url)
        {
            Path = "/BulkProcessing";
            KendoGrid = new KendoGridPageObj(driver);
        }
        #region WebElements
        private IWebElement Title => Driver.FindElement(By.XPath("//div[@id='content']/h1[contains(text(),'Bulk Processing')]"));
        private IWebElement BagLabelsRunButton => Driver.FindElement(By.Id("PendingNonActiveBagLabelBulkProcess"));
        private IWebElement UnitLabelsRunButton => Driver.FindElement(By.Id("PendingNonActiveUnitLabelBulkProcess"));
        private IWebElement PendingInvoiceLabelCount => Driver.FindElement(By.Id("PendingInvoiceLabelCount"));
        private IWebElement PendingInvoiceLabelBulkRunButton => Driver.FindElement(By.Id("PendingInvoiceLabelBulkProcess"));
        private IWebElement PendingBagLabelsCount => Driver.FindElement(By.XPath("//div/span[@id='PendingNonActiveBagLabelCount']"));
        private IWebElement PendingUnitLabelsCount => Driver.FindElement(By.XPath("//div/span[@id='PendingNonActiveUnitLabelCount']"));
        private IWebElement ContinueButton => Driver.FindElement(By.XPath("//input[@id='PerformBulkAction']"));
        private IWebElement ConfirmationForm => Driver.FindElement(By.XPath("//div[@class='modal-content']"));
        private IWebElement Logs => Driver.FindElement(By.XPath("//span[contains(text(),'Logs')]"));
        private IWebElement CloseActiveLabelsRunButton => Driver.FindElement(By.Id("SetPrintedAndActiveToClosedBulkProcess"));
        private IWebElement PrintedAndActiveLabelsCount => Driver.FindElement(By.XPath("//div/span[@id='SetPrintedAndActiveToClosedCount']"));
        private IWebElement NotificationsIcon => Driver.FindElement(By.XPath("//span[@id='activity']"));
        private IWebElement BulkProcessNotificationsLatestLogs => Driver.FindElement(By.XPath("//*[@id='BulkProcessLogs']/div[1]/div[1]/h4"));
        private IWebElement TotalFilesProcessed => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[1]/td[1]/strong[contains(text(),'Total')]"));
        private IWebElement SuccessFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[1]/td[2]/strong[contains(text(),'Success')]"));
        private IWebElement WarningFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[2]/td[1]/strong[contains(text(),'Warning')]"));
        private IWebElement ErrorFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[2]/td[2]/strong[contains(text(),'Errors')]"));
        private IWebElement ProcessNameInLogs => Driver.FindElement(By.XPath("//*[@id='grdViewLogsSummary']/div[2]/table/tbody/tr[1]/td[contains(text(),'Set Printed And Active To Closed Action')]"));
        private IWebElement LogPageProcessName => Driver.FindElement(By.XPath("//*[@id='grdViewLogsSummary']/div[2]/table/tbody/tr[1]/td[2]"));
        private IWebElement LogPageTotalProcessed => Driver.FindElement(By.XPath("//tbody/tr[1]/td[5]"));
        private IWebElement LogPageTotalSuccess => Driver.FindElement(By.XPath("//tbody/tr[1]/td[6]"));
        private IWebElement LogPageErrors => Driver.FindElement(By.XPath("//tbody/tr[1]/td[7]"));
        private IWebElement LogPageWarnings => Driver.FindElement(By.XPath("//tbody/tr[1]/td[8]"));
        private IWebElement LogPageStatus => Driver.FindElement(By.XPath("//tbody/tr[1]/td[9]/div"));
        private IWebElement LogDetailsPageTitle => Driver.FindElement(By.XPath("//h1[contains(text(),'Log Details')]"));
        private IWebElement LogPageHyperlinkProcessID => Driver.FindElement(By.XPath("//*[@id='grdViewLogsSummary']/div[2]/table/tbody/tr[1]/td[1]/a"));
        private IWebElement BulkProcessCompletionMessage => Driver.FindElement(By.XPath("//body/div[11]/div[1]/div[2]/div[1]/span[1]"));

        #endregion

        #region
        private const string BagLabelsRunButtonXPath = "//button[@id='PendingNonActiveBagLabelBulkProcess']";
        private const string UnitLabelsRunButtonXPath = "//button[@id='PendingNonActiveUnitLabelBulkProcess']";
        private const string ContinueButtonXPath = "//input[@id='PerformBulkAction']";
        private const string CloseActiveLabelsRunButtonXPath = "//button[@id='PendingNonActiveBagLabelBulkProcess']";
        public const string ProcessNameLogXpath = "//*[@id='grdViewLogsSummary']/div[2]/table/tbody/tr[1]/td[2]";
        public const string LogDetailsPageTitleXpath = "//h1[contains(text(),'Log Details')]";
        public const string BulkProcessCompletionMessageXpath = "//body/div[11]/div[1]/div[2]/div[1]/span[1]";

        #endregion

        #region IsDisplayedMethods
        public bool IsTitleDisplayed()
        {
            return IsElementDisplayedAfterWait(Title, 20);
        }

        #endregion

        #region
        public void ClickBagLabelsRunButton()
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(BagLabelsRunButtonXPath)));
            Extensions.JavaScriptExicuterClick(Driver, BagLabelsRunButton);
        }

        public void ClickUnitLabelsRunButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, UnitLabelsRunButton);
        }

        public void ClickPendingInvoiceLabelBulkRunButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, PendingInvoiceLabelBulkRunButton);
        }

        public void ClickAlertConfirmation()
        {
            ChangeBrowserTab(0);
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(ContinueButtonXPath)));
            Extensions.JavaScriptExicuterClick(Driver, ContinueButton);
        }

        public bool IsConfirmationFormDisplayed()
        {
            return IsElementDisplayedAfterWait(ConfirmationForm, 30);
        }

        public void ClickOnLogsInLeftMenu()
        {
            Extensions.JavaScriptExicuterClick(Driver,Logs);
        }

        public int VerifyPendingBagLabelsCount()
        {
            var pendingbagcount = PendingBagLabelsCount.Text;

            int count = Convert.ToInt32(pendingbagcount);
            return count;
        }

        public int GetPendingInvoiceLabelCount()
        {
            return Convert.ToInt32(PendingInvoiceLabelCount.Text);
        }

        public string GetLogPageProcessName()
        {
            return LogPageProcessName.Text;
        }

        public string GetLogPageStatus()
        {
            return LogPageStatus.Text;
        }

        public int VerifyPendingUnitLabelsCount()
        {
            var pendingunitcount = PendingUnitLabelsCount.Text;

            int count = Convert.ToInt32(pendingunitcount);
            return count;
        }

        public void CreateDataForActivatependingLabels(bool isUnitLabel )
        {
            string Labeltype = isUnitLabel ? "1" : "2";
            string UpdateQuery = $"UPDATE [lm].[Labels] SET LabelStatusTypeId = 1 WHERE LabelId IN (select Top 5 LabelId from lm.labels where labelTypeid = {Labeltype} and clientCode = 'HERTZ' and processinglocationcode ='FL-BRADENTON' order by labelid asc);";
            SQLHelper.ExecuteNonQuery(UpdateQuery);
        }

        public int CreateDbDataForInvoicePendingLabelsBulkProcess(int countNeeded = 1)
        {
            if (countNeeded < 1 || countNeeded > 100)
                countNeeded = 1;

            for (int i = 0; i < countNeeded; i++)
            {
                DataHelper.InsertLabel(statueType: LabelStatusTypeEnum.Pending, printLabel: true);
            }

            return countNeeded;
        }

        public int ClearDbDataForInvoicePendingLabelsBulkProcess()
        {
            const string updateQuery = "update lm.Labels set PrintCount = 0 where LabelId in ( SELECT lbl.LabelId FROM lm.[LabelBillings] as LBL " +
                        "JOIN lm.[Labels] as LB ON LBL.LabelId = LB.LabelId WHERE LB.LabelStatusTypeId != 5 AND LBL.Void = 0 AND(LBL.InvoiceId = 0 OR " +
                        "LBL.InvoiceId Is Null) AND LB.PrintCount != 0)";

            return SQLHelper.ExecuteNonQuery(updateQuery);
        }


        public int GetDbCountForPendingInvoiceLabelBulkProcess()
        {
            const string SQLSelect = @"SELECT count(distinct lbl.LabelId) FROM lm.[LabelBillings] as LBL JOIN lm.[Labels] as LB ON LBL.LabelId = LB.LabelId" +
                                " WHERE LB.LabelStatusTypeId != 5 AND LBL.Void = 0 AND (LBL.InvoiceId = 0 OR LBL.InvoiceId Is Null) AND LB.PrintCount != 0";

            return SQLHelper.ExecuteScalar(SQLSelect);
        }

        public int PendingBagLabelsDBCount()
        {
            const string SQLSelect = @"select count(*) from [lm].[Labels] where LabelStatusTypeId=1 and LabelTypeId=2 and clientCode = 'HERTZ' and processinglocationcode ='FL-BRADENTON'";
            return SQLHelper.ExecuteScalar(SQLSelect);
        }

        public int PendingUnitLabelsDBCount()
        {
            const string SQLSelect = @"select count(*) from [lm].[Labels] where LabelStatusTypeId=1 and LabelTypeId=1 and clientCode = 'HERTZ' and processinglocationcode ='FL-BRADENTON'";
            return SQLHelper.ExecuteScalar(SQLSelect);
        }

        #region "Set Printed and Active to Closed Status"

        public int VerifyPrintedAndActiveLabelsCount()
        {
            var pendingbagcount = PrintedAndActiveLabelsCount.Text;

            int count = Convert.ToInt32(pendingbagcount);
            return count;
        }

        public void ClickOnNotificationsIcon()
        {
            //NotificationsIcon.Click();
            Extensions.JavaScriptExicuterClick(Driver, NotificationsIcon);
        }

        public void ClickCloseActiveLabelsRunButton()
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(CloseActiveLabelsRunButtonXPath)));
            Extensions.JavaScriptExicuterClick(Driver, CloseActiveLabelsRunButton);
        }

        public bool VerifyCloseActiveLabelsInNotifications()
        {
            //BulkProcessNotificationsLatestLogs.Click();
            Extensions.JavaScriptExicuterClick(Driver, BulkProcessNotificationsLatestLogs);
            return IsElementDisplayedAfterWait(TotalFilesProcessed) &&
            IsElementDisplayedAfterWait(SuccessFiles) &&
            IsElementDisplayedAfterWait(WarningFiles) &&
            IsElementDisplayedAfterWait(ErrorFiles);
        }

        public bool VerifyCloseActiveLabelsInLogsPage()
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            return IsElementDisplayedAfterWait(ProcessNameInLogs);
        }

        public bool VerifyLogsPageTotalCountSuccessErrorAndWarnings()
        {
            return IsElementDisplayedAfterWait(LogPageTotalProcessed)&&
             IsElementDisplayedAfterWait(LogPageTotalSuccess)&&
             IsElementDisplayedAfterWait(LogPageErrors)&&
              IsElementDisplayedAfterWait(LogPageWarnings);

        }

        public int LogPageTotalProcessedCount()
        {
            return Convert.ToInt32(LogPageTotalProcessed.Text.Trim());
        }

        public int LogPageSuccessCount()
        {
            return Convert.ToInt32(LogPageTotalSuccess.Text.Trim());
        }

        public int LogPageErrorCount()
        {
            return Convert.ToInt32(LogPageErrors.Text.Trim());
        }

        public int LogPageWarningCount()
        {
            return Convert.ToInt32(LogPageWarnings.Text.Trim());
        }

        public bool VerifyLogDetailsPage()
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(300));
            IsElementDisplayedAfterWait(LogPageHyperlinkProcessID);
            Extensions.JavaScriptExicuterClick(Driver, LogPageHyperlinkProcessID);
            return IsElementDisplayedAfterWait(LogDetailsPageTitle);
        }

        public bool VerifyBulkProcessCompletionMessage()
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(300));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(BulkProcessCompletionMessageXpath)));

            return IsElementDisplayedAfterWait(BulkProcessCompletionMessage);
        }

        public int PrintedActiveLabelsDBCount()
        {
            const string SQLSelect = @"select count(*) from lm.Labels where lm.Labels.LabelStatusTypeId = 3 and lm.Labels.IsPrinted = 1 "+
                "and ClientCode = 'Hertz' and ProcessingLocationCode = 'FL-BRADENTON';";

            return SQLHelper.ExecuteScalar(SQLSelect);
        }

        public void CreateDataForPrintedAndActiveLabels()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl.IsPrinted = true;
            lbl.PrintCount = 1;
            DataHelper.InsertLabel(lbl);

            const string UpdateQuery = @"UPDATE [lm].[Labels] SET IsPrinted = 1, LabelStatusTypeId = 3  WHERE LabelId in (" +
                "select top 10 labelId from lm.labels where ClientCode = 'Hertz' and ProcessingLocationCode = 'FL-BRADENTON'  order by  labelId asc)";
            SQLHelper.ExecuteNonQuery(UpdateQuery);
        }

        #endregion

        #endregion
    }
}
