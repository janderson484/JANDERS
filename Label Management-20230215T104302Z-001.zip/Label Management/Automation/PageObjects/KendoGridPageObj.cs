using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using NPOI.Util;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class KendoGridPageObj : KendoGridObjBase
    {
        public KendoGridPageObj(IWebDriver driver) : base(driver)
        {
            Border = new BorderPageObj(driver);
        }

        public BorderPageObj Border { get; }

        #region WebElements

        private IEnumerable<IWebElement> HeadersList => Driver.FindElements(By.XPath("//thead/tr/th[@role='columnheader']"));
        private List<IWebElement> KendoGridList => Driver.FindElements(By.XPath("//div[@data-role='grid']")).ToList();
        private List<IWebElement> CurrentPageSelectionList => Driver.FindElements(By.XPath("//li[@class='k-current-page']//span")).ToList();
        private List<IWebElement> PageOneButtonList => Driver.FindElements(By.XPath("//ul[@class='k-pager-numbers k-reset']//a[@data-page='1']")).ToList();
        private List<IWebElement> PageTwoButtonList => Driver.FindElements(By.XPath("//ul[@class='k-pager-numbers k-reset']//a[@data-page='2']")).ToList();
        private List<IWebElement> FirstPageArrowButtonList => Driver.FindElements(By.XPath("//a[@title='Go to the first page']")).ToList();
        private List<IWebElement> PreviousPageArrowButtonList => Driver.FindElements(By.XPath("//a[@title='Go to the previous page']")).ToList();
        private List<IWebElement> NextPageArrowButtonList => Driver.FindElements(By.XPath("//a[@title='Go to the next page']")).ToList();
        private List<IWebElement> LastPageArrowButtonList => Driver.FindElements(By.XPath("//a[@title='Go to the last page']")).ToList();
        private IWebElement FirstPageArrowButton => Driver.FindElement(By.XPath("//a[@title='Go to the first page']"));
        private IWebElement PreviousPageArrowButton => Driver.FindElement(By.XPath("//a[@title='Go to the previous page']"));
        private IWebElement NextPageArrowButton => Driver.FindElement(By.XPath("//a[@title='Go to the next page']"));
        private IWebElement LastPageArrowButton => Driver.FindElement(By.XPath("//a[@title='Go to the last page']"));
        private List<IWebElement> ItemsPerPageDropdownList => Driver.FindElements(By.XPath("//span[contains(text(), 'items per page')]/span[@role='listbox']/span/span")).ToList();
        private IWebElement CurrentPageLabel => Driver.FindElement(By.XPath("//li[@class='k-current-page']"));
        private IEnumerable<IWebElement> NearbyPageNumberButtonsList => Driver.FindElements(By.XPath("//div[@data-role='pager']/ul/li[not(@class='k-current-page')]"));
        private IEnumerable<IWebElement> ItemsPerPageOptions => Driver.FindElements(By.XPath("//ul[@class='k-list k-reset']/li"));
        private List<IWebElement> PageItemsInfoLabel => Driver.FindElements(By.XPath("//span[@class='k-pager-info k-label'][1]")).ToList();
        private IWebElement ColumnSortedAscending => Driver.FindElement(By.XPath("//th[@aria-sort='ascending']"));
        private IWebElement ColumnSortedDescending => Driver.FindElement(By.XPath("//th[@aria-sort='descending']"));
        private IWebElement HeaderSelectAllCheckbox => Driver.FindElement(By.XPath("//thead//input[@data-role='checkbox']"));
        private IWebElement GridLoadingIconElement => Driver.FindElement(By.XPath("//div[@class='k-loading-mask']"));
        
        #endregion

        #region Xpath Helpers
        
        private string dataColumnListXpath = "//tbody/tr[1]/td[not(input)]";

        private string dataRowCountBeginXpath = "(//table[@role='grid']//tbody)[";
        private string dataRowCountEndXpath = "]/tr[@role='row' and (@class='k-state-selected' or @class='k-alt k-state-selected')]";
        private string dataRowCountEndXpathForExportAll = "]/tr[@role='row']";

        private string dataRowBeforeTableXpath = "(//div/table[@role='grid']/tbody)[";
        private string dataRowAfterTableXpath = "]/tr[";
        private string dataRowMiddleXpath = "]/td[";
        private string dataRowMiddleXpathExcludingCheckbox = "]/td[not(input) and not(contains(@style,'display:none'))][";
        private string dataRowEndXpath = "]";

        private string ColumnHeadersXpath = "//th[@role = 'columnheader']";
        private string headerColumnBeginXpath = "(//thead)[";
        private string headerColumnEndXpath = "]/tr/th[@role='columnheader']";
        private string headerSortableColumnEndXpath = "]/tr/th[@role='columnheader']";

        private string gridHeaderResizableXpath = "//div[@data-role='grid']//div[@data-role='resizable']";

        #endregion

        /// <summary>
        /// Waits to continue until the grid no longer displays the "loading" animation.
        /// </summary>
        public bool WaitForSpinningLoadIcon(int seconds = 15)
        {
            try
            {
                var gridLoadingIconXpath = "//div[@class='k-loading-mask']";


                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(seconds);
                var wait = new WebDriverWait(Driver, new TimeSpan(0, 0, seconds));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(gridLoadingIconXpath)));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.StalenessOf(GridLoadingIconElement));

                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);

                return true;
            }
            catch
            {
                //Loading icon never displayed (The grid did not refresh)
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                return false;
            }
        }
        
        public void WaitForGridAnimation()
        {
            // Using "wait" will remove focus from the element
            Thread.Sleep(500);
        }

        public int GetNumberOfKendoGrids()
        {
            return KendoGridList.Count;
        }

        /// <summary>
        /// Gets cell text at desired row and column
        /// </summary>
        /// <param name="rowNumber"></param>
        /// <param name="columnNumber"></param>
        /// <param name="tableNumber"></param>
        /// <returns></returns>
        public string GetDataCellText(int rowNumber, int columnNumber, int tableNumber = 1)
        {
            var dataCellXpath = GetDataCellXpathByRowColumnAndTable(rowNumber, columnNumber, tableNumber);
            return Driver.FindElement(By.XPath(dataCellXpath)).Text;
        }


        /// <summary>
        /// Gets rpw text at desired row
        /// </summary>
        /// <param name="rowNumber"></param>
        /// <param name="tableNumber"></param>
        /// <returns></returns>
        public List<string> GetDataRowTextList(int rowNumber, int tableNumber = 1)
        {
            var rowTextList = new List<string>();
            var headerCount = GetAllHeaderList(tableNumber).Count;

            for (var headerNumber = 1; headerNumber <= headerCount; headerNumber++)
            {
                rowTextList.Add(GetDataCellText(rowNumber, headerNumber, tableNumber));
            }

            return rowTextList;
        }

        /// <summary>
        /// Select cell by row and column. NOTE: first cell is row = 1, column = 1.
        /// </summary>
        /// <param name="rowNumber">First data row = 1</param>
        /// <param name="columnNumber">First data column = 1</param>
        /// <param name="tableNumber">First table = 1</param>
        public void ClickDataCellByRowAndColumnNumber(int rowNumber, int columnNumber, int tableNumber = 1)
        {
            if (rowNumber < 1 || columnNumber < 1)
            {
                throw new ArgumentException($"{nameof(rowNumber)} cannot be less than 1. {nameof(columnNumber)} cannot be less than 1.");
            }

            var dataCellXpath = GetDataCellXpathByRowColumnAndTable(rowNumber, columnNumber, tableNumber);

            //Driver.FindElement(By.XPath(dataCellXpath)).Click();
            Extensions.JavaScriptExicuterClick(Driver, Driver.FindElement(By.XPath(dataCellXpath)));
        }

        public void ClickCellHyperlinkByRowAndColumnNumber(int rowNumber, int columnNumber, int tableNumber = 1)
        {
            if (rowNumber < 1 || columnNumber < 1)
            {
                throw new ArgumentException($"{nameof(rowNumber)} cannot be less than 1. {nameof(columnNumber)} cannot be less than 1.");
            }

            var dataCellHyperlinkXpath = GetDataCellXpathByRowColumnAndTable(rowNumber, columnNumber, tableNumber) + "/a";

            Extensions.JavaScriptExicuterClick(Driver, Driver.FindElement(By.XPath(dataCellHyperlinkXpath)));
        }

        private string GetDataCellXpathByRowColumnAndTable(int rowNumber, int columnNumber, int tableNumber)
        {
            return dataRowBeforeTableXpath + tableNumber + dataRowAfterTableXpath + rowNumber
                            + dataRowMiddleXpathExcludingCheckbox + columnNumber + dataRowEndXpath;
        }

        public int GetCurrentPageNumberSelection(int tableNumber = 1)
        {
            Thread.Sleep(1000);
            return int.Parse(CurrentPageSelectionList[tableNumber - 1].GetAttribute("textContent"));
        }

        public bool ClickFirstPage(int tableNumber = 1, int waitSeconds = 15)
        {
            PageOneButtonList[tableNumber - 1].Click();
            return WaitForSpinningLoadIcon(waitSeconds);
        }

        public bool ClickSecondPage(int tableNumber = 1, int waitSeconds = 15)
        {
            try
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1);
                PageTwoButtonList[tableNumber - 1].Click();
                var secondPageExists = WaitForSpinningLoadIcon(waitSeconds);
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);

                return secondPageExists;
            }
            catch (ArgumentOutOfRangeException)
            {
                return false;
            }
            catch (ElementNotVisibleException)
            {
                return false;
            }
        }

        public bool IsMoreThanOnePage(int tableNumber = 1)
        {
            return Driver.FindElements(By.XPath(
                       "(//ul[@class='k-pager-numbers k-reset'])[" + tableNumber +
                       "]/li[not(contains(@class,'k-current-page'))]")).Count > 1;
        }

        public bool ClickFirstPageArrow(int tableNumber = 1, int waitSeconds = 15)
        {
            FirstPageArrowButtonList[tableNumber - 1].Click();
            return WaitForSpinningLoadIcon(waitSeconds);
        }

        public bool ClickLastPageArrow(int tableNumber = 1, int waitSeconds = 15)
        {
            LastPageArrowButtonList[tableNumber - 1].Click();
            return WaitForSpinningLoadIcon(waitSeconds);
        }

        public bool ClickPreviousPageArrow(int tableNumber = 1, int waitSeconds = 15)
        {
            PreviousPageArrowButtonList[tableNumber - 1].Click();
            return WaitForSpinningLoadIcon(waitSeconds);
        }

        public bool ClickNextPageArrow(int tableNumber = 1, int waitSeconds = 15)
        {
            //NextPageArrowButtonList[tableNumber - 1].Click();
            Extensions.JavaScriptExicuterClick(Driver, NextPageArrowButtonList[tableNumber - 1]);
            return WaitForSpinningLoadIcon(waitSeconds);
        }

        public void ClickFirstPageArrowButton()
        {
            if (!GetCurrentPageNumberSelection().ToString().Equals("1"))
            {
                FirstPageArrowButton.Click();
                WaitForSpinningLoadIcon();
            }
        }

        public int GetFirstNearbyPageNumber()
        {
            return Convert.ToInt32(NearbyPageNumberButtonsList.First().Text);
        }

        public int GetLastNearbyPageNumber()
        {
            return Convert.ToInt32(NearbyPageNumberButtonsList.Last().Text);
        }

        public int GetNearbyPageNumberCount()
        {
            return NearbyPageNumberButtonsList.Count();
        }

        public IWebElement GetLastPageArrowElement()
        {
            return LastPageArrowButton;
        }

        public int GetCurrentItemsPerPageDropdownValue(int tableNumber = 1)
        {
            Thread.Sleep(1000);

            return Convert.ToInt32(ItemsPerPageDropdownList[tableNumber - 1].GetAttribute("innerHTML"));
        }

        public IList<string> GetItemsPerPageTextOptions(int tableNumber = 1)
        {
            Extensions.ScrollToElement(ItemsPerPageDropdownList[tableNumber - 1], Driver);
            Extensions.JavaScriptExicuterClick(Driver, ItemsPerPageDropdownList[tableNumber - 1]);
            WaitForGridAnimation();
            var pageOptions = ItemsPerPageOptions.Select(x => x.Text).ToList();
            //Click off the drodown
            Extensions.JavaScriptExicuterClick(Driver, PageItemsInfoLabel[tableNumber - 1]);
            WaitForGridAnimation();

            pageOptions.RemoveAll(x => x.Equals(""));
            Extensions.ScrollToTop(Driver);

            return pageOptions;
        }

        public int GetTotalSearchResultCount(int tableNumber = 1)
        {
            WaitForKendoReadyState();
            var text = PageItemsInfoLabel[tableNumber - 1].Text;
            return text.Equals("No items to display") ? 0 : Convert.ToInt32(text.Split(' ')[4]);
        }

        public void SelectItemsPerPageByString(string itemsPerPageOption, int tableNumber = 1, int waitSeconds = 30)
        {
            if (itemsPerPageOption.Equals(GetCurrentItemsPerPageDropdownValue(tableNumber).ToString())) return;

            Extensions.JavaScriptExicuterClick(Driver, ItemsPerPageDropdownList[tableNumber - 1]);
            WaitForGridAnimation();
            Extensions.JavaScriptExicuterClick(Driver, ItemsPerPageOptions.First(x => x.Text.Equals(itemsPerPageOption)));
            WaitForSpinningLoadIcon(waitSeconds);
        }

        public void SelectMinimumItemsPerPage(int tableNumber = 1)
        {
            SelectItemsPerPageByString(GetItemsPerPageTextOptions().First(), tableNumber);
        }

        public void SelectMaximumItemsPerPage(int tableNumber = 1)
        {
            SelectItemsPerPageByString(GetItemsPerPageTextOptions().Last(), tableNumber);
        }

        public void SelectAllGridCheckboxes(bool tickCheckbox = true)
        {
            Driver.WaitUntilElementExists(HeaderSelectAllCheckbox);
            HeaderSelectAllCheckbox.SetCheckbox(tickCheckbox);
        }

        /// <summary>
        /// Gets total columns contained within the table (Excluding checkbox column).
        /// </summary>
        /// <returns></returns>
        public int GetNumberOfDataColumns(int tableNumber = 1)
        {
            var headerColumnListXpath = headerColumnBeginXpath + tableNumber + headerSortableColumnEndXpath;
            return Driver.FindElements(By.XPath(headerColumnListXpath)).Count;
        }

        /// <summary>
        /// Gets total number of data rows currently displayed in the table (Excluding header row).
        /// </summary>
        /// <returns></returns>
        public int GetNumberOfDataRows(int tableNumber = 1, bool exportAll = false)
        {
            try
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(.5);
                var dataRowXpath = dataRowCountBeginXpath + tableNumber + (exportAll ? dataRowCountEndXpathForExportAll : dataRowCountEndXpath);
                var rowCount = Driver.FindElements(By.XPath(dataRowXpath)).Count;
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);

                return rowCount;
            }
            catch (NoSuchElementException)
            {
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(DefaultSettings.ImplicitWait);
                return 0;
            }
        }

        public string GetAllGridDataAsString(int tableNumber = 1)
        {
            var rowCount = GetNumberOfDataRows(tableNumber);
            var columnCount = GetNumberOfDataColumns();
            var tableTextString = "";

            for (var rowNumber = 1; rowNumber < rowCount; rowNumber++)
            {
                for (var columnNumber = 1; columnNumber < columnCount; columnNumber++)
                {
                    tableTextString += GetDataCellText(rowNumber, columnNumber, tableNumber);
                }
            }

            return tableTextString;
        }

        public string GetColumnDataAsString(int columnNumber, int tableNumber = 1)
        {
            var rowCount = GetNumberOfDataRows(tableNumber, true);
            var columnTextString = "";

            if (rowCount != 0)
            {
                for (var rowNumber = 1; rowNumber <= rowCount; rowNumber++)
                {
                    columnTextString += GetDataCellText(rowNumber, columnNumber, tableNumber);
                }
            }

            return columnTextString;
        }


        public List<string> GetColumnDataAsList(int columnNumber, int tableNumber = 1)
        {
            var rowCount = GetNumberOfDataRows(tableNumber, true);
            var columnTextList = new List<string>();

            for (var rowNumber = 1; rowNumber <= rowCount; rowNumber++)
            {
                columnTextList.Add(GetDataCellText(rowNumber, columnNumber, tableNumber));
            }

            return columnTextList;
        }

        public bool IsEntireColumnSameValue(int columnNumber, int tableNumber = 1)
        {
            //This assumes sorting only sorts current page values, not the entire table dataset
            var rowCount = GetNumberOfDataRows(tableNumber);
            var firstColumnValue = GetDataCellText(1, columnNumber, tableNumber);

            for (var rowNumber = 2; rowNumber < rowCount; rowNumber++)
            {
                var nextColumnValue = GetDataCellText(rowNumber, columnNumber, tableNumber);

                if (!firstColumnValue.Equals(nextColumnValue))
                    return false;
            }

            return true;
        }

        public bool IsHeaderSortable(int columnNumber, int tableNumber = 1)
        {
            try
            {
                var headerList = GetAllHeaderList(tableNumber);

                return headerList[columnNumber - 1].GetAttribute("data-role").Equals("columnsorter");
            }
            catch
            {
                return false;
            }
        }

        public void PerformSortAllColumnsTest(int waitSeconds = 60)
        {
            var tableCount = GetNumberOfKendoGrids();

            for (var tableNumber = 1; tableNumber <= tableCount; tableNumber++)
            {
                if (!IsGridSinglePaged(tableNumber))
                {
                    // The less items on the page, the faster the test will perform
                    SelectMinimumItemsPerPage(tableNumber);
                }

                var headerList = GetAllHeaderList(tableNumber);

                for (var columnNumber = 1; columnNumber <= headerList.Count; columnNumber++)
                {
                    // if all columns values are the same, no reason to sort that column
                    if (!IsHeaderSortable(columnNumber) || GetNumberOfDataRows(tableNumber, true) <= 1
                        || IsEntireColumnSameValue(columnNumber, tableNumber)) continue;

                    var rowCount = GetNumberOfDataRows(tableNumber);

                    ClickSortColumnByColumnNumber(columnNumber, tableNumber, waitSeconds, onlySortableColumns: true);
                    Assert.AreEqual(GetNumberOfDataRows(tableNumber, true), rowCount);
                    var firstSortColumnData = GetColumnDataAsList(columnNumber, tableNumber);

                    ClickSortColumnByColumnNumber(columnNumber, tableNumber, waitSeconds, onlySortableColumns: true);
                    Assert.AreEqual(GetNumberOfDataRows(tableNumber, true), rowCount);
                    var secondSortColumnData = GetColumnDataAsList(columnNumber, tableNumber);

                    // Both lists should not be identical (Different ordering of indices)
                    Assert.IsTrue(!firstSortColumnData.SequenceEqual(secondSortColumnData));
                    // Both lists should contain the same indices
                    Assert.IsTrue(!firstSortColumnData.Except(secondSortColumnData).Any());
                }
            }
        }

        /// <summary>
        /// Clicks Column number, sorting the column if enabled
        /// </summary>
        /// <param name="columnNumber">Column number desired (First column = 1)</param>
        /// <param name="tableNumber">Table number desired (First table = 1)</param>
        /// <param name="waitSeconds">Seconds to wait for column sorting</param>
        /// <param name="onlySortableColumns">Unless iterating a for-loop, leave false</param>
        public void ClickSortColumnByColumnNumber(int columnNumber, int tableNumber = 1, int waitSeconds = 15, bool onlySortableColumns = false)
        {
            var headerList = GetAllHeaderList(tableNumber);

            headerList[columnNumber - 1].ScrollToElement(Driver);
            Extensions.JavaScriptExicuterClick(Driver, headerList[columnNumber - 1]);
            //headerList[columnNumber - 1].Click();
            WaitForSpinningLoadIcon(waitSeconds);
        }

        public void ScrollColumnToView(int columnNumber)
        {
            var xpath = Driver.FindElement(By.XPath(GetDataCellXpathByRowColumnAndTable(10, 2, 1)));
            xpath.ScrollToElement(Driver);

            //var allColumns = Driver.FindElements(By.XPath(ColumnHeadersXpath));
            //if (columnNumber < allColumns.Count)
            //{
            //    Extensions.ScrollToElement(allColumns[columnNumber], Driver);
            //}
        }

        public ReadOnlyCollection<IWebElement> GetAllHeaderList(int tableNumber = 1)
        {
            var headerColumnListXpath = headerColumnBeginXpath + tableNumber + headerColumnEndXpath;
            
            return Driver.FindElements(By.XPath(headerColumnListXpath));
        }

        public List<string> GetAllHeadersTextList(int tableNumber = 1)
        {
            var headerColumnListXpath = headerColumnBeginXpath + tableNumber + headerColumnEndXpath + "/a";

            var allHeaders = Driver.FindElements(By.XPath(headerColumnListXpath));
            var headersList = allHeaders.Select(i => i.GetAttribute("text")).ToList<string>();

            return headersList;
        }

        public void PerformPageSelectionTest(int waitSeconds = 90, bool secondPageButtonExists = true)
        {
            var tableCount = GetNumberOfKendoGrids();
           
                for (var tableNumber = 1; tableNumber <= tableCount; tableNumber++)
                {
                    if (GetCurrentPageNumberSelection(tableNumber) >= 1 && !IsGridSinglePaged(tableNumber))
                    {
                        // The less items on the page, the faster the test will perform
                        SelectMinimumItemsPerPage(tableNumber);

                        Assert.AreEqual(GetCurrentPageNumberSelection(tableNumber), 1);

                        // At least two pages of data needed for arrows to be clickable
                        var columnData = GetColumnDataAsString(1, tableNumber);

                        ClickNextPageArrow(tableNumber, waitSeconds);
                        columnData = ValidateAndGetNewPageColumnData(columnData, tableNumber);

                        ClickPreviousPageArrow(tableNumber, waitSeconds);
                        columnData = ValidateAndGetNewPageColumnData(columnData, tableNumber);

                        if (secondPageButtonExists)
                        {
                            ClickSecondPage(tableNumber, waitSeconds);
                            columnData = ValidateAndGetNewPageColumnData(columnData, tableNumber);

                            ClickFirstPage(tableNumber, waitSeconds);
                            columnData = ValidateAndGetNewPageColumnData(columnData, tableNumber);
                        }

                        ClickLastPageArrow(tableNumber, waitSeconds);
                        columnData = ValidateAndGetNewPageColumnData(columnData, tableNumber);

                        ClickFirstPageArrow(tableNumber, waitSeconds);
                        columnData = ValidateAndGetNewPageColumnData(columnData, tableNumber);

                        ClickNextPageArrow(tableNumber, waitSeconds);
                        ValidateAndGetNewPageColumnData(columnData, tableNumber);
                    }
                    else if (IsGridSinglePaged())
                    {
                        Assert.AreEqual(GetCurrentPageNumberSelection(tableNumber), 1);
                    }
                    else
                    {
                        // No data available in Report
                        Assert.AreEqual(GetCurrentPageNumberSelection(tableNumber), 0);
                    }
            }
        }

        public string ValidateAndGetNewPageColumnData(string oldTableData, int tableNumber = 1, int uniqueColumn = 1)
        {
            var newTableData = GetColumnDataAsString(uniqueColumn, tableNumber);
            Assert.IsNotEmpty(newTableData);
            Assert.IsTrue(!oldTableData.Equals(newTableData));
            return newTableData;
        }

        public void PerformItemsPerPageTest(int waitSeconds = 60)
        {
            var tableCount = GetNumberOfKendoGrids();

            for (var tableNumber = 1; tableNumber <= tableCount; tableNumber++)
            {
                var pageNumberOptions = GetItemsPerPageTextOptions(tableNumber);
                var previousRowsDisplayed = 0;

                // Expected to be ordered from min to max
                foreach (var option in pageNumberOptions)
                {
                    SelectItemsPerPageByString(option, tableNumber);
                    int.TryParse(option, out var selectedPageOption);
                    var numberOfRowsDisplayed = GetNumberOfDataRows(tableNumber);

                    Assert.True(numberOfRowsDisplayed >= 0);
                    Assert.True(numberOfRowsDisplayed <= selectedPageOption);
                    Assert.True(numberOfRowsDisplayed >= previousRowsDisplayed);

                    previousRowsDisplayed = numberOfRowsDisplayed;
                }
            }
        }

        /// <summary>
        /// Checks if one or more grids are resizeable so columns can be adjusted
        /// </summary>
        /// <param name="numberOfGrids">The number of grids expected to be resizeable</param>
        /// <returns>True for success, false for fail</returns>
        public bool IsGridResizeable(int numberOfGrids = 1)
        {
            var elementCount = Driver.FindElements(By.XPath(gridHeaderResizableXpath));
            return elementCount.Count == numberOfGrids;
        }

        /// <summary>
        /// Waits for any jquery to finish executing and the kendo spinner to go invisible
        /// </summary>
        /// <param name="seconds">The total number of seconds to wait</param>
        public void WaitForKendoReadyState(int seconds = 15)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(seconds));
            wait.Until(driver =>
            {
                var isAjaxFinished = (bool)((IJavaScriptExecutor)driver).
                    ExecuteScript("return jQuery.active == 0");
                var isLoaderHidden = (bool)((IJavaScriptExecutor)driver).
                    ExecuteScript("return $('.k-loading-image').is(':visible') == false");
                return isAjaxFinished & isLoaderHidden;
            });
        }

        public bool IsGridSinglePaged(int tableNumber = 1)
        {
            var test = IsFirstPageArrowButtonDisabled();
            var test2 = IsLastPageArrowButtonDisabled();
            var test3 = GetCurrentPageNumberSelection(tableNumber);
            return (IsFirstPageArrowButtonDisabled() && IsLastPageArrowButtonDisabled() && GetCurrentPageNumberSelection(tableNumber) <= 1) ? true : false;
        }

        private bool IsFirstPageArrowButtonDisabled(int tableNumber = 1)
        {
            return FirstPageArrowButtonList[tableNumber - 1].GetAttribute("class").Contains("k-state-disabled");
        }

        private bool IsLastPageArrowButtonDisabled(int tableNumber = 1)
        {
            return LastPageArrowButtonList[tableNumber - 1].GetAttribute("class").Contains("k-state-disabled");
        }
    }
}
