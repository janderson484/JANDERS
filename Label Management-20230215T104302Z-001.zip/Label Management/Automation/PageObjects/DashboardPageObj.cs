using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class DashboardPageObj : TnrPageObjBase
    {
        private enum KendoDropdownListIds
        {
            ClientCode = 1,
            Inventory = 2,
            ProcessingLocation = 3
        }
        public DashboardPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "";
        }

        #region WebElements

        /// <summary>
        /// Title Header
        /// </summary>
        private IWebElement TitleText => Driver.FindElement(By.XPath("//*[@id='content']/div[1]/h1"));

        /// <summary>
        /// Coming Soon text
        /// </summary>
        private IWebElement ComingSoonText => Driver.FindElement(By.XPath("//div[@id='content']//b"));
        private IWebElement InitialCustomerListWindow => Driver.FindElement(By.XPath("//div[@id='CustomerListModal']"));
        private IWebElement InitialCustomerListClientDropdown => Driver.FindElement(By.XPath("//*[@id='CustomerListModal']/div/div/div[2]/div/span/span/span[1]"));
        private IWebElement InitialCustomerListInventoryDropdown => Driver.FindElement(By.XPath("//*[@id='CustomerListModal']/div/div/div[2]/div/span/span/span"));
        private IWebElement InitialCustomerListCancelButton => Driver.FindElement(By.XPath("//input[@id='Cancel']"));
        private IWebElement InitialCustomerListSubmitButton => Driver.FindElement(By.XPath("//input[@id='Continue']"));
        private IWebElement ClientCodeFieldValidationError => Driver.FindElement(By.XPath("//span[@id='ClientCode_validationMessage']"));
        private IWebElement InventoryFieldValidationError => Driver.FindElement(By.XPath("//*[@id='ProcessingLocation_validationMessage']"));

        #endregion

        #region Xpath helpers

        private string InitialCustomerListClientErrorNotification = "//span[contains(text(),'Please select a Customer.')]/parent::div";
        private string InitialCustomerListInventoryErrorNotification = "//span[contains(text(),'Please select a DMV State.')]/parent::div";
        private string InitialCustomerListWindowXPath = "//div[@id='CustomerListModal']";

        #endregion

        public new void Navigate(string user, string pass)
        {
            base.Navigate(user, pass);
            Driver.WaitUntilElementExists(TitleText);
        }
         
        public new void DirectNavigate()
        {
            base.DirectNavigate();
            TitleTextDisplayed();
        }

        public bool TitleTextDisplayed()
        {
            return TitleText.Displayed;
        }

        public bool ComingSoonTextDisplayed()
        {
            return ComingSoonText.Displayed;
        }

        public bool IsInitialCustomerListWindowDisplayed()
        {
            return IsElementDisplayedAfterWait(InitialCustomerListWindowXPath);
        }

        public bool IsInitialCustomerListClientDropdownDisplayed()
        {
            return IsElementDisplayedAfterWait(InitialCustomerListClientDropdown);
        }

        public bool IsInitialCustomerListInventoryDropdownDisplayed()
        {
            return IsElementDisplayedAfterWait(InitialCustomerListInventoryDropdown);
        }

        public bool IsInitialCustomerListCancelButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(InitialCustomerListCancelButton);
        }

        public bool IsInitialCustomerListSubmitButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(InitialCustomerListSubmitButton);
        }

        public bool IsInitialClientErrorDisplayed()
        {
            return IsElementDisplayedAfterWait(ClientCodeFieldValidationError);
        }

        public bool IsInitialInventoryErrorDisplayed()
        {
            return IsElementDisplayedAfterWait(InventoryFieldValidationError);
        }

        public void ClickInitialCustomerListCancelButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, InitialCustomerListCancelButton);
        }

        public void ClickInitialCustomerListSubmitButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, InitialCustomerListSubmitButton);
        }

        public void ClickInitialCustomerListInventoryDropdown()
        {
            InitialCustomerListInventoryDropdown.Click();
        }

        public void ClickInitialCustomerListClientDropdown()
        {
            InitialCustomerListClientDropdown.Click();
        }

        public void SelectInitialInventoryOption(string inventoryOption)
        {
            var inventoryDropdownOptions = new SelectElement(InitialCustomerListInventoryDropdown);
            inventoryDropdownOptions.SelectByValue(inventoryOption);
        }

        public void SelectInitialClientOption(string clientOption)
        {
            Thread.Sleep(500);
            Driver.WaitUntilElementExists(InitialCustomerListClientDropdown);

            var clientDropdownOptions = new SelectElement(InitialCustomerListClientDropdown);
            clientDropdownOptions.SelectByValue(clientOption);
        }

        public void SetInitialClientAndInventory(string client, string inventory)
        {
            Driver.WaitUntilElementExists(InitialCustomerListInventoryDropdown);

            if (client != "" && inventory != "")
            {
                SelectInitialClientOption(client);
                SelectInitialInventoryOption(inventory);
            }
        }

        public void SetInitialCustomerListDropdownsAndSubmit(string client, string inventory)
        {
            SetInitialClientAndInventory(client, inventory);

            ClickInitialCustomerListSubmitButton();
        }

        /// <summary>
        /// Selects a dmv state item from a kendo dropdown list control by index
        /// </summary>
        /// <param name="stateOptionIndex"></param>
        public void SelectInitialInventoryOption(int inventoryOptionIndex)
        {
            Extensions.WaitUntilElementExists(Driver, InitialCustomerListInventoryDropdown);
            SelectKendoDropDownListItemByIndex(Driver, KendoDropdownListIds.ProcessingLocation.GetDescription(), inventoryOptionIndex);
        }

        public void SelectInitialClientOption(int clientOptionIndex)
        {
            Extensions.WaitUntilElementExists(Driver, InitialCustomerListClientDropdown);
            SelectKendoDropDownListItemByIndex(Driver, KendoDropdownListIds.ClientCode.GetDescription(), clientOptionIndex);
        }

        public void SetInitialInventoryClientAndSubmit(int clientOptionIndex = 1, int inventoryOptionIndex = 1)
        {            
            SelectInitialClientOption(clientOptionIndex);
            SelectInitialInventoryOption(inventoryOptionIndex);
            ClickInitialCustomerListSubmitButton();
        }
    }
}
