using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Linq;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class PersonalSettingsConfigPageObj : TnrPageObjBase
    {
        public PersonalSettingsConfigPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Configuration/PersonalSettings";
        }

        #region Messages

        public string Success_UpdatedPersonalSettings = "Updated personal settings";
        public string Success_LabelSortOrderConfigUpdated ="Label sort order configuration status has been updated";

        #endregion Messages

        #region WebElements

        private IWebElement ProcessingLocation => Driver.FindElement(By.XPath("//*[@id='ProcessingLocationCode']"));
        private IWebElement SaveButton => Driver.FindElement(By.Id("btnFormSubmit"));
        private IWebElement RowsPerPage => Driver.FindElement(By.XPath("//*[@id='rowsPerPage']"));

        private IWebElement DaysOfHistoryLabelView => Driver.FindElement(By.XPath("//form[@id='PersonalSettingForm']/div[1]/div[2]/label"));
        private IWebElement HistoryDays => Driver.FindElement(By.Id("historyDays"));
        private IWebElement PrintSortOrderDropdown => Driver.FindElement(By.Id("sortOrder"));
        private IWebElement SavePersonalSettingsButton => Driver.FindElement(By.Id("btnFormSubmit"));
        private IWebElement ClientCodeDropdown => Driver.FindElement(By.Id("HeaderClientCode"));
        private IWebElement ApplyButton => Driver.FindElement(By.Id("HeaderApplySelection"));
        private IWebElement SettingsMenu => Driver.FindElement(By.XPath("//div[@id='config-settings']"));
        private IWebElement SortOrders => Driver.FindElement(By.XPath("//div[@id='config-settings']/div/ul/li[3]/a"));
        private IWebElement AddNewSortOrderButton => Driver.FindElement(By.XPath("//button[contains(text(),' Add New Sort Order')]"));
        private IWebElement Description => Driver.FindElement(By.Id("description"));
        private IWebElement SortorderDropdown => Driver.FindElement(By.XPath("//select[@id='importField_0']"));
        private IWebElement SaveNewSortOrderButton => Driver.FindElement(By.XPath("//button[@id='saveButton']"));

        private const string OnOffToggleInputXPath = "//*[@id='ImportLayoutTypes']//tr[{0}]//td[1]//div[1]//input";
        private const string OnOffToggleButtonXPath = "//*[@id='ImportLayoutTypes']//tbody//tr[{0}]//td[1]//div[1]//div";

        #endregion

        /// <summary>
        /// Get Processing Location selected Text
        /// </summary>
        /// <returns></returns>
        public void SelectProcessingLocationByIndex(int index)
        {
            var processLocation = new SelectElement(ProcessingLocation);
            processLocation.SelectByIndex(index);
        }

        public int GetNoofHistoryDays()
        {
            return  Convert.ToInt32(HistoryDays.GetAttribute("Value"));
        }

        public void SetNoofHistoryDays(string historyDays)
        {
            HistoryDays.Clear();
            HistoryDays.SendKeys(historyDays);
        }

        public bool IsDaysOfHistoryLabelViewVisible()
        {
             return DaysOfHistoryLabelView.Displayed && DaysOfHistoryLabelView.Text == "Days of History for Label View";
        }

        public bool IsSaveButtonDisplayed()
        {
            return SaveButton.Displayed && SaveButton.GetAttribute("value") == "Save";
        }
        public string GetProcessingLocationText()
        {
            return ProcessingLocation.GetSelectDropDownCurrentText();
        }

        /// <summary>
        /// Personal settings Processing Location dropdown count
        /// </summary>
        /// <returns></returns>
        public int GetProcessingLocationCount()
        {
            var processLocation = new SelectElement(ProcessingLocation);
            return processLocation.Options.Count;
        }
        
        /// <summary>
        /// Get Personal Settings dropdown, Number of Rows value
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public void SelectRowsPerPageByIndex(int index)
        {
            var rowsPerPageValue = new SelectElement(RowsPerPage);
            rowsPerPageValue.SelectByIndex(index);
        }

        public void SelectRowsPerPageByValue(string text)
        {
            var rowsPerPageValue = new SelectElement(RowsPerPage);
            rowsPerPageValue.SelectByText(text);
        }

        public int GetRowsPerPage()
        {
            return Convert.ToInt32(RowsPerPage.GetSelectDropDownCurrentText());
        }

        /// <summary>
        /// Get Number of Rows Per Page from personal settings
        /// </summary>
        /// <returns></returns>
        public int GetRowsPerPageCount()
        {
            var rowsPerPageCount = new SelectElement(RowsPerPage);
            return rowsPerPageCount.Options.Count;
        }

        /// <summary>
        /// Save Personal Settings
        /// </summary>
        public void ClickSave()
        {
            //SaveButton.Click();
            Extensions.JavaScriptExicuterClick(Driver, SaveButton);
        }

        public bool IsPrintSortOrderDropdownDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintSortOrderDropdown, 10);
        }

        public bool IsPrintSortOrderSaveButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(SavePersonalSettingsButton, 10);
        }

        public void SelectPrintSortOrderDropdownValue(string description)
        {
            Extensions.SelectDropdownByText(PrintSortOrderDropdown, description);
        }

        public void ClickSavePrintSortOrderButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, SavePersonalSettingsButton);
        }

        public void SelectClientFromDropdown()
        {
            Extensions.SelectDropdownByText(ClientCodeDropdown, "Enterprise");
        }

        public void ClickApplyButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ApplyButton);
        }

        public void SelectValuePrintSortOrderDropdownForEnterprise(string description)
        {
            Extensions.SelectDropdownByText(PrintSortOrderDropdown, description);
        }

        public void NavigateToSortOrders()
        {
            Extensions.JavaScriptExicuterClick(Driver, SettingsMenu);
            Extensions.JavaScriptExicuterClick(Driver, SortOrders);
        }

        public void ClickAddNewSortOrderButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, AddNewSortOrderButton);
        }

        public void AddNewSortOrderRecord(string description, string field)
        {
            ClickAddNewSortOrderButton();
            Description.SendKeys(description);
            Extensions.SelectDropdownByText(SortorderDropdown, field);
            ClickAddNewOrderSaveButton();
        }

        public void EnterDescription()
        {
            ChangeBrowserTab(0);
            Description.SendKeys("DeliveryCode");
        }

        public void SelectSortOrderPageDropdown(string field)
        {
            Extensions.SelectDropdownByText(SortorderDropdown, field);
        }

        public void ClickAddNewOrderSaveButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, SaveNewSortOrderButton);
        }

        public bool IsOnOffInputChecked(int rownumber)
        {
            var onOffInputElementXPath = string.Format(OnOffToggleInputXPath, rownumber);
            var onOffInputElement = Driver.FindElement(By.XPath(onOffInputElementXPath));
            return onOffInputElement.GetAttribute("checked") == "true" ? true : false;
        }

        public void ToggleOnOffToggleByRowNumber(int rownumber)
        {
            var onOffElementXPath = string.Format(OnOffToggleButtonXPath, rownumber);
            var onOffElement = Driver.FindElement(By.XPath(onOffElementXPath));
            Extensions.JavaScriptExicuterClick(Driver, onOffElement);
        }

        public string VerifySelectedDropdwonOption()
        {
            var dropDownControl = new SelectElement(PrintSortOrderDropdown);
            return (dropDownControl.SelectedOption.Text);
        }
    }
}
