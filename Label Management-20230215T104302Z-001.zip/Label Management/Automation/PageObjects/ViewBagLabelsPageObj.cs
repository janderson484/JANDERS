using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using VM.FleetServices.TnR.LM.Web.Automation.Model;
using System.Drawing;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class ViewBagLabelsPageObj : TnrPageObjBase
    {
        public const string Error_SelectActiveOrClosed = "Error: Please select only Active/Closed, Printed & Non invoiced labels to invoice";

        #region Methods
        
        public KendoGridPageObj KendoGrid { get; }

        /// <summary>
        /// Contains a list of grid columns ,containing the name and index matching the Kendo UI Grid
        /// </summary>
        private List<GridColumn> _gridColumnList { get; set; }

        /// <summary>
        /// Contains a list of grid columns to ignore when comparing the export excel file against the kendo grid columns
        /// </summary>
        private List<string> _columnsToIgnore { get; }

        public ViewBagLabelsPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Label/ViewBagLabels";
            KendoGrid = new KendoGridPageObj(driver);
        }

        public bool VerifyExportButtonDropdownValues()
        {
            string[] exp = { "Export All", "Export Selected" };
            ExportButtonClick();
            IList<IWebElement> ele = Driver.FindElements(By.XPath(ExportButtonDropdown));
            foreach (IWebElement expdropdown in ele)
            {
                for (int i = 0; i < exp.Length; i++)
                {
                    if (expdropdown.Text.Equals(exp[i]))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void ClickExportAllButtonFlow()
        {
            ExportButtonClick();
            ExportAllClick();
        }

        public void VerifyExportSelected()
        {
            var rowCount = KendoGrid.GetNumberOfDataRows();
            var rowsToProcessTotal = rowCount > GridExport.AutoSelectRowCount ? GridExport.AutoSelectRowCount : rowCount;
            for (var i = 1; i <= rowCount; i++)
            {
                ClickDataCheckmarkByRowNumber(i);
            }
            ExportButtonClick();
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(10));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(ExpSelected)));
            ExportSelectedClick();

        }

        public void ClickExportSelectedButtonFlow()
        {
            ExportButtonClick();
            ExportSelectedClick();
        }

        public void VerifyExportAllBySelectingRecords()
        {
            var rowCount = KendoGrid.GetNumberOfDataRows();
            var rowsToProcessTotal = rowCount > GridExport.AutoSelectRowCount ? GridExport.AutoSelectRowCount : rowCount;
            for (var i = 1; i <= rowCount; i++)
            {
                ClickDataCheckmarkByRowNumber(i);
            }
            ExportButtonClick();
            ExportAllClick();
        }

        /// <summary>
        /// Clicks a kendo grid rows checkbox to select or deselect the row
        /// </summary>
        /// <returns>Void</returns>
        public void ClickDataCheckmarkByRowNumber(int rowNumber, bool? tickCheckbox = null)
        {
            if (rowNumber < 1)
            {
                throw new ArgumentException($"{nameof(rowNumber)} cannot be less than 1.");
            }
            else if (rowNumber > KendoGrid.GetNumberOfDataRows(1, true))
            {
                throw new ArgumentException("Insufficient rows in the table");
            }

            KendoGrid.WaitForKendoReadyState();

            var fullXpath = dataRowBeforeXpath + rowNumber + dataRowMiddleXpath + "1" + dataRowEndXpath + "/input";
            var checkboxElement = Driver.FindElement(By.XPath(fullXpath));

            if (tickCheckbox == null)
            {
                Extensions.JavaScriptExicuterClick(Driver, checkboxElement);
                // checkboxElement.Click();
            }
            else
            {
                Extensions.SetCheckbox(checkboxElement, tickCheckbox.GetValueOrDefault());
            }
        }

        #endregion

        #region Filter Interactions
        public void ExportButtonClick()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportButton);
        }

        public void ExportAllClick()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportAllButton);
        }

        public void ExportSelectedClick()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExportSelected);
        }

        /// <summary>
        /// Checks if the export file exists on the current machine
        /// </summary>
        /// <returns>true if the file exists, false otherwise</returns>
        public bool ExportedFileExists()
        {
            try
            {
                return File.Exists(GridExport.DownloadedFile);
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Elements

        private IWebElement ViewBagLabelsGrid => Driver.FindElement(By.XPath("//*[@id='content']/div[1]/div[2]/div[1]/div[1]/div[2]"));
        private IWebElement GridPagination => Driver.FindElement(By.XPath("//*[@id='gridViewLabels']/div[4]/div/ul"));
        private IWebElement ViewBagLabels => Driver.FindElement(By.XPath("//span[contains(text(),'View Bag Labels')]"));
        private IEnumerable<IWebElement> GridRowsCount => Driver.FindElements(By.XPath("//*[@id='gridViewLabels']/div[2]/table/tbody/tr"));
        private IWebElement GridSize => Driver.FindElement(By.XPath("//*[@id='gridViewLabels']/div[4]/span[1]/span"));
        private IEnumerable<IWebElement> ColumnHeaderList => Driver.FindElements(By.XPath("//thead/tr/th[@role='columnheader']"));
        private IWebElement SelectSpanish => Driver.FindElement(By.XPath("//select[@id='requestCulture_RequestCulture_UICulture_Name']"));
        private IEnumerable<IWebElement> GridData => Driver.FindElements(By.XPath("//div[@id='gridViewLabels']//table/tbody[@role='rowgroup']/tr[1]/td[2]"));
        private IWebElement SaveChangesButton => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']/div[1]/a[contains(text(),'Save changes')]"));
        private IWebElement CancelChnagesButton => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']/div[1]/a[contains(text(),'Cancel changes')]"));
        private IWebElement BulkUpdateButton => Driver.FindElement(By.Id("bulkUpdate"));
        private IWebElement SelectCheckbox => Driver.FindElement(By.XPath("//table[@role='grid']/tbody/tr[1]/td[1]/input"));
        private IWebElement BulkUpdateWindow => Driver.FindElement(By.Id("bulkUpdateWindow"));
        private IWebElement UpdateButton => Driver.FindElement(By.Id("btnBulkUpdateAction"));
        private IWebElement ExitButton => Driver.FindElement(By.Id("btnBulkUpdateExit"));
        private IWebElement Notes => Driver.FindElement(By.Id("notes"));
        private IWebElement TotalCount => Driver.FindElement(By.XPath("//span[@id='totalLabels']"));
        private IWebElement PassedCount => Driver.FindElement(By.XPath("//span[@id='totalPassed']"));
        private IWebElement FailedCount => Driver.FindElement(By.XPath("//span[@id='totalFailed']"));
        private IWebElement BagLabelsGrid => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']"));
        private IWebElement ViewLog => Driver.FindElement(By.XPath("//a[contains(text(),'View Log.. ')]"));
        private IWebElement DownloadButton => Driver.FindElement(By.XPath("//span[@class='k-tool-icon k-icon k-i-pdf']"));
        private IWebElement Status => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody/tr[1]/td[3]"));
        private IEnumerable<IWebElement> LabelStatusFilterOption => Driver.FindElements(By.XPath("//ul[@class='k-list k-reset']/li"));
        private IWebElement SaveChangesWindow => Driver.FindElement(By.Id("UpdateLabelResponseWindowContentAsync"));
        private IWebElement NotesInGrid => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody/tr[1]/td[20]"));
        private IWebElement NotesFieldInGrid => Driver.FindElement(By.Name("Notes"));
        private IWebElement PendingCheckbox => Driver.FindElement(By.Name("LabelStatusTypes[0].Selected"));
        private IWebElement DuplicateCheckbox => Driver.FindElement(By.Name("LabelStatusTypes[1].Selected"));
        private IWebElement ActiveCheckbox => Driver.FindElement(By.Name("LabelStatusTypes[2].Selected"));
        private IWebElement ClosedCheckbox => Driver.FindElement(By.Name("LabelStatusTypes[3].Selected"));
        private IWebElement VoidCheckbox => Driver.FindElement(By.Name("LabelStatusTypes[4].Selected"));
        private IWebElement PrintedCheckbox => Driver.FindElement(By.Name("printedCheckbox"));
        private IWebElement OrderBySearchListCheckbox => Driver.FindElement(By.Name("searchCheckbox"));
        private IWebElement SearchButton => Driver.FindElement(By.XPath("//button[@id='searchButton']"));
        private IWebElement TextArea => Driver.FindElement(By.XPath("//iframe[@class='k-content']"));
        private IWebElement SearchTextField => Driver.FindElement(By.XPath("//div[@class='bootstrap-tagsinput']//input"));
        private IWebElement ActiveVIN => Driver.FindElement(By.XPath("//textarea[contains(text(),'Active Label already exists')]"));
        private IWebElement PrintSelected => Driver.FindElement(By.Id("printSelected"));
        private IWebElement PrintPreviewPage => Driver.FindElement(By.Id("content"));
        private IWebElement PrinterName => Driver.FindElement(By.Id("printerList"));
        private IWebElement EditAlignment => Driver.FindElement(By.Id("editLabelAlignment"));
        private IWebElement TopMargin => Driver.FindElement(By.Id("topMargin"));
        private IWebElement BottomMargin => Driver.FindElement(By.Id("bottomMargin"));
        private IWebElement LeftMargin => Driver.FindElement(By.Id("leftMargin"));
        private IWebElement RightMargin => Driver.FindElement(By.Id("rightMargin"));
        private IWebElement PrintPreviewSaveButton => Driver.FindElement(By.Id("saveLabelAlignment"));
        private IWebElement BagLabelsVINInGrid => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody/tr[1]/td[2]"));
        private IWebElement PrintPreviewVINInGrid => Driver.FindElement(By.XPath("//div[@id='content']//div[@id='gridViewLabels']//table/tbody/tr[1]/td[2]"));
        
        private IWebElement ConfirmPrintPopup => Driver.FindElement(By.XPath("//div[@class='modal-content']"));
        private IWebElement ContinueButton => Driver.FindElement(By.Id("PerformPrintAction"));
        private IWebElement NotificationContainer => Driver.FindElement(By.ClassName("notifyjs-corner"));
        private IWebElement Reports => Driver.FindElement(By.XPath("//span[contains(text(),'Reports')]"));
        private IWebElement VinNumber => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody/tr[1]/td[4]"));
        private IWebElement VINButton => Driver.FindElement(By.XPath("//*[@id='btnSearchGroup']/button[1]"));
        private IWebElement BatchButton => Driver.FindElement(By.XPath("//*[@id='btnSearchGroup']/button[2]"));
        private IWebElement ClearButton => Driver.FindElement(By.Id("clearSearchButton"));
        private IWebElement InputTagHelpers => Driver.FindElement(By.XPath("//span[@class='tag label label-default label-break']"));
        private IReadOnlyCollection<IWebElement> GridHeadingNames => Driver.FindElements(By.XPath(headerColumnListXpath));
        private IWebElement InvoiceAndCloseButton => Driver.FindElement(By.Id("invoiceSelected"));
        private IWebElement LabelStatus => Driver.FindElement(By.XPath("//span[contains(text(),'Select Status..')]"));

        
        private IWebElement Invoiced => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody[@role='rowgroup']/tr[1]/td[15]"));
        private IWebElement PrintCount => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody[@role='rowgroup']/tr[1]/td[5]"));
        private IWebElement CreditButton => Driver.FindElement(By.Id("creditSelected"));
        private IWebElement TotalAmount => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody[@role='rowgroup']/tr[1]/td[19]"));
        private IWebElement RefreshButton => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']/div[4]/a[@title='Refresh']"));
        private IWebElement LabelId => Driver.FindElement(By.XPath("//div[@id='gridViewLabels']//table/tbody[@role='rowgroup']/tr[1]/td[1]"));
        
        private IWebElement NotificationsIcon => Driver.FindElement(By.XPath("//span[@id='activity']"));
        private IWebElement PrintLabelsLatestJob => Driver.FindElement(By.XPath("//*[@id='BulkProcessLogs']/div[1]/div[1]/h4"));
        private IWebElement TotalFilesProcessed => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[1]/td[1]/strong[contains(text(),'Total')]"));
        private IWebElement SuccessFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[1]/td[2]/strong[contains(text(),'Success')]"));
        private IWebElement WarningFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[2]/td[1]/strong[contains(text(),'Warning')]"));
        private IWebElement ErrorFiles => Driver.FindElement(By.XPath("//div[@id='BulkProcessLogs']/div[1]//table/tbody/tr[2]/td[2]/strong[contains(text(),'Errors')]"));
        private IWebElement HorizontalPositionTextbox => Driver.FindElement(By.Id("horizontalMargin"));
        private IWebElement VerticalPosistionTextbox => Driver.FindElement(By.Id("verticalMargin"));
        private IWebElement UpArrow => Driver.FindElement(By.XPath("//div[@id='arrowUp']/button[@id='upArrowButton']//*[name()='svg']"));
        private IWebElement ResetButton => Driver.FindElement(By.XPath("//button[@id='arrowReset']"));

        private IWebElement Logs => Driver.FindElement(By.XPath("//span[contains(text(),'Logs')]"));
        private IWebElement MoveSelectedButton => Driver.FindElement(By.Id("moveSelected"));
        private IWebElement MoveLabelsModal => Driver.FindElement(By.Id("UpdateProcessingLocationOfficeWindow"));
        private IWebElement ProcessingOfficeDropdown => Driver.FindElement(By.XPath("//span[contains(text(),'Select Processing Office')]"));
        private IWebElement MoveLabelsSaveButton => Driver.FindElement(By.Id("saveButton"));
        private IWebElement MoveLabelsCancelButton => Driver.FindElement(By.XPath("//button[contains(text(),'  Cancel')]"));
        private IList<IWebElement> ProcessingLocationDropdownValues => Driver.FindElements(By.XPath("//ul[@id='processingLocationOffice_listbox']/li"));
        private IWebElement CopySelectedButton => Driver.FindElement(By.Id("copySelected"));
        private IWebElement CopyLabelsModal => Driver.FindElement(By.Id("CopyLabelWindow"));
        private IWebElement ExitButtonCopyLabels => Driver.FindElement(By.Id("btnBulkUpdateExit"));
        private IWebElement ViewLogLink => Driver.FindElement(By.XPath("//a[contains(text(),' View Log.. ')]"));
        private IWebElement CopyLabelLogDisplayed => Driver.FindElement(By.Id("copyLabelsLogWindow"));
        private IWebElement TotalCopyLabels => Driver.FindElement(By.XPath("//span[@id='totalLabels']"));
        private IWebElement PassedCopyLabels => Driver.FindElement(By.XPath("//span[@id='totalPassed']"));
        private IWebElement FailedCopyLabels => Driver.FindElement(By.XPath("//span[@id='totalFailed']"));
        private IWebElement CopyLabelsFrame => Driver.FindElement(By.XPath("//div[@id='copyLabelsLogWindow']//textarea[contains(text(),'Active labels already exists for the VIN')]"));

        private string VoidTransactionErrormessage = "Validation error message for is Cannot change a voided transaction..";
        private string dataRowBeforeXpath = "//div[@id='gridViewLabels']//tbody/tr[";
        private string dataRowMiddleXpath = "]/td[";
        private string dataRowEndXpath = "]";
        private string StatusXPath = "//span[@class='k-widget k-dropdown']/span/span[@class='k-input']";
        private string headerColumnListXpath = "//thead/tr/th[@role='columnheader']";
        private IWebElement ExportButton => Driver.FindElement(By.XPath("//button[@class='btn dropdown-toggle']"));
        private IWebElement ExportAllButton => Driver.FindElement(By.XPath("//ul[@class='dropdown-menu dropdown-menu-right']/li[1]/a"));
        private IWebElement EndDate => Driver.FindElement(By.Id("endDate"));
        private IWebElement StartDate => Driver.FindElement(By.Id("startDate"));

        private const string LabelStatusDropDownXpath = "//span[contains(text(),'Select Status..')]";
        private IWebElement ExportSelected => Driver.FindElement(By.XPath("//ul[@class='dropdown-menu dropdown-menu-right']/li[2]/a"));
        private IWebElement ViewGridLabels => Driver.FindElement(By.Id("gridViewLabels"));

        private IWebElement ExportFileNotification => Driver.FindElement(By.XPath("//span[contains(text(), 'Export Labels is completed')]"));
        #endregion

        #region Private Xpath elements
        private const string ExportButtonDropdown = "//ul[@class='dropdown-menu dropdown-menu-right']/li";
        private const string ExpSelected = "//ul[@class='dropdown-menu dropdown-menu-right']/li[2]";
        private const string ExpAllSelected = "//ul[@class='dropdown-menu dropdown-menu-right']/li[1]";
        #endregion
        #region Helpers

        public void Navigate()
        {
            base.Navigate();
            KendoGrid.WaitForSpinningLoadIcon();

            Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunshineBradenton);
        }

        public new void Navigate(string user, string pass)
        {
            base.Navigate(user, pass);
            KendoGrid.WaitForSpinningLoadIcon();

            Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunshineBradenton);
        }

        public bool IsPageLoaded()
        {
            if (ViewBagLabelsGrid.Displayed)
            {
                return true;
            }
            return false;
        }

        public void ClickViewPageLabelSpanish()
        {
            Extensions.SelectDropdownByText(SelectSpanish, "Spanish");
        }

        /// <summary>
        /// Validate Pagination exist in grid
        /// </summary>
        /// <returns></returns>
        public bool IsGridPaginationExist()
        {
            KendoGrid.WaitForKendoReadyState();
            return GridPagination.Displayed;
        }

        /// <summary>
        /// Grid Rows Size Validations
        /// </summary>
        /// <returns></returns>
        public bool IsGridRowsMatchWithDropDownSizeSelection()
        {
            KendoGrid.WaitForKendoReadyState();
            return GridRowsCount.Count() == Convert.ToInt16(GridSize.Text);
            //return KendoGrid.GetNumberOfDataRows(1) == KendoGrid.GetCurrentItemsPerPageDropdownValue(1);
        }

        /// <summary>
        /// Validate Grid Row size dropdown exist in grid
        /// </summary>
        /// <returns></returns>
        public bool IsGridRowSizeDropdownExist()
        {
            KendoGrid.WaitForKendoReadyState();
            return GridSize.Displayed;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetNumberOfColumnHeaders()
        {
            return ColumnHeaderList.Count();
        }

        /// <summary>
        /// Verify number of columns listed in proper order
        /// </summary>
        /// <param name="columnNames"></param>
        /// <returns></returns>
        public bool VerifyColumnNames(List<string> columnNames)
        {
            var columnOrderPositionIndex = 0;

            foreach (var columnHeaderElement in ColumnHeaderList)
            {
                var expectedColumnName = columnNames[columnOrderPositionIndex];
                var s = columnHeaderElement.Text;
                if ((!string.IsNullOrWhiteSpace(columnHeaderElement.Text)) && columnHeaderElement.Text != expectedColumnName)
                {
                    return false;
                }

                columnOrderPositionIndex++;
            }
            return true;
        }

        public List<string> GetColumnHedders(int type)
        {
            List<string> hedders = new List<string>();
            if (type == 0)
            {
                foreach (var colums in ViewBagLabelsColumnHeadings.Headers)
                {
                    hedders.Add(colums);
                }
            }
            else
            {
                foreach (var colums in ViewBagLabelsSpanishColumnHeadings.Headers)
                {
                    hedders.Add(colums);
                }
            }
            return hedders;
        }

        public bool VerifyGridData()
        {
            Label data = DataHelper.SelectLabelData();
            var id = GridData.FirstOrDefault();
            return data.LabelId.ToString().Equals(id.Text);
        }

        public bool IsSaveChangesButtonExists()
        {
            return IsElementDisplayedAfterWait(SaveChangesButton, 20);
        }

        public bool IsCancelChnagesButtonExists()
        {
            return IsElementDisplayedAfterWait(CancelChnagesButton, 20);
        }

        public string GetEndDateText()
        {
            return EndDate.GetAttribute("value");
        }

        public string GetStartDateText()
        {
            return StartDate.GetAttribute("value");
        }

        public void SetStartDate(DateTime startDate)
        {
            StartDate.SendIndividualKeys(startDate.ToString("MM/dd/yyyy"));

        }
        public void SetEndDate(DateTime startDate)
        {
            EndDate.SendIndividualKeys(startDate.ToString("MM/dd/yyyy"));
        }

        public bool IsPrintedCheckBoxExist()
        {
            return IsElementDisplayedAfterWait(PrintedCheckbox);
        }

        public bool IsOrderBySearchListSelected()
        {
            return OrderBySearchListCheckbox.Selected;
        }

        public void ClickOrderBySearchListCheckbox(bool expectedState)
        {
            if (OrderBySearchListCheckbox.Selected != expectedState)
                Extensions.JavaScriptExicuterClick(Driver, OrderBySearchListCheckbox);
        }

        public bool IsOrderBySearchListExist()
        {
            return IsElementDisplayedAfterWait(OrderBySearchListCheckbox);
        }

        public bool IsBulkUpdateButtonExists()
        {
            return IsElementDisplayedAfterWait(BulkUpdateButton, 20);
        }

        public void ClickCheckBox()
        {
            Extensions.JavaScriptExicuterClick(Driver, SelectCheckbox);
        }

        public void ClickBulkUpdateButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, BulkUpdateButton);
        }

        public bool IsBulkUpdateWindowDisplayed()
        {
            return IsElementDisplayedAfterWait(BulkUpdateWindow);
        }

        public void ClickUpdateButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, UpdateButton);
        }

        public void SelectStatusFromDropdown(string labelstatus)
        {
            var SelectInvoiceDropDownButton = Driver.FindElement(By.XPath("//div[@id='bulkUpdateWindow']/div/span/span"));
            var SelectInvoiceDropDownListXpath = "//ul[@id='LabelStatusId_listbox']/li";
            var allItems = Driver.FindElements(By.XPath(SelectInvoiceDropDownListXpath));
            var Count = allItems.Count;
            bool itemFound = false;
            for (int i = 0;  i < Count; i++)
            {
                var txt = allItems[i].GetAttribute("innerHTML");
                if (txt.ToLower().Equals(labelstatus.ToLower()))
                {
                    Extensions.JavaScriptExicuterClick(Driver, allItems[i]);
                    itemFound = true;
                    break;
                }
            }

            if (!itemFound)
            {
                Extensions.JavaScriptExicuterClick(Driver, SelectInvoiceDropDownButton);
            }

        }

        public void NotesField()
        {
            Notes.SendKeys("Note1");
        }

        public int TotalLabelsCount()
        {
            return Convert.ToInt32(TotalCount.GetAttribute("innerHTML"));
        }

        public int FailedLabelsCount()
        {
            return Convert.ToInt32(FailedCount.GetAttribute("innerHTML"));
        }

        public int PassedLabelsCount()
        {
            return Convert.ToInt32(PassedCount.GetAttribute("innerHTMl"));
        }

        public void ClickPendingCheckbox(bool expectedState)
        {
            if (PendingCheckbox.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, PendingCheckbox);
            }
        }

        public void ClickPendingCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, PendingCheckbox);
        }
       

        public void ClickActiveCheckbox(bool expectedState)
        {
            if (ActiveCheckbox.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, ActiveCheckbox);
            }
        }

        public void ClickActiveCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, ActiveCheckbox);
        }

        public void ClickClosedCheckbox(bool expectedState)
        {
            if (ClosedCheckbox.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, ClosedCheckbox);
            }
        }

        public void ClickClosedCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, ClosedCheckbox);
        }

        public void ClickPrintedCheckbox(bool expectedState)
        {
            if (PrintedCheckbox.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, PrintedCheckbox);
            }
        }

        public void ClickPrintedCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintedCheckbox);
        }

        public void ClickVoidCheckbox(bool expectedState)
        {
            if (VoidCheckbox.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, VoidCheckbox);
            }
        }

        public void ClickVoidCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, VoidCheckbox);
        }

        public void ClickExitButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExitButton);
        }


        public void ClickDuplicateCheckbox(bool expectedState)
        {
            if (DuplicateCheckbox.Selected != expectedState)
            {
                Extensions.JavaScriptExicuterClick(Driver, DuplicateCheckbox);
            }
        }

        public void ClickDuplicateCheckbox()
        {
            Extensions.JavaScriptExicuterClick(Driver, DuplicateCheckbox);
        }

        public bool IsViewBagLabelsGridDisplayed()
        {
            return IsElementDisplayedAfterWait(BagLabelsGrid, 50);
        }

        public void ClickViewLog()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewLog);
        }

        public void ClickDownloadButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, DownloadButton);
        }

        public void ClickStatus()
        {
            Extensions.JavaScriptExicuterClick(Driver, Status);
        }

        public void LabelStatusFieldOption(string statuslabel)
        {
            ClickStatus();
            ClickStatus();
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var status = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(StatusXPath)));
            Extensions.JavaScriptExicuterClick(Driver, status);
            var value = "//li[contains(text(),'" + statuslabel + "')]";
            var labelValue = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(value)));
            Extensions.JavaScriptExicuterClick(Driver, labelValue);
        }

        public void ClickSaveChangesbutton()
        {
            Extensions.JavaScriptExicuterClick(Driver, SaveChangesButton);
        }

        public bool IsSaveChangesSuccessWindowDisplayed()
        {
            return IsElementDisplayedAfterWait(SaveChangesWindow, 80);
        }

        public void EnterNotesInGrid()
        {
            Extensions.JavaScriptExicuterClick(Driver, NotesInGrid);
            NotesFieldInGrid.SendKeys("Notes11");

        }

        public void ClickCancelChanges()
        {
            Extensions.JavaScriptExicuterClick(Driver, CancelChnagesButton);
        }

        public bool VoidTransactionErrorMessageDisplayed()
        {
            ChangeBrowserTab(0);
            return IsElementDisplayedAfterWait(TextArea, 60);
        }

        public void ClickSearchButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, SearchButton);
            KendoGrid.WaitForKendoReadyState();
        }

        public void SelectAllFilterCheckBoxes()
        {
            ClickActiveCheckbox(true);
            ClickPendingCheckbox(true);
            ClickClosedCheckbox(true);
            ClickVoidCheckbox(true);
            ClickDuplicateCheckbox(true);
            ClickPrintedCheckbox(true);
        }

        public void UnselectAllCheckbox()
        {
                if (PendingCheckbox.Selected)
                    Extensions.JavaScriptExicuterClick(Driver, PendingCheckbox);
                if (DuplicateCheckbox.Selected)
                    Extensions.JavaScriptExicuterClick(Driver, DuplicateCheckbox);
                if (ActiveCheckbox.Selected)
                    Extensions.JavaScriptExicuterClick(Driver, ActiveCheckbox);
                if (ClosedCheckbox.Selected)
                    Extensions.JavaScriptExicuterClick(Driver, ClosedCheckbox);
                if (VoidCheckbox.Selected)
                    Extensions.JavaScriptExicuterClick(Driver, VoidCheckbox);
                if (PrintedCheckbox.Selected)
                    Extensions.JavaScriptExicuterClick(Driver, PrintedCheckbox);
        }

        public void EnterSearchTextField(string searchValue)
        {
            SearchTextField.SendKeys(searchValue+Keys.Tab);
        }

        public bool DuplicateVINErrorMessageDisplayed()
        {
            return IsElementDisplayedAfterWait(TextArea, 60);
        }

        public bool IsCheckboxSelected()
        {
            return SelectCheckbox.Selected;
        }

        public void ClickPrintSelected()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintSelected);
        }

        public bool IsPrintPreviewPageDisplayed()
        {
            return IsElementDisplayedAfterWait(PrintPreviewPage, 60);
        }

        public bool IsPrinterNameDisplayed()
        {
            return IsElementDisplayedAfterWait(PrinterName, 60);
        }

        public void ClickEditAlignment()
        {
            Extensions.JavaScriptExicuterClick(Driver, EditAlignment);
        }

        public void ClickTopMargin()
        {
            TopMargin.SendKeys(Keys.Control + 'a' + Keys.Backspace);
            TopMargin.SendKeys("1");
        }

        public void ClickBottomMargin()
        {
            BottomMargin.SendKeys(Keys.Control + 'a' + Keys.Backspace);
            BottomMargin.SendKeys("5");
        }

        public void ClickLeftMargin()
        {
            LeftMargin.SendKeys(Keys.Control + 'a' + Keys.Backspace);
            LeftMargin.SendKeys("6");
        }

        public void ClickRightMargin()
        {
            RightMargin.SendKeys(Keys.Control + 'a' + Keys.Backspace);
            RightMargin.SendKeys("24");
        }

        public void ClickPrintPreviewSaveButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintPreviewSaveButton);
        }

        public void VerifyGridValues()
        {
            Assert.AreEqual(BagLabelsVINInGrid.Text, PrintPreviewVINInGrid.Text);
        }

        public string BagLabelPageIdValue()
        {
            //return BagLabelsVINInGrid.Text;
            return KendoGrid.GetDataCellText(1, 1, 1);
        }

        public bool IsConfirmPrintPopup()
        {
            return IsElementDisplayedAfterWait(ConfirmPrintPopup, 60);
        }

        public void ClickContinueButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ContinueButton);
        }

        public void ClickOnReportsInLeftMenu()
        {
            Extensions.JavaScriptExicuterClick(Driver, Reports);
            KendoGrid.WaitForKendoReadyState();
        }

        public string GetStatusText()
        {
            return Status.Text;
        }

        public bool IsActiveCheckboxSelected()
        {
            return ActiveCheckbox.Selected;
        }

        public void ClickVinTab()
        {
            Extensions.JavaScriptExicuterClick(Driver, VINButton);
        }

        public void ClickBatchTab()
        {
            Extensions.JavaScriptExicuterClick(Driver, BatchButton);
            KendoGrid.WaitForKendoReadyState();
        }

        public void ClickClearButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ClearButton);
            KendoGrid.WaitForKendoReadyState();
        }

        public bool IsInputTagDisplayed()
        {
            return IsElementDisplayedAfterWait(InputTagHelpers, 20);
        }

        public void EnterTabKey()
        {
            SearchTextField.SendKeys(Extensions.GetRandomString(6) + Keys.Tab);
        }

        public void EnterSpaceKey()
        {
            SearchTextField.SendKeys(Extensions.GetRandomString(6) + Keys.Space);
        }

        public void EnterKey()
        {
            SearchTextField.SendKeys(Extensions.GetRandomString(6) + Keys.Enter);
            //SearchTextField.SendKeys(Keys.Enter);
        }

        /// <summary>
        /// Sets a list of the kendo grids columns containing the name and index
        /// </summary>
        /// <returns>void</returns>
        private void SetGridHeadingNames()
        {
            var columnIndex = 1;
            _gridColumnList = new List<GridColumn>();

            foreach (var webElement in GridHeadingNames)
            {
                if (string.IsNullOrWhiteSpace(webElement.Text))
                {
                    //The column header was out of view when the grid headings were obtained
                    webElement.ScrollToElement(Driver);
                }

                var isIgnored = _columnsToIgnore != null && _columnsToIgnore.Contains(webElement.Text);
                if (!isIgnored)
                {
                    _gridColumnList.Add(new GridColumn()
                    {
                        ColumnIndex = columnIndex++,
                        ColumnText = webElement.Text.ToUpper(),
                        Id = webElement.GetAttribute("id")
                    });
                }
                else
                {
                    columnIndex++;
                }
            }
        }


        /// <summary>
        /// Gets a grid column by column name
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns>A columns index</returns>
        public GridColumn GetGridColumn(string columnName)
        {
            if (string.IsNullOrWhiteSpace(columnName))
            {
                throw new ArgumentNullException(nameof(columnName));
            }
            if (_gridColumnList == null)
            {
                SetGridHeadingNames();
            }

            return _gridColumnList.FirstOrDefault(hd => hd.ColumnText == columnName.ToUpper());
        }


        /// <summary>
        /// Gets a list of grid column values based on a number of rows
        /// </summary>
        /// <param name="columnName">(Required) A grid column name: </param>
        /// <param name="maxRows">(Defaults to 1) The number of rows to get column values from </param>
        /// <returns></returns>
        public List<string> GetGridCellValues(string columnName, int maxRows = 1)
        {
            if (string.IsNullOrWhiteSpace(columnName))
            {
                throw new ArgumentNullException(nameof(columnName));
            }

            var gridColumn = GetGridColumn(columnName);
            var gridRowCount = KendoGrid.GetNumberOfDataRows();
            var cellValues = new List<string>();

            if (gridColumn != null && gridRowCount > 0)
            {
                for (var rowNumber = 1; rowNumber < gridRowCount + 1; rowNumber++)
                {
                    cellValues.Add(KendoGrid.GetDataCellText(rowNumber, gridColumn.ColumnIndex));
                    if (rowNumber == maxRows + 1)
                    {
                        break;
                    }
                }
            }

            return cellValues;

        }

        /// <summary>
        /// Compares grid column values against a set
        /// </summary>
        /// <param name="gridColumnName">(Required) The grid column name</param>
        /// <param name="valuesToVerify">(Required) A set of values to validate against</param>
        /// <returns></returns>
        public bool VerifyOrders(string gridColumnName, List<string> valuesToVerify)
        {
            SetGridHeadingNames();

            KendoGrid.WaitForKendoReadyState();

            var numberOfRows = KendoGrid.GetNumberOfDataRows();

            for (var row = 1; row <= numberOfRows; row++)
            {
                var gridColumn = GetGridColumn(gridColumnName);
                if (gridColumn != null)
                {
                    var cellValue = KendoGrid.GetDataCellText(row, gridColumn.ColumnIndex);
                    var result = valuesToVerify.First(val => val == cellValue);
                    if (string.IsNullOrWhiteSpace(cellValue) || cellValue != result)
                    {
                        // Cell value not found in list of values to verify against
                        return false;
                    }
                }
                else
                {
                    // Column not found
                    return false;
                }

            }

            return true;
        }

        public void ClickSearchTextField()
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var status = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[@class='bootstrap-tagsinput']//input")));
            Extensions.JavaScriptExicuterClick(Driver, SearchTextField);
        }

        public void EnterSearchText(List<string> searchValues)
        {
            foreach (var searchValue in searchValues)
            {
                SearchTextField.SendIndividualKeys(searchValue);
            }

        }

        public string GetSearchFieldText()
        {
            return SearchTextField.Text;
        }

        public string GetSearchButtonText()
        {
            return SearchButton.GetAttribute("innerText");
        }

        public string GetClearButtonText()
        {
            return ClearButton.GetAttribute("innerText");
        }

        public void WaitForKendoReadyState(int seconds = 15)
        {
            KendoGrid.WaitForKendoReadyState(seconds);
        }

        public void ClickInvoiceAndCloseButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, InvoiceAndCloseButton);
        }

        public string InvoicedColumn()
        {
            return Invoiced.Text;
        }

        public string PrintCountValue()
        {
            return PrintCount.Text;
        }

        public void ClickCreditButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CreditButton);
        }

        public string GetTotalAmount()
        {
            return TotalAmount.Text;
        }

        public void ClickRefreshButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, RefreshButton);
        }

        public int GetlabelIdData()
        {
            return Convert.ToInt32(LabelId.Text);
        }

        public void ClickOnLogs()
        {
            Extensions.JavaScriptExicuterClick(Driver, Logs);
        }


        public void VerifyValidationMessage(string expectedText, string actualText)
        {
            Assert.True(actualText.Contains(expectedText));
        }

        public void ClickNotificationsIcon()
        {
            Extensions.JavaScriptExicuterClick(Driver, NotificationsIcon);
        }

        public bool VerifyPrintLabelsInNotifications()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrintLabelsLatestJob);
            return IsElementDisplayedAfterWait(TotalFilesProcessed) &&
            IsElementDisplayedAfterWait(SuccessFiles) &&
            IsElementDisplayedAfterWait(WarningFiles) &&
            IsElementDisplayedAfterWait(ErrorFiles);
        }

        public bool IsHorizontalPositionTextboxDisplayed()
        {
            return IsElementDisplayedAfterWait(HorizontalPositionTextbox, 20);
        }

        public bool IsVerticalPositionTextboxDisplayed()
        {
            return IsElementDisplayedAfterWait(VerticalPosistionTextbox, 20);
        }

        public void ClickUpArrow()
        {
            //var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(60));
            //wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//div[@id='arrowUp']/button[@id='upArrowButton']//*[name()='svg']")));
            Extensions.JavaScriptExicuterClick(Driver, UpArrow);

            //Actions action = new Actions(Driver);
            //action.MoveToElement(UpArrow).Click().Perform();
        }

        public void ClickResetButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ResetButton);
        }

        public void ClickLabelsStausDropdown()
        {
            Extensions.JavaScriptExicuterClick(Driver, LabelStatus);
        }

        public bool IsMoveSelectedButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(MoveSelectedButton);
        }

        public void ClickMoveSelectedButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, MoveSelectedButton);
        }

        public bool IsMoveLabelsModalDisplayed()
        {
            return IsElementDisplayedAfterWait(MoveLabelsModal);
        }

        public void ClickProcessingLocationDropdown()
        {
            Extensions.JavaScriptExicuterClick(Driver, ProcessingOfficeDropdown);
        }

        public void SelectProcessingLocationOfficeValues(string location)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var processingoffice = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("processingLocationOffice_listbox")));
            Extensions.JavaScriptExicuterClick(Driver, processingoffice);
            var value = "//li[contains(text(),'" + location + "')]";
            var locationValue = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(value)));
            Extensions.JavaScriptExicuterClick(Driver, locationValue);
        }


        public List<string> ProcessingLocationDropDownValuesList()
        {
            string xpathProcessingLocations = "//ul[@id='processingLocationOffice_listbox']/li";
            List<string> validations = new List<string>();
            var processingoffice = Driver.FindElement(By.XPath("//div[@id='AssignPrinter']/div/div/div/span/span/span[2]"));
            Extensions.JavaScriptExicuterClick(Driver, processingoffice);

            Driver.WaitUntilElementExists(xpathProcessingLocations, 5);
            var allLocations = Driver.FindElements(By.XPath(xpathProcessingLocations));

            foreach (IWebElement element in allLocations)
            {
                validations.Add(element.Text);
            }

            Extensions.JavaScriptExicuterClick(Driver, processingoffice);

            return validations;
        }


        public void ClickMoveLabelsSaveButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, MoveLabelsSaveButton);
        }

        public void ClickMoveLabelsCancelButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, MoveLabelsCancelButton);
        }

        public bool IsProcessigLocationDropdownDisplayed()
        {
            return IsElementDisplayedAfterWait(ProcessingOfficeDropdown);
        }

        public bool IsCopySelectedButtonDisplayed()
        {
           var abcd = IsElementDisplayedAfterWait(CopySelectedButton);
            return IsElementDisplayedAfterWait(CopySelectedButton);
        }

        public void ClickCopySelectedButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, CopySelectedButton);
        }

        public bool IsCopySelectedModalDisplayed()
        {
            return IsElementDisplayedAfterWait(CopyLabelsModal);
        }

        public void ClickCopyLabelsExitButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ExitButtonCopyLabels);
        }

        public void ClickViewLogLinkInCopyLabelsModal()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewLogLink);
        }

        public bool IsCopyLabelsLogDisplayed()
        {
            return IsElementDisplayedAfterWait(CopyLabelLogDisplayed);
        }

        public int TotalCopyLabelsCount()
        {
            return Convert.ToInt32(TotalCopyLabels.GetAttribute("innerHTML"));
        }

        public int PassedCopyLabelsCount()
        {
            return Convert.ToInt32(PassedCopyLabels.GetAttribute("innerHTML"));
        }

        public int FailedCopyLabelsCount()
        {
            return Convert.ToInt32(FailedCopyLabels.GetAttribute("innerHTML"));
        }

        public void IsUserNameColumnSorted()
        {
            var cells = Driver.FindElements(By.XPath("//div[@id='gridViewLabels']//table/tbody/tr/td[6]"));
             Assert.IsTrue(cells.OrderBy(c => c.Text).SequenceEqual(cells));
        }

        public void VerifyExportCompletionMessage(string expectedText)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(180));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath($"//span[contains(text(), '{expectedText}')]")));
            VerifyValidationMessage(expectedText, ExportFileNotification.Text);
        }

        #endregion

        #region SQL


        //private List<T> ConvertDataTable<T>(DataTable dt)
        //{
        //    var data = new List<T>();
        //    foreach (DataRow row in dt.Rows)
        //    {
        //        var item = GetItem<T>(row);
        //        data.Add(item);
        //    }
        //    return data;
        //}

        //private T GetItem<T>(DataRow dr)
        //{
        //    var temp = typeof(T);
        //    var obj = Activator.CreateInstance<T>();

        //    foreach (DataColumn column in dr.Table.Columns)
        //    {
        //        foreach (var pro in temp.GetProperties())
        //        {
        //            if (pro.Name == column.ColumnName)

        //                if (dr[column.ColumnName] == DBNull.Value)
        //                {
        //                    pro.SetValue(obj, null, null);
        //                }
        //                else
        //                {
        //                    pro.SetValue(obj, dr[column.ColumnName], null);
        //                }
        //            else
        //                continue;
        //        }
        //    }
        //    return obj;
        //}

        public string ActiveVINInDB()
        {
            var VIN = string.Empty;
            const string SQLSelect = @"select VIN from [lm].[Labels] where VIN in (select VIN from [lm].[Labels] group by VIN having count(*) > 1);";

            return SQLHelper.ExecuteReader(SQLSelect, 0);
        }

        public string GetVINFromDB()
        {
            var VIN = string.Empty;
            const string SQLSelect = @"select top 1 VIN FROM [lm].[Labels] where LabelStatusTypeId = 3 and LabelTypeId = 2;";
            return SQLHelper.ExecuteReader(SQLSelect, 0);
        }

        public string GetBatchNumberFromDB()
        {
            var BatchNumber = string.Empty;
            const string SQLSelect = @"select top 1 BatchNumber FROM [lm].[Labels] where LabelStatusTypeId=3 and LabelTypeId=2;";
            return SQLHelper.ExecuteReader(SQLSelect, 0);
        }


        #endregion
    }
}

