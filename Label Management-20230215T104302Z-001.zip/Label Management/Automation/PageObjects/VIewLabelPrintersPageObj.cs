using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using System.Linq;
using OpenQA.Selenium.Support.UI;
using VM.FleetServices.TnR.LM.Web.Automation.Model;
using NUnit.Framework;

namespace VM.FleetServices.TnR.LM.Web.Automation.PageObjects
{
    public class VIewLabelPrintersPageObj : TnrPageObjBase
    {
        public KendoGridPageObj KendoGrid { get; }
        public VIewLabelPrintersPageObj(IWebDriver driver, string url) : base(driver, url)
        {
            Path = "/Configuration/ViewPrinterAssignment";
            KendoGrid = new KendoGridPageObj(driver);
        }

        private List<GridColumn> _gridColumnList { get; set; }
        private List<string> _columnsToIgnore { get; }

        #region WebElements
        private IWebElement SettingsMenu => Driver.FindElement(By.XPath("//*[@id='config-settings']/div/a"));
        private IWebElement UserPrinterMappings => Driver.FindElement(By.XPath("//div[@id='config-settings']/div/ul/li[4]/a"));
        private IWebElement AssignPrinterButton => Driver.FindElement(By.XPath("//button[contains(text(),' Assign Printer')]"));
        private IWebElement PrinterDropdown => Driver.FindElement(By.XPath("//span[contains(text(),'Select Printer')]"));
        private IWebElement UserName => Driver.FindElement(By.Id("userName"));
        private IWebElement AssignPrinterSaveButton => Driver.FindElement(By.Id("saveButton"));
        private IWebElement AssignPrinterGrid => Driver.FindElement(By.Id("PrinterAssignments"));
        private IWebElement Gridpagination => Driver.FindElement(By.XPath("//*[@id='PrinterAssignments']/div[3]/a/span"));
        private IWebElement EditAssignmentButton => Driver.FindElement(By.Id("editButton"));
        private IWebElement AssignprinterGridRow => Driver.FindElement(By.XPath("//*[@id='PrinterAssignments']/div[2]//table/tbody/tr[1]"));
        private IWebElement EditAssignmentPrinterDropdown => Driver.FindElement(By.XPath("//div[@class='col-md-12']//span[@class='k-dropdown-wrap k-state-default']/span[@class='k-input']"));
        private IWebElement LanguageDropdown => Driver.FindElement(By.Id("requestCulture_RequestCulture_UICulture_Name"));
        private IWebElement ManagePrinterButton => Driver.FindElement(By.XPath("//button[contains(text(),'Manage Printers')]"));
        private IWebElement AddPrinterButton => Driver.FindElement(By.XPath("//button[contains(text(),' Assign Printer')]"));
        private IWebElement EditPrinterButton => Driver.FindElement(By.Id("editButton"));
        private IWebElement UserPrinterMappingsButton => Driver.FindElement(By.XPath("//button[contains(text(),'User Printer Mappings')]"));
        private IWebElement PrinterName => Driver.FindElement(By.Id("printerName"));
        private IWebElement IpAddress => Driver.FindElement(By.Id("IPAddress"));
        private IWebElement PortNumber => Driver.FindElement(By.Id("portNumber"));
        private IWebElement AddPrinterSaveButton => Driver.FindElement(By.Id("saveButton"));
        private IWebElement ViewPrinterGridRow => Driver.FindElement(By.XPath("//*[@id='LabelPrinters']/div[2]/table/tbody/tr[1]"));
        private IReadOnlyCollection<IWebElement> GridHeadingNames => Driver.FindElements(By.XPath(headerColumnListXpath));
        private IWebElement ClientCodeDropdown => Driver.FindElement(By.Id("HeaderClientCode"));
        private IWebElement ApplyButton => Driver.FindElement(By.Id("HeaderApplySelection"));
        private IWebElement ViewBagLabel => Driver.FindElement(By.XPath("//span[contains(text(),'View Bag Labels')]"));

        private IWebElement PrinterDropdownPrintPreviewPage => Driver.FindElement(By.XPath("//div[@id='printerList']//span[@class='k-dropdown-wrap k-state-default']/span[@class='k-input']"));
        private IWebElement PrinterDropdownList => Driver.FindElement(By.Id("dropdownlist_listbox"));
        private IList<IWebElement> DropdownOptions => Driver.FindElements(By.XPath("//div[@id='dropdownlist-list']//ul/li"));
        private IWebElement ShowDisabledConfigurationsLabel => Driver.FindElement(By.XPath("//div[@id='main']//strong[1]"));
        private IWebElement ShowDisabledConfigurationsChekbox => Driver.FindElement(By.Id("Disabled"));
        private IWebElement DisabledConfiguration => Driver.FindElement(By.XPath("//tr[@class='k-alt']//div[@class='toggle btn btn-default off slow']//label[@class='btn btn-default active toggle-off'][normalize-space()='Off']"));
        private IWebElement ActiveRecords => Driver.FindElement(By.XPath("//tbody/tr[1]/td[1]/div[1]/div[1]/div[1]/label[text()='On']"));
        private IWebElement ProcessingLocation => Driver.FindElement(By.XPath("//label[normalize-space()='ProcessingLocationCode']"));
        private IWebElement Client => Driver.FindElement(By.XPath("//label[normalize-space()='Client']"));
        private IWebElement ProcessingLocationDropDown => Driver.FindElement(By.Id("ProcessingLocationCode"));
        private IWebElement ClientDrodown => Driver.FindElement(By.Id("ClientCode"));
        private IWebElement ClientCodeInGrid => Driver.FindElement(By.XPath("//a[normalize-space()='Client Code']"));
        private IWebElement ProcessingLocationInGrid => Driver.FindElement(By.XPath("//a[normalize-space()='Processing Location Code']"));

        private IWebElement ModalClientCodeDropdownButton => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[1]/div/span/div/button"));
        private IWebElement ModalClientCode_SelectAll => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[1]/div/span/div/ul/li/a/label"));
        private IWebElement ModalClientCode_Hertz => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[1]/div/span/div/ul/li[2]/a/label"));
        private IWebElement ModalClientCode_Enterprise => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/Div[2]/div[1]/div/span/div/ul/li[3]/a/label"));
        private IWebElement ModalProcessingLocationtDropdownButton => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/button"));
        private IWebElement ModalProcessingLocation_SelectAll => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/ul/li/a/label"));
        private IWebElement ModalProcessingLocation_SunShine => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/ul/li[2]/a/label"));
        private IWebElement ModalProcessingLocation_Suncity => Driver.FindElement(By.XPath("//div[@id='AddEditPlateHoldType']/div[2]/div[2]/div/span/div/ul/li[3]/a/label"));


        #endregion

        #region
        private string headerColumnListXpath = "//thead/tr/th[@role='columnheader']";
        private string dataRowBeforeXpath = "//div[@id='gridViewLabels']//tbody/tr[";
        private string dataRowMiddleXpath = "]/td[";
        private string dataRowEndXpath = "]";

        #endregion

        #region
        public void NavigateToUserPrinterMappings()
        {
            Extensions.JavaScriptExicuterClick(Driver, SettingsMenu);
            Extensions.JavaScriptExicuterClick(Driver, UserPrinterMappings);
        }

        public void ClickAssignPrinterButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, AssignPrinterButton);
        }

        public void ClickPrinterDropdown()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterDropdown);
        }

        public void PrinterDropdownOption(string printerOptions)
        {
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var status = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("printerName_listbox")));
            Extensions.JavaScriptExicuterClick(Driver, status);
            var value = "//li[contains(text(),'" + printerOptions + "')]";
            var printerValue = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(value)));
            Extensions.JavaScriptExicuterClick(Driver, printerValue);
        }

        public void EnterUserName()
        {
            Extensions.JavaScriptExicuterClick(Driver, UserName);
            UserName.SendKeys("User" + Extensions.GetRandomNumber(1, 150));
        }

        public void ClickAssignPrinterSaveButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, AssignPrinterSaveButton);
        }

        public bool IsAssignPrinterGridDisplayed()
        {
            return IsElementDisplayedAfterWait(AssignPrinterGrid, 50);
        }

        public bool IsGridPaginationExists()
        {
            return Gridpagination.Enabled;
        }

        public void ClickEditAssignmentButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, EditAssignmentButton);
        }

        public void ClickAssignprinterGridRow()
        {
            Extensions.JavaScriptExicuterClick(Driver, AssignprinterGridRow);
        }

        public void ClickEditAssignmentPrinterDropdown()
        {
            Extensions.JavaScriptExicuterClick(Driver, EditAssignmentPrinterDropdown);
        }

        public void SelectSpanishLanguage()
        {
            Extensions.SelectDropdownByText(LanguageDropdown, "Spanish");
        }

        public string GetAssignPrinterButtonText()
        {
            return AssignPrinterButton.GetAttribute("innerText");
        }

        public string GetEditAssignmentButtonText()
        {
            return EditAssignmentButton.GetAttribute("innerText");
        }

        public string GetManagePrinterButtonText()
        {
            return ManagePrinterButton.GetAttribute("innerText");
        }

        public void ClickManagePrinterButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ManagePrinterButton);
        }

        public bool IsAddPrinterButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(AddPrinterButton, 20);
        }

        public bool IsEditPrinterButtonDisplayed()
        {
            return IsElementDisplayedAfterWait(EditPrinterButton, 20);
        }

        public bool IsUserPrinterMappingsButtonDisplayed()
        {
            //return IsElementDisplayedAfterWait(UserPrinterMappingsButton, 20);
            return UserPrinterMappingsButton.Enabled;
        }

        public void ClickUserMappingsButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, UserPrinterMappingsButton);
        }

        public void ClickAddPrinterButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, AddPrinterButton);
        }

        public void ClickAddPrinterSaveButon()
        {
            Extensions.JavaScriptExicuterClick(Driver, AddPrinterSaveButton);
        }

        public void EnterPrinterName()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterName);
            PrinterName.SendKeys("Printer" + Extensions.GetRandomNumber(1, 100));
        }

        public void EnterPortNumber()
        {
            Extensions.JavaScriptExicuterClick(Driver, PortNumber);
            PortNumber.SendKeys("2" + Extensions.GetRandomNumber(1, 50));
        }

        public void EnterIPAddress()
        {
            Extensions.JavaScriptExicuterClick(Driver, IpAddress);
            IpAddress.SendKeys(Extensions.GetRandomNumber(100, 999) + "." + Extensions.GetRandomNumber(100, 999) + "." + Extensions.GetRandomNumber(0, 9) + "." + Extensions.GetRandomNumber(0, 9));
        }

        public void EditPrinterButtonClick()
        {
            Extensions.JavaScriptExicuterClick(Driver, EditPrinterButton);
        }

        public void ViewPrinterGridRowClick()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewPrinterGridRow);
        }

        public void EditPrinterName()
        {
            PrinterName.SendKeys(Keys.Control + 'a' + Keys.Backspace);
            PrinterName.SendKeys("Printer" + Extensions.GetRandomNumber(1, 100));
        }

        private void SetGridHeadingNames()
        {
            var columnIndex = 1;
            _gridColumnList = new List<GridColumn>();

            foreach (var webElement in GridHeadingNames)
            {
                if (string.IsNullOrWhiteSpace(webElement.Text))
                {
                    //The column header was out of view when the grid headings were obtained
                    webElement.ScrollToElement(Driver);
                }

                var isIgnored = _columnsToIgnore != null && _columnsToIgnore.Contains(webElement.Text);
                if (!isIgnored)
                {
                    _gridColumnList.Add(new GridColumn()
                    {
                        ColumnIndex = columnIndex++,
                        ColumnText = webElement.Text.ToUpper(),
                        Id = webElement.GetAttribute("id")
                    });
                }
                else
                {
                    columnIndex++;
                }
            }
        }

        private bool IsHeaderElementSortedAscending(IWebElement headerElement)
        {
            var wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(15));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-icon k-i-sort-asc-sm']")));
            return headerElement.GetAttribute("aria-sort") == "ascending";
        }

        private bool IsHeaderElementSortedDescending(IWebElement headerElement)
        {
            var wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(15));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-icon k-i-sort-desc-sm']")));
            return headerElement.GetAttribute("aria-sort") == "descending";
        }

        private bool IsColumnHeaderSortable(IWebElement headerElement)
        {
            Extensions.ScrollToElement(headerElement, Driver);
            Extensions.JavaScriptExicuterClick(Driver, headerElement);

            var sortableAscending = IsHeaderElementSortedAscending(headerElement);
            Extensions.JavaScriptExicuterClick(Driver, headerElement);
            var sortableDescending = IsHeaderElementSortedDescending(headerElement);

            return sortableAscending && sortableDescending;
        }

        private bool IsColumnHeaderSortable(string gridColumnName)
        {
            if (_gridColumnList == null)
            {
                SetGridHeadingNames();
            }

            var gridColumn = _gridColumnList.FirstOrDefault(col => col.ColumnText == gridColumnName.ToUpper());
            var column = Driver.FindElement(By.Id(gridColumn.Id));
            var result = IsColumnHeaderSortable(column);
            return result;
        }

        public bool IsOnOffSortable()
        {
            return IsColumnHeaderSortable(AssignPrinterColumnHeadings.OnOff);
        }

        public bool IsPrinterNameSortable()
        {
            return IsColumnHeaderSortable(AssignPrinterColumnHeadings.PrinterName);
        }

        public bool IsIPAddressSortable()
        {
            return IsColumnHeaderSortable(AssignPrinterColumnHeadings.IpAddress);
        }

        public bool IsPortNumberSortable()
        {
            return IsColumnHeaderSortable(AssignPrinterColumnHeadings.PortNumber);
        }

        public bool IsClientCodeSortable()
        {
            return IsColumnHeaderSortable(AssignPrinterColumnHeadings.ClientDetails);
        }

        public bool IsUserIdSortable()
        {
            return IsColumnHeaderSortable(AssignPrinterColumnHeadings.UserId);
        }

        public void SelectClientFromDropdown()
        {
            SelectElement clientCOde = new SelectElement(ClientCodeDropdown);
            clientCOde.SelectByIndex(1);
            Extensions.SelectDropdownByText(ClientCodeDropdown, " Enterprise");
        }

        public void SelectProcessingLocationFromDropdown()
        {
            Extensions.SelectDropdownByText(ProcessingLocationDropDown, "Select All");
        }

        public bool IsSelectedClientCode(string client)
        {
            bool val = false;
            string classname = string.Empty;

            switch (client)
            {
                case "Select All":
                    classname = ModalClientCode_SelectAll.GetAttribute("class");
                    break;
                case "Hertz":
                    classname = ModalClientCode_Hertz.GetAttribute("class");
                    break;
                case "Enterprise":
                    classname = ModalClientCode_Enterprise.GetAttribute("class");
                    break;
                default:
                    break;
            }

            if (!string.IsNullOrEmpty(classname))
            {
                val = classname.Contains("Active");
            }

            return val;
        }

        public void ClearAllClientCodes()
        {
            if (!IsSelectedClientCode("Select All"))
            {
                ClickClientCodeOption("Select All");
            }

            ClickClientCodeOption("Select All");
        }

        public void SelectClientCodeOptions(List<string> clients)
        {
            try
            {
                Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropdownButton);
                ClearAllClientCodes();

                foreach (string client in clients)
                    ClickClientCodeOption(client);

                Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropdownButton);
            }
            catch (Exception ed)
            {
            }

            ClearAllClientCodes();

            foreach (string client in clients)
                ClickClientCodeOption(client);

            Extensions.JavaScriptExicuterClick(Driver, ModalClientCodeDropdownButton);
        }

        public void ClickClientCodeOption(string client)
        {
            IWebElement element = null;

            switch (client)
            {
                case "Select All":
                    element = ModalClientCode_SelectAll;
                    break;
                case "Hertz":
                    element = ModalClientCode_Hertz;
                    break;
                case "Enterprise":
                    element = ModalClientCode_Enterprise;
                    break;
                default:
                    break;
            }

            if (element != null)
            {
                Extensions.JavaScriptExicuterClick(Driver, element);
            }
        }


        public void SelectProcessingLocationOptions(List<string> locations)
        {
            Extensions.JavaScriptExicuterClick(Driver, ModalProcessingLocationtDropdownButton);

            ClearAllProcessingLocations();

            foreach (string location in locations)
                ClickProcessingLocationOption(location);

            Extensions.JavaScriptExicuterClick(Driver, ModalProcessingLocationtDropdownButton);
        }


        public bool IsSelectedProcessingLocation(string location)
        {
            bool val = false;
            string classname = string.Empty;

            switch (location)
            {
                case "Select All":
                    classname = ModalProcessingLocation_SelectAll.GetAttribute("class");
                    break;
                case "Sunshine Bradenton, FL":
                    classname = ModalProcessingLocation_SunShine.GetAttribute("class");
                    break;
                case "Sun City, AZ":
                    classname = ModalProcessingLocation_Suncity.GetAttribute("class");
                    break;
                default:
                    break;
            }
            if (!string.IsNullOrEmpty(classname))
            {
                val = classname.Contains("Active");
            }

            return val;
        }

        public void ClearAllProcessingLocations()
        {
            if (!IsSelectedProcessingLocation("Select All"))
            {
                ClickProcessingLocationOption("Select All");
            }

            ClickProcessingLocationOption("Select All");
        }

        public void ClickProcessingLocationOption(string location)
        {
            IWebElement element = null;

            switch (location)
            {
                case "Select All":
                    element = ModalProcessingLocation_SelectAll;
                    break;
                case "Sunshine Bradenton, FL":
                    element = ModalProcessingLocation_SunShine;
                    break;
                case "Sun City, AZ":
                    element = ModalProcessingLocation_Suncity;
                    break;
                default:
                    break;
            }

            if (element != null)
            {
                Extensions.JavaScriptExicuterClick(Driver, element);
            }
        }

        public void ClickApplyButton()
        {
            Extensions.JavaScriptExicuterClick(Driver, ApplyButton);
        }

        public void CopyUserNameText()
        {
            Extensions.JavaScriptExicuterClick(Driver, UserName);
            UserName.SendKeys(Keys.Control + "ac");
        }

        public void EnterSameuserNameText()
        {
            Extensions.JavaScriptExicuterClick(Driver, UserName);
            UserName.SendKeys(Keys.Control + "v");
        }

        public void CopyPrinterNameText()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterName);
            PrinterName.SendKeys(Keys.Control + "ac");
        }

        public void EnterSamePrinterNameText()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterName);
            PrinterName.SendKeys(Keys.Control + "v");
        }

        public void EnterAdminUserName()
        {
            Extensions.JavaScriptExicuterClick(Driver, UserName);
            UserName.SendKeys("FSAMSTESTUSER");
        }

        public void ClickOnViewBagLabels()
        {
            Extensions.JavaScriptExicuterClick(Driver, ViewBagLabel);
        }

        public void VerifyPrinterExists(string printerOptionsViewPage)
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterDropdownPrintPreviewPage);
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(50));
            var status = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("dropdownlist_listbox")));
            Extensions.JavaScriptExicuterClick(Driver, status);
            var value = "//li[contains(text(),'" + printerOptionsViewPage + "')]";
            var printerValue = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(value)));
            Extensions.JavaScriptExicuterClick(Driver, printerValue);
        }

        public void EnterTestPrinterName()
        {
            Extensions.JavaScriptExicuterClick(Driver, PrinterName);
            PrinterName.SendKeys("Printer201");
        }

        public bool VerifyShowDisabledConfigurations()
        {
            return IsElementDisplayedAfterWait(ShowDisabledConfigurationsLabel);
        }

        public bool CheckShowDisabledConfigurations()
        {
            IsElementDisplayedAfterWait(ShowDisabledConfigurationsLabel);

            Extensions.JavaScriptExicuterClick(Driver, ShowDisabledConfigurationsChekbox);

            return IsElementDisplayedAfterWait(DisabledConfiguration);
        }

        public bool CheckShowDisabledConfigurationsIsSelected()
        {
            return ShowDisabledConfigurationsChekbox.Selected;
        }

        public bool VerifyActiveRecordsInTop()
        {
            return IsElementDisplayedAfterWait(ActiveRecords);
        }

        public void VerifySortOrder()
        {
            var cells = Driver.FindElements(By.XPath("//td[@data-field='DisplayName']"));
            Assert.True(cells.OrderBy(c => c.Text).SequenceEqual(cells));
        }

        public bool VerifyProcessingLocationCodeDisply()
        {
            return IsElementDisplayedAfterWait(ProcessingLocation);

        }
        public bool VerifyClientFieldInAssignPrinterPopUp()
        {
            return IsElementDisplayedAfterWait(Client);
        }

        public bool VerifyIsClientDropdownMultiSelect()
        {
            SelectElement client = new SelectElement(ClientDrodown);
            return client.IsMultiple;
        }

        public bool VerifyIsProcessingLocationMultiSelect()
        {
            SelectElement processingLocation = new SelectElement(ClientDrodown);

            return processingLocation.IsMultiple;
        }
        public bool VerifyCLientCodeAndProcessinglocationInGrid()
        {
            IsElementDisplayedAfterWait(ClientCodeInGrid);
            return IsElementDisplayedAfterWait(ProcessingLocationInGrid);
        }
        #endregion
    }
}

