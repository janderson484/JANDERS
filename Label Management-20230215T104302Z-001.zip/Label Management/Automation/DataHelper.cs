using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using VM.FleetServices.TnR.LM.Web.Automation.Model;

namespace VM.FleetServices.TnR.LM.Web.Automation
{
    public class DataHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string GetRandomVin()
        {
            return $"{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(4)}{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(2)}{Extensions.GetRandomNumber(1, 9)}{Extensions.GetRandomString(3)}{Extensions.GetRandomNumber(10000, 99999)}".ToUpper();
        }

        private static int ConvertLabelTypeEnumToInt(LabelStatusTypeEnum statusType)
        {
            switch (statusType)
            {
                case LabelStatusTypeEnum.Active:
                    return LabelStatusType.Active;
                case LabelStatusTypeEnum.Pending:
                    return LabelStatusType.Pending;
                case LabelStatusTypeEnum.Closed:
                    return LabelStatusType.Closed;
                case LabelStatusTypeEnum.Void:
                    return LabelStatusType.Void ;
                case LabelStatusTypeEnum.Duplicate:
                    return LabelStatusType.Duplicate;
                default:
                    return LabelStatusType.Active;
            }
        }

        /// <summary>
        /// Gets a Active Unit label object
        /// </summary>
        /// <returns></returns>
        public static Label GetRandomLabel(bool unitLabel = true, LabelStatusTypeEnum statueType = LabelStatusTypeEnum.Active, string client = Clients.Hertz,
            string processingLocationCode = ProcessingLocations.SunshineBradenton)
        {
            var date = DateTime.Now;
            const string user = "FSAMSTESTUSER";

            var label = new Model.Label()
            {
                LabelStatusTypeId = ConvertLabelTypeEnumToInt(statueType),
                LabelTypeId = unitLabel ? (int)LabelType.Unit: (int) LabelType.Bag, 
                ClientCode = Clients.Hertz.ToUpper(),
                StateProvinceCode = "FL",
                ProcessingLocationCode = ProcessingLocations.SunshineBradenton.ToUpper(),
                VIN = string.Empty,
                DeliveryCode = "2131",
                Model = "C999",
                Make = "Benz",
                PrintCount = 0,
                CreatedUser = user,
                CreatedDate = date,
                ModifiedUser = user,
                ModifiedDate = date,
                BatchNumber =  ((int)DateTime.Now.ToOADate()).ToString()
            };

            return label;
        }

        private static void PrintLabel(int labelid, bool unitLabel = true)
        {
            //Update Print count
            string updatePrintCountQuery = "update lm.labels set PrintCount = 1 where LabelId = {0}";
            string updatePrintCount = string.Format(updatePrintCountQuery, labelid);

            SQLHelper.ExecuteNonQuery(updatePrintCount);

            //Update billing info
            string price = unitLabel? "1.65" : "5.00";
            string insertBillingData;
            string billingQuery = $"INSERT INTO [lm].[LabelBillings] ([LabelId],[BillingFeeId],[ProcessingLocationCode],[InvoiceId],[IsDebit],[Void],[BillingAmount],[Comment],[CreatedUser],[CreatedDate]) values ";

            if (unitLabel)
            {
                insertBillingData = $"{billingQuery} ({labelid}, 15, 'FL-BRADENTON', NULL, 1, 0, 1.65, 'Print Unit label-Automated', 'FSAMSTESTUSER', '{DateTime.Now}')";
            }
            else
            {
                insertBillingData = $"{billingQuery} ({labelid}, 13, 'FL-BRADENTON', NULL, 1, 0, 5.00, 'Print Bag label-Automated', 'FSAMSTESTUSER', '{DateTime.Now}')";
            }

            SQLHelper.ExecuteNonQuery(insertBillingData);
        }


        private static void CreateLabelData(ref Label label)
        {
            if (label == null)
                throw new ArgumentNullException(nameof(label));

            var vin = GetRandomVin();

            // Insert the label
            var sqlQuery = @"INSERT INTO [lm].[Labels]
                     (  [LabelStatusTypeId],[LabelTypeId],[ClientCode],[StateProvinceCode],[ProcessingLocationCode],[VIN],[PrintCount],[CreatedUser],
                [CreatedDate],[ModifiedUser],[ModifiedDate],[IsPrinted],[DeliveryCode],[Make],[Model], [BatchNumber])
                             VALUES ";

            var values = $"({label.LabelStatusTypeId},{label.LabelTypeId},'{label.ClientCode}','{label.StateProvinceCode}'," +
                $"'{label.ProcessingLocationCode}','{vin}',{label.PrintCount},'{label.CreatedUser}','{label.CreatedDate}','{label.ModifiedUser}'," +
                $"'{label.ModifiedDate}',{0}, '{label.DeliveryCode}', '{label.Make}', '{label.Model}','{label.BatchNumber}')";

            sqlQuery = $"{sqlQuery}{values}";

            SQLHelper.ExecuteNonQuery(sqlQuery);

            label.VIN = vin;
            label.LabelId = SQLHelper.ExecuteScalar("Select LabelId from lm.labels where vin = '"+vin +"'");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="statusType">Refer LabelStatusType</param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Label InsertLabel(int statusType, LabelType type, bool printLabel= false)
        {
            var label = GetRandomLabel();
            label.LabelStatusTypeId = statusType;
            label.LabelTypeId = (int)type;
            CreateLabelData(ref label);

            if (printLabel)
            {
                PrintLabel(label.LabelId);
            }

            return label;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="label"></param>
        /// <returns></returns>
        public static Label InsertLabel(Label label, bool printLabel = false)
        {
            CreateLabelData( ref label);

            if (printLabel)
            {
                PrintLabel(label.LabelId, label.LabelTypeId == 1);
            }

            return label;
        }

        public static Label InsertLabel(bool unitLabel = true, LabelStatusTypeEnum statueType = LabelStatusTypeEnum.Active, string client = Clients.Hertz,
            string processingLocationCode = ProcessingLocations.SunshineBradenton, bool printLabel = false)
        {
            var label = GetRandomLabel(unitLabel, statueType, client, processingLocationCode);
            CreateLabelData(ref label);

            if (printLabel)
            {
                PrintLabel(label.LabelId);
            }

            return label;
        }

        private static string CreateBagLabelData(Label label)
        {
            if (label == null)
                throw new ArgumentNullException(nameof(label));

            var vin = GetRandomVin();

            // Insert the label
            var sqlQuery = @"INSERT INTO [lm].[Labels]
                                (  [LabelStatusTypeId],[LabelTypeId],[ClientCode],[StateProvinceCode]
                                  ,[ProcessingLocationCode],[VIN],[DeliveryCode],[Model],[PrintCount]
                                  ,[CreatedUser],[CreatedDate],[ModifiedUser],[ModifiedDate],[IsPrinted])
                             VALUES ";

            var values = $"({label.LabelStatusTypeId},{label.LabelTypeId},'{label.ClientCode}','{label.StateProvinceCode}','{label.ProcessingLocationCode}','{vin}','{label.DeliveryCode}','{label.Model}',{label.PrintCount},'{label.CreatedUser}','{label.CreatedDate}','{label.ModifiedUser}','{label.ModifiedDate}',{0})";

            sqlQuery = $"{sqlQuery}{values}";

            SQLHelper.ExecuteNonQuery(sqlQuery);

            return vin;
        }

        /// <summary>
        /// Inserts a random Label(active unit). QUICK CALL
        /// </summary>
        /// <returns></returns>
        public static Label InsertActiveBagLabel(bool printLabel =false)
        {
            return InsertLabel(false, printLabel: printLabel);
        }

        /// <summary>
        /// This funtion will close the Open Invoices.
        /// </summary>
        public static void CloseAllOpenInvoices()
        {
            string updateQuery = @"update invoice.Invoices set InvoiceStatusTypeId = 2 " +
                "where invoiceid in (select invoiceid from invoice.invoices where ClientCode = 'HERTZ' and InvoiceStatusTypeId=1)";

            SQLHelper.ExecuteNonQuery(updateQuery, SQLHelper.PMConnectionString);
        }

        public static void VoidAllOpenInvoices()
        {
            string updateQuery = @"update invoice.Invoices set InvoiceStatusTypeId = 3 " +
                "where invoiceid in (select invoiceid from invoice.invoices where InvoiceStatusTypeId = 1)";

            SQLHelper.ExecuteNonQuery(updateQuery, SQLHelper.PMConnectionString);
        }

        /// <summary>
        /// Gets labels based on label status and label type (optional)
        /// </summary>
        /// <param name="labelStatus">The label status to get labels for</param>
        /// <param name="numOfRows">The number of rows to return</param>
        /// <param name="labelType">The label type to get labels for</param>
        /// <returns>List of LabelData</returns>
        public static List<LabelData> GetLabels(string labelStatus, int numOfRows = 1, LabelType labelType = LabelType.All)
        {
            if (labelStatus == null)
                throw new ArgumentNullException(nameof(labelStatus));

            if (numOfRows <= 0)
                throw new ArgumentOutOfRangeException(nameof(numOfRows));

            var sqlQuery = $"SELECT TOP {numOfRows} ";

            sqlQuery += @"LB.LabelId, 
	                      LB.LabelTypeId, 
	                      LT.DisplayName AS LabelTypeDisplayName, 
	                      LS.LabelStatusTypeId,  
	                      LS.DisplayName AS LabelStatusTypeDisplayName, 
	                      LB.Vin
                        FROM [lm].[Labels] LB 
	                       JOIN [lm].[LabelTypes] LT ON LB.LabelTypeId = LT.LabelTypeId
	                       JOIN [lm].[LabelStatusTypes] LS ON LB.[LabelStatusTypeId] = LS.[LabelStatusTypeId]";

            sqlQuery = $"{sqlQuery} WHERE LEN(TRIM(LB.Vin)) = 17 AND UPPER(LS.DisplayName) = '{labelStatus.ToUpper()}'";

            if (labelType != LabelType.All)
            {
                sqlQuery = $"{sqlQuery} AND LB.LabelTypeId = {(int)labelType}";
            }

            var dataTable = SQLHelper.ExecuteAdapterFill(sqlQuery, SQLHelper.LMConnectionString);
            return ConvertDataTable<LabelData>(dataTable);
        }

        /// <summary>
        /// Gets labels based on a list of vins and label types
        /// </summary>
        /// <param name="vinsList">The list of vins to search for</param>
        /// <param name="labelType">The label type/s to get labels for</param>
        /// <returns>List of LabelData</returns>
        public static List<LabelData> GetLabels(List<string> vinsList, LabelType labelType = LabelType.All)
        {
            if (vinsList == null)
                throw new ArgumentNullException(nameof(vinsList));

            if (vinsList.Count == 0)
                throw new ArgumentException("Value cannot be an empty collection.", nameof(vinsList));

            // Build the vins string 
            var vins = vinsList.Count == 1
                ? $"'{vinsList.First()}'"
                : vinsList.Aggregate(string.Empty, (current, vin) => current + $"{current},'{vin.Trim().ToUpper()}'");

            vins = vins.Replace("\r\n", "");

            var sqlQuery = @"
                          SELECT
                          LB.LabelId, 
	                      LB.LabelTypeId, 
	                      LT.DisplayName AS LabelTypeDisplayName, 
	                      LS.LabelStatusTypeId,  
	                      LS.DisplayName AS LabelStatusTypeDisplayName, 
	                      LB.Vin
                        FROM [lm].[Labels] LB 
	                       JOIN [lm].[LabelTypes] LT ON LB.LabelTypeId = LT.LabelTypeId
	                       JOIN [lm].[LabelStatusTypes] LS ON LB.[LabelStatusTypeId] = LS.[LabelStatusTypeId]";

            sqlQuery = $"{sqlQuery} WHERE LEN(TRIM(LB.Vin)) = 17 AND UPPER(LB.Vin) in ({vins.Trim()})";

            sqlQuery = labelType != LabelType.All
                ? $"{sqlQuery} AND LB.LabelTypeId = {(int)labelType}"
                : $"{sqlQuery} AND LB.LabelTypeId in (1,2)";

            var dataTable = SQLHelper.ExecuteAdapterFill(sqlQuery, SQLHelper.LMConnectionString);

            return ConvertDataTable<LabelData>(dataTable);
        }

        /// <summary>
        /// Updates a labels status if a label with the status does not already exist 
        /// </summary>
        /// <param name="labelStatus">The label status value to update to </param>
        /// <param name="labelType">The type of label to update</param>
        /// <returns>The updated label</returns>
        public static string UpdateLabelStatus(string labelStatus, LabelType labelType = LabelType.All)
        {
            if (string.IsNullOrWhiteSpace(labelStatus))
                throw new ArgumentNullException(nameof(labelStatus));

            // Try to get a label with the specified status first
            var labelDataList = GetLabels(labelStatus, 1, labelType);
            if (labelDataList.Any())
            {
                return ConvertListToString(labelDataList);
            }

            // Get get an active label since none exist for the specified status
            labelDataList = GetLabels(LabelStatus.Active, 1, labelType);

            // Return if no active labels found (cant do anything about this scenario)
            if (!labelDataList.Any())
                return string.Empty;

            // Update a labels status since none exist for the specified status
            var labelToUpdate = labelDataList.Single();

            var sqlQuery = "UPDATE [lm].[Labels] " +
                           "SET [LabelStatusTypeId] = " +
                           $"(SELECT [LabelStatusTypeId] FROM [lm].[LabelStatusTypes] WHERE UPPER(DisplayName) = '{labelStatus.ToUpper()}') " +
                           $"WHERE [LabelId] = {labelToUpdate.LabelId}";

            using (var connection = new SqlConnection(SQLHelper.LMConnectionString))
            {
                connection.Open();
                var updateCommand = new SqlCommand(sqlQuery, connection);
                updateCommand.ExecuteNonQuery();
            }

            return ConvertListToString(labelDataList);

        }

        /// <summary>
        /// Gets the latest log entry for a client code, process name, start date and optional log id
        /// </summary>
        /// <param name="clientCode">The required client code</param>
        /// <param name="processName">The required process name ie: Import Labels</param>
        /// <param name="startDate">The required start date</param>
        /// <param name="logId">An optional log id</param>
        /// <returns>Log Entry</returns>
        public static List<LogData> GetLatestLog(string clientCode, string processName, DateTime startDate, int logId = 0)
        {
            if (string.IsNullOrWhiteSpace(clientCode))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(clientCode));

            if (string.IsNullOrWhiteSpace(processName))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(processName));

            List<LogData> logDataList = null;
            for (var i = 0; i < 10; i++)
            {
                // Wait for up to 10 iterations for job status to become completed
                var sqlQuery = @"
                            SELECT TOP (1)
                                 [LogId]
                                ,[ProcessName]
                                ,[ProcessType]
                                ,[Filename]
                                ,[TotalCount]
                                ,[SuccessfulCount]
                                ,[ErrorCount]
                                ,[WarningCount]
                                ,[Status]
                                ,[CreatedUser]
                                ,[ProcessStartDate]
                                ,[ProcessEndDate]
                            FROM [lm].[Logs]";

                sqlQuery = $"{sqlQuery} WHERE UPPER([ClientCode]) = '{clientCode.ToUpper()}' ";
                sqlQuery = $"{sqlQuery} AND UPPER([ProcessName]) = '{processName.ToUpper()}' ";
                sqlQuery = $"{sqlQuery} AND [ProcessStartDate] >= '{startDate.ToShortDateString()}' ";

                if (logId > 0)
                    sqlQuery = $"{sqlQuery} AND [LogId] = {logId} ";

                sqlQuery = $"{sqlQuery} ORDER BY [LogId] DESC ";

                var dataTable = new DataTable();

                using (var connection = new SqlConnection(SQLHelper.LMConnectionString))
                {
                    var adapter = new SqlDataAdapter { SelectCommand = new SqlCommand(sqlQuery, connection) };
                    adapter.Fill(dataTable);
                    logDataList = ConvertDataTable<LogData>(dataTable);
                }

                var log = logDataList.First();
                if (string.Equals(log.Status, LogDetailsPageStatus.Failed, StringComparison.CurrentCultureIgnoreCase) ||
                    string.Equals(log.Status, LogDetailsPageStatus.Completed, StringComparison.CurrentCultureIgnoreCase))
                {
                    break;
                }
            }
            return logDataList;
        }

        /// <summary>
        /// Select data from Labels table
        /// </summary>
        public static Label SelectLabelData()
        {
            const string sqlQuery = SqlSelectDataViewBagLabels.SelectLabelRecord;
            var dataset = SQLHelper.ExecuteAdapterFill(sqlQuery, SQLHelper.LMConnectionString);

            return ConvertDataTable<Label>(dataset).FirstOrDefault();
        }

        #region SQL Helpers

        private static List<T> ConvertDataTable<T>(DataTable dt)
        {
            var data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                var item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }

        private static T GetItem<T>(DataRow dr)
        {
            var temp = typeof(T);
            var obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (var pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)

                        if (dr[column.ColumnName] == DBNull.Value)
                        {
                            pro.SetValue(obj, null, null);
                        }
                        else
                        {
                            pro.SetValue(obj, dr[column.ColumnName], null);
                        }
                    else
                        continue;
                }
            }
            return obj;
        }

        /// <summary>
        /// Converts a list of LabelData to a string representation
        /// </summary>
        /// <param name="labelDataList">The list to convert</param>
        /// <returns>String</returns>
        public static string ConvertListToString(List<LabelData> labelDataList)
        {
            // Returns a string containing the vin with a new linefeed after each vin
            return labelDataList.Aggregate(string.Empty, (current, label) => current + $"{label.Vin}\r\n");
        }

        #endregion


    }

    public static class StandardQueries
    {
        public const string InvoiceIdNullAndVoidIsFalse = "select Count(*) from [lm].[LabelBillings] where LabelId = {0} and InvoiceId is null and Void = 0";
        public const string InvoiceIdNotNullAndVoidIsFalse = " select Count(*) from [lm].[LabelBillings] where LabelId = {0} and InvoiceId is not null and Void = 0";

    }
}
