using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace VM.FleetServices.TnR.LM.Web.Automation
{
    /// PLEASE MAKE SURE CONNECTIONS ARE CLOSED AFTER QUERY IS DONE
    public static class SQLHelper
    {
        //public static string LMConnectionString = SQL.LMSqlDevConnection;
        //public static string PMConnectionString = SQL.PMSqlDevConnection;

        public static string LMConnectionString = SQL.LMSqlQAConnection;
        public static string PMConnectionString = SQL.PMSqlQAConnection;

        //public static string LMConnectionString = SQL.LMSqlDevConnection;
        //public static string PMConnectionString = SQL.PMSqlDevConnection;

        public static int ExecuteScalar(string query, string ConnectionString= "")
        {
            int count = 0;
            if (string.IsNullOrEmpty(ConnectionString))
                ConnectionString = LMConnectionString;

            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    count = (int)cmd.ExecuteScalar();
                    conn.Close();
                }
                Console.WriteLine(count);
            }
            return count;
        }

        public static int ExecuteNonQuery(string query, string ConnectionString ="")
        {
            if (string.IsNullOrEmpty(ConnectionString))
            {
                ConnectionString = LMConnectionString;
            }

            int rowsUpdated = 0;
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    rowsUpdated =cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }

            return rowsUpdated;
        }

        public static string ExecuteReader(string query, int columnNumber, string connectionString = "")
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                connectionString = LMConnectionString;
            }
            string result = string.Empty;
            using (SqlConnection conn = new SqlConnection(SQLHelper.LMConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            result = reader.GetString(columnNumber);
                        }
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            return result;
        }

        public static DataTable ExecuteAdapterFill(string query, string connectionString)
        {
            DataTable dataTable = new DataTable();
            using (var connection = new SqlConnection(connectionString))
            {
                var adapter = new SqlDataAdapter
                {
                    SelectCommand = new SqlCommand(query, connection)
                };
                adapter.Fill(dataTable);
            }

            return dataTable;
        }
        
    }
}
