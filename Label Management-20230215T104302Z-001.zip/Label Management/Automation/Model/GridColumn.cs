namespace VM.FleetServices.TnR.LM.Web.Automation.Model
{
    public class GridColumn
    {
        public string ColumnText { get; set; }
        public int ColumnIndex { get; set; }
        public string Id { get; set; }
    }
}
