using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Web.Automation.Model
{
    public class LabelData
    {
        public int LabelId { get; set; }
        public int LabelTypeId { get; set; }
        public string LabelTypeDisplayName { get; set; }
        public int LabelStatusTypeId { get; set; }
        public string LabelStatusTypeDisplayName { get; set; }
        public string Vin { get; set; }
        
    }
}
