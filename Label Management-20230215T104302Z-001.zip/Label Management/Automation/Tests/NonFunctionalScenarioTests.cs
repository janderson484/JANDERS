using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Timers;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class NonFunctionalScenarioTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(TestName = "VerifySessionPopupDoesNotAppearWhenUserRemainsActiveOnOnePage")]
        [Category("231524")]
        public void VerifySessionPopupDoesNotAppearWhenUserRemainsActiveOnOnePage()
        {
            int minActivityTime = TimeOuts.AppTimeOut * 2 / 10;
            
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);

            for (int count = 0; count < 10; count++)
            {
                if (count % 2 == 0)
                    viewUnitLabelPage.Navigate();
                else
                    viewBagLabelPage.Navigate();

                Thread.Sleep(minActivityTime);
                Assert.IsFalse(viewBagLabelPage.IsTimeOutDialogVisible(), "Time out dialog is displayed.");
            }

            Assert.Pass("Time out dialog didnt showup");
        }

        [TestCase(TestName = "VerifySessionTimeoutPopupAppearsAfterTimeoutIntervalSetting")]
        [Category("231641")]
        public void VerifySessionTimeoutPopupAppearsAfterTimeoutIntervalSetting()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Thread.Sleep(TimeOuts.AppTimeOut);

            Assert.IsTrue(viewBagLabelPage.IsTimeOutDialogVisible(15), "Time out dialog is not displayed.");
        }

        [TestCase(TestName = "VerifyUserIsLoggedOutAfterClickingOnSignOutButtonOnSessionTimeoutPopup")]
        [Category("231648")]
        public void VerifyUserIsLoggedOutAfterClickingOnSignOutButtonOnSessionTimeoutPopup()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Thread.Sleep(TimeOuts.AppTimeOut);

            Assert.IsTrue(viewUnitLabelPage.IsTimeOutDialogVisible(15), "Time out dialog is not displayed.");
            viewUnitLabelPage.ClickSignOutOnAutoLogOut();

            Assert.AreEqual(PageTitles.Login, viewUnitLabelPage.PageTitle, "User is not signed out");
        }

        [TestCase(TestName = "VerifyUserIfNotLoggedOutAfterClickingOnStayLoggedInButtonOnSessionTimeoutPopup")]
        [Category("231656")]
        public void VerifyUserIfNotLoggedOutAfterClickingOnStayLoggedInButtonOnSessionTimeoutPopup()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Thread.Sleep(TimeOuts.AppTimeOut);

            Assert.IsTrue(viewBagLabelPage.IsTimeOutDialogVisible(15), "Time out dialog is not displayed.");
            viewBagLabelPage.ClickStayLoggedInOnAutoLogout();

            Assert.AreEqual(PageTitles.ViewBagLabels, viewBagLabelPage.PageTitle, "User is not signed out");
        }


        [TestCase(TestName = "VerifyUserIsLoggedOutAutomaticallyAfterSessionTimeoutPopupCountdownTimerReachesZero")]
        [Category("231657")]
        public void VerifyUserIsLoggedOutAutomaticallyAfterSessionTimeoutPopupCountdownTimerReachesZero()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            Thread.Sleep(TimeOuts.AppTimeOut);

            Assert.IsTrue(bulkProcessingPage.IsTimeOutDialogVisible(15), "Time out dialog is not displayed.");
            Thread.Sleep(TimeOuts.CountDownTimer);

            Assert.AreEqual(PageTitles.Login, bulkProcessingPage.PageTitle, "User is not signed out");
        }
    }

}
