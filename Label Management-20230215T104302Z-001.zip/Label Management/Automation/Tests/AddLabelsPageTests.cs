using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Office.Interop.Excel;
using NPOI;
using NPOI.OpenXmlFormats.Spreadsheet;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;
using VM.FleetServices.TnR.LM.Web.Automation.Model;
using System.Text;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class AddLabelsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        private const string UnitLabelTest = "Unit Label Test";
        private const string UnitLabelsWithBagLabels = "Unit Labels with bag labels";

        #region Older Tests
        [TestCase(TestName = "AddLabelsPage_Expect_PageDisplayedCorrectly")]
        public void AddLabelsPage_Expect_PageDisplayedCorrectly()
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed(), "Import Profile");
            Assert.IsTrue(addLabelsPage.IsLabelTypeDropdownDisplayed(), "Label Type");
            Assert.IsTrue(addLabelsPage.IsProcessingOfficeDropdownDisplayed(), "Processing OFfice");
            Assert.IsTrue(addLabelsPage.IsLabelDataTextareaDisplayed(), "Label data");
            Assert.IsFalse(addLabelsPage.IsGenerateBagLabelsCheckboxDisplayed(), "Generate Bage labels");
            Assert.IsFalse(addLabelsPage.IsClearButtonDisplayed(), "Clear Button");
            Assert.IsFalse(addLabelsPage.IsSubmitLabelsButtonDisplayed(), "Submit button");
        }

        [TestCase("DupTest", TestName = "AddLabelsPage_NoLabelRecordsEntered_Expect_ErrorNotification")]
        public void AddLabelsPage_NoLabelRecordsEntered_Expect_ErrorNotification(string importProfileDesc)
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());

            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            var importProfileColCount = addLabelsPage.GetNumberImportProfileColumns();
            Assert.Greater(importProfileColCount, 0);

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());

            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());

            // TODO: Assert after actual notification are added to LM
            //Assert.AreEqual("Error:Must contain one record!", addLabelsPage.GetErrorNotificationMessage());

        }

        [TestCase("DupTest", TestName = "AddLabelsPage_ClickClearButton_Expect_LabelDataCleared")]
        public void AddLabelsPage_ClickClearButton_Expect_LabelDataCleared(string importProfileDesc)
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());

            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            var importProfileColCount = addLabelsPage.GetNumberImportProfileColumns();
            Assert.Greater(importProfileColCount, 0);

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());

            addLabelsPage.AddLabelData("testing string");
            Assert.IsFalse(addLabelsPage.IsLabelDataTextAreaEmpty());

            //Assert.IsTrue(addLabelsPage.IsClearButtonDisplayed());
            addLabelsPage.ClickClearButton();

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());
            Assert.IsTrue(addLabelsPage.IsLabelDataTextAreaEmpty());
        }

        [TestCase("New Layout Config", "123\t456\r\n", TestName = "AddLabelsPage_NotEnoughColumnsEntered_TabDelimited_Expect_ErrorNotification")]
        [TestCase("New Layout Config", "123,456\r\n", TestName = "AddLabelsPage_NotEnoughColumnsEntered_CommaDelimited_Expect_ErrorNotification")]
        public void AddLabelsPage_NotEnoughColumnsEntered_Expect_ErrorNotification(string importProfileDesc, string labelDataRow)
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());

            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            var importProfileColCount = addLabelsPage.GetNumberImportProfileColumns();
            Assert.Greater(importProfileColCount, 0);

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            //Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());

            addLabelsPage.AddLabelData(labelDataRow);

            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());

            // TODO: Assert after actual notification are added to LM
            //Assert.AreEqual("Error:The pasted data does not match the expected layout.", addLabelsPage.GetErrorNotificationMessage());
        }

        [TestCase("DupTest", "123\t456\r\n", TestName = "AddLabelsPage_TooManyColumnsEntered_TabDelimited_Expect_ErrorNotification")]
        [TestCase("DupTest", "123,456\r\n", TestName = "AddLabelsPage_TooManyColumnsEntered_CommaDelimited_Expect_ErrorNotification")]
        public void AddLabelsPage_TooManyColumnsEntered_Expect_ErrorNotification(string importProfileDesc, string labelDataRow)
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());

            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            var importProfileColCount = addLabelsPage.GetNumberImportProfileColumns();
            Assert.Greater(importProfileColCount, 0);

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());

            addLabelsPage.AddLabelData(labelDataRow);

            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());

            // TODO: Assert after actual notification are added to LM
            //Assert.AreEqual("Error:The pasted data does not match the expected layout.", addLabelsPage.GetErrorNotificationMessage());
        }

        [TestCase("DupTest", "1234567890ABCDEFG\r\n", 1, TestName = "AddLabelsPage_EnterValidLabelData_SingleRow_Expect_SuccessNotification")]
        [TestCase("DupTest", "1234567890ABCDEFG\r\n", 4, TestName = "AddLabelsPage_EnterValidLabelData_MultipleRows_Expect_SuccessNotification")]
        [TestCase("DupTest", "1234567890ABCDEFG\r\n", 1000, TestName = "AddLabelsPage_EnterValidLabelData_MultipleRows_MaxCount_Expect_SuccessNotification")]
        public void AddLabelsPage_EnterValidLabelData_Expect_SuccessNotification(string importProfileDesc, string labelDataRow, int numDataRows)
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            var labelData = "";

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());

            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            var importProfileColCount = addLabelsPage.GetNumberImportProfileColumns();
            Assert.Greater(importProfileColCount, 0);

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());

            for (var i = 0; i < numDataRows; i++)
            {
                // For test with VIN only import profile
                labelData += DataHelper.GetRandomVin() + "\r\n";
            }

            addLabelsPage.AddLabelData(labelData);

            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed()); // Note: This is also the success notification modal

            addLabelsPage.WaitForPageRefresh();
        }

        // TODO: Update to use Header Page Obj when added
        [TestCase("DupTest", ProcessingLocations.SunCityAz, TestName = "AddLabelsPage_ChangingProcessingOffice_DoesNotMatchHeader_Expect_ErrorNotification")]
        public void AddLabelsPage_ChangingProcessingOffice_DoesNotMatchHeader_Expect_ErrorNotification(string importProfileDesc, string processingLocationDesc)
        {
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());

            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            var importProfileColCount = addLabelsPage.GetNumberImportProfileColumns();
            Assert.Greater(importProfileColCount, 0);

            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetLabelTypeSelectionDescription());
            Assert.AreNotEqual(DescriptionText.AddLabelsDropdownPlaceholder, addLabelsPage.GetProcessingOfficeSelectionDescription());

            addLabelsPage.SelectProcessingOfficeByText(processingLocationDesc);

            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());
        }
        #endregion

        #region New Tests

        [TestCase(UnitLabelTest, 1, TestName = "AddLabelsPage_SubmitDuplicateLabels_Expect_Errors")]
        public void AddLabelsPage_SubmitDuplicateLabels_Expect_Errors(string importProfileDesc, int numDataRows)
        {
            // ** Ensure log errors are displayed for adding labels containing duplicate vins **

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Labels Test' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Paste 2 duplicate rows containing a valid Vin in the 'Paste Records Below' text area
            var labelDataList = DataHelper.GetLabels(LabelStatus.Active, numDataRows, LabelType.Unit);
            Assert.NotNull(labelDataList, $"Failed to get label data for the status value: {LabelStatus.Active}");
            Assert.True(labelDataList.Count > 0, $"Failed to get label data for the status value: {LabelStatus.Active}");

            // Duplicate the data
            var labelDataString = DataHelper.ConvertListToString(labelDataList);
            labelDataString = $"{labelDataString}{labelDataString}";

            // Paste the data in
            addLabelsPage.AddLabelData(labelDataString);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            //Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains an error containing the partial text about duplicate vins 
            Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("is duplicated in the input"));

        }

        [TestCase(UnitLabelTest, LabelStatus.Closed, TestName = "AddLabelsPage_SubmitExistingLabelWithCertainStatus_Closed_Expect_Success")]
        public void AddLabelsPage_SubmitExistingLabelWithCertainStatus_Closed_Expect_Success(string importProfileDesc, string labelStatus)
        {
            // ** Ensure a label is successfully added when an existing label with the same vin has a status of CLOSED **

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Label Test' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Paste a row where an existing label with a CLOSED status already exists
            var label = DataHelper.InsertLabel(statueType: LabelStatusTypeEnum.Closed);
            var labelDataList = DataHelper.GetLabels(new List<string>() { label.VIN }, LabelType.Unit);
            var labelDataString = DataHelper.ConvertListToString(labelDataList);
            Assert.IsNotEmpty(labelDataString, $"Failed to get label data for the status value: {labelStatus}");

            // Paste the data in
            addLabelsPage.AddLabelData(labelDataString);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains a successful submit
            Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("submitted"));

            //Get the log details
            var logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);

            // Must be a log
            Assert.NotNull(logData);
            var log = logData.First();

            if (log.Status != LogDetailsPageStatus.Completed)
            {
                // If the log is still not completed then try one more time to get a completed job
                logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);
                log = logData.First();
            }

            // Verify total count should be 1
            Assert.AreEqual(1, log.TotalCount);

            // Verify error count, should be 0 
            Assert.AreEqual(0, log.ErrorCount);

            // Verify success count should be 1
            Assert.AreEqual(1, log.SuccessfulCount);

            // Verify log status should be completed
            Assert.AreEqual(LogDetailsPageStatus.Completed.ToUpper(), log.Status.ToUpper());
        }

        [TestCase(UnitLabelTest, LabelStatus.Pending, TestName = "AddLabelsPage_SubmitExistingLabelWithCertainStatus_Pending_Expect_Success")]
        public void AddLabelsPage_SubmitExistingLabelWithCertainStatus_Pending_Expect_Success(string importProfileDesc, string labelStatus)
        {
            // ** Ensure a label is successfully added when an existing label with the same vin has a status of PENDING **

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Label Test' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Paste a row where an existing label with a PENDING status already exists
            //Insert(stage) a new label to use as the existing label
            var date = DateTime.Now;
            const string user = "FSAMSTESTUSER";

            var label = new Model.Label()
            {
                LabelStatusTypeId = LabelStatusType.Pending,
                LabelTypeId = (int)LabelType.Unit,
                ClientCode = Clients.Hertz.ToUpper(),
                StateProvinceCode = string.Empty,
                ProcessingLocationCode = ProcessingLocations.SunshineBradenton.ToUpper(),
                VIN = string.Empty,
                PrintCount = 0,
                CreatedUser = user,
                CreatedDate = date,
                ModifiedUser = user,
                ModifiedDate = date
            };

            label = DataHelper.InsertLabel(label);
            var labelDataList = DataHelper.GetLabels(new List<string>() { label.VIN }, LabelType.Unit);
            var labelDataString = DataHelper.ConvertListToString(labelDataList);
            Assert.IsNotEmpty(labelDataString, $"Failed to get label data for the status value: {labelStatus}");

            // Paste the data in
            addLabelsPage.AddLabelData(labelDataString);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains a successful submit
            Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("submitted"));

            //Get the log details
            var logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);

            // Must be a log
            Assert.NotNull(logData);
            var log = logData.First();

            if (log.Status != LogDetailsPageStatus.Completed)
            {
                // If the log is still not completed then try one more time to get a completed job
                logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);
                log = logData.First();
            }

            // Verify total count should be 1
            Assert.AreEqual(1, log.TotalCount);

            // Verify error count, should be 0 
            Assert.AreEqual(0, log.ErrorCount);

            // Verify success count should be 1
            Assert.AreEqual(1, log.SuccessfulCount);

            // Verify log status should be completed
            Assert.AreEqual(LogDetailsPageStatus.Completed.ToUpper(), log.Status.ToUpper());

        }

        [TestCase(UnitLabelTest, LabelStatus.Void, TestName = "AddLabelsPage_SubmitExistingLabelWithCertainStatus_Void_Expect_Success")]
        public void AddLabelsPage_SubmitExistingLabelWithCertainStatus_Void_Expect_Success(string importProfileDesc, string labelStatus)
        {
            // ** Ensure a label is successfully added when an existing label with the same vin has a status of VOID **

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Label Test' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Paste a row where an existing label with a PENDING status already exists
            //Insert(stage) a new label to use as the existing label
            var date = DateTime.Now;
            const string user = "FSAMSTESTUSER";

            var label = new Model.Label()
            {
                LabelStatusTypeId = LabelStatusType.Void,
                LabelTypeId = (int)LabelType.Unit,
                ClientCode = Clients.Hertz.ToUpper(),
                StateProvinceCode = string.Empty,
                ProcessingLocationCode = ProcessingLocations.SunshineBradenton.ToUpper(),
                VIN = string.Empty,
                PrintCount = 0,
                CreatedUser = user,
                CreatedDate = date,
                ModifiedUser = user,
                ModifiedDate = date
            };

            label = DataHelper.InsertLabel(label);
            var labelDataList = DataHelper.GetLabels(new List<string>() { label.VIN }, LabelType.Unit);
            var labelDataString = DataHelper.ConvertListToString(labelDataList);
            //Assert.IsNotEmpty(labelDataString, $"Failed to get label data for the status value: {labelStatus}");

            // Paste the data in
            addLabelsPage.AddLabelData(labelDataString);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains a successful submit
            Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("submitted"));

            //Get the log details
            var logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);

            // Must be a log
            Assert.NotNull(logData);
            var log = logData.First();

            if (log.Status != LogDetailsPageStatus.Completed)
            {
                // If the log is still not completed then try one more time to get a completed job
                logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);
                log = logData.First();
            }

            // Verify total count should be 1
            Assert.AreEqual(1, log.TotalCount);

            // Verify error count, should be 0 
            Assert.AreEqual(0, log.ErrorCount);

            // Verify success count should be 1
            Assert.AreEqual(1, log.SuccessfulCount);

            // Verify log status should be completed
            Assert.AreEqual(LogDetailsPageStatus.Completed.ToUpper(), log.Status.ToUpper());

        }

        [TestCase(UnitLabelTest, LabelStatus.Duplicate, TestName = "AddLabelsPage_SubmitExistingLabelWithCertainStatus_Duplicate_Expect_Success")]
        public void AddLabelsPage_SubmitExistingLabelWithCertainStatus_Duplicate_Expect_Success(string importProfileDesc, string labelStatus)
        {
            // ** Ensure a label is successfully added when an existing label with the same vin has a status of DUPLICATE **

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Label Test' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Paste a row where an existing label with a DUPLICATE status already exists
            var label = DataHelper.InsertLabel(statueType: LabelStatusTypeEnum.Duplicate);
            var labelDataList = DataHelper.GetLabels(new List<string>() { label.VIN }, LabelType.Unit);
            var labelDataString = DataHelper.ConvertListToString(labelDataList);
            Assert.IsNotEmpty(labelDataString, $"Failed to get label data for the status value: {labelStatus}");

            // Paste the data in
            addLabelsPage.AddLabelData(labelDataString);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            //Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains a successful submit
            Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("submitted"));

            //Get the log details
            var logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);

            // Must be a log
            Assert.NotNull(logData);
            var log = logData.First();

            if (log.Status != LogDetailsPageStatus.Completed)
            {
                // If the log is still not completed then try one more time to get a completed job
                logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);
                log = logData.First();
            }

            // Verify total count should be 1
            Assert.AreEqual(1, log.TotalCount);

            // Verify error count, should be 0 
            Assert.AreEqual(0, log.ErrorCount);

            // Verify success count should be 1
            Assert.AreEqual(1, log.SuccessfulCount);

            // Verify log status should be completed
            Assert.AreEqual(LogDetailsPageStatus.Completed.ToUpper(), log.Status.ToUpper());

        }

        [TestCase(UnitLabelsWithBagLabels, LabelStatus.Closed, TestName = "AddLabelsPage_SubmitNewLabel_Expect_UnitAndBagLabelCreated")]
        public void AddLabelsPage_SubmitNewLabel_UnitAndBagLabelCreated_Expect_Success(string importProfileDesc, string labelStatus)
        {
            // ** Ensure that a Unit label and Bag label with the same vin is successfully added **
            // ** The profile 'Unit label and Bag label' is configured to create Bag labels as well **

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Labels with bag labels' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Paste a row where an existing label with a CLOSED status already exists
            //Insert(stage) a new label to use as the existing label
            var date = DateTime.Now;
            const string user = "FSAMSTESTUSER";

            var label = new Model.Label()
            {
                LabelStatusTypeId = LabelStatusType.Closed,
                LabelTypeId = (int)LabelType.Unit,
                ClientCode = Clients.Hertz.ToUpper(),
                StateProvinceCode = string.Empty,
                ProcessingLocationCode = ProcessingLocations.SunshineBradenton.ToUpper(),
                VIN = string.Empty,
                PrintCount = 0,
                CreatedUser = user,
                CreatedDate = date,
                ModifiedUser = user,
                ModifiedDate = date
            };

            label = DataHelper.InsertLabel(label);
            var labelDataList = DataHelper.GetLabels(new List<string>() { label.VIN }, LabelType.Unit);
            var labelDataString = DataHelper.ConvertListToString(labelDataList);
            Assert.IsNotEmpty(labelDataString, $"Failed to get label data for the status value: {labelStatus}");

            // Paste the data in
            addLabelsPage.AddLabelData(labelDataString);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            //Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains a successful submit
            Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("submitted"));

            //Get the log details
            var logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);

            var log = logData.First();
            if (log.Status != LogDetailsPageStatus.Completed)
            {
                // If the log is still not completed then try one more time to get a completed job
                logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);
                log = logData.First();
            }

            // Verify the 2 labels exist, one unit label and one bag label for the same vin
            var vinsResultList = DataHelper.GetLabels(new List<string>() { labelDataString }, LabelType.All);
            vinsResultList = vinsResultList.Where(x => x.LabelStatusTypeId == LabelStatusType.Active).ToList();

            // Ensure we have 2 vins
            Assert.AreEqual(2, vinsResultList.Count);

            // Ensure 1 label is a Bag and the other is Unit
            var unit = vinsResultList.Where(x => x.LabelTypeId == (int)LabelType.Unit);
            var bag = vinsResultList.Where(x => x.LabelTypeId == (int)LabelType.Bag);
            Assert.NotNull(unit);
            Assert.NotNull(bag);

            // Ensure they are the same
            var vin1 = vinsResultList.First().Vin;
            var vin2 = vinsResultList.Last().Vin;
            Assert.AreEqual(vin1, vin2);

            // Must be a log
            Assert.NotNull(logData);
            
            // Verify total count should be 1
            Assert.AreEqual(1, log.TotalCount);

            // Verify error count, should be 0 errors
            Assert.AreEqual(0, log.ErrorCount);

            // Verify success count should be 1
            Assert.AreEqual(1, log.SuccessfulCount);

            // Verify log status should be completed
            Assert.AreEqual(LogDetailsPageStatus.Completed.ToUpper(), log.Status.ToUpper());
        }

        [TestCase(UnitLabelTest, LabelStatus.Closed, TestName = "AddLabelsPage_SubmitMultipleLabels_Expect_AllShouldFail")]
        public void AddLabelsPage_SubmitMultipleLabels_Expect_AllShouldFail(string importProfileDesc, string labelStatus)
        {
            // ** Ensure ALL labels fail when 1 UNIT label exists with an ACTIVE status that fails**

            //Login to Label Management application
            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);

            //Navigate to Add Label page
            addLabelsPage.Navigate();

            //Choose the 'Unit Labels with bag labels' Import profile
            Assert.IsTrue(addLabelsPage.IsImportProfileDropdownDisplayed());
            addLabelsPage.SelectImportProfileByText(importProfileDesc);

            //Insert(stage) a new label with CLOSED status to use as the existing label
            var date = DateTime.Now;
            const string user = "FSAMSTESTUSER";

            var successLabel = new Model.Label()
            {
                LabelStatusTypeId = LabelStatusType.Closed,
                LabelTypeId = (int)LabelType.Unit,
                ClientCode = Clients.Hertz.ToUpper(),
                StateProvinceCode = string.Empty,
                ProcessingLocationCode = ProcessingLocations.SunshineBradenton.ToUpper(),
                VIN = string.Empty,
                PrintCount = 0,
                CreatedUser = user,
                CreatedDate = date,
                ModifiedUser = user,
                ModifiedDate = date
            };

            successLabel = DataHelper.InsertLabel(successLabel);
            var successLabelDataList = DataHelper.GetLabels(new List<string>() { successLabel.VIN }, LabelType.Unit);
            var successLabelDataString = DataHelper.ConvertListToString(successLabelDataList);
            Assert.IsNotEmpty(successLabelDataString, $"Failed to get label data for the status value: {labelStatus}");

            //////////////////////////////////////////////////////////////////////////////////////////////////
            //Insert(stage) a new label with ACTIVE status to use as the existing label
            //This label would fail if added again since this label is in ACTIVE status
            
            var errorLabel = new Model.Label()
            {
                LabelStatusTypeId = LabelStatusType.Active,
                LabelTypeId = (int)LabelType.Unit,
                ClientCode = Clients.Hertz.ToUpper(),
                StateProvinceCode = string.Empty,
                ProcessingLocationCode = ProcessingLocations.SunshineBradenton.ToUpper(),
                VIN = string.Empty,
                PrintCount = 0,
                CreatedUser = user,
                CreatedDate = date,
                ModifiedUser = user,
                ModifiedDate = date
            };

            errorLabel = DataHelper.InsertLabel(errorLabel);
            var errorLabelDataList = DataHelper.GetLabels(new List<string>() { errorLabel.VIN }, LabelType.Unit);
            var errorLabelDataString = DataHelper.ConvertListToString(errorLabelDataList);
            Assert.IsNotEmpty(errorLabelDataString, "Failed to get error label data for the status value: ACTIVE");

            //Paste the label data in
            var labelData = $"{successLabelDataString}{errorLabelDataString}";
            addLabelsPage.AddLabelData(labelData);

            //Click the submit button 
            //Assert.IsTrue(addLabelsPage.IsSubmitLabelsButtonDisplayed());
            addLabelsPage.ClickSubmitLabelsButton();

            //Is the popup window visible
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());

            //Ensure the popup window contains a successful submit
            //Assert.IsTrue(addLabelsPage.IsPopupWindowMessageDisplayed("submitted"));
             
            //Get the log details
            var logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);

            // Must be a log
            Assert.NotNull(logData);
            var log = logData.First();

            if (log.Status != LogDetailsPageStatus.Completed)
            {
                // If the log is still not completed then try one more time to get a completed job
                logData = DataHelper.GetLatestLog(Clients.Hertz, ProcessName.ImportLabels, DateTime.Now.Date);
                log = logData.First();
            }

            if (log.Status.ToUpper() == LogDetailsPageStatus.InProgress.ToUpper())
            {
                Assert.Fail("The job was still in progress but the allotted time for job completion had expired!");
            }
            
            // Verify total count should be 2
            Assert.AreEqual(2, log.TotalCount);

            // Verify error count, should be 2 errors
            Assert.AreEqual(2, log.ErrorCount);

            // Verify success count should be 0
            Assert.AreEqual(0, log.SuccessfulCount);

        }

        [TestCase(TestName = "VerifyImportProfilesOrderIsSorted")]
        [Category("Bug : Few items not coming in list"), Category("238672")]
        public void VerifyImportProfilesOrderIsSorted()
        {
            var importLabelsPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            importLabelsPage.Navigate();

            importLabelsPage.KendoGrid.SelectMaximumItemsPerPage();

            importLabelsPage.CheckShowDisabledConfigs(false);
            importLabelsPage.KendoGrid.ClickSortColumnByColumnNumber(3);

            var availableImportLabels = importLabelsPage.KendoGrid.GetColumnDataAsList(3);

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            var allLabels = addLabelsPage.GetImportProfileDropdownValues();
            allLabels.RemoveAt(0);

            Assert.AreEqual(availableImportLabels, allLabels, "Bug : Few items not coming in list");

        }

        #endregion
    }
}
