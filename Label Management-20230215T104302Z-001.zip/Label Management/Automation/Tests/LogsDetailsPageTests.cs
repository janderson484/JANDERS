using System;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class LogsDetailsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(TestName = "LogDetailsPage_LogPageIdClicked_LogInfoInHeader")]
        public void LogDetailsPage_LogPageIdClicked_LogInfoInHeader()
        {
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            var logDetailsPage = new LogDetailsPageObj(Driver, LabelMgmtBaseUrl);
            var rowNumber = 1;

            logPage.Navigate();

            //TODO: This is grabbing the wrong column (one off)
            var logId = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetIdColumnNumber());
            var processName = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetProcessNameColumnNumber());
            var processType = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetProcessTypeColumnNumber());
            var fileName = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetFileNameColumnNumber());
            var totalCount = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetTotalCountColumnNumber());
            var successCount = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetSuccessCountColumnNumber());
            var errorCount = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetErrorCountColumnNumber());
            var warningCount = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetWarningCountColumnNumber());
            var status = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetStatusColumnNumber());
            var userName = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetUserNameColumnNumber());
            var startTime = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetStartTimeColumnNumber());
            var endTime = logPage.KendoGrid.GetDataCellText(rowNumber, logPage.GetEndTimeColumnNumber());

            logPage.ClickLogIdToNavigateToLogDetails(rowNumber);

            Assert.AreEqual(logId, logDetailsPage.GetHeaderProcessIdValue());
            Assert.AreEqual(processName, logDetailsPage.GetHeaderProcessNameValue());
            Assert.AreEqual(processType, logDetailsPage.GetHeaderProcessTypeValue());
            Assert.AreEqual(fileName, logDetailsPage.GetHeaderFileNameValue());
            Assert.AreEqual(totalCount, logDetailsPage.GetHeaderTotalCountValue());
            Assert.AreEqual(successCount, logDetailsPage.GetHeaderSuccessfulCountValue());
            Assert.AreEqual(errorCount, logDetailsPage.GetHeaderErrorCountValue());
            Assert.AreEqual(warningCount, logDetailsPage.GetHeaderWarningCountValue());
            Assert.AreEqual(status, logDetailsPage.GetHeaderStatusValue());
            Assert.AreEqual(userName, logDetailsPage.GetHeaderUserValue());
            Assert.AreEqual(Convert.ToDateTime(startTime).ToString("g"), logDetailsPage.GetHeaderStartTimeValue());

            if (!string.IsNullOrWhiteSpace(endTime))
            {
                Assert.AreEqual(Convert.ToDateTime(endTime).ToString("g"), logDetailsPage.GetHeaderEndTimeValue());
            }
        }

        [TestCase]
        public void LogDetailsPage_AllColumnsSort()
        {
            //TODO: The log details grid is not sorting on page only, this needs to be fixed, enable this test once fixed

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();
            logPage.SetStartDateTimeYear();
            Thread.Sleep(3000); //Let page reload
            var kendoPageObj = new KendoGridPageObj(Driver);

            // Only click a log record that contains error counts > 1
            var errorCountColumnData = kendoPageObj.GetColumnDataAsList(logPage.GetErrorCountColumnNumber());
            var rowNumber = 0;
            var nextPage = 0;
            do
            {
                if (nextPage != 0)
                {
                    logPage.KendoGrid.ClickNextPageArrow();
                    errorCountColumnData = kendoPageObj.GetColumnDataAsList(logPage.GetErrorCountColumnNumber());
                }
                for (var i = 0; i < errorCountColumnData.Count; i++)
                {
                    var errorCount = Convert.ToInt32(errorCountColumnData[i]);
                    if (errorCount <= 1)
                    {
                        if (i == errorCountColumnData.Count - 1)
                        {
                            nextPage = 1;
                        }
                        continue;
                    }
                    rowNumber = i + 1;
                    break;
                }
            } while (rowNumber == 0);

            logPage.ClickLogIdToNavigateToLogDetails(rowNumber);
            var logDetailsPage = new LogDetailsPageObj(Driver, LabelMgmtBaseUrl);
            logDetailsPage.KendoGrid.PerformSortAllColumnsTest();
        }

        [TestCase(TestName = "LogDetailsPage_IsGridResizeable")]
        public void LogDetailsPage_IsGridResizeable()
        {
            //TODO: Test will fail until grid resizing is applied

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            var kendoPageObj = new KendoGridPageObj(Driver);
            logPage.ClickLogIdToNavigateToLogDetails(1);
            Assert.True(kendoPageObj.IsGridResizeable());
        }
    }
}
