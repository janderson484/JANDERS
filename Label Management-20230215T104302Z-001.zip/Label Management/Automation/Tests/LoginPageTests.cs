using System;
using System.Data;
using System.Data.SqlClient;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    //[TestFixture(typeof(FirefoxDriver))]
    [TestFixture(typeof(ChromeDriver))]
    //[TestFixture(typeof(InternetExplorerDriver))]
    public class LoginPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : RemoteWebDriver, new()
    {
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "LoginPage_LoginSuccessful_Admin")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "LoginPage_LoginSuccessful_Supervisor")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "LoginPage_LoginSuccessful_Internal")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "LoginPage_LoginSuccessful_External")]
        [Category("SmokeTest")]
        public void LoginPage_LoginSuccessful(string user, string pass)
        {
            // Remove data from the UserPreferences table so login pop-up will appear
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.RemoveTestUserPreferences(user);

            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.Navigate();

            loginPage.AttemptLogin(user, pass);

            //dashboardPage.SetInitialCustomerListDropdownsAndSubmit(Clients.Hertz, Inventories.FloridaInventory);
            dashboardPage.SetInitialInventoryClientAndSubmit(1, 1);


            Assert.IsTrue(dashboardPage.TitleTextDisplayed());
        }

        [Test]
        public void LoginPage_EmptyUsername_ErrorDisplayed()
        {
            //TODO: This could be expanded (Reset password, etc.)
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.Navigate();

            loginPage.AttemptLogin(string.Empty, "BADPASSWORD");
            Assert.IsTrue(loginPage.UsernameRequiredErrorDisplayed());
        }

        [Test]
        public void LoginPage_EmptyPassword_ErrorDisplayed()
        {
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.Navigate();

            loginPage.AttemptLogin("BADUSERNAME", string.Empty);
            Assert.IsTrue(loginPage.PasswordRequiredErrorDisplayed());
        }

        //[Test]
        //public void LoginPage_InvalidPassword_ErrorDisplayed()
        //{
        //    var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
        //    loginPage.Navigate();

        //    loginPage.AttemptLogin(UserCredentials.ExternalUsername, "BADPASSWORD");
        //    Assert.IsTrue(loginPage.InvalidLoginErrorDisplayed());
        //}

        [Test]
        public void LoginPage_EmptyUsernameAndPassword_MultipleErrorsDisplayed()
        {
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.Navigate();

            loginPage.AttemptLogin(string.Empty, string.Empty);
            Assert.IsTrue(loginPage.UsernameRequiredErrorDisplayed());
            Assert.IsTrue(loginPage.PasswordRequiredErrorDisplayed());
        }
    }
}
