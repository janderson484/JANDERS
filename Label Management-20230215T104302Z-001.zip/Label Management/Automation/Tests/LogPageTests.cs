using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class LogPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : RemoteWebDriver, new()
    {
        #region KendoTests

        [TestCase(TestName = "LogPage_AllColumnsSort")]
        //Sorting is not yet enabled for the grid, but can be expected in the future
        public void LogPage_AllColumnsSort()
        {
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            //TODO: May need to update to support horizontal scroll bar
            logPage.KendoGrid.PerformSortAllColumnsTest();
        }

        [TestCase(TestName = "LogPage_ItemsPerPageSelector")]
        public void LogPage_ItemsPerPageSelector()
        {
            //TODO: This page needs to implement this functionality (Remove when this test passes)
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            logPage.KendoGrid.PerformItemsPerPageTest();
        }

        [TestCase(TestName = "LogPage_PageNumberSelector")]
        public void LogPage_PageNumberSelector()
        {
            //TODO: This page needs to implement this functionality (Remove when this test passes)
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            logPage.KendoGrid.PerformPageSelectionTest(30);
        }

        [TestCase(TestName = "LogPage_IsGridResizeable")]
        public void LogPage_IsGridResizeable()
        {
            //TODO: Test will fail until grid resizing is applied
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();
            Assert.True(logPage.KendoGrid.IsGridResizeable());
        }

        [TestCase(TestName = "VerifyAllProcessNames")]
        public void VerifyAllProcessNames()
        {
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();
            var processNames = logPage.GetFilterByProcessValues();
            processNames.Sort();
            LogsPage.FilterProcessNames.Sort();
            Assert.AreEqual(LogsPage.FilterProcessNames, processNames);
        }


        #endregion KendoTests
    }
}
