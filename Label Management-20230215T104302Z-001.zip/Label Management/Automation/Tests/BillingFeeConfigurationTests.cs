using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class BillingFeeConfigurationTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(TestName = "VerifyBillingFeeConfiguarationPageNavigation")]
        [Category("233616")]
        public void VerifyBillingFeeConfiguarationPageNavigation()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            Assert.AreEqual(PageTitles.BillingSetup, billingFeeConfigPage.PageTitle);
        }

        [TestCase(TestName = "VerifyFieldsInBillingFeeConfigurationPage")]
        [Category("233617")]
        public void VerifyActiveUnitLabelsAreInvoiced()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            Assert.IsTrue(billingFeeConfigPage.IsAddBillingFeeButtonDisplayed(), "Add billing fee button");
            Assert.IsTrue(billingFeeConfigPage.IsEditBillingFeeButtonDisplayed(), "Edit bililng fee button");
            Assert.IsTrue(billingFeeConfigPage.IsShowDisabledConfigurationsDisplayed(), "Show Disabled Configurations");
        }

        [TestCase(TestName = "VerifyAddNewBillingFeeConfigFields")]
        [Category("233618")]
        public void VerifyAddNewBillingFeeConfigFields()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            billingFeeConfigPage.ClickAddBillingFeeConfigurationButton();
            Assert.IsTrue(billingFeeConfigPage.IsModalCancelButtonDisplayed());
            Assert.IsTrue(billingFeeConfigPage.IsModalSaveButtonDisplayed());
        }

        [TestCase(TestName = "VerifyErrorMessageWithoutSelectRecordToEdit")]
        [Category("233619")]
        public void VerifyErrorMessageWithoutSelectRecordToEdit()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            billingFeeConfigPage.ClickEditSelectedRowButton(false);

            Assert.IsTrue(billingFeeConfigPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(billingFeeConfigPage.Error_SelectRecordToEdit, billingFeeConfigPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyCancelButtonInAddNewBillingFee")]
        [Category("233620")]
        public void VerifyCancelButtonInAddNewBillingFee()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            billingFeeConfigPage.ClickAddBillingFeeConfigurationButton();

            Assert.IsTrue(billingFeeConfigPage.IsModalSaveButtonDisplayed());
            billingFeeConfigPage.CloseModal();

            Assert.IsFalse(billingFeeConfigPage.IsModalSaveButtonDisplayed());
        }


        [TestCase(TestName = "VerifyGridHeadersInBillingFeeConfigurationPage")]
        [Category("233621")]
        public void VerifyGridHeadersInBillingFeeConfigurationPage()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            Assert.AreEqual(BillingFeeConfigurationColumnHeadings.Headers.ToList(), billingFeeConfigPage.KendoGrid.GetAllHeadersTextList(1));
        }

        [TestCase(TestName = "VerifyShowDisabledConfigurationFunctionality")]
        [Category("233622")]
        public void VerifyShowDisabledConfigurationFunctionality()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            billingFeeConfigPage.CheckShowDisabledConfigs(false);

            List<string> allItems = billingFeeConfigPage.GetAllBillingFeesForSortOrderVerification();
            var sortedOrder = new List<string> (allItems);

            Assert.AreEqual(sortedOrder, allItems);
            Assert.IsTrue(allItems.Count(i => i.StartsWith("D")) == 0);
            billingFeeConfigPage.CheckShowDisabledConfigs(true);

            allItems = billingFeeConfigPage.GetAllBillingFeesForSortOrderVerification();
            sortedOrder = new List<string> ( allItems );
            Assert.AreEqual(sortedOrder, allItems);

            billingFeeConfigPage.CheckShowDisabledConfigs(false);

            allItems = billingFeeConfigPage.GetAllBillingFeesForSortOrderVerification();
            sortedOrder = new List<string> (allItems);

            Assert.AreEqual(sortedOrder, allItems);
            Assert.IsTrue(allItems.Count(i => i.StartsWith("D")) == 0);
        }


        [TestCase(TestName = "VerifyMessageOnTurningONOffBillingFeeCondition")]
        [Category("233630")]
        public void VerifyMessageOnTurningONOffBillingFeeCondition()
        {
            var billingFeeConfigPage = new BillingFeeconfigurationPageObj(Driver, LabelMgmtBaseUrl);
            billingFeeConfigPage.Navigate();

            billingFeeConfigPage.CheckShowDisabledConfigs(true);

            var rowNumber = 1;
            var billingfeeName = billingFeeConfigPage.GetBillingFeeConfigName(rowNumber);
            billingFeeConfigPage.TurnOnOffConfigurationbyRowNumber(rowNumber, false, false);

            Assert.IsTrue(billingFeeConfigPage.IsNotificationMessageDisplayed(NotificationType.Success), "1st Success notification message");
            Assert.AreEqual(billingFeeConfigPage.Success_ConfigStatusChanged, billingFeeConfigPage.GetNotificationMessageText(NotificationType.Success));

            billingFeeConfigPage.WaitForPageLoad();
            rowNumber = billingFeeConfigPage.GetRowNumberForBillingFeeConfig(billingfeeName);
            billingFeeConfigPage.TurnOnOffConfigurationbyRowNumber(rowNumber, true, false);

            Assert.IsTrue(billingFeeConfigPage.IsNotificationMessageDisplayed(NotificationType.Success), "2nd Success notification message");
            Assert.AreEqual(billingFeeConfigPage.Success_ConfigStatusChanged, billingFeeConfigPage.GetNotificationMessageText(NotificationType.Success));

        }

    }
}
