using System;
using System.Data;
using System.Data.SqlClient;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{

    [TestFixture(typeof(ChromeDriver))]
    public class PersistFilterTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        #region Filter Persistence Tests

        

        #endregion

        #region Helper Methods

        

        /// <summary>
        /// Reset User Preferences for new TestUser
        /// </summary>
        /// <param name="userId"></param>
        public void RemoveTestUserPreferences(string userId)
        {
            if (userId == null)
                throw new ArgumentOutOfRangeException(nameof(userId));

            const string sqlQuery =
                @" Delete From [dbo].[UserPreferences] Where UserId = @UserId";

            using (var conn = new SqlConnection(SQL.PMSqlDevConnection))
            {
                var cmd = new SqlCommand(sqlQuery, conn);
                cmd.Parameters.Add("@UserId", SqlDbType.NVarChar);
                cmd.Parameters["@UserId"].Value = userId;

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        }
        #endregion
    }
}
