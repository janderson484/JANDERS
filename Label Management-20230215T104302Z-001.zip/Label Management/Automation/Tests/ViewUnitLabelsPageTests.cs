using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ViewUnitLabelsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(TestName = "1_ViewUnitLabels_PageRender")]
        public void ViewUnitLabels_PageRender()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded(), "1_ViewUnitLabels_PageRende Test Failed");
        }

        [TestCase(TestName = "2_ViewUnitLabels_SortGrid")]
        public void ViewUnitLabels_SortGrid()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            /*var pageLoaded = viewUnitLabelPage.IsPageLoaded();
            if (pageLoaded)
            {
                // Get Column Count
                var headerCount = viewUnitLabelPage.KendoGrid.GetAllHeaderList().Count;

                // Sort each column in both directions
                for (var headerNumber = 1; headerNumber <= headerCount; headerNumber++)
                {
                    // Ascending
                    viewUnitLabelPage.KendoGrid.ClickSortColumnByColumnNumber(headerNumber, 1, 10);
                    // Descending
                    viewUnitLabelPage.KendoGrid.ClickSortColumnByColumnNumber(headerNumber, 1, 10);
                }
            }
            else
            {
                Assert.Fail("2_ViewUnitLabels_SortGrid Test Failed");
            }*/
            viewUnitLabelPage.KendoGrid.PerformSortAllColumnsTest();
        }

        [TestCase(TestName = "3_ViewUnitLabels_VerifyGridPagination")]
        public void ViewUnitLabels_GridPagination()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
            Assert.IsTrue(viewUnitLabelPage.IsGridPaginationExist());
            Assert.IsTrue(viewUnitLabelPage.IsGridRowSizeDropdownExist());
        }

        [TestCase(TestName = "4_ViewUnitLabelsPage_ViewUnitLabelsColumnOrder")]
        public void ViewUnitLabelsColumnOrderTest()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var expectedColumnHeaders = viewUnitLabelPage.GetColumnHedders(0);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
            Assert.AreEqual(expectedColumnHeaders.Count, viewUnitLabelPage.GetNumberOfColumnHeaders());
            Assert.IsTrue(viewUnitLabelPage.VerifyColumnNames(expectedColumnHeaders));
        }

        [TestCase(TestName = "5_ViewUnitLabelsPage_ViewUnitLabelsSpanishColumnOrder")]
        public void ViewUnitLabelsSpanishColumnOrderTest()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var expectedColumnHeaders = viewUnitLabelPage.GetColumnHedders(1);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickViewPageLabelSpanish();
            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());

            Assert.IsTrue(viewUnitLabelPage.VerifyColumnNames(expectedColumnHeaders));
            Assert.AreEqual(expectedColumnHeaders.Count, viewUnitLabelPage.GetNumberOfColumnHeaders());
        }

        [TestCase(TestName = "6_ViewUnitLabels_VerifyUserLoginAdmin")]
        public void ViewUnitLabels_UserLoginAdmin()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(UserCredentials.AdminUsername, UserCredentials.AdminPassword);

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
        }


        [TestCase(TestName = "7_ViewUnitLabels_VerifyUserLoginSupervisor")]
        public void ViewUnitLabels_UserLoginSupervisor()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword);

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
        }

        [TestCase(TestName = "8_ViewUnitLabels_VerifyUserLoginInternal")]
        public void ViewUnitLabels_UserLoginInternal()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(UserCredentials.InternalUsername, UserCredentials.InternalPassword);

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
        }

        [TestCase(TestName = "9_ViewUnitLabels_VerifyUserLoginExternal")]
        public void ViewUnitLabels_UserLoginExternal()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword);

            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
        }

        [TestCase(TestName = "10_ViewUnitLabels_VerifyGridData")]
        public void ViewBagLabels_VerifyGridData()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(UserCredentials.AdminUsername, UserCredentials.AdminPassword);

            viewUnitLabelPage.SelectAllFilterCheckBoxes();
            viewUnitLabelPage.Navigate();
            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());
            Assert.IsTrue(viewUnitLabelPage.VerifyGridData());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatSavechangesCancelchangesAndBulkUpdateButtonIsPresent")]

        public void ViewUnitLabels_VerifyThatSavechangesCancelchangesAndBulkUpdateButtonIsPresent()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsSaveChangesButtonExists());
            Assert.IsTrue(viewUnitLabelPage.IsCancelChnagesButtonExists());
            Assert.IsTrue(viewUnitLabelPage.IsBulkUpdateButtonExists());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatBulkUpdateWindowIsOpenedWhenBulkUpdateButtonIsClicked")]
        public void ViewUnitLabels_VerifyThatBulkUpdateWindowIsOpenedWhenBulkUpdateButtonIsClicked()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);

            Assert.IsTrue(viewUnitLabelPage.IsBulkUpdateWindowDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsClickedWithoutSelectingRecords")]

        public void ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsClickedWithoutSelectingRecords()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickBulkUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateError_SelectLabels, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenUpdateButtonIsClickedWithoutSelectingFields")]
        public void ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenUpdateButtonIsClickedWithoutSelectingFields()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.AddNotesForBulkUpdate, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatSuccessMessageIsDisplayedWhenBulkUpdateIsCompleted")]
        public void ViewUnitLabels_VerifyThatSuccessMessageIsDisplayedWhenBulkUpdateIsCompleted()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();


            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatExitButtonShouldCloseTheBulkUpdateWindow")]
        public void ViewUnitLabels_VerifyThatExitButtonShouldCloseTheBulkUpdateWindow()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickExitButton();

            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());

        }

        [TestCase(TestName = "ViewUnitLabels_VerifySaveChangesButton")]
        public void ViewUnitLabels_VerifySaveChangesButton()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPendingCheckbox();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
            viewUnitLabelPage.ClickSaveChangesbutton();

            Assert.IsTrue(viewUnitLabelPage.IsSaveChangesSuccessWindowDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyCancelChangesButton")]
        public void ViewUnitLabels_VerifyCancelChangesButton()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.EnterNotesInGrid();
            viewUnitLabelPage.ClickCancelChanges();

            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyTheDownloadButtonIsWorkingAsExpected")]
        public void ViewUnitLabels_VerifyTheDownloadButtonIsWorkingAsExpected()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewUnitLabelPage.ClickViewLog();
            viewUnitLabelPage.ClickDownloadButton();
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatSelectedRecordCountAndTotalCountInBulkUpdateWindowShouldBeSame")]
        public void ViewUnitLabels_VerifyThatSelectedRecordCountAndTotalCountInBulkUpdateWindowShouldBeSame()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();

            Assert.AreEqual(1, viewUnitLabelPage.TotalLabelsCount());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsDoneForTheStatusVoid")]
        public void ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsDoneForTheStatusVoid()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickVoidCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(1, viewUnitLabelPage.FailedLabelsCount());
            viewUnitLabelPage.ClickViewLog();
            Assert.IsTrue(viewUnitLabelPage.VoidTransactionErrorMessageDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatProcessIsSuccessWhenALabelTypeIsUpdatedToActiveDoesNotCreateDuplicate")]
        public void ViewUnitLabels_VerifyThatProcessIsSuccessWhenALabelTypeIsUpdatedToActiveDoesNotCreateDuplicate()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Pending;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPendingCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatLabelStatusCanBeUpdatedToClosedFromActiveStatus")]
        public void ViewUnitLabels_VerifyThatLabelStatusCanBeUpdatedToClosedFromActiveStatus()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Closed);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatClosedStatusCanBeUpdatedToPending")]
        public void ViewUnitLabels_VerifyThatClosedStatusCanBeUpdatedToPending()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Closed;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatTheUserCanUpdateNotesWithoutChangingStatus")]
        public void ViewUnitLabels_VerifyThatTheUserCanUpdateNotesWithoutChangingStatus()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatIfCurrentStatusIsActiveAndDesiredStatusIsSameAddNotes")]
        public void ViewUnitLabels_VerifyThatIfCurrentStatusIsActiveAndDesiredStatusIsSameAddNotes()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatIfCurrentStatusIsPendingAndDesiredStatusIsSameAddNotes")]
        public void ViewUnitLabels_VerifyThatIfCurrentStatusIsPendingAndDesiredStatusIsSameAddNotes()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Pending;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPendingCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatIfCurrentStatusIsClosedAndDesiredStatusIsSameAddNotes")]
        public void ViewUnitLabels_VerifyThatIfCurrentStatusIsClosedAndDesiredStatusIsSameAddNotes()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Closed;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Closed);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(LabelStatus.Pending, TestName = "ViewUnitLabels_VerifyThatOnlyNotesAndStatusFieldAreEditable")]
        public void ViewUnitLabels_VerifyThatOnlyNotesAndStatusFieldAreEditable(string status)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
            viewUnitLabelPage.EnterNotesInGrid();
        }

        [TestCase(1, new int[] { 1, 2, 3, 4, 5 }, TestName = "ViewUnitLabels_ViewUnitLabelsVerifyBulkUpdateForMultipleRecords")]
        public void ViewUnitLabels_ViewUnitLabelsVerifyBulkUpdateForMultipleRecords(int pageNumber, int[] rowNumbers)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            while (viewUnitLabelPage.KendoGrid.GetCurrentPageNumberSelection() < pageNumber)
            {
                viewUnitLabelPage.KendoGrid.ClickNextPageArrow();
            }
            foreach (var rowNumber in rowNumbers)
            {
                viewUnitLabelPage.ClickDataCheckmarkByRowNumber(rowNumber);
            }
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
            Assert.AreEqual(rowNumbers.Length, viewUnitLabelPage.TotalLabelsCount());
        }

        [TestCase(1, new int[] { 1, 2, 3, 4, 5 }, TestName = "ViewUnitLabels_VerifyThatSaveChangesIsSuccessfulForMultipleRecords")]
        public void ViewUnitLabels_VerifyThatSaveChangesIsSuccessfulForMultipleRecords(int pageNumber, int[] rowNumbers)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPendingCheckbox(true); 
            viewUnitLabelPage.ClickSearchButton();

            List<string> updatedVins = new List<string>();

            while (viewUnitLabelPage.KendoGrid.GetCurrentPageNumberSelection() < pageNumber)
            {
                viewUnitLabelPage.KendoGrid.ClickNextPageArrow();
            }
            foreach (var rowNumber in rowNumbers)
            {
                viewUnitLabelPage.ClickDataCheckmarkByRowNumber(rowNumber);
                viewUnitLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
                updatedVins.Add(viewUnitLabelPage.KendoGrid.GetDataCellText(rowNumber, UnitLabelPageColumnNumbers.Vin));
            }
            viewUnitLabelPage.ClickSaveChangesbutton();
            Assert.IsTrue(viewUnitLabelPage.IsSaveChangesSuccessWindowDisplayed());

            viewUnitLabelPage.EnterSearchText(updatedVins);
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();

            foreach (var rowNumber in rowNumbers)
            {
                Assert.AreEqual("Active", viewUnitLabelPage.KendoGrid.GetDataCellText(rowNumber, UnitLabelPageColumnNumbers.Status));
            }
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatOnlyAdminCanVoidTheTransaction")]
        public void ViewUnitLabels_VerifyThatOnlyAdminCanVoidTheTransaction()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Pending;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPendingCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Void);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatStatusCanBeUpdatedToClosedWhichIsInActivePendingDuplicate")]
        public void ViewUnitLabels_VerifyThatStatusCanBeUpdatedToClosedWhichIsInActivePendingDuplicate()
        {

            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Duplicate;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickDuplicateCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.ClickLabelsStausDropdown();
            viewUnitLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Closed);
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(UnitLabelPageMessages.BulkUpdateCompleted, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenUpdatingALabelTypeToActiveWillCreateTwoActiveVINOfSameLabelType")]
        public void ViewUnitLabels_VerifyThatErrorMessageIsDisplayedWhenUpdatingALabelTypeToActiveWillCreateTwoActiveVINOfSameLabelType()
        {
            var lbl = DataHelper.InsertLabel();

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.SelectStatusFromDropdown(LabelStatus.Active);
            viewUnitLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewUnitLabelPage.ClickViewLog();
            Assert.IsTrue(viewUnitLabelPage.DuplicateVINErrorMessageDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyTheGridDataOfViewUnitLabelsPageIsSelectable")]
        public void ViewUnitLabels_VerifyTheGridDataOfViewUnitLabelsPageIsSelectable()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickCheckBox();
            Assert.IsTrue(viewUnitLabelPage.IsCheckboxSelected());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewUnitLabelsPageWithoutSelectingAnyRows")]
        public void ViewUnitLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewUnitLabelsPageWithoutSelectingAnyRows()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.PleaseSelectAtleastOneLabelToPrint, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewUnitLabelsPageWithoutSelectingAnyActiveLabels")]
        public void ViewUnitLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewUnitLabelsPageWithoutSelectingAnyActiveLabels()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickDuplicateCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.PleaseSelectOnlyActiveLabels, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThePrintedSelectedFunctionalityOfViewUnitLabelsPage")]
        public void ViewUnitLabels_VerifyThePrintedSelectedFunctionalityOfViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewUnitLabelPage.IsPrintPreviewPageDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThePrintPreviewsPagePrinterDropDownIsDisplaying")]

        public void ViewUnitLabels_VerifyThePrintPreviewsPagePrinterDropDownIsDisplaying()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewUnitLabelPage.IsPrinterNameDisplayed());
        }

        //[TestCase(TestName = "ViewUnitLabels_VerifyTheEditAlignmentFunctionalityOfPrintPreviewPage")]
        public void ViewUnitLabels_VerifyTheEditAlignmentFunctionalityOfPrintPreviewPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            viewUnitLabelPage.ClickEditAlignment();
            viewUnitLabelPage.ClickTopMargin();
            viewUnitLabelPage.ClickBottomMargin();
            viewUnitLabelPage.ClickLeftMargin();
            viewUnitLabelPage.ClickRightMargin();
            viewUnitLabelPage.ClickPrintPreviewSaveButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyTheGridDataOfPrintPreviewPage")]
        public void ViewUnitLabels_VerifyTheGridDataOfPrintPreviewPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            var unitLabelPageIdValue = viewUnitLabelPage.UnitLabelPageIdValue();
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);

            Assert.AreEqual(unitLabelPageIdValue, printPreviewPage.PrintPreviewPageIdValue());
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThePrintFirstPageFunctionalityOfPrintPreviewPage")]
        public void ViewUnitLabels_VerifyThePrintFirstPageFunctionalityOfPrintPreviewPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();
            Assert.IsTrue(printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyThePrintAllFunctionalityOfPrintPreviewPage")]
        public void ViewUnitLabels_VerifyThePrintAllFunctionalityOfPrintPreviewPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintAllButton();

            Assert.IsTrue(viewUnitLabelPage.IsConfirmPrintPopup());
            viewUnitLabelPage.ClickContinueButton();
            Assert.IsTrue(printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        public void ViewUnitLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers(string user, string password)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, password);
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewUnitLabelPage.IsPrintPreviewPageDisplayed());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRowsInternalUser")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "ViewUnitLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRowsExternalUser")]
        public void ViewUnitLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows(string user, string password)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
        }

        [TestCase(TestName = "ViewUnitLabels_VerifyFilterPersistenceOnViewUnitLabelsPage")]
        public void ViewUnitLabels_VerifyFilterPersistenceOnViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            Assert.AreEqual("Active", viewUnitLabelPage.GetStatusText());
            viewUnitLabelPage.ClickOnReportsInLeftMenu();
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsActiveCheckboxSelected());
            Assert.AreEqual("Active", viewUnitLabelPage.GetStatusText());
        }

        [TestCase(TestName = "ViewUnitLabels_ViewUnitLabelsValidateSearchFunctionalityForVIN")]
        public void ViewUnitLabels_ViewUnitLabelsValidateSearchFunctionalityForVIN()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            var vinsToTest = viewUnitLabelPage.KendoGrid.GetColumnDataAsList(3, 1);
            if (vinsToTest.Count > 5)
            {
                var totalToRemove = vinsToTest.Count-5;
                vinsToTest.RemoveRange(5, totalToRemove);
            }
            viewUnitLabelPage.ClickVinTab();
            viewUnitLabelPage.EnterSearchText(vinsToTest);
            viewUnitLabelPage.ClickSearchButton();
            var result=viewUnitLabelPage.VerifyOrders(BagLabelsColumnHeadings.Vin, vinsToTest);

            Assert.True(result);
        }

        [TestCase(TestName = "ViewUnitLabels_ViewUnitLabelsValidateSearchFunctionalityForBatchNumber")]
        public void ViewUnitLabels_ViewUnitLabelsValidateSearchFunctionalityForBatch()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            var batchNoToTest = viewUnitLabelPage.KendoGrid.GetColumnDataAsList(8, 1);
            viewUnitLabelPage.ClickBatchTab();
            viewUnitLabelPage.EnterSearchText(batchNoToTest);
            viewUnitLabelPage.ClickSearchButton();
            var result = viewUnitLabelPage.VerifyOrders(BagLabelsColumnHeadings.BatchNumber, batchNoToTest);

            Assert.True(result);
        }

        [TestCase(TestName = "ViewUnitLabels_ViewUnitLabelsVerifySearchTermsAreClearedOnClearButtonClick")]
        public void ViewUnitLabels_ViewUnitLabelsVerifySearchTermsAreClearedOnClearButtonClick()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            var vinsToTest = viewUnitLabelPage.KendoGrid.GetColumnDataAsList(3, 1);
            viewUnitLabelPage.ClickVinTab();
            viewUnitLabelPage.EnterSearchText(vinsToTest);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickClearButton();

            Assert.IsTrue(string.IsNullOrEmpty(viewUnitLabelPage.GetSearchFieldText()));
            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "ViewUnitLabels_ViewUnitLabelsEnsureTabSpacAndEnterKeyPressesWillCreateSearchElementInputTagHelpers")]
        public void ViewUnitLabels_ViewUnitLabelsEnsureTabSpacAndEnterKeyPressesWillCreateSearchElementInputTagHelpers()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.EnterTabKey();
            Assert.IsTrue(viewUnitLabelPage.IsInputTagDisplayed());
            viewUnitLabelPage.ClickClearButton();

            viewUnitLabelPage.EnterSpaceKey();
            Assert.IsTrue(viewUnitLabelPage.IsInputTagDisplayed());
        }
        
        [TestCase(TestName = "ViewUnitLabels_ViewUnitLabelsValidateThatControlLabelsLanguageSwitchesOnLanguageSelectorSwitch")]
        [Category("Bug")]
        public void ViewUnitLabels_ViewUnitLabelsValidateThatControlLabelsLanguageSwitchesOnLanguageSelectorSwitch()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickViewPageLabelSpanish();
            Assert.IsTrue(viewUnitLabelPage.IsPageLoaded());

            Assert.AreEqual(" Claro", viewUnitLabelPage.GetClearButtonText());
            Assert.AreEqual(" Buscar", viewUnitLabelPage.GetSearchButtonText());
        }

        #region Export
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "11_ViewUnitLabels_VerifyTheExportDropdownHavingExportAllAndExportSelectedForViewOrders")]
        public void VerifyTheExportDropdownHavingExportAllAndExportSelectedForViewOrders(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);

            viewUnitLabelPage.IsPageLoaded();

            Assert.IsTrue(viewUnitLabelPage.VerifyExportButtonDropdownValues());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "12_ViewUnitLabels_VerifyExportAllButton")]
        public void VerifyExportAllButton(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);

            viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.ClickExportAllButtonFlow();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "13_ViewUnitLabels_VerifyExportSelectedButton")]
        public void VerifyExportSelectedButton(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);

            //SP: making sure the Export file does not exist at the start of test
            viewUnitLabelPage.DeleteExportedFile();

            viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.VerifyExportSelected();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("All visible rows will be exported to Excel:", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
            Assert.IsTrue(viewUnitLabelPage.ExportedFileExists());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "14_ViewUnitLabels_VerifyExportSelectedButtonWithoutSelectingRecords")]
        public void VerifyExportSelectedButtonWithoutSelectingRecords(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);

            //SP: making sure the Export file does not exist at the start of test
            viewUnitLabelPage.DeleteExportedFile();

            viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickExportSelectedFlow();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("All visible rows will be exported to Excel:", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
            Assert.IsTrue(viewUnitLabelPage.ExportedFileExists());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "15_ViewUnitLabels_VerifyExportAllButtonBySelectingRecords")]
        public void VerifyExportAllButtonBySelectingRecords(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);

            viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.VerifyExportAllBySelectingRecords();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Request to export report submitted", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "ViewUnitLabels_VerifyTheErrorMessageWhenClickOnExportAll")]

        public void ViewUnitLabels_VerifyTheErrorMessageWhenClickOnExportAll(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);
            //viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickExportAllButtonFlow();
            Assert.AreEqual("No data available to export", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "17_ViewUnitLabels_VerifyTheErrorMessageWhenClickOnExportSelected")]
        public void ViewUnitLabels_VerifyTheErrorMessageWhenClickOnExportSelected(string user, string pass)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, pass);
            viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.VerifyExportSelected();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyErrorWhenExportingMoreThan20000Rows")]
        public void VerifyErrorWhenExportingMoreThan20000Rows()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.IsPageLoaded();
            viewUnitLabelPage.SelectAllFilterCheckBoxes();
            viewUnitLabelPage.SetStartDate(new DateTime(2020, 1, 1));

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.WaitForKendoReadyState();

            var totalRows = viewUnitLabelPage.KendoGrid.GetTotalSearchResultCount();
            if (totalRows > 20000)
            {
                viewUnitLabelPage.ClickExportAllButtonFlow();
                Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
                Assert.AreEqual(ViewUnitLabelsPageObj.Error_SelectFewerRecordsToExport, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
            }
            else
                Assert.Inconclusive("Fewer than 20,000 records found to export. Data issue.");
        }

        #endregion
        [TestCase(TestName = "EnsureAPrintedUnitLabelIsInvoicedSuccessfully")]
        public void EnsureAPrintedUnitLabelIsInvoicedSuccessfully()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success);
            viewUnitLabelPage.WaitForKendoReadyState();
            Assert.AreEqual("Yes", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyTheChargesAreAddedOnlyWhenTheUnitLabelIsInvoiced")]
        public void VerifyTheChargesAreAddedOnlyWhenTheUnitLabelIsInvoiced()
        {
            var lbl = DataHelper.InsertLabel(printLabel: true);
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewUnitLabelPage.WaitForKendoReadyState();
            Assert.AreEqual(lbl.VIN, viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.Vin), "VIN Mismatched");
            Assert.AreEqual("Yes", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.Invoiced), "INvoice status Mismatched");
        }

        [TestCase(TestName = "VerifyTheChargesAreInvoicedOnlyWhenItIsPrintedFirstTimeForUnitLabels")]
        public void VerifyTheChargesAreInvoicedOnlyWhenItIsPrintedFirstTimeForUnitLabels()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();

            printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success);
            
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceButton();

            viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);
            
            viewUnitLabelPage.SelectAllFilterCheckBoxes(false);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewUnitLabelPage.ClickPrintSelected();
            printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();

            viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);
            
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyUserCanPrintremainsingIfMoreThan1LabelExists")]
        [Category("240309")]
        public void VerifyUserCanPrintremainsingIfMoreThan1LabelExists()
        {
            var lbl1 = DataHelper.GetRandomLabel(unitLabel : true, statueType:LabelStatusTypeEnum.Active);
            lbl1 = DataHelper.InsertLabel(lbl1);

            var lbl2 = DataHelper.GetRandomLabel(unitLabel: true, statueType: LabelStatusTypeEnum.Active);
            lbl2 = DataHelper.InsertLabel(lbl2);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl1.VIN);
            viewUnitLabelPage.EnterSearchTextField(lbl2.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(2);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintRemainingUnitLabels();

            printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success);
            Assert.AreEqual(PrintPrivewPageMessages.PrintRequestSent, printPreviewPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyUserCanNotPrintremainsingIfLessThan2LabelExists")]
        [Category("240309")]
        public void VerifyUserCanNotPrintremainsingIfLessThan2LabelExists()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintRemainingUnitLabels();

            printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Error);
            Assert.AreEqual(PrintPrivewPageMessages.NoRecordsToPrint, printPreviewPage.GetNotificationMessageText(NotificationType.Error));
        }


        [TestCase(TestName = "VerifyThatIfAUnitLabelRowIsSelectedAndThePrintCountZeroThenItIsNotInvoicedAndLabelCannotBeClosed")]
        public void VerifyThatIfAUnitLabelRowIsSelectedAndThePrintCountZeroThenItIsNotInvoicedAndLabelCannotBeClosed()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewUnitLabelPage.ClickInvoiceButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.SelectActiveOrClosedPrintedNonInvoiced,
                viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyThatPrintedCheckboxIsDisplayedInViewUnitLabelsPage.")]
        [Category("232291")]
        public void VerifyThatPrintedCheckboxIsDisplayedInViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            
            Assert.IsTrue(viewUnitLabelPage.IsPrintedCheckBoxExist(), "Printed Check Box is not Dispalyed");

        }

        [TestCase("Active", TestName = "VerifyWhenPrintedCheckBoxIsSelectedUnitLabelsWithPrintCountGreaterthanOneAreShown_Active")] 
        [TestCase("Pending", TestName = "VerifyWhenPrintedCheckBoxIsSelectedUnitLabelsWithPrintCountGreaterthanOneAreShown_Pending")]
        [TestCase("Duplicate", TestName = "VerifyWhenPrintedCheckBoxIsSelectedUnitLabelsWithPrintCountGreaterthanOneAreShown_Duplicate")] 
        [TestCase("Closed", TestName = "VerifyWhenPrintedCheckBoxIsSelectedUnitLabelsWithPrintCountGreaterthanOneAreShown_Closed")]
        [TestCase("Void", TestName = "VerifyWhenPrintedCheckBoxIsSelectedUnitLabelsWithPrintCountGreaterthanOneAreShown_Void")] 
        [Category("233025"), Category("233120"), Category("233123"), Category("233125"), Category("233127")]
        public void VerifyWhenPrintedCheckBoxIsSelectedUnitLabelsWithPrintCountGreaterthanOneAreShown(string labelStatusType)
        {
            var label1 = DataHelper.GetRandomLabel();
            var label2 = DataHelper.GetRandomLabel();
            var label3 = DataHelper.GetRandomLabel();
            var label4 = DataHelper.GetRandomLabel();

            int lblStatusType = 0;
            switch (labelStatusType)
            {
                case "Active": lblStatusType = LabelStatusType.Active;
                    break;
                case "Duplicate":
                    lblStatusType = LabelStatusType.Duplicate;
                    break;
                case "Pending":
                    lblStatusType = LabelStatusType.Pending;
                    break;
                case "Void":
                    lblStatusType = LabelStatusType.Void;
                    break;
                case "Closed":
                    lblStatusType = LabelStatusType.Closed;
                    break;
                default: lblStatusType = LabelStatusType.Active;
                    break;
            }

            label1.LabelStatusTypeId = label2.LabelStatusTypeId = label3.LabelStatusTypeId = label4.LabelStatusTypeId = lblStatusType;

            label1.PrintCount = 1;
            label2.PrintCount = 5;
            label3.PrintCount = 15;
            label4.PrintCount = 0;

            label1.IsPrinted = true;
            label2.IsPrinted = true;
            label3.IsPrinted = true;
            label4.IsPrinted = false;

            label1 = DataHelper.InsertLabel(label1);
            label2 = DataHelper.InsertLabel(label2);
            label3 = DataHelper.InsertLabel(label3);
            label4 = DataHelper.InsertLabel(label4);

            var allLabels = label1.VIN + " " + label2.VIN + " " + label3.VIN + " " + label4.VIN;

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPrintedCheckbox();

            switch (labelStatusType)
            {
                case "Active": viewUnitLabelPage.ClickActiveCheckbox();
                    break;
                case "Duplicate":
                    viewUnitLabelPage.ClickDuplicateCheckbox();
                    break;
                case "Pending":
                    viewUnitLabelPage.ClickPendingCheckbox();
                    break;
                case "Void":
                    viewUnitLabelPage.ClickVoidCheckbox();
                    break;
                case "Closed":
                    viewUnitLabelPage.ClickClosedCheckbox();
                    break;
                default:
                    viewUnitLabelPage.ClickActiveCheckbox();
                    break;
            }

            viewUnitLabelPage.EnterSearchTextField(allLabels);
            viewUnitLabelPage.ClickSearchButton();

            var itemsFromKendoGrid = viewUnitLabelPage.KendoGrid.GetColumnDataAsList(3);

            Assert.IsTrue(itemsFromKendoGrid.Contains(label1.VIN));
            Assert.IsTrue(itemsFromKendoGrid.Contains(label2.VIN));
            Assert.IsTrue(itemsFromKendoGrid.Contains(label3.VIN));
            Assert.IsFalse(itemsFromKendoGrid.Contains(label4.VIN));
        }

        [TestCase(TestName = "VerifyDateRangeFilterPlaceholderHelperTextIsUpdatedWithDateFormat_mmddyyyy")]
        [Category("233298")]
        public void VerifyDateRangeFilterPlaceholderHelperTextIsUpdatedWithDateFormat_mmddyyyy()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            DateTime dt;
            Assert.IsTrue(DateTime.TryParseExact(viewUnitLabelPage.GetEndDateText(), "MM/dd/yyyy hh:mm tt", CultureInfo.InvariantCulture.DateTimeFormat,
                DateTimeStyles.AllowWhiteSpaces, out dt), "End Date time not in expected format.");
        }
       
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyAdminUserCanCreditChargesOnOpenInvoice")]
        [Category("230364")]
        public void VerifyAdminUserCanCreditChargesOnOpenInvoice(string user, string password)
        {
            var labelInfo = DataHelper.InsertLabel(printLabel: true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, password);

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();
            viewUnitLabelPage.ClickRefreshButton();
            viewUnitLabelPage.WaitForKendoReadyState();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCreditButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Credits applied for selected labels", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
            viewUnitLabelPage.ClickRefreshButton();
            viewUnitLabelPage.WaitForKendoReadyState();
            
            Assert.AreEqual("", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.TotalAmount));
            Assert.AreEqual("No", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.Invoiced));
            Assert.AreEqual("", viewUnitLabelPage.KendoGrid.GetColumnDataAsString(UnitLabelPageColumnNumbers.DebitCredit));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyAdminUserCanCreditChargesOnAClosedInvoice")]
        [Category("230365")]
        public void VerifyAdminUserCanCreditChargesOnAClosedInvoice(string user, string password)
        {
            var labelInfo = DataHelper.InsertLabel(printLabel: true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, password);

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();
            
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            viewUnitLabelPage.WaitForKendoReadyState();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();
            viewInvoicesPage.ClickCloseInvoiceButton();
            viewInvoicesPage.ClickConfirmCloseInvoiceButton();

            viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, password);

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCreditButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Credits applied for selected labels", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Success));
            viewUnitLabelPage.WaitForKendoReadyState();
            viewUnitLabelPage.ClickRefreshButton();
            
            Assert.AreNotEqual("", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.TotalAmount));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyAdminUserCanCreditChargesNotOnAnInvoiceToVoidThem")]
        [Category("230366")]
        public void VerifyAdminUserCanCreditChargesNotOnAnInvoiceToVoidThem(string user, string password)
        {
            var labelInfo = DataHelper.InsertLabel(printLabel: true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, password);

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCreditButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            viewUnitLabelPage.WaitForKendoReadyState();
            viewUnitLabelPage.ClickRefreshButton();
            Assert.AreEqual("No", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.Invoiced));
            Assert.AreEqual("", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.TotalAmount));
            Assert.AreEqual("", viewUnitLabelPage.KendoGrid.GetDataCellText(1, UnitLabelPageColumnNumbers.DebitCredit));
        }

        [TestCase(TestName = "VerifyInvoicedColumnIsAddedInViewUnitLabelsPage")]
        [Category("232231")]
        public void VerifyInvoicedColumnIsAddedInViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.KendoGrid.ScrollColumnToView(UnitLabelPageColumnNumbers.Invoiced);
            var allColumns = viewUnitLabelPage.KendoGrid.GetAllHeadersTextList();
            Assert.IsTrue(allColumns.Contains("Invoiced"));
        }

        [TestCase(TestName = "VerifyThatWhenInvoice_IdIsZeroOrNullAndVoidFlagIsZeroTheInvoicedFlagShouldBeNoInViewUnitLabelsPage")]
        [Category("232232")]
        public void VerifyThatWhenInvoice_IdIsZeroOrNullAndVoidFlagIsZeroTheInvoicedFlagShouldBeNoInViewUnitLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();
            printPreviewPage.WaitForSpecificNotificationMessage(NotificationType.Success, "Print Unit Labels is completed");

            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();

            Assert.AreEqual(1, SQLHelper.ExecuteScalar(string.Format(StandardQueries.InvoiceIdNullAndVoidIsFalse, lbl.LabelId)));
            Assert.AreEqual("No", viewUnitLabelPage.KendoGrid.GetColumnDataAsString(UnitLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyThatWhenInvoice_IdHasChargesAndVoidFlagIsZeroTheInvoicedFlagShouldBeYesInViewUnitLabelsPage")]
        [Category("232241")]
        public void VerifyThatWhenInvoice_IdHasChargesAndVoidFlagIsZeroTheInvoicedFlagShouldBeYesInViewUnitLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();
            printPreviewPage.WaitForSpecificNotificationMessage(NotificationType.Success, "Print Unit Labels is completed");

            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton(true);

            Assert.AreEqual(1, SQLHelper.ExecuteScalar(string.Format(StandardQueries.InvoiceIdNotNullAndVoidIsFalse, lbl.LabelId)));
            Assert.AreEqual("Yes", viewUnitLabelPage.KendoGrid.GetColumnDataAsString(UnitLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyThatHorizontalPositionVerticalPositionTextboxIsPresentInViewUnitLabelsPage")]
        [Category("232093")]
        public void VerifyThatHorizontalPositionVerticalPositionTextboxResetButtonAndIncrementalAndDecrementalArrowIsPresentInViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();

            Assert.IsTrue(viewUnitLabelPage.IsHorizontalPositionTextboxDisplayed());
            Assert.IsTrue(viewUnitLabelPage.IsVerticalPositionTextboxDisplayed());
        }

        [TestCase(TestName = "VerifyThatPrintFirstPrintRemainingAndPrintAllButtonIsPresentInViewUnitLabelsPage")]
        [Category("232100")]
        public void VerifyThatPrintFirstPrintRemainingAndPrintAllButtonIsPresentInViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);

            Assert.IsTrue(printPreviewPage.IsPrintFirstUnitLabelButtonDisplayed());
            Assert.IsTrue(printPreviewPage.IsPrintFirstRemaningUnitLabelButtonDisplayed());
            Assert.IsTrue(printPreviewPage.IsPrintAllUnitLabelButtonDisplayed());

        }

        [TestCase(TestName = "VerifyThatWhenAnInvoicedLabelIsUpdatedToPendingTheInvoicedFlagShouldBeNoInViewUnitLabelsPage")]
        [Category("232703")]
        public void VerifyThatWhenAnInvoicedLabelIsUpdatedToPendingTheInvoicedFlagShouldBeNoInViewUnitLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.ClickPendingCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            
            viewUnitLabelPage.ClickInvoiceAndCloseButton(true);
            
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.SelectStatusFromDropdown(LabelStatus.Pending);
            viewUnitLabelPage.ClickUpdateButton();
            viewUnitLabelPage.ClickExitButton();

            viewUnitLabelPage.WaitForKendoReadyState();
            Assert.AreEqual("No", viewUnitLabelPage.KendoGrid.GetColumnDataAsString(UnitLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyThatWhenAnInvoicedLabelIsCreditedTheInvoicedFlagShouldBeUpdatedToNoInViewUnitLabelsPage")]
        [Category("233023")]
        public void VerifyThatWhenAnInvoicedLabelIsCreditedTheInvoicedFlagShouldBeUpdatedToNoInViewUnitLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel();
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton(true);

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCreditButton();
            viewUnitLabelPage.WaitForKendoReadyState();
            Assert.AreEqual("Credit", viewUnitLabelPage.KendoGrid.GetColumnDataAsString(UnitLabelPageColumnNumbers.DebitCredit));
        }

        [TestCase(TestName = "VerifyWhetherTheUserIsAbleToPrintTheLabelsFromSelectedPrinter")]
        [Category("232217")]
        public void VerifyWhetherTheUserIsAbleToPrintTheLabelsFromSelectedPrinter()
        {
            var newLabel = DataHelper.GetRandomLabel();
            newLabel.LabelStatusTypeId = LabelStatusType.Active;
            newLabel = DataHelper.InsertLabel(newLabel);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(newLabel.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();

            Assert.IsTrue(printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyTheUserIsAbleToChangeTheConfiguredPrintersFromTheDropdown")]
        [Category("232218")]
        public void VerifyTheUserIsAbleToChangeTheConfiguredPrintersFromTheDropdown()
        {
            var newLabel = DataHelper.GetRandomLabel();
            newLabel.LabelStatusTypeId = LabelStatusType.Active;
            newLabel = DataHelper.InsertLabel(newLabel);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(newLabel.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            
            var allPrinters = printPreviewPage.GetAvailablePrinters();
            var printerSelected = allPrinters[allPrinters.Count - 1];

            printPreviewPage.SelectValueInPrinterDropdown(printerSelected);
            Assert.AreEqual(printerSelected, printPreviewPage.GetPrinterSelected());
        }

        [TestCase(TestName = "VerifyTheUserIsAbleToPrintTheRemainingLabels")]
        [Category("232306")]
        public void VerifyTheUserIsAbleToPrintTheRemainingLabels()
        {
            var newLabel = DataHelper.GetRandomLabel();
            newLabel.LabelStatusTypeId = LabelStatusType.Active;
            newLabel = DataHelper.InsertLabel(newLabel);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickActiveCheckbox(true);
            //viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(2);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintRemainingUnitLabels();

            Assert.IsTrue(printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyTheUserIsAbleToPrintAllTheLabels")]
        [Category("232307")]
        public void VerifyTheUserIsAbleToPrintAllTheLabels()
        {
            var newLabel = DataHelper.GetRandomLabel();
            newLabel.LabelStatusTypeId = LabelStatusType.Active;
            newLabel = DataHelper.InsertLabel(newLabel);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            //viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(2);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintAllUnitLabels();
            printPreviewPage.ClickContinueButton();

            Assert.IsTrue(printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }


        [TestCase(TestName = "VerifyThatSaveAndGoBackButtonIsPresentInViewUnitLabelsPage")]
        [Category("234802")]
        public void VerifyThatSaveAndGoBackButtonIsPresentInViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);

            Assert.IsTrue(printPreviewPage.IsSaveUnitLabelButtonDisplayed());
        }

        [TestCase(TestName = "VerifyThatWhenUserClickOnGoBackButtonUserShouldBeNavigatedToViewUnitLabelsPage")]
        [Category("234929")]
        public void VerifyThatWhenUserClickOnGoBackButtonUserShouldBeNavigatedToViewUnitLabelsPage()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickGoBackUnitLabelButton();

            viewUnitLabelPage.Navigate();
            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());

        }

        [TestCase(TestName = "VerifyMoveSelectedButtonIsDisplayed")]
        [Category("239627")]
        public void VerifyMoveSelectedButtonIsDisplayed()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsMoveSelectedButtonDisplayed());
        }

        [TestCase(TestName = "VerifyErrorMessageAsErrorPleaseSelectAtLeastOneLabelToMoveWithOutSelectingRecordsWhile")]
        [Category("239630")]
        public void VerifyErrorMessageAsErrorPleaseSelectAtLeastOneLabelToMoveWithOutSelectingRecordsWhile()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickMoveSelectedButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select at least one label to move", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyMoveSelectedButton")]
        [Category("239638")]
        public void VerifyMoveSelectedButton()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunshineBradenton);
            
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();
            var VinNumberForFL = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 3);
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickMoveSelectedButton();
            viewUnitLabelPage.IsMoveLabelsModalDisplayed();

            viewUnitLabelPage.SelectProcessingLocationOfficeValues("Sun City, AZ");
            viewUnitLabelPage.ClickMoveLabelsSaveButton();

            //Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            //Assert.AreEqual("Labels Moved Successfully", viewUnitLabelPage.GetSuccessMessageText());

            viewUnitLabelPage.Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunCityAz);
            viewUnitLabelPage.Border.ClickHeaderApplyButton();
            viewUnitLabelPage.Navigate(false);

            viewUnitLabelPage.EnterSearchTextField(VinNumberForFL);
            viewUnitLabelPage.ClickSearchButton();
            var VinNumberForAZ = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 3);
            viewUnitLabelPage.KendoGrid.WaitForKendoReadyState();
            viewUnitLabelPage.Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunshineBradenton);
            viewUnitLabelPage.Border.ClickHeaderApplyButton();
            Assert.AreEqual(VinNumberForFL, VinNumberForAZ);
        }

        [TestCase(TestName = "VerifyCancelButtonInMoveLabelPopup")]
        [Category("239640")]
        public void VerifyCancelButtonInMoveLabelPopup()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickMoveSelectedButton();
            Assert.IsTrue(viewUnitLabelPage.IsMoveLabelsModalDisplayed());
            viewUnitLabelPage.ClickMoveLabelsCancelButton();

            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());
        }

        /// <summary>
        /// Need to get dropdown values
        /// </summary>
        [TestCase(TestName = "VerifySelectProcessingOfficeDropdown")]
        [Category("240529")]
        public void VerifySelectProcessingOfficeDropdown()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickMoveSelectedButton();
            Assert.IsTrue(viewUnitLabelPage.IsMoveLabelsModalDisplayed());
            Assert.IsTrue(viewUnitLabelPage.IsProcessigLocationDropdownDisplayed());
            
            var expectedList = new List<string>() { "Sunshine Bradenton, FL", "Sun City, AZ", "San Antonio TX" };
            Assert.AreEqual(expectedList, viewUnitLabelPage.ProcessingLocationDropDownValuesList());

        }

        [TestCase(TestName = "VerifyIsCopySelectedButtonDisplayed")]
        [Category("240718")]
        public void VerifyIsCopySelectedButtonDisplayed()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsCopySelectedButtonDisplayed());
        }

        [TestCase(TestName = "VerifyErrorMessageAsPleaseSelectAtLeastOneVoidOrClosedRecord")]
        [Category("240719")]
        public void VerifyErrorMessageAsPleaseSelectAtLeastOneVoidOrClosedRecord()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickCopySelectedButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.PleaseSelectVoidOrClosedLabels_AtLeast, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyErrorMessageAsPleaseSelectVoidOrClosedLabelToCopy")]
        [Category("240720")]
        public void VerifyErrorMessageAsPleaseSelectVoidOrClosedLabelToCopy()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCopySelectedButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select void or closed label to copy", viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyExitButtonInCopySelectedButton")]
        [Category("240732")]
        public void VerifyExitButtonInCopySelectedButton()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickVoidCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewUnitLabelPage.IsCopySelectedModalDisplayed());

            viewUnitLabelPage.ClickCopyLabelsExitButton();
            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "VerifyViewLogsOptionInCopyLabelsPopup")]
        [Category("240734")]
        public void VerifyViewLogsOptionInCopyLabelsPopup()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickVoidCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewUnitLabelPage.IsCopySelectedModalDisplayed());

            viewUnitLabelPage.ClickViewLogLinkInCopyLabelsModal();
            Assert.IsTrue(viewUnitLabelPage.IsCopyLabelsLogDisplayed());
        }

        [TestCase(TestName = "VerifyCopySelected")]
        [Category("240721")]
        public void VerifyCopySelected()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickVoidCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            var VinNumber = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 3);
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(4);
            viewUnitLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewUnitLabelPage.IsCopySelectedModalDisplayed());
            Assert.AreEqual(viewUnitLabelPage.TotalCopyLabelsCount(),viewUnitLabelPage.PassedCopyLabelsCount());
            viewUnitLabelPage.ClickCopyLabelsExitButton();
            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());

            viewUnitLabelPage.EnterSearchTextField(VinNumber);
            viewUnitLabelPage.ClickSearchButton();
            var VinNumberForActiveLabel = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 3);
            Assert.AreEqual(VinNumber,VinNumberForActiveLabel);
        }

        [TestCase(TestName = "VerifyIfAlreadyRecordIsCopiedAndCreatedRecordInActiveStatusUserShouldBeUnableToCopy")]
        [Category("240735")]
        public void VerifyIfAlreadyRecordIsCopiedAndCreatedRecordInActiveStatusUserShouldBeUnableToCopy()
        {
            var labelInfo = DataHelper.GetRandomLabel();
            labelInfo.LabelStatusTypeId = LabelStatusType.Closed;
            labelInfo = DataHelper.InsertLabel(labelInfo);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickClosedCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewUnitLabelPage.IsCopySelectedModalDisplayed());
            Assert.AreEqual(viewUnitLabelPage.TotalCopyLabelsCount(), viewUnitLabelPage.PassedCopyLabelsCount());
            viewUnitLabelPage.ClickCopyLabelsExitButton();
            Assert.IsTrue(viewUnitLabelPage.IsViewBagLabelsGridDisplayed());

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickCopySelectedButton();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual(UnitLabelPageMessages.PleaseSelectVoidOrClosedLabels, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewUnitLabels_EnsureThatLabelStatusChangedInDropdownShouldBeReflectedInstantlyBeforeSaving")]

        public void EnsureThatLabelStatusChangedInDropdownShouldBeReflectedInstantlyBeforeSaving()
        {
            var labelInfo = DataHelper.GetRandomLabel();
            labelInfo.LabelStatusTypeId = LabelStatusType.Pending;
            labelInfo = DataHelper.InsertLabel(labelInfo);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickPendingCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickStatus();
            viewUnitLabelPage.ClickStatus();
            viewUnitLabelPage.LabelStatusFieldOption("Active");
            Assert.AreEqual(viewUnitLabelPage.KendoGrid.GetDataCellText(1, 2), "Active");
            viewUnitLabelPage.ClickSaveChangesbutton();

            Assert.IsTrue(viewUnitLabelPage.IsSaveChangesSuccessWindowDisplayed());
        }

        [TestCase(TestName = "EnsureThatNotificationsShouldBeDisplayedAfterExportAllBackendJobIsCompleted")]
        [Category("251512")]
        public void EnsureThatNotificationsShouldBeDisplayedAfterExportAllBackendJobIsCompleted()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickExportAllButtonFlow();
            Assert.IsTrue(Extensions.WaitForAndRemoveSuccessPopup(Driver));
            viewUnitLabelPage.VerifyExportCompletionMessage(ExportFileValidations.ExportCompleted);

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            Assert.AreEqual("Export Labels", logPage.KendoGrid.GetDataCellText(1, 2));
            Assert.AreEqual("Export", logPage.KendoGrid.GetDataCellText(1, 3));
            Assert.AreEqual("Completed", logPage.KendoGrid.GetDataCellText(1, 9));

        }

        [TestCase(TestName = "VerifyOrderBySearchListCheckBoxIsAvailableOnTheGrid")]
        [Category("265667")]
        public void VerifyOrderBySearchListCheckBoxIsAvailableOnTheGrid()
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            Assert.IsTrue(viewUnitLabelPage.IsOrderBySearchListExist());
            Assert.IsFalse(viewUnitLabelPage.IsOrderBySearchListSelected());
        }

        [TestCase(3,6, TestName = "VerifySearchResultsAreOrderBySearchListOnVinTab_FewItems")]
        [TestCase(20,30, TestName = "VerifySearchResultsAreOrderBySearchListOnVinTab_MoreItems")]
        [Category("265674")]
        public void VerifySearchResultsAreOrderBySearchListOnVinTab(int minCount, int maxCount)
        {
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.SelectAllFilterCheckBoxes();
            viewUnitLabelPage.ClickOrderBySearchListCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();

            var totalrows = viewUnitLabelPage.KendoGrid.GetNumberOfDataRows(1, true);
            var itemstopick = Extensions.GetRandomNumber(minCount, maxCount);

            if (itemstopick > totalrows)
            {
                itemstopick = totalrows;
            }

            var searchItems = new List<string>();
            var searchResults = new List<string>();
            for (int i = 1; i <= itemstopick; i++)
            {
                searchItems.Add(viewUnitLabelPage.KendoGrid.GetDataCellText(i, UnitLabelPageColumnNumbers.Vin).Trim());
            }

            searchItems.Sort();

            viewUnitLabelPage.EnterSearchText(searchItems);
            viewUnitLabelPage.ClickSearchButton();

            Assert.AreEqual(itemstopick, viewUnitLabelPage.KendoGrid.GetNumberOfDataRows(1, true));

            for (int i = 1; i <= itemstopick; i++)
            {
                searchResults.Add(viewUnitLabelPage.KendoGrid.GetDataCellText(i, UnitLabelPageColumnNumbers.Vin).Trim());
            }

            Assert.AreEqual(searchItems, searchResults);
        }

        [TestCase(TestName = "VerifyOrderBySearchListCheckBoxIsPersistent")]
        [Category("265676")]
        public void VerifyOrderBySearchListCheckBoxIsPersistent()
        {
            var abcd = DateTime.Now.ToOADate();
            var asas = DateTime.Now.ToFileTime();
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickOrderBySearchListCheckbox(true);

            var addLabelPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelPage.Navigate();

            viewUnitLabelPage.Navigate();
            Assert.IsTrue(viewUnitLabelPage.IsOrderBySearchListSelected());

            viewUnitLabelPage.ClickOrderBySearchListCheckbox(false);

            addLabelPage.Navigate();

            viewUnitLabelPage.Navigate();
            Assert.IsFalse(viewUnitLabelPage.IsOrderBySearchListSelected());
        }

        [TestCase( TestName = "VerifySearchResultsAreOrderBySearchListOnBatchTab")]
        [Category("265674")]
        public void VerifySearchResultsAreOrderBySearchListOnBatchTab()
        {
            var batchNum = DateTime.Now.ToString("Mdyyhhmmss");
            var lbl1 = DataHelper.GetRandomLabel(true);
            lbl1.BatchNumber = batchNum + "1q2s";
            var lbl2 = DataHelper.GetRandomLabel(true);
            lbl2.BatchNumber = batchNum + "5rPs";
            var lbl3 = DataHelper.GetRandomLabel(true);
            lbl3.BatchNumber = batchNum + "1qPs";
            var lbl4 = DataHelper.GetRandomLabel(true);
            lbl4.BatchNumber = batchNum + "3qPs";
            var lbl5 = DataHelper.GetRandomLabel(true);
            lbl5.BatchNumber = batchNum + "2qP1";

            DataHelper.InsertLabel(lbl1);
            DataHelper.InsertLabel(lbl2);
            DataHelper.InsertLabel(lbl3);
            DataHelper.InsertLabel(lbl4);
            DataHelper.InsertLabel(lbl5);

            var searchItems = new List<string> { lbl1.BatchNumber, lbl2.BatchNumber, lbl3.BatchNumber, lbl4.BatchNumber, lbl5.BatchNumber };
            var searchResults = new List<string>();

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.SelectAllFilterCheckBoxes();
            viewUnitLabelPage.ClickOrderBySearchListCheckbox(true);

            viewUnitLabelPage.ClickBatchTab();

            viewUnitLabelPage.EnterSearchText(searchItems);
            viewUnitLabelPage.ClickSearchButton();

            Assert.AreEqual(searchItems.Count, viewUnitLabelPage.KendoGrid.GetNumberOfDataRows(1, true));

            for (int i = 1; i <= searchItems.Count; i++)
            {
                searchResults.Add(viewUnitLabelPage.KendoGrid.GetDataCellText(i, UnitLabelPageColumnNumbers.BatchNumber).Trim());
            }

            Assert.AreEqual(searchItems, searchResults);
        }

        [TestCase(TestName = "VerifyWhetherThePrintFirstIsSuccessfulUsingTheSelectedPrinter")]
        [Category("232259")]
        public void VerifyWhetherThePrintFirstIsSuccessfulUsingTheSelectedPrinter()
        {
            var labelInfo = DataHelper.InsertLabel();

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            viewUnitLabelPage.WaitForKendoReadyState();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstUnitLabel();

            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            Assert.AreEqual("Print Unit Labels", logPage.GetProcessName());
            Assert.AreEqual("Completed", logPage.StatusInLogs());
            Assert.IsTrue(logPage.GetFileNameInLogs().Length > 5);
        }

        [TestCase(TestName = "VerifyWhetherThePrintAllIsSuccessfulUsingSelectedPrinter")]
        [Category("232260")]
        public void VerifyWhetherThePrintAllIsSuccessfulUsingSelectedPrinter()
        {
            var labelInfo = DataHelper.InsertLabel();

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickPrintSelected();
            viewUnitLabelPage.WaitForKendoReadyState();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintAllBagLabels();

            Assert.IsTrue(viewUnitLabelPage.IsConfirmPrintPopup());
            viewUnitLabelPage.ClickContinueButton();
            Assert.IsTrue(viewUnitLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            logPage.ClickOnLogsRefreshButton();
            logPage.WaitForKendoReadyState();
            Assert.AreEqual("Print Unit Labels", logPage.GetProcessName());
            Assert.AreEqual("Completed", logPage.StatusInLogs(), "BUG: Print label is not showing up in Logs");
            Assert.IsTrue(logPage.GetFileNameInLogs().Length > 5);
        }
    }
}

