using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;
using VM.FleetServices.TnR.LM.Web.Automation.Model;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ViewBagLabelsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {

        [TestCase(TestName = "1_ViewBagLabels_PageRender")]
        public void ViewBagLabels_PageRender()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            var pageLoaded = viewBagLabelPage.IsPageLoaded();
            if (pageLoaded)
            {
                Assert.IsTrue(pageLoaded);
            }
            else
            {
                Assert.Fail("1_ViewBagLabels_PageRende Test Failed");
            }

        }

        [TestCase(TestName = "2_ViewBagLabels_SortGrid")]
        public void ViewBagLabels_SortGrid()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            var pageLoaded = viewBagLabelPage.IsPageLoaded();
            if (pageLoaded)
            {
                // Get Column Count
                var headerCount = viewBagLabelPage.KendoGrid.GetAllHeaderList().Count;

                // Sort each column in both directions
                for (var headerNumber = 1; headerNumber <= headerCount; headerNumber++)
                {
                    // Ascending
                    viewBagLabelPage.KendoGrid.ClickSortColumnByColumnNumber(headerNumber, 1, 10);
                    // Descending
                    viewBagLabelPage.KendoGrid.ClickSortColumnByColumnNumber(headerNumber, 1, 10);
                }
            }
            else
            {
                Assert.Fail("2_ViewBagLabels_SortGrid Test Failed");
            }
        }

        [TestCase(TestName = "3_ViewBagLabels_VerifyGridPagination")]
        public void ViewBagLabels_GridPagination()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsPageLoaded(), "Pageload");
            Assert.IsTrue(viewBagLabelPage.IsGridPaginationExist(), "GridPagination");
            Assert.IsTrue(viewBagLabelPage.IsGridRowSizeDropdownExist(), "GridRowSize");
            //Assert.IsTrue(viewBagLabelPage.IsGridRowsMatchWithDropDownSizeSelection());
        }

        [TestCase(TestName = "4_ViewBagLabelsPage_ViewBagLabelsColumnOrder")]
        public void ViewBagLabelsColumnOrderTest()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var expectedColumnHeaders = viewBagLabelPage.GetColumnHedders(0);
            viewBagLabelPage.Navigate();
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());
            Assert.AreEqual(expectedColumnHeaders.Count, viewBagLabelPage.GetNumberOfColumnHeaders());
            Assert.IsTrue(viewBagLabelPage.VerifyColumnNames(expectedColumnHeaders));
        }

        [TestCase(TestName = "5_ViewBagLabelsPage_ViewBagLabelsSpanishColumnOrder")]
        [Category("Bug")]
        public void ViewBagLabelsSpanishColumnOrderTest()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var expectedColumnHeaders = viewBagLabelPage.GetColumnHedders(1);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickViewPageLabelSpanish();
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());
            Assert.AreEqual(expectedColumnHeaders.Count, viewBagLabelPage.GetNumberOfColumnHeaders());
            Assert.IsTrue(viewBagLabelPage.VerifyColumnNames(expectedColumnHeaders));
        }

        [TestCase(TestName = "6_ViewBagLabels_VerifyUserLoginAdmin")]
        public void ViewBagLabels_UserLoginAdmin()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(UserCredentials.AdminUsername, UserCredentials.AdminPassword);
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());
        }


        [TestCase(TestName = "7_ViewBagLabels_VerifyUserLoginSupervisor")]
        public void ViewBagLabels_UserLoginSupervisor()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword);
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());
        }

        [TestCase(TestName = "8_ViewBagLabels_VerifyUserLoginInternal")]
        public void ViewBagLabels_UserLoginInternal()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(UserCredentials.InternalUsername, UserCredentials.InternalPassword);
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());
        }

        [TestCase(TestName = "9_ViewBagLabels_VerifyUserLoginExternal")]
        public void ViewBagLabels_UserLoginExternal()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword);
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());
        }

        [TestCase(TestName = "10_ViewBagLabels_VerifyGridData")]
        public void ViewBagLabels_VerifyGridData()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(UserCredentials.AdminUsername, UserCredentials.AdminPassword);

            viewBagLabelPage.SelectAllFilterCheckBoxes();
            viewBagLabelPage.KendoGrid.ClickSortColumnByColumnNumber(BagLabelPageColumnNumbers.Id);
            viewBagLabelPage.KendoGrid.ClickSortColumnByColumnNumber(BagLabelPageColumnNumbers.Id);

            Assert.IsTrue(viewBagLabelPage.IsPageLoaded(), "Pageload");
            Assert.IsTrue(viewBagLabelPage.VerifyGridData(), "GridData");
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatSavechangesCancelchangesAndBulkUpdateButtonIsPresent")]
        public void ViewBagLabels_VerifyThatSavechangesCancelchangesAndBulkUpdateButtonIsPresent()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsSaveChangesButtonExists());
            Assert.IsTrue(viewBagLabelPage.IsCancelChnagesButtonExists());
            Assert.IsTrue(viewBagLabelPage.IsBulkUpdateButtonExists());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatBulkUpdateWindowIsOpenedWhenBulkUpdateButtonIsClicked")]
        public void ViewBagLabels_VerifyThatBulkUpdateWindowIsOpenedWhenBulkUpdateButtonIsClicked()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();

            Assert.IsTrue(viewBagLabelPage.IsBulkUpdateWindowDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsClickedWithoutSelectingRecords")]

        public void ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsClickedWithoutSelectingRecords()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickBulkUpdateButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Bulk Update Error\r\nPlease select labels for bulk update action", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenUpdateButtonIsClickedWithoutSelectingFields")]
        public void ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenUpdateButtonIsClickedWithoutSelectingFields()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Please add note/status for bulk update and try again.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatSuccessMessageIsDisplayedWhenBulkUpdateIsCompleted")]

        public void ViewBagLabels_VerifyThatSuccessMessageIsDisplayedWhenBulkUpdateIsCompleted()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Bulk update completed successfully.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatExitButtonShouldCloseTheBulkUpdateWindow")]

        public void ViewBagLabels_VerifyThatExitButtonShouldCloseTheBulkUpdateWindow()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickExitButton();

            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifySaveChangesButton")]

        public void ViewBagLabels_VerifySaveChangesButton()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Pending);
            viewBagLabelPage.ClickSaveChangesbutton();

            Assert.IsTrue(viewBagLabelPage.IsSaveChangesSuccessWindowDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyCancelChangesButton")]

        public void ViewBagLabels_VerifyCancelChangesButton()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.EnterNotesInGrid();
            viewBagLabelPage.ClickCancelChanges();
            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());
        }
        [TestCase(TestName = "ViewBagLabels_VerifyTheDownloadButtonIsWorkingAsExpected")]

        public void ViewBagLabels_VerifyTheDownloadButtonIsWorkingAsExpected()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewBagLabelPage.ClickViewLog();
            viewBagLabelPage.ClickDownloadButton();
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatSelectedRecordCountAndTotalCountInBulkUpdateWindowShouldBeSame")]

        public void ViewBagLabels_VerifyThatSelectedRecordCountAndTotalCountInBulkUpdateWindowShouldBeSame()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();

            Assert.AreEqual(1, viewBagLabelPage.TotalLabelsCount());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsDoneForTheStatusVoid")]
        [Category("ScriptIssue")]
        public void ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenBulkUpdateIsDoneForTheStatusVoid()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickVoidCheckbox(true);
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Pending);


            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(1, viewBagLabelPage.FailedLabelsCount());
            viewBagLabelPage.ClickViewLog();
            Assert.IsTrue(viewBagLabelPage.VoidTransactionErrorMessageDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatProcessIsSuccessWhenALabelTypeIsUpdatedToActiveDoesNotCreateDuplicate")]

        public void ViewBagLabels_VerifyThatProcessIsSuccessWhenALabelTypeIsUpdatedToActiveDoesNotCreateDuplicate()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickPendingCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.SelectStatusFromDropdown(LabelStatus.Active);
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatLabelStatusCanBeUpdatedToClosedFromActiveStatus")]

        public void ViewBagLabels_VerifyThatLabelStatusCanBeUpdatedToClosedFromActiveStatus()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Closed);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Bulk update completed successfully.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatClosedStatusCanBeUpdatedToPendingDuplicate")]

        public void ViewBagLabels_VerifyThatClosedStatusCanBeUpdatedToPendingDuplicate()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.SelectStatusFromDropdown(LabelStatus.Pending);
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatTheUserCanUpdateNotesWithoutChangingStatus")]

        public void ViewBagLabels_VerifyThatTheUserCanUpdateNotesWithoutChangingStatus()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatIfCurrentStatusIsActiveAndDesiredStatusIsSameAddNotes")]

        public void ViewBagLabels_VerifyThatIfCurrentStatusIsActiveAndDesiredStatusIsSameAddNotes()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Bulk update completed successfully.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatIfCurrentStatusIsPendingAndDesiredStatusIsSameAddNotes")]

        public void ViewBagLabels_VerifyThatIfCurrentStatusIsPendingAndDesiredStatusIsSameAddNotes()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickPendingCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Pending);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Bulk update completed successfully.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatIfCurrentStatusIsClosedAndDesiredStatusIsSameAddNotes")]

        public void ViewBagLabels_VerifyThatIfCurrentStatusIsClosedAndDesiredStatusIsSameAddNotes()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Closed);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Bulk update completed successfully.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(LabelStatus.Pending, TestName = "ViewBagLabels_VerifyThatOnlyNotesAndStatusFieldAreEditable")]

        public void ViewBagLabels_VerifyThatOnlyNotesAndStatusFieldAreEditable(string status)
        {

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
            viewBagLabelPage.EnterNotesInGrid();
        }

        [TestCase(1, new int[] { 1, 2, 3, 4, 5 },TestName = "ViewBagLabels_VerifyBulkUpdateForMultipleRecords")]

        public void ViewBagLabels_VerifyBulkUpdateForMultipleRecords(int pageNumber, int[] rowNumbers)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            while (viewBagLabelPage.KendoGrid.GetCurrentPageNumberSelection() < pageNumber)
            {
                viewBagLabelPage.KendoGrid.ClickNextPageArrow();
            }
            foreach (var rowNumber in rowNumbers)
            {
                viewBagLabelPage.ClickDataCheckmarkByRowNumber(rowNumber);
            }
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Active);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(rowNumbers.Length, viewBagLabelPage.TotalLabelsCount());
        }

        [TestCase(1, new int[] { 1, 2, 3, 4, 5 }, TestName = "ViewBagLabels_VerifyThatSaveChangesIsSuccessfulForMultipleRecords")]

        public void ViewBagLabels_VerifyThatSaveChangesIsSuccessfulForMultipleRecords(int pageNumber, int[] rowNumbers)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickPendingCheckbox(true);

            while (viewBagLabelPage.KendoGrid.GetCurrentPageNumberSelection() < pageNumber)
            {
                viewBagLabelPage.KendoGrid.ClickNextPageArrow();
            }
            foreach (var rowNumber in rowNumbers)
            {
                viewBagLabelPage.ClickDataCheckmarkByRowNumber(rowNumber);
                viewBagLabelPage.ClickStatus();
                viewBagLabelPage.ClickStatus();
                viewBagLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
            }
            viewBagLabelPage.ClickSaveChangesbutton();
            Assert.IsTrue(viewBagLabelPage.IsSaveChangesSuccessWindowDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatOnlyAdminCanVoidTheTransaction")]

        public void ViewBagLabels_VerifyThatOnlyAdminCanVoidTheTransaction()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickPendingCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.ClickLabelsStausDropdown();
            viewBagLabelPage.SelectStatusFromDropdown(BagUnitLabelStatus.Void);
            viewBagLabelPage.NotesField();
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Bulk update completed successfully.", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatStatusCanBeUpdatedToClosedWhichIsInActivePendingDuplicate")]

        public void ViewBagLabels_VerifyThatStatusCanBeUpdatedToClosedWhichIsInActivePendingDuplicate()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickDuplicateCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.SelectStatusFromDropdown(LabelStatus.Closed);
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenUpdatingALabelTypeToActiveWillCreateTwoActiveVINOfSameLabelType")]

        public void ViewBagLabels_VerifyThatErrorMessageIsDisplayedWhenUpdatingALabelTypeToActiveWillCreateTwoActiveVINOfSameLabelType()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            string VIN=viewBagLabelPage.ActiveVINInDB();
            viewBagLabelPage.EnterSearchTextField(VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.SelectStatusFromDropdown(LabelStatus.Active);
            viewBagLabelPage.ClickUpdateButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewBagLabelPage.ClickViewLog();
            Assert.IsTrue(viewBagLabelPage.DuplicateVINErrorMessageDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyTheGridDataOfViewBagLabelsPageIsSelectable")]

        public void ViewBagLabels_VerifyTheGridDataOfViewBagLabelsPageIsSelectable()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickCheckBox();
            Assert.IsTrue(viewBagLabelPage.IsCheckboxSelected());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewBagLabelsPageWithoutSelectingAnyRows")]

        public void ViewBagLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewBagLabelsPageWithoutSelectingAnyRows()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickPrintSelected();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select at least one Active labels to print", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewBagLabelsPageWithoutSelectingAnyActiveLabels")]

        public void ViewBagLabels_VerifyErrorMessageWhileClickingOnPrintedSelectedButtonOfViewBagLabelsPageWithoutSelectingAnyActiveLabels()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickDuplicateCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select only Active labels to print", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThePrintedSelectedFunctionalityOfViewBagLabelsPage")]

        public void ViewBagLabels_VerifyThePrintedSelectedFunctionalityOfViewBagLabelsPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();

            Assert.IsTrue(viewBagLabelPage.IsPrintPreviewPageDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThePrintPreviewsPagePrinterDropDownIsDisplaying")]

        public void ViewBagLabels_VerifyThePrintPreviewsPagePrinterDropDownIsDisplaying()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();

            Assert.IsTrue(viewBagLabelPage.IsPrinterNameDisplayed());
        }

        //[TestCase(TestName = "ViewBagLabels_VerifyTheEditAlignmentFunctionalityOfPrintPreviewPage")]

        public void ViewBagLabels_VerifyTheEditAlignmentFunctionalityOfPrintPreviewPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.ClickEditAlignment();
            viewBagLabelPage.ClickTopMargin();
            viewBagLabelPage.ClickBottomMargin();
            viewBagLabelPage.ClickLeftMargin();
            viewBagLabelPage.ClickRightMargin();
            viewBagLabelPage.ClickPrintPreviewSaveButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyTheGridDataOfPrintPreviewPage")]

        public void ViewBagLabels_VerifyTheGridDataOfPrintPreviewPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);

            Assert.AreEqual(viewBagLabelPage.BagLabelPageIdValue(), printPreviewPage.PrintPreviewPageIdValue());
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThePrintAllFunctionalityOfPrintPreviewPag")]

        public void ViewBagLabels_VerifyThePrintAllFunctionalityOfPrintPreviewPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintAllBagLabels();
            Assert.IsTrue(viewBagLabelPage.IsConfirmPrintPopup());
            viewBagLabelPage.ClickContinueButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyThePrintFirstPageFunctionalityOfPrintPreviewPage")]

        public void ViewBagLabels_VerifyThePrintFirstPageFunctionalityOfPrintPreviewPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Print request created successfully",viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers")]

        public void ViewBagLabels_VerifyThatPrintPreviewPageIsAccessibleToDifferentUsers(string user, string password)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewBagLabelPage.IsPrintPreviewPageDisplayed());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "ViewBagLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows")]

        public void ViewBagLabels_VerifyThatPrintPreviewPageIsNotAccessibleToUsersWithoutSelectingAnyRows(string user, string password)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);
            viewBagLabelPage.ClickPrintSelected();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select at least one Active labels to print", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewBagLabels_VerifyFilterPersistenceOnViewBagLabelsPage")]

        public void ViewBagLabels_VerifyFilterPersistenceOnViewBagLabelsPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            Assert.AreEqual("Active", viewBagLabelPage.GetStatusText());
            viewBagLabelPage.ClickOnReportsInLeftMenu();
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsActiveCheckboxSelected());
            Assert.AreEqual("Active", viewBagLabelPage.GetStatusText());
        }

        [TestCase(TestName = "ViewBagLabels_ViewBagLabelsValidateSearchFunctionalityForVIN")]

        public void ViewBagLabels_ViewBagLabelsValidateSearchFunctionalityForVIN()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            var vinsToTest = viewBagLabelPage.KendoGrid.GetColumnDataAsList(3, 1);
            if (vinsToTest.Count > 5)
            {
                var totalToRemove = vinsToTest.Count - 5;
                vinsToTest.RemoveRange(5, totalToRemove);
            }
            viewBagLabelPage.ClickVinTab();
            viewBagLabelPage.EnterSearchText(vinsToTest);
            viewBagLabelPage.ClickSearchButton();
            var result = viewBagLabelPage.VerifyOrders(BagLabelsColumnHeadings.Vin, vinsToTest);

            Assert.True(result);
        }

        [TestCase(TestName = "ViewBagLabels_ViewBagLabelsValidateSearchFunctionalityForBatchNumber")]

        public void ViewBagLabels_ViewBagLabelsValidateSearchFunctionalityForBatchNumber()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            var batchNoToTest = viewBagLabelPage.KendoGrid.GetColumnDataAsList(8, 1);
            viewBagLabelPage.ClickBatchTab();
            viewBagLabelPage.EnterSearchText(batchNoToTest);
            viewBagLabelPage.ClickSearchButton();
            var result = viewBagLabelPage.VerifyOrders(BagLabelsColumnHeadings.BatchNumber, batchNoToTest);

            Assert.True(result);
        }


        [TestCase(TestName = "ViewBagLabels_ViewBagLabelsVerifySearchTermsAreClearedOnClearButtonClick")]

        public void ViewBagLabels_ViewBagLabelsVerifySearchTermsAreClearedOnClearButtonClick()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            var vinsToTest = viewBagLabelPage.GetGridCellValues(BagLabelsColumnHeadings.Vin, 5);
            viewBagLabelPage.ClickVinTab();
            viewBagLabelPage.EnterSearchText(vinsToTest);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickClearButton();

            Assert.IsTrue(string.IsNullOrEmpty(viewBagLabelPage.GetSearchFieldText()));
            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "ViewBagLabels_ViewBagLabelsEnsureTabSpaceAndEnterKeyPressesWillCreateSearchElementInputTagHelpers")]

        public void ViewBagLabels_ViewBagLabelsEnsureTabSpaceAndEnterKeyPressesWillCreateSearchElementInputTagHelpers()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.EnterTabKey();
            Assert.IsTrue(viewBagLabelPage.IsInputTagDisplayed());
            viewBagLabelPage.ClickClearButton();

            viewBagLabelPage.EnterSpaceKey();
            Assert.IsTrue(viewBagLabelPage.IsInputTagDisplayed());

        }

        [TestCase(TestName = "ViewBagLabels_ViewBagLabelsValidateThatControlLabelsLanguageSwitchesOnLanguageSelectorSwitch")]
        [Category("Bug")]
        public void ViewBagLabels_ViewBagLabelsValidateThatControlLabelsLanguageSwitchesOnLanguageSelectorSwitch()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickViewPageLabelSpanish();
            Assert.IsTrue(viewBagLabelPage.IsPageLoaded());

            Assert.AreEqual(" Claro", viewBagLabelPage.GetClearButtonText());
            Assert.AreEqual(" Buscar", viewBagLabelPage.GetSearchButtonText());
        }

        #region Export
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "11_ViewBagLabels_VerifyTheExportDropdownHavingExportAllAndExportSelectedForViewOrders")]
        public void VerifyTheExportDropdownHavingExportAllAndExportSelectedForViewOrders(string user, string pass)
        {
            //Navigate to view bag labels page
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate(user, pass);

            viewBagLabelsPage.IsPageLoaded();

            Assert.IsTrue(viewBagLabelsPage.VerifyExportButtonDropdownValues());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "13_ViewBagLabels_VerifyExportSelectedButton")]
        public void VerifyExportSelectedButton(string user, string pass)
        {
            //Navigate to view bag labels page
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate(user, pass);

            viewBagLabelsPage.IsPageLoaded();
            viewBagLabelsPage.VerifyExportSelected();

            Assert.IsTrue(viewBagLabelsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("All visible rows will be exported to Excel:", viewBagLabelsPage.GetNotificationMessageText(NotificationType.Success));

            Assert.IsTrue(viewBagLabelsPage.ExportedFileExists());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "14_ViewBagLabels_VerifyExportSelectedButtonWithoutSelectingRecords")]
        public void VerifyExportSelectedButtonWithoutSelectingRecords(string user, string pass)
        {
            //Navigate to view bag labels page
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate(user, pass);

            viewBagLabelsPage.IsPageLoaded();
            viewBagLabelsPage.ClickExportSelectedButtonFlow();

            Assert.IsTrue(viewBagLabelsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.IsTrue(viewBagLabelsPage.ExportedFileExists());
            Assert.AreEqual("All visible rows will be exported to Excel:", viewBagLabelsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "15_ViewBagLabels_VerifyExportAllButtonBySelectingRecords")]
        public void VerifyExportAllButtonBySelectingRecords(string user, string pass)
        {
            //Navigate to view bag labels page
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate(user, pass);

            viewBagLabelsPage.IsPageLoaded();
            viewBagLabelsPage.VerifyExportAllBySelectingRecords();

            Assert.IsTrue(viewBagLabelsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Request to export report submitted", viewBagLabelsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "16_ViewBagLabels_VerifyTheErrorMessageWhenClickOnExportAll")]
        public void ViewBagLabels_VerifyTheErrorMessageWhenClickOnExportAll(string user, string pass)
        {
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate(user, pass);
            viewBagLabelsPage.IsPageLoaded();
            viewBagLabelsPage.UnselectAllCheckbox();
            viewBagLabelsPage.ClickSearchButton();
            viewBagLabelsPage.ClickExportAllButtonFlow();
            Assert.AreEqual("No data avaialble to export", viewBagLabelsPage.GetNotificationMessageText(NotificationType.Error));
            Assert.IsTrue(viewBagLabelsPage.IsNotificationMessageDisplayed(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "17_ViewBagLabels_VerifyTheErrorMessageWhenClickOnExportSelected")]
        public void ViewBagLabels_VerifyTheErrorMessageWhenClickOnExportSelected(string user, string pass)
        {
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate(user, pass);
            viewBagLabelsPage.IsPageLoaded();
            viewBagLabelsPage.UnselectAllCheckbox();
            viewBagLabelsPage.ClickSearchButton();
            viewBagLabelsPage.VerifyExportSelected();
            Assert.IsTrue(viewBagLabelsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("No data avaialble to export", viewBagLabelsPage.GetNotificationMessageText(NotificationType.Error));

        }

        [TestCase(TestName = "VerifyErrorWhenExportingMoreThan20000Rows")]
        public void VerifyErrorWhenExportingMoreThan20000Rows()
        {
            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate();
            viewBagLabelsPage.IsPageLoaded();
            viewBagLabelsPage.SelectAllFilterCheckBoxes();
            viewBagLabelsPage.SetStartDate(new DateTime(2020, 1, 1));

            viewBagLabelsPage.ClickSearchButton();
            viewBagLabelsPage.WaitForKendoReadyState();

            var totalRows = viewBagLabelsPage.KendoGrid.GetTotalSearchResultCount();
            if (totalRows > 20000)
            {
                viewBagLabelsPage.ClickExportAllButtonFlow();
                Assert.IsTrue(viewBagLabelsPage.IsNotificationMessageDisplayed(NotificationType.Error));
                Assert.AreEqual(ViewUnitLabelsPageObj.Error_SelectFewerRecordsToExport, viewBagLabelsPage.GetNotificationMessageText(NotificationType.Error));
            }
            else
                Assert.Inconclusive("Fewer than 20,000 records found to export. Data issue.");
        }

        #endregion

        [TestCase(TestName = "EnsureAPrintedBagLabelIsInvoicedSuccessfully")]

        public void EnsureAPrintedBagLabelIsInvoicedSuccessfully()
        {
            var labelinfo = DataHelper.InsertActiveBagLabel();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickClosedCheckbox(true);

            viewBagLabelPage.EnterSearchTextField(labelinfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);
            printPreviewPage.ClickGoBackBagLabelButton();
            viewBagLabelPage.ClickRefreshButton();

            viewBagLabelPage.WaitForKendoReadyState();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            viewBagLabelPage.ClickRefreshButton();
            viewBagLabelPage.WaitForKendoReadyState();

            Assert.AreEqual("Yes", viewBagLabelPage.KendoGrid.GetDataCellText(1, BagLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyTheChargesAreAddedOnlyWhenTheBagLabelIsInvoiced")]
        public void VerifyTheChargesAreAddedOnlyWhenTheBagLabelIsInvoiced()
        {
            var labelinfo = DataHelper.InsertActiveBagLabel(printLabel:true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelinfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));

            viewBagLabelPage.ClickRefreshButton();
            viewBagLabelPage.WaitForKendoReadyState();

            Assert.AreEqual("Yes", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyTheChargesAreInvoicedOnlyWhenItIsPrintedFirstTimeForBagLabels")]

        public void VerifyTheChargesAreInvoicedOnlyWhenItIsPrintedFirstTimeForBagLabels()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);

            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickPrintSelected();
            printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);

            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyThatIfABagLabelRowIsSelectedAndThePrintCountIsZeroThenItIsNotInvoicedAndLabelCannotBeClosed")]

        public void VerifyThatIfABagLabelRowIsSelectedAndThePrintCountIsZeroThenItIsNotInvoicedAndLabelCannotBeClosed()
        {
            var labelinfo = DataHelper.InsertActiveBagLabel();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelinfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickInvoiceAndCloseButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("No", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Invoiced));
        }


        [TestCase(TestName = "VerifyThatPrintedCheckboxIsDisplayedInViewBagLabelsPage.")]
        [Category("232290")]
        public void VerifyThatPrintedCheckboxIsDisplayedInViewBagLabelsPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsPrintedCheckBoxExist(), "Printed Check Box is not Dispalyed");

        }

        [TestCase("Active", TestName = "VerifyWhenPrintedCheckBoxIsSelectedBagLabelsWithPrintCountGreaterthanOneAreShown_Active")]
        [TestCase("Pending", TestName = "VerifyWhenPrintedCheckBoxIsSelectedBagLabelsWithPrintCountGreaterthanOneAreShown_Pending")]
        [TestCase("Duplicate", TestName = "VerifyWhenPrintedCheckBoxIsSelectedBagLabelsWithPrintCountGreaterthanOneAreShown_Duplicate")]
        [TestCase("Closed", TestName = "VerifyWhenPrintedCheckBoxIsSelectedBagLabelsWithPrintCountGreaterthanOneAreShown_Closed")]
        [TestCase("Void", TestName = "VerifyWhenPrintedCheckBoxIsSelectedBagLabelsWithPrintCountGreaterthanOneAreShown_Void")]
        [Category("233024"), Category("233118"), Category("233122"), Category("233124"), Category("233126")]

        public void VerifyWhenPrintedCheckBoxIsSelectedBagLabelsWithPrintCountGreaterthanOneAreShown(string labelStatusType)
        {
            var label3 = DataHelper.GetRandomLabel(false);
            var label2 = DataHelper.GetRandomLabel(false);
            var label1 = DataHelper.GetRandomLabel(false);
            var label4 = DataHelper.GetRandomLabel(false);

            int lblStatusType = 0;
            switch (labelStatusType)
            {
                case "Active":
                    lblStatusType = LabelStatusType.Active;
                    break;
                case "Duplicate":
                    lblStatusType = LabelStatusType.Duplicate;
                    break;
                case "Pending":
                    lblStatusType = LabelStatusType.Pending;
                    break;
                case "Void":
                    lblStatusType = LabelStatusType.Void;
                    break;
                case "Closed":
                    lblStatusType = LabelStatusType.Closed;
                    break;
                default:
                    lblStatusType = LabelStatusType.Active;
                    break;
            }

            label1.LabelStatusTypeId = label2.LabelStatusTypeId = label3.LabelStatusTypeId = label4.LabelStatusTypeId = lblStatusType;

            label1.PrintCount = 1;
            label2.PrintCount = 5;
            label3.PrintCount = 15;
            label4.PrintCount = 0;

            label1.IsPrinted = true;
            label2.IsPrinted = true;
            label3.IsPrinted = true;
            label4.IsPrinted = false;

            label1 = DataHelper.InsertLabel(label1);
            label2 = DataHelper.InsertLabel(label2);
            label3 = DataHelper.InsertLabel(label3);
            label4 = DataHelper.InsertLabel(label4);

            var allLabels = label1.VIN + " " + label2.VIN + " " + label3.VIN + " " + label4.VIN;

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickPrintedCheckbox();

            switch (labelStatusType)
            {
                case "Active":
                    viewBagLabelPage.ClickActiveCheckbox();
                    break;
                case "Duplicate":
                    viewBagLabelPage.ClickDuplicateCheckbox();
                    break;
                case "Pending":
                    viewBagLabelPage.ClickPendingCheckbox();
                    break;
                case "Void":
                    viewBagLabelPage.ClickVoidCheckbox();
                    break;
                case "Closed":
                    viewBagLabelPage.ClickClosedCheckbox();
                    break;
                default:
                    viewBagLabelPage.ClickActiveCheckbox();
                    break;
            }

            viewBagLabelPage.EnterSearchTextField(allLabels);
            viewBagLabelPage.ClickSearchButton();

            var itemsFromKendoGrid = viewBagLabelPage.KendoGrid.GetColumnDataAsList(3);

            Assert.IsTrue(itemsFromKendoGrid.Contains(label1.VIN));
            Assert.IsTrue(itemsFromKendoGrid.Contains(label2.VIN));
            Assert.IsTrue(itemsFromKendoGrid.Contains(label3.VIN));
            Assert.IsFalse(itemsFromKendoGrid.Contains(label4.VIN));
        }

        [TestCase(TestName = "VerifyViewBagLabelsPageDateRangeFilterPlaceholderHelperTextIsUpdatedWithTheCurrentDateFormat(mmddyyyy)")]
        [Category("233297")]
        public void VerifyViewBagLabelsPageDateRangeFilterPlaceholderHelperTextIsUpdatedWithTheCurrentDateFormat()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            DateTime dt;
            Assert.IsTrue(DateTime.TryParseExact(viewBagLabelPage.GetEndDateText(), "MM/dd/yyyy hh:mm tt", CultureInfo.InvariantCulture.DateTimeFormat,
                DateTimeStyles.AllowWhiteSpaces, out dt), "End Date time not in expected format.");

        }


        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyAdminUserCanCreditChargesOnOpenInvoice")]
        [Category("230364")]
        public void VerifyAdminUsersCanCreditChargesOnOpenInvoice(string user,string password)
        {
            var labelInfo = DataHelper.InsertActiveBagLabel(printLabel:true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user,password);

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();
            viewBagLabelPage.ClickRefreshButton();
            viewBagLabelPage.WaitForKendoReadyState();
            
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCreditButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Credits applied for selected labels", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));

            viewBagLabelPage.WaitForKendoReadyState();
            viewBagLabelPage.ClickRefreshButton();

            Assert.AreEqual("No", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Invoiced));
            Assert.AreEqual("", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.TotalAmount));
            Assert.AreEqual("", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.DebitCredit));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyAdminUserCanCreditChargesOnAClosedInvoice")]
        [Category("230365")]
        public void VerifyAdminUserCanCreditChargesOnAClosedInvoice(string user, string password)
        {
            var labelInfo = DataHelper.InsertActiveBagLabel(printLabel: true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            viewBagLabelPage.WaitForKendoReadyState();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();
            viewInvoicesPage.ClickCloseInvoiceButton();
            viewInvoicesPage.ClickConfirmCloseInvoiceButton();

            viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCreditButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Credits applied for selected labels", viewBagLabelPage.GetNotificationMessageText(NotificationType.Success));
            viewBagLabelPage.WaitForKendoReadyState();
            viewBagLabelPage.ClickRefreshButton();

            Assert.AreNotEqual("", viewBagLabelPage.KendoGrid.GetDataCellText(1, BagLabelPageColumnNumbers.TotalAmount));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="password"></param>
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyAdminUserCanCreditChargesNotOnAnInvoiceToVoidThem")]
        [Category("230366")]
        public void VerifyAdminUserCanCreditChargesNotOnAnInvoiceToVoidThem(string user, string password)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCreditButton();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            
            viewBagLabelPage.ClickRefreshButton();
            viewBagLabelPage.WaitForKendoReadyState();
            Assert.AreEqual("No", viewBagLabelPage.KendoGrid.GetDataCellText (1, BagLabelPageColumnNumbers.Invoiced  ), "Invoiced column");
            Assert.AreEqual(string.Empty, viewBagLabelPage.KendoGrid.GetDataCellText(1, BagLabelPageColumnNumbers.TotalAmount), "Total amount");
        }

        [TestCase(TestName = "VerifyInvoicedColumnIsAddedInViewBagLabelsPage")]
        [Category("232230")]
        public void VerifyInvoicedColumnIsAddedInViewBagLabelsPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

           // viewBagLabelPage.KendoGrid.ScrollColumnToView(BagLabelPageColumnNumbers.Invoiced);
            var allColumns = viewBagLabelPage.KendoGrid.GetAllHeadersTextList();
            Assert.IsTrue(allColumns.Contains("Invoiced"));
        }


        [TestCase(TestName = "VerifyThatWhenInvoice_IdIsZeroOrNullAndVoidFlagIsZeroTheInvoicedFlagShouldBeNoInViewBagLabelsPage")]
        [Category("232232")]
        public void VerifyThatWhenInvoice_IdIsZeroOrNullAndVoidFlagIsZeroTheInvoicedFlagShouldBeNoInViewBagLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel(false);
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(lbl.VIN);

            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            viewBagLabelPage.Navigate();
            viewBagLabelPage.EnterSearchTextField(lbl.VIN);
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickSearchButton();

            Assert.AreEqual(1, SQLHelper.ExecuteScalar(string.Format(StandardQueries.InvoiceIdNullAndVoidIsFalse, lbl.LabelId)));
            Assert.AreEqual("No", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyThatWhenInvoice_IdHasChargesAndFlagIsZeroTheInvoicedFlagShouldBeYesInViewBagLabelsPage")]
        [Category("232240")]
        public void VerifyThatWhenInvoice_IdHasChargesAndFlagIsZeroTheInvoicedFlagShouldBeYesInViewBagLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel(false);
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(lbl.VIN);

            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();
            viewBagLabelPage.WaitForKendoReadyState(30);

            Assert.AreEqual(1, SQLHelper.ExecuteScalar(string.Format(StandardQueries.InvoiceIdNotNullAndVoidIsFalse, lbl.LabelId)));
            Assert.AreEqual("Yes", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyThatWhenAnInvoicedLabelIsUpdatedToPendingTheInvoicedFlagShouldBeNoInViewBagLabelsPage")]
        [Category("232701")]
        public void VerifyThatWhenAnInvoicedLabelIsUpdatedToPendingTheInvoicedFlagShouldBeNoInViewBagLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel(unitLabel:false);
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickClosedCheckbox(true);

            viewBagLabelPage.EnterSearchTextField(lbl.VIN);

            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickInvoiceAndCloseButton();
            viewBagLabelPage.WaitForKendoReadyState(30);

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.SelectStatusFromDropdown(LabelStatus.Pending);
            viewBagLabelPage.ClickUpdateButton();
            viewBagLabelPage.ClickExitButton();
            viewBagLabelPage.WaitForKendoReadyState();
            Assert.AreEqual("No", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyThatWhenAnInvoicedLabelIsCreditedTheInvoicedFlagShouldBeUpdatedToNoInViewBagLabelsPage")]
        [ Category("232721")]
        public void VerifyThatWhenAnInvoicedLabelIsCreditedTheInvoicedFlagShouldBeUpdatedToNoInViewBagLabelsPage()
        {
            var lbl = DataHelper.GetRandomLabel(false);
            lbl.LabelStatusTypeId = LabelStatusType.Active;
            lbl = DataHelper.InsertLabel(lbl, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickClosedCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(lbl.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();
            viewBagLabelPage.WaitForKendoReadyState(30);
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCreditButton();
            viewBagLabelPage.WaitForKendoReadyState(30);
            Assert.AreEqual("Credit", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.DebitCredit), "Bug");
        }

        [TestCase(TestName = "VerifyWhetherTheLabelIsSuccessfullyPrintedFromSelectedPrinter")]
        [Category("232258")]
        public void VerifyWhetherTheLabelIsSuccessfullyPrintedFromSelectedPrinter()
        {
            var labelInfo = DataHelper.InsertActiveBagLabel();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.WaitForKendoReadyState();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyWhetherThePrintFirstIsSuccessfulUsingTheSelectedPrinter")]
        [Category("232259")]
        public void VerifyWhetherThePrintFirstIsSuccessfulUsingTheSelectedPrinter()
        {
            var labelInfo = DataHelper.InsertActiveBagLabel();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.WaitForKendoReadyState();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));


            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();
            Assert.AreEqual("Completed", logPage.StatusInLogs());
            Assert.AreEqual("Print Bag Labels", logPage.GetProcessName());
            Assert.IsTrue(logPage.GetFileNameInLogs().Length > 5);
            logPage.ClickFileNameInLogs();
            logPage.VerifyFileExportValidationDisplayed(PrintLabelsValidations.RequestToDownload);
        }

        [TestCase(TestName = "VerifyWhetherThePrintAllIsSuccessfulUsingSelectedPrinter")]
        [Category("232260")]
        public void VerifyWhetherThePrintAllIsSuccessfulUsingSelectedPrinter()
        {
            var labelInfo = DataHelper.InsertActiveBagLabel();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.WaitForKendoReadyState();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintAllBagLabels();

            Assert.IsTrue(viewBagLabelPage.IsConfirmPrintPopup());
            viewBagLabelPage.ClickContinueButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            //Assert.AreEqual("Print request created successfully", viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            //Assert.AreEqual("Print Bag Labels is completed \tTotal:1 Success:1 \t Warning:0 Errors:0",viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));
            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            logPage.ClickOnLogsRefreshButton();
            logPage.WaitForKendoReadyState();
            Assert.AreEqual("Completed", logPage.StatusInLogs(), "BUG: Print label is not showing up in Logs");
            Assert.AreEqual("Print Bag Labels", logPage.GetProcessName());
            Assert.IsTrue(logPage.GetFileNameInLogs().Length > 5);
            logPage.ClickFileNameInLogs();
            logPage.VerifyFileExportValidationDisplayed(PrintLabelsValidations.RequestToDownload);
        }

        [TestCase(1, new int[] { 1, 2, 3, 4, 5 ,6 , 7, 8, 9, 10, 11,12}, TestName = "VerifyWhetherThePrintRemainingIsSuccessfulWithTheSelectedPrinter")]
        [Category("232264")]
        public void VerifyWhetherThePrintRemainingIsSuccessfulWithTheSelectedPrinter(int pageNumber, int[] rowNumbers)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            while (viewBagLabelPage.KendoGrid.GetCurrentPageNumberSelection() < pageNumber)
            {
                viewBagLabelPage.KendoGrid.ClickNextPageArrow();
            }
            foreach (var rowNumber in rowNumbers)
            {
                viewBagLabelPage.ClickDataCheckmarkByRowNumber(rowNumber);
            }

            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.WaitForKendoReadyState();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));

            printPreviewPage.ClickPrintRemainingBagLabels();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            logPage.ClickOnLogsRefreshButton();
            logPage.WaitForKendoReadyState();
            Assert.AreEqual("Completed", logPage.StatusInLogs());
            Assert.AreEqual("Print Bag Labels", logPage.GetProcessName());
            Assert.IsTrue(logPage.GetFileNameInLogs().Length > 5);
            logPage.ClickFileNameInLogs();
            logPage.VerifyFileExportValidationDisplayed(PrintLabelsValidations.RequestToDownload);
        }

        [TestCase(TestName = "VerifyThatPintJobLogIsDisplayedInLogsAndNotificationsWhenTheJobIsCompleted")]
        [Category("232274")]
        public void VerifyThatPintJobLogIsDisplayedInLogsAndNotificationsWhenTheJobIsCompleted()
        {
            var labelInfo = DataHelper.InsertActiveBagLabel();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.WaitForKendoReadyState();

            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintFirstBagLabel();

            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();
            logPage.ClickOnLogsRefreshButton();
            viewBagLabelPage.WaitForKendoReadyState();
            Assert.AreEqual("Completed", logPage.StatusInLogs());
            Assert.AreEqual("Print Bag Labels", logPage.GetProcessName());
            Assert.IsTrue(logPage.GetFileNameInLogs().Length > 5);
            logPage.ClickFileNameInLogs();
            logPage.VerifyFileExportValidationDisplayed(PrintLabelsValidations.RequestToDownload);

            viewBagLabelPage.ClickNotificationsIcon();
            viewBagLabelPage.VerifyPrintLabelsInNotifications();
        }

        [TestCase(TestName = "VerifyThatHorizontalPositionVerticalPositionTextboxIsPresentInViewBagLabelsPage")]
        [Category("232092")]
        public void VerifyThatHorizontalPositionVerticalPositionTextboxIsPresentInViewBagLabelsPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            viewBagLabelPage.WaitForKendoReadyState();

            Assert.IsTrue(viewBagLabelPage.IsHorizontalPositionTextboxDisplayed());
            Assert.IsTrue(viewBagLabelPage.IsVerticalPositionTextboxDisplayed());
        }

        [TestCase(TestName = "VerifyThatPrintFirstPrintRemainingandPrintAllButtonIsPresentInViewBagLabelsPage.")]
        [Category("232094")]

        public void VerifyThatPrintFirstPrintRemainingandPrintAllButtonIsPresentInViewBagLabelsPage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            var printpreview = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);

            Assert.IsTrue(printpreview.IsPrintFirstBagLabelButtonDisplayed());
            Assert.IsTrue(printpreview.IsPrintFirstRemaningBagLabelButtonDisplayed());
            Assert.IsTrue(printpreview.IsPrintAllBagLabelButtonDisplayed());
        }

        [TestCase(TestName = "VerifyThatSaveAndGoBackButtonIsPresentInViewBagLabelspage")]
        [Category("234800")]
        public void VerifyThatSaveAndGoBackButtonIsPresentInViewBagLabelspage()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();
            var printpreview = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);

            Assert.IsTrue(printpreview.IsSaveBagLabelButtonDisplayed());
        }

        [TestCase(TestName = "VerifyThatWhenUserClickOnGoBackButtonUserShouldBeNavigatedToViewBagLabelsPage")]
        [Category("234928")]
        public void VerifyThatWhenUserClickOnGoBackButtonUserShouldBeNavigatedToViewBagLabelsPage()
        {
            var lbl = DataHelper.InsertLabel(false, LabelStatusTypeEnum.Active);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickPrintSelected();

            var printpreview = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printpreview.ClickGoBackBagLabelButton();

            viewBagLabelPage.Navigate();
            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());

        }

        [TestCase(TestName ="VerifyMoveSelectedButtonIsDisplayed")]
        [Category("239627")]
        public void VerifyMoveSelectedButtonIsDisplayed()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsMoveSelectedButtonDisplayed());
        }

        [TestCase(TestName = "VerifyErrorMessageAsErrorPleaseSelectAtLeastOneLabelToMoveWithOutSelectingRecordsWhile")]
        [Category("239630")]
        public void VerifyErrorMessageAsErrorPleaseSelectAtLeastOneLabelToMoveWithOutSelectingRecordsWhile()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickMoveSelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select at least one label to move", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyMoveSelectedButton")]
        [Category("239638")]
        public void VerifyMoveSelectedButton()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            var VinNumberForFL = viewBagLabelPage.KendoGrid.GetDataCellText(1,3);
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickMoveSelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsMoveLabelsModalDisplayed());

            viewBagLabelPage.ClickProcessingLocationDropdown();
            viewBagLabelPage.SelectProcessingLocationOfficeValues("Sun City, AZ");
            viewBagLabelPage.ClickMoveLabelsSaveButton();

            viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success);
            // Assert.AreEqual("Labels Moved Successfully", viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Success));

            viewBagLabelPage.Border.SelectHeaderProcessingLocationByValue(ProcessingLocations.SunCityAz);
            viewBagLabelPage.Border.ClickHeaderApplyButton();
            viewBagLabelPage.Navigate();

            viewBagLabelPage.EnterSearchTextField(VinNumberForFL);
            viewBagLabelPage.ClickSearchButton();
            var VinNumberForAZ = viewBagLabelPage.KendoGrid.GetDataCellText(1, 3);
            viewBagLabelPage.KendoGrid.WaitForKendoReadyState();
            Assert.AreEqual(VinNumberForFL, VinNumberForAZ);
        }

        [TestCase(TestName = "VerifyCancelButtonInMoveLabelPopup")]
        [Category("239640")]

        public void VerifyCancelButtonInMoveLabelPopup()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickMoveSelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsMoveLabelsModalDisplayed());
            viewBagLabelPage.ClickMoveLabelsCancelButton();

            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "VerifySelectProcessingOfficeDropdown")]
        [Category("240529")]

        public void VerifySelectProcessingOfficeDropdown()
        {
            var lbl = DataHelper.InsertLabel(false, LabelStatusTypeEnum.Active);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickMoveSelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsMoveLabelsModalDisplayed());
            Assert.IsTrue(viewBagLabelPage.IsProcessigLocationDropdownDisplayed());
            viewBagLabelPage.ClickProcessingLocationDropdown();

            var expectedList = new List<string>() { "Sunshine Bradenton, FL", "Sun City, AZ", "San Antonio TX" };
            Assert.AreEqual(expectedList, viewBagLabelPage.ProcessingLocationDropDownValuesList());
        }

        [TestCase(TestName = "VerifyIsCopySelectedButtonDisplayed")]
        [Category("240718")]

        public void VerifyIsCopySelectedButtonDisplayed()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsCopySelectedButtonDisplayed());
        }

        [TestCase(TestName = "VerifyErrorMessageAsPleaseSelectAtLeastOneVoidOrClosedRecord")]
        [Category("240719")]

        public void VerifyErrorMessageAsPleaseSelectAtLeastOneVoidOrClosedRecord()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select at least one void or closed label to copy", viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyErrorMessageAsPleaseSelectVoidOrClosedLabelToCopy")]
        [Category("240720")]

        public void VerifyErrorMessageAsPleaseSelectVoidOrClosedLabelToCopy()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Error: Please select void or closed label to copy",viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyExitButtonInCopySelectedButton")]
        [Category("240732")]

        public void VerifyExitButtonInCopySelectedButton()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickVoidCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsCopySelectedModalDisplayed());

            viewBagLabelPage.ClickCopyLabelsExitButton();
            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());
        }

        [TestCase(TestName = "VerifyViewLogsOptionInCopyLabelsPopup")]
        [Category("240734")]

        public void VerifyViewLogsOptionInCopyLabelsPopup()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickVoidCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsCopySelectedModalDisplayed());

            viewBagLabelPage.ClickViewLogLinkInCopyLabelsModal();
            Assert.IsTrue(viewBagLabelPage.IsCopyLabelsLogDisplayed());
        }

        [TestCase(TestName = "VerifyCopySelected")]
        [Category("240721")]

        public void VerifyCopySelected()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickVoidCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();
            viewBagLabelPage.ClickSearchButton();

            var VinNumber = viewBagLabelPage.KendoGrid.GetDataCellText(1, 3);
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(3);
            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsCopySelectedModalDisplayed());
            Assert.AreEqual(viewBagLabelPage.TotalCopyLabelsCount(), viewBagLabelPage.PassedCopyLabelsCount());
            viewBagLabelPage.ClickCopyLabelsExitButton();
            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());

            viewBagLabelPage.EnterSearchTextField(VinNumber);
            viewBagLabelPage.ClickSearchButton();
            var VinNumberForActiveLabel = viewBagLabelPage.KendoGrid.GetDataCellText(1, 3);
            Assert.AreEqual(VinNumber,VinNumberForActiveLabel);
        }

        [TestCase(TestName = "VerifyIfAlreadyRecordIsCopiedAndCreatedRecordInActiveStatusUserShouldBeUnableToCopy")]
        [Category("240735")]

        public void VerifyIfAlreadyRecordIsCopiedAndCreatedRecordInActiveStatusUserShouldBeUnableToCopy()
        {
            var labelInfo = DataHelper.GetRandomLabel(false);
            labelInfo.LabelStatusTypeId = LabelStatusType.Closed;
            labelInfo = DataHelper.InsertLabel(labelInfo);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickClosedCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsCopySelectedModalDisplayed());
            Assert.AreEqual(viewBagLabelPage.TotalCopyLabelsCount(), viewBagLabelPage.PassedCopyLabelsCount());
            viewBagLabelPage.ClickCopyLabelsExitButton();
            Assert.IsTrue(viewBagLabelPage.IsViewBagLabelsGridDisplayed());

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickCopySelectedButton();
            Assert.IsTrue(viewBagLabelPage.IsCopySelectedModalDisplayed());
            Assert.AreEqual(viewBagLabelPage.TotalCopyLabelsCount(), viewBagLabelPage.FailedCopyLabelsCount());
        }

        [TestCase(TestName = "VerifyUserCanPrintremainingBagLabelsIfMoreThan10labels")]
        [Category("240309")]
        public void VerifyUserCanPrintremainingBagLabelsIfMoreThan10labels ()
        {
            var numberOfLabels = 10;

            Label tmpLabel;
            var listOfLabels = new List<Label>();
            for (int i = 0; i < numberOfLabels; i++)
            {
                tmpLabel = DataHelper.GetRandomLabel(unitLabel: false, statueType: LabelStatusTypeEnum.Active);
                listOfLabels.Add(DataHelper.InsertLabel(tmpLabel));
            }

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            foreach (var lbl in listOfLabels)
                viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.KendoGrid.SelectAllGridCheckboxes(true);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintRemainingBagLabels();

            printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Success);
            Assert.AreEqual(PrintPrivewPageMessages.PrintRequestSent, printPreviewPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyUserCanNotPrintRemainingBagLabelsIfLessThan10labels")]
        [Category("240309")]
        public void VerifyUserCanNotPrintRemainingBagLabelsIfLessThan10labels()
        {
            var numberOfLabels = 10;

            Label tmpLabel;
            var listOfLabels = new List<Label>();
            for (int i = 0; i < numberOfLabels; i++)
            {
                tmpLabel = DataHelper.GetRandomLabel(unitLabel: false, statueType: LabelStatusTypeEnum.Active);
                listOfLabels.Add(DataHelper.InsertLabel(tmpLabel));
            }

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.UnselectAllCheckbox();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            foreach (var lbl in listOfLabels)
                viewUnitLabelPage.EnterSearchTextField(lbl.VIN);

            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.KendoGrid.SelectAllGridCheckboxes(true);
            viewUnitLabelPage.ClickPrintSelected();
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            printPreviewPage.ClickPrintRemainingBagLabels();

            printPreviewPage.IsNotificationMessageDisplayed(NotificationType.Error);
            Assert.AreEqual(PrintPrivewPageMessages.NoRecordsToPrint, printPreviewPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "ViewBagLabels_EnsureThatLabelStatusChangedInDropdownShouldBeReflectedInstantlyBeforeSaving")]

        public void EnsureThatLabelStatusChangedInDropdownShouldBeReflectedInstantlyBeforeSaving()
        {
            var labelInfo = DataHelper.GetRandomLabel(false);
            labelInfo.LabelStatusTypeId = LabelStatusType.Pending;
            labelInfo = DataHelper.InsertLabel(labelInfo);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickPendingCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            //viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.LabelStatusFieldOption("Active");
            Assert.AreEqual(viewBagLabelPage.KendoGrid.GetDataCellText(1,2),"Active");
            viewBagLabelPage.ClickSaveChangesbutton();

            Assert.IsTrue(viewBagLabelPage.IsSaveChangesSuccessWindowDisplayed());
        }

        [TestCase(TestName = "EnsureThatNotificationsShouldBeDisplayedAfterExportAllBackendJobIsCompleted")]
        [Category("251512")]

        public void EnsureThatNotificationsShouldBeDisplayedAfterExportAllBackendJobIsCompleted()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.UnselectAllCheckbox();
            viewBagLabelPage.ClickActiveCheckbox();
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickExportAllButtonFlow();
            Assert.IsTrue(Extensions.WaitForAndRemoveSuccessPopup(Driver));
            viewBagLabelPage.VerifyExportCompletionMessage(ExportFileValidations.ExportCompleted);

            var logPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
            logPage.Navigate();

            Assert.AreEqual("Export Labels", logPage.KendoGrid.GetDataCellText(1, 2));
            Assert.AreEqual("Export", logPage.KendoGrid.GetDataCellText(1, 3));
            Assert.AreEqual("Completed", logPage.KendoGrid.GetDataCellText(1, 9));

        }

        [TestCase(TestName = "VerifyOrderBySearchListCheckBoxIsAvailableOnTheGrid")]
        [Category("265667")]
        public void VerifyOrderBySearchListCheckBoxIsAvailableOnTheGrid()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            Assert.IsTrue(viewBagLabelPage.IsOrderBySearchListExist());
            Assert.IsFalse(viewBagLabelPage.IsOrderBySearchListSelected());
        }

        [TestCase(3, 6, TestName = "VerifySearchResultsAreOrderBySearchListOnVinTab_FewItems")]
        [TestCase(20, 30, TestName = "VerifySearchResultsAreOrderBySearchListOnVinTab_MoreItems")]
        [Category("265674")]
        public void VerifySearchResultsAreOrderBySearchListOnVinTab(int minCount, int maxCount)
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.SelectAllFilterCheckBoxes();
            viewBagLabelPage.ClickOrderBySearchListCheckbox(true);
            viewBagLabelPage.ClickSearchButton();

            var totalrows = viewBagLabelPage.KendoGrid.GetNumberOfDataRows(1, true);
            var itemstopick = Extensions.GetRandomNumber(minCount, maxCount);

            if (itemstopick > totalrows)
            {
                itemstopick = totalrows;
            }

            var searchItems = new List<string>();
            var searchResults = new List<string>();
            for (int i = 1; i <= itemstopick; i++)
            {
                searchItems.Add(viewBagLabelPage.KendoGrid.GetDataCellText(i, BagLabelPageColumnNumbers.Vin).Trim());
            }

            searchItems.Sort();

            viewBagLabelPage.EnterSearchText(searchItems);
            viewBagLabelPage.ClickSearchButton();

            Assert.AreEqual(itemstopick, viewBagLabelPage.KendoGrid.GetNumberOfDataRows(1, true));

            for (int i = 1; i <= itemstopick; i++)
            {
                searchResults.Add(viewBagLabelPage.KendoGrid.GetDataCellText(i, BagLabelPageColumnNumbers.Vin).Trim());
            }

            Assert.AreEqual(searchItems, searchResults);
        }

        [TestCase(TestName = "VerifyOrderBySearchListCheckBoxIsPersistent")]
        [Category("265676")]
        public void VerifyOrderBySearchListCheckBoxIsPersistent()
        {
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickOrderBySearchListCheckbox(true);

            var addLabelPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelPage.Navigate();

            viewBagLabelPage.Navigate();
            Assert.IsTrue(viewBagLabelPage.IsOrderBySearchListSelected());

            viewBagLabelPage.ClickOrderBySearchListCheckbox(false);

            addLabelPage.Navigate();

            viewBagLabelPage.Navigate();
            Assert.IsFalse(viewBagLabelPage.IsOrderBySearchListSelected());
        }

        [TestCase(TestName = "VerifySearchResultsAreOrderBySearchListOnBatchTab")]
        [Category("265675")]
        public void VerifySearchResultsAreOrderBySearchListOnBatchTab()
        {
            var batchNum = DateTime.Now.ToString("Mdyyhhmmss");
            var lbl1 = DataHelper.GetRandomLabel(false);
            lbl1.BatchNumber = batchNum + "1q2s";
            var lbl2 = DataHelper.GetRandomLabel(false);
            lbl2.BatchNumber = batchNum + "5rPs";
            var lbl3 = DataHelper.GetRandomLabel(false);
            lbl3.BatchNumber = batchNum + "1qPs";
            var lbl4 = DataHelper.GetRandomLabel(false);
            lbl4.BatchNumber = batchNum + "3qPs";
            var lbl5 = DataHelper.GetRandomLabel(false);
            lbl5.BatchNumber = batchNum + "2qP1";

            DataHelper.InsertLabel(lbl1);
            DataHelper.InsertLabel(lbl2);
            DataHelper.InsertLabel(lbl3);
            DataHelper.InsertLabel(lbl4);
            DataHelper.InsertLabel(lbl5);

            var searchItems = new List<string> { lbl1.BatchNumber, lbl2.BatchNumber, lbl3.BatchNumber, lbl4.BatchNumber, lbl5.BatchNumber };
            var searchResults = new List<string>();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.SelectAllFilterCheckBoxes();
            viewBagLabelPage.ClickOrderBySearchListCheckbox(true);

            viewBagLabelPage.ClickBatchTab();

            viewBagLabelPage.EnterSearchText(searchItems);
            viewBagLabelPage.ClickSearchButton();

            Assert.AreEqual(searchItems.Count, viewBagLabelPage.KendoGrid.GetNumberOfDataRows(1, true));

            for (int i = 1; i <= searchItems.Count; i++)
            {
                searchResults.Add(viewBagLabelPage.KendoGrid.GetDataCellText(i, BagLabelPageColumnNumbers.BatchNumber).Trim());
            }

            Assert.AreEqual(searchItems, searchResults);
        }
    }
}
