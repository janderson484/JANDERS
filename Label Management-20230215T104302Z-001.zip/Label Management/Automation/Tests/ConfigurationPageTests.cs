using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ConfigurationPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        AddLabelsPageObj addLabelsPage;
        ConfigurationPageObj configurationPage;
        string importProfileName;

        [TestCase(TestName = "1_ImportLayout_ConfigurationPage_PageRender")]
        public void ImportLayout_ConfigurationPage_PageRender()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var pageLoaded = configurationPage.IsPageLoaded();
            if (pageLoaded)
            {
                Assert.IsTrue(pageLoaded);
            }
            else
            {
                Assert.Fail("1_ImportLayout_ConfigurationPage_PageRender Test Failed");
            }
        }

        [TestCase(TestName = "2_ImportLayout_ConfigurationPage_SortGrid")]
        public void ImportLayout_ConfigurationPage_SortGrid()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var pageLoaded = configurationPage.IsPageLoaded();
            if (pageLoaded)
            {
                // Get Column Count
                var headerCount = configurationPage.KendoGrid.GetAllHeaderList().Count;

                // Sort each column in both directions
                for (var headerNumber = 1; headerNumber <= headerCount; headerNumber++)
                {
                    // Ascending
                    configurationPage.KendoGrid.ClickSortColumnByColumnNumber(headerNumber, 1, 10);
                    // Descending
                    configurationPage.KendoGrid.ClickSortColumnByColumnNumber(headerNumber, 1, 10);
                }
            }
            else
            {
                Assert.Fail("2_ImportLayout_ConfigurationPage_SortGrid Test Failed");
            }
        }

        [TestCase(TestName = "3_ImportLayout_ConfigurationPage_ToggleActive")]
        public void ImportLayout_ConfigurationPage_ToggleActive()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var pageLoaded = configurationPage.IsPageLoaded();
            if (pageLoaded)
            {
                var result = configurationPage.ToggleImportLayoutRecords();
                Assert.IsTrue(result);
            }
            else
            {
                Assert.Fail("3_ImportLayout_ConfigurationPage_ToggleActive Test Failed");
            }
        }

        [TestCase(TestName = "4_ImportLayout_ConfigurationPage_Edit")]
        public void ImportLayout_ConfigurationPage_Edit()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var pageLoaded = configurationPage.IsPageLoaded();
            if (pageLoaded)
            {
                var result = configurationPage.EditImportLayoutConfigurationRecord();
                Assert.IsTrue(result);
            }
            else
            {
                Assert.Fail("4_ImportLayout_ConfigurationPage_Edit Test Failed");
            }
        }

        [TestCase(TestName = "5_ImportLayout_ConfigurationPage_Add")]
        public void ImportLayout_ConfigurationPage_Add()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var pageLoaded = configurationPage.IsPageLoaded();
            if (pageLoaded)
            {
                var result = configurationPage.AddImportLayoutConfigurationRecord();
                Assert.IsTrue(result);
            }
            else
            {
                Assert.Fail("4_ImportLayout_ConfigurationPage_Edit Test Failed");
            }
        }

        [TestCase(TestName = "6_ImportLayout_ConfigurationPage_AddLayoutNoVin_ExpectFail")]
        public void ImportLayout_ConfigurationPage_AddLayoutNoVin_ExpectFail()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var pageLoaded = configurationPage.IsPageLoaded();
            if (pageLoaded)
            {
                var result = configurationPage.AddImportLayoutConfigurationRecordWithNoVin();
                Assert.IsTrue(result);

                Assert.IsTrue(configurationPage.IsNoVinErrorNotificationDisplayed());
            }
            else
            {
                Assert.Fail("6_ImportLayout_ConfigurationPage_AddLayoutNoVin_ExpectFail");
            }
        }

        [TestCase(TestName = "ProcessingLocationsColumnAddedInImportLayoutsGrid.")]
        [Category("240386")]
        public void ProcessingLocationsColumnAddedInImportLayoutsGrid()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();
            
            var headers = configurationPage.KendoGrid.GetAllHeadersTextList(1);

            Assert.IsTrue(headers.Contains("Processing Location"));
        }

        [TestCase(TestName = "ClientAndLocationsDropdownValuesDisplayedInAddAndEditModal")]
        [Category("240390")]
        public void ClientAndLocationsDropdownValuesDisplayedInAddAndEditModal()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            configurationPage.ClickAddNewImportLayoutButton();

            Assert.IsTrue(configurationPage.VerifyProcessingLocationCodeDropdownValues());
            Assert.IsTrue(configurationPage.VerifyClientCodeDropdownValues());

            configurationPage.CloseModal();
            configurationPage.KendoGrid.WaitForKendoReadyState();

            configurationPage.KendoGrid.ClickDataCellByRowAndColumnNumber(1, 2);
            configurationPage.ClickEditSelectedRowButton();
            Assert.IsTrue(configurationPage.VerifyProcessingLocationCodeDropdownValues());
            Assert.IsTrue(configurationPage.VerifyClientCodeDropdownValues());

            configurationPage.CloseModal();
        }

        public string AssertImportProfileOnClientAndLocation(List<ClientProcessingLocationExpectation> allScenarios)
        {
            StringBuilder errors = new StringBuilder();
            foreach (var scenario in allScenarios)
            {
                addLabelsPage.Border.ChangeClientAndProcessingLocation(scenario.ClientCode, scenario.ProcLocation);
                addLabelsPage.WaitForPageRefresh();

                 if (addLabelsPage.IsImportProfileDropdownContainsProfile(importProfileName) != scenario.ShowProfile)
                {
                    errors.AppendLine(scenario.ClientCode + " ; " + scenario.ProcLocation + " expected: " + scenario.ShowProfile +
                        " Actual: " + !scenario.ShowProfile);
                }
            }

            return errors.ToString();
        }

        public class ClientProcessingLocationExpectation
        {
            public string ClientCode, ProcLocation;
            public bool ShowProfile;

            public ClientProcessingLocationExpectation(string client, string proc, bool expectedShow)
            {
                ClientCode = client;
                ProcLocation = proc;
                ShowProfile = expectedShow;
            }
        }

        [TestCase(TestName = "EnsureThatWhenAllValueIsSelectedFromClientAndLocationsTheImportLayoutShouldBeDisplayedToBothTheClients")]
        [Category("240396")]
        public void EnsureThatWhenAllValueIsSelectedFromClientAndLocationsTheImportLayoutShouldBeDisplayedToBothTheClients()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            
            configurationPage.Navigate();
            var proclocs = new List<string>() { "Select All"};
            var clients = new List<string>() { "Select All" };
            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();
            var allscenarios = new List<ClientProcessingLocationExpectation>();
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunCityAz, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunshineBradenton, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunshineBradenton, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunCityAz, true));

            var errors = AssertImportProfileOnClientAndLocation(allscenarios);

            Assert.IsTrue(string.IsNullOrEmpty(errors), errors);
        }

        [TestCase(TestName = "EnsureThatWhenASpecificClientAndLocationIsSelectedImportLayoutShouldBeDisplayedToTheSpecificClientAndLocation")]
        [Category("240536")]
        public void EnsureThatWhenASpecificClientAndLocationIsSelectedImportLayoutShouldBeDisplayedToTheSpecificClientAndLocation()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();
            var proclocs = new List<string>() { "Sunshine Bradenton, FL" };
            var clients = new List<string>() { "Hertz" };
            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            var allscenarios = new List<ClientProcessingLocationExpectation>();
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunCityAz, false));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunshineBradenton, false));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunshineBradenton, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunCityAz, false));

            var errors = AssertImportProfileOnClientAndLocation(allscenarios);

            Assert.IsTrue(string.IsNullOrEmpty(errors), errors);
            
        }

        [TestCase(TestName = "EnsureThatWhenAllClientsAndASpecificLocationIsSelectedTheImportLayoutShouldBeReflectedToTheSelectedOnes")]
        [Category("240537")]
        public void EnsureThatWhenAllClientsAndASpecificLocationIsSelectedTheImportLayoutShouldBeReflectedToTheSelectedOnes()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();
            var proclocs = new List<string>() { "Sunshine Bradenton, FL" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            var allscenarios = new List<ClientProcessingLocationExpectation>();
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunCityAz, false));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunshineBradenton, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunshineBradenton, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunCityAz, false));

            var errors = AssertImportProfileOnClientAndLocation(allscenarios);

            Assert.IsTrue(string.IsNullOrEmpty(errors), errors);
        }

        [TestCase(TestName = "EnsureThatWhenASpecificClientAndAllLocationsIsSelectedTheImportLayoutShouldBeDisplayedToAllLocationsOfTheClient")]
        [Category("240540")]
        public void EnsureThatWhenASpecificClientAndAllLocationsIsSelectedTheImportLayoutShouldBeDisplayedToAllLocationsOfTheClient()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();
            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Hertz" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            var allscenarios = new List<ClientProcessingLocationExpectation>();
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunCityAz, false));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Ehi, ProcessingLocations.SunshineBradenton, false));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunshineBradenton, true));
            allscenarios.Add(new ClientProcessingLocationExpectation(Clients.Hertz, ProcessingLocations.SunCityAz, true));

            var errors = AssertImportProfileOnClientAndLocation(allscenarios);

            Assert.IsTrue(string.IsNullOrEmpty(errors), errors);
        }

        [TestCase(TestName = "EnsureThatClientCodeAndProcessingLocationsColumnsInGridShouldDisplayAllTheValuesSelectedFromTheClientAndLocationsDropdown")]
        [Category("241802")]
        public void EnsureThatClientCodeAndProcessingLocationsColumnsInGridShouldDisplayAllTheValuesSelectedFromTheClientAndLocationsDropdown()
        {
            var configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();
            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1+ DateTime.Now.Millisecond % 2;
            string labelTypeString = labelType == 1 ? "Unit" : "Bag";

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            Assert.AreEqual(importProfileName, configurationPage.KendoGrid.GetDataCellText(1, 3, 1));
            Assert.AreEqual(labelTypeString, configurationPage.KendoGrid.GetDataCellText(1, 4, 1));
            Assert.AreEqual("All", configurationPage.KendoGrid.GetDataCellText(1, 5, 1));
            Assert.AreEqual("All", configurationPage.KendoGrid.GetDataCellText(1, 6, 1));
        }

        //[TestCase(TestName = "EnsureThatClientAndLocationDropdownShouldDisplayTheHeaderValueSelected")]
        [Category("EnsureThatClientAndLocationDropdownShouldDisplayTheHeaderValueSelected")]
        public void A241804()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();

            VerifyHeaderCodesWithDefaultCodes(Clients.Ehi, ProcessingLocations.SunCityAz);
            VerifyHeaderCodesWithDefaultCodes(Clients.Ehi, ProcessingLocations.SunshineBradenton);
            VerifyHeaderCodesWithDefaultCodes(Clients.Hertz, ProcessingLocations.SunCityAz);
            VerifyHeaderCodesWithDefaultCodes(Clients.Hertz, ProcessingLocations.SunshineBradenton);
        }

        public void VerifyHeaderCodesWithDefaultCodes(string clientCode, string processingLocation)
        {
            configurationPage.Border.ChangeClientAndProcessingLocation(clientCode, processingLocation);
            configurationPage.WaitForPageLoad();

            var headerClientCode = new List<string> { configurationPage.Border.GetHeaderClientCurrentText() };
            var headerProcessingLocation = new List<string> { configurationPage.Border.GetHeaderProcessingLocationCurrentText() };

            configurationPage.ClickAddNewImportLayoutButton();

            Assert.AreEqual(headerClientCode, configurationPage.GetSelectedClientCodes());
            Assert.AreEqual(headerProcessingLocation, configurationPage.GetSelectedProcessingLocations());
            configurationPage.CloseModal();
        }

        [TestCase(TestName = "EnsureThatAddingALabelIsSuccessfulIfTheVINSpecifiedIs1Character")]
        [Category("242901"), Category("242903"), Category("243135")]
        public void EnsureThatAddingALabelIsSuccessfulIfTheVINSpecifiedIs1Character()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            string labelTypeString = labelType == 1 ? "Unit" : "Bag";

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);

            var labelDataOver25 = Extensions.GetRandomString(DateTime.Now.Millisecond % 6 + 26).ToUpper();

            addLabelsPage.AddLabelData(labelDataOver25);
            addLabelsPage.ClickSubmitLabelsButton();
            var errMsg = "Error:The VIN: {0} can not be more than 25 characters long.";
            Assert.AreEqual(string.Format(errMsg, labelDataOver25), addLabelsPage.GetErrorNotificationMessage());
            addLabelsPage.ClickErrorNotificationOkButton();

            addLabelsPage.WaitForPageRefresh();

            addLabelsPage.ClickClearButton();

            //Testing with no text
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.AreEqual("Error:Must contain one record!", addLabelsPage.GetErrorNotificationMessage());
            addLabelsPage.ClickErrorNotificationOkButton();
            addLabelsPage.WaitForPageRefresh();

            var goodLabel = Extensions.GetRandomString(1 + DateTime.Now.Millisecond % 24);
            addLabelsPage.AddLabelData(goodLabel);
            addLabelsPage.ClickSubmitLabelsButton();
        }


        [TestCase(TestName = "VerifyImportLayoutWith2BlankColumnsInBeginning")]
        [Category("242914")]
        public void VerifyImportLayoutWith2BlankColumnsInBeginning()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };
            var fields = new List<string>() { "BLANK_COLUMN", "BLANK_COLUMN", "VIN" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, fields);

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);
            var goodLabel = Extensions.GetRandomString(1 + DateTime.Now.Millisecond % 24);

            addLabelsPage.AddLabelData(goodLabel);
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.AreEqual("Error:The pasted data does not match the expected layout.", addLabelsPage.GetErrorNotificationMessage());
            addLabelsPage.ClickErrorNotificationOkButton();
            addLabelsPage.WaitForPageRefresh();

            addLabelsPage.ClickClearButton();
            
            addLabelsPage.AddLabelData("\t\t"+goodLabel);
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());
        }

        [TestCase(TestName = "VerifyImportLayoutWithThreeBlankColumnInMiddle")]
        [Category("VerifyImportLayoutWithThreeBlankColumnInMiddle")]
        public void A242917()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };
            var fields = new List<string>() { "VIN", "BLANK_COLUMN", "BLANK_COLUMN", "BLANK_COLUMN", "Notes" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, fields);

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);
            var goodLabel = Extensions.GetRandomString(1 + DateTime.Now.Millisecond % 24);

            addLabelsPage.AddLabelData(goodLabel);
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.AreEqual("Error:The pasted data does not match the expected layout.", addLabelsPage.GetErrorNotificationMessage());
            addLabelsPage.ClickErrorNotificationOkButton();
            addLabelsPage.WaitForPageRefresh();

            addLabelsPage.ClickClearButton();

            addLabelsPage.AddLabelData(goodLabel+"\t\t\t" + "\ttest Notes");
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());
        }

        [TestCase(TestName = "VerifyImportLayoutWithTwoBlankColumnAtEnd")]
        [Category("242922"), Category("242932")]
        public void VerifyImportLayoutWithTwoBlankColumnAtEnd()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };
            var fields = new List<string>() { "VIN", "Batch_Number","Notes", "BLANK_COLUMN", "BLANK_COLUMN",};

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, fields);

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);
            var goodLabel = Extensions.GetRandomString(1 + DateTime.Now.Millisecond % 24);

            addLabelsPage.AddLabelData(goodLabel);
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.AreEqual("Error:The pasted data does not match the expected layout.", addLabelsPage.GetErrorNotificationMessage());
            addLabelsPage.ClickErrorNotificationOkButton();
            addLabelsPage.WaitForPageRefresh();

            addLabelsPage.ClickClearButton();

            addLabelsPage.AddLabelData(goodLabel +"\tTestBatchNumber\t Test Notes" + "\t\t");
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());
        }

        //var proclocs = new List<string>() { "Sunshine Bradenton, FL", "Sun City, AZ" };
        //var clients = new List<string>() { "Hertz", "Enterprise" };

        [TestCase(TestName = "VerifyThatShowDisabledConfigurationsCheckboxIsDisplayed")]
        [Category("243894")]

        public void VerifyThatShowDisabledConfigurationsCheckboxIsDisplayed()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            Assert.IsTrue(configurationPage.IsShowDisabledConfigurationCheckboxDisplayed());
        }

        [TestCase(new int[] { 1, 2, 3, 4, 5 }, TestName = "VerifyThatWheShowDisabledConfigurationCheckboxIsUncheckedOnlyTheEnabledImportLayoutShouldBeDisplayed")]
        [Category("243897")]

        public void VerifyThatWhenShowDisabledConfigurationCheckboxIsCheckedDisabledImportLayoutIsDisplayed(int[] rowNumbers)
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            /*var rownumbers = configurationPage.KendoGrid.GetNumberOfDataRows();
            Console.WriteLine(rownumbers);*/
            foreach (var rowNumber in rowNumbers)
            {
                Assert.IsTrue(configurationPage.IsOnOffInputChecked(rowNumber));
            }       
        }

        [TestCase(TestName = "EnsureThatWhenMultipleProcessingLocationsIsSelectedInImportLayoutTheAddLabelsPageProcessingLocationShouldBeDisplayedWithDefaultHeaderSelected")]
        [Category("244750")]

        public void EnsureThatWhenMultipleProcessingLocationsIsSelectedInImportLayoutTheAddLabelsPageProcessingLocationShouldBeDisplayedWithDefaultHeaderSelected()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };
            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);
            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            addLabelsPage.WaitForPageRefresh();
            Assert.AreEqual(addLabelsPage.GetSelectedProcessingLocationValue(), addLabelsPage.Border.GetHeaderProcessingLocationCurrentText());
            
        }

        [TestCase(TestName = "EnsureThatTheAddLabelsPageProcessingLocationIsBoundOnlyToTheProcessingLocationSelectedForImportLayoutDescription")]
        [Category("244749")]

        public void EnsureThatTheAddLabelsPageProcessingLocationIsBoundOnlyToTheProcessingLocationSelectedForImportLayoutDescription()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var proclocs = new List<string>() { "Sunshine Bradenton, FL" };
            var clients = new List<string>() { "Select All" };
            importProfileName = "Automation" + Extensions.GetDateTimeStamp();
            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);
            Assert.IsTrue(addLabelsPage.IsExpectedLayoutResultsDisplayed());
            addLabelsPage.WaitForPageRefresh();
            var expectedList = new List<string>() { "Sunshine Bradenton, FL" };
            Assert.AreEqual(expectedList, addLabelsPage.GetAllOptionsOfProcessingLocationValues());
        }

        [TestCase(TestName = "EnsureThatAddingALabelIsUnsuccessfulIfVINSpecifiedIsMoreThan25Characters")]
        [Category("242903")]

        public void EnsureThatAddingALabelIsUnsuccessfulIfVINSpecifiedIsMoreThan25Characters()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            string labelTypeString = labelType == 1 ? "Unit" : "Bag";

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);

            var labelDataOver25 = Extensions.GetRandomString(DateTime.Now.Millisecond % 6 + 26);

            addLabelsPage.AddLabelData(labelDataOver25);
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());
        }

        [TestCase(TestName = "EnsureThatAddingALabelIsSuccessfulIfTheVINSpecifiedIs25Characters")]
        [Category("243888")]

        public void EnsureThatAddingALabelIsSuccessfulIfTheVINSpecifiedIs25Characters()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            string labelTypeString = labelType == 1 ? "Unit" : "Bag";

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);

            var labelDataOver25 = Extensions.GetRandomString(25);
            addLabelsPage.AddLabelData(labelDataOver25);
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());
        }

        [TestCase(TestName = "EnsureThatAddingALabelIsSuccessfulIfTheVINSpecifiedIs17Characters")]
        [Category("243888")]

        public void EnsureThatAddingALabelIsSuccessfulIfTheVINSpecifiedIs17Characters()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            string labelTypeString = labelType == 1 ? "Unit" : "Bag";

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);

            var labelDataOver25 = Extensions.GetRandomString(17);
            Console.WriteLine(labelDataOver25);
            addLabelsPage.AddLabelData(labelDataOver25);
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());
        }

        [TestCase(TestName = "EnsureThatAddingALabelIsUnsuccessfulIfVinSpecifiedIsNull")]
        [Category("243135")]
        public void EnsureThatAddingALabelIsUnsuccessfulIfVinSpecifiedIsNull()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;
            string labelTypeString = labelType == 1 ? "Unit" : "Bag";

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, "VIN");

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);

            var labelDataNull ="";
            Console.WriteLine(labelDataNull);
            addLabelsPage.AddLabelData(labelDataNull);
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsErrorNotificationPopupWindowDisplayed());
        }

        [TestCase(1,TestName = "VerifyThatWhenShowDisabledConfigurationCheckboxIsCheckedDisabledImportLayoutIsDisplayed")]
        [Category("243896")]
        public void VerifyThatWhenShowDisabledConfigurationCheckboxIsCheckedDisabledImportLayoutIsDisplayed(int rownumber)
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);
            configurationPage.Navigate();

            
            Assert.IsTrue(configurationPage.IsOnOffInputChecked(rownumber));
            configurationPage.ClickShowDisabledConfigurationCheckbox();
            //configurationPage.KendoGrid.SelectItemsPerPageByString("150");
            configurationPage.KendoGrid.ClickSortColumnByColumnNumber(2, 1, 10);
            configurationPage.KendoGrid.ClickSortColumnByColumnNumber(2, 1, 10);
            Assert.IsFalse(configurationPage.IsOnOffInputChecked(rownumber));

        }


        [TestCase(TestName = "A244957")]
        [Category("244957")]
        public void A244957 ()
        {
            configurationPage = new ConfigurationPageObj(Driver, LabelMgmtBaseUrl);

            configurationPage.Navigate();

            var proclocs = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };
            var fields = new List<string>() { "VIN", "BLANK_COLUMN", "BLANK_COLUMN", "BLANK_COLUMN", "Notes" };

            //Randomizing LabelType
            int labelType = 1 + DateTime.Now.Millisecond % 2;

            importProfileName = "Automation" + Extensions.GetDateTimeStamp();

            configurationPage.AddImportLayoutConfigurationRecord(importProfileName, labelType, clients, proclocs, fields);

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            addLabelsPage.SelectImportProfileByText(importProfileName);
            var goodLabel = Extensions.GetRandomString(1 + DateTime.Now.Millisecond % 24);

            addLabelsPage.AddLabelData(goodLabel);
            addLabelsPage.ClickSubmitLabelsButton();

            Assert.AreEqual("Error:The pasted data does not match the expected layout.", addLabelsPage.GetErrorNotificationMessage());
            addLabelsPage.ClickErrorNotificationOkButton();
            addLabelsPage.WaitForPageRefresh();

            addLabelsPage.ClickClearButton();

            addLabelsPage.AddLabelData(goodLabel + "\t\t\t" + "\ttest Notes");
            addLabelsPage.ClickSubmitLabelsButton();
            Assert.IsTrue(addLabelsPage.IsNotificationPopupWindowVisible());
        }
    }
}
