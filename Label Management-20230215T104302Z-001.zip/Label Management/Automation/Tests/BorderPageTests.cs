using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;
using Assert = NUnit.Framework.Assert;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    //[TestFixture(typeof(FirefoxDriver))]
    [TestFixture(typeof(ChromeDriver))]
    //[TestFixture(typeof(InternetExplorerDriver))]
    public class BorderPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "BorderPage_VerifyPageAccess_Admin")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "BorderPage_VerifyPageAccess_Supervisor")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "BorderPage_VerifyPageAccess_Internal")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "BorderPage_VerifyPageAccess_External")]
        public void BorderPage_VerifyPageAccess_ManualNavigate(string user, string pass)
        {
            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);

            dashboardPage.Navigate(user, pass);
            //dashboardPage.Border.EnsureCorrectUser(user);

            //User-dependent elements, also validates if page exists for user
            if (user.Equals(UserCredentials.AdminUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                //Assert.IsTrue(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
            else if (user.Equals(UserCredentials.SupervisorUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                Assert.IsFalse(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
            else if (user.Equals(UserCredentials.InternalUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                Assert.IsFalse(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
            else if (user.Equals(UserCredentials.ExternalUsername))
            {
                Assert.IsTrue(dashboardPage.Border.GotoPersonalSettingsPage());
                Assert.IsFalse(dashboardPage.Border.GotoClientLocationsConfigPage());
            }
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "BorderPage_VerifyPageAccess_DirectUrl_Admin")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "BorderPage_VerifyPageAccess_DirectUrl_Supervisor")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "BorderPage_VerifyPageAccess_DirectUrl_Internal")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "BorderPage_VerifyPageAccess_DirectUrl_External")]
        public void BorderPage_VerifyPageAccess_DirectUrlNavigate(string user, string pass)
        {
            // TODO: There is future story to figure out which users should have access to which pages.
            // TODO: Until then, we can disregard failures here. 
            // Internal fails - Should not be able to access
            // External fails - Should not be able to access

            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);

            dashboardPage.Navigate(user, pass);
            //dashboardPage.Border.EnsureCorrectUser(user);

            //User-dependent elements, also validates if page exists for user
            if (user.Equals(UserCredentials.AdminUsername))
            {
                var logsPage = new LogPageObj(Driver, LabelMgmtBaseUrl);
                logsPage.DirectNavigate();
                Assert.False(dashboardPage.ErrorMessage403Displayed());

                var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
                personalSettingsPage.DirectNavigate();
                Assert.False(dashboardPage.ErrorMessage403Displayed());

                var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
                clientLocationsPage.DirectNavigate();
                //Assert.False(dashboardPage.ErrorMessage403Displayed());

            }
            else if (user.Equals(UserCredentials.SupervisorUsername))
            {
                var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
                personalSettingsPage.DirectNavigate();
                Assert.False(dashboardPage.ErrorMessage403Displayed());

                var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
                clientLocationsPage.DirectNavigate();
                Assert.True(dashboardPage.ErrorMessage403Displayed());
                dashboardPage.DirectNavigate(); //must return to dashboard after 403 screen
            }
            else if (user.Equals(UserCredentials.InternalUsername))
            {
                var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
                personalSettingsPage.DirectNavigate();
                Assert.False(dashboardPage.ErrorMessage403Displayed()); 

                var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
                clientLocationsPage.DirectNavigate();
                Assert.True(dashboardPage.ErrorMessage403Displayed());
                dashboardPage.DirectNavigate(); //must return to dashboard after 403 screen
            }
            else if (user.Equals(UserCredentials.ExternalUsername))
            {
                var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
                personalSettingsPage.DirectNavigate();
                Assert.False(dashboardPage.ErrorMessage403Displayed()); 

                var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
                clientLocationsPage.DirectNavigate();
                Assert.True(dashboardPage.ErrorMessage403Displayed());
                dashboardPage.DirectNavigate(); //must return to dashboard after 403 screen
            }
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "BorderPage_NavigateToIdentityServerProfilePage_Admin")]
        //[TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "BorderPage_NavigateToIdentityServerProfilePage_Supervisor")]
        //[TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "BorderPage_NavigateToIdentityServerProfilePage_Internal")]
        //[TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "BorderPage_NavigateToIdentityServerProfilePage_External")]
        public void BorderPage_NavigateToIdentityServerProfilePage(string user, string pass)
        {
            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);

            dashboardPage.Navigate(user, pass);
            dashboardPage.Border.SelectHeaderDropdownProfilePage();

            var identityServerProfilePage = new IdentityServerProfilePageObj(Driver, IdentityServerBaseUrl);

            identityServerProfilePage.ChangeFocusToNewTab();
            Assert.IsTrue(identityServerProfilePage.TitleDisplayed());

            dashboardPage.ChangeBrowserTab(0);
        }
    }
}
