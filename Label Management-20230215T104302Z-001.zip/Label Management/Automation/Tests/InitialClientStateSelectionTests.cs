using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    class InitialClientStateSelectionTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [Category("SmokeTest")]
        [TestCase(TestName = "InitialClientStateForm_FormLoadSuccess")]
        public void InitialClientStateFormSmokeTest()
        {
            // Remove data from the UserPreferences table so login pop-up will appear
            var user = UserCredentials.AdminUsername;
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.RemoveTestUserPreferences(user);

            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);

            //loginPage.Navigate();
            loginPage.NavigateToInitialClientStateForm();

            Assert.True(dashboardPage.IsInitialCustomerListWindowDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListClientDropdownDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListInventoryDropdownDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListCancelButtonDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListSubmitButtonDisplayed());
        }

        [Category("InitialClientStateSelect")]
        [TestCase(Clients.Hertz, ClientLocationCode.Bradenton, TestName = "InitialClientStateForm_FormSubmitSuccess")]
        public void ValidInitialClientStateSubmit(string initialClient, string initialOffice)
        {
            // Remove data from the UserPreferences table so login pop-up will appear
            var user = UserCredentials.AdminUsername;
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.RemoveTestUserPreferences(user);

            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);

            //loginPage.Navigate();
            loginPage.NavigateToInitialClientStateForm();

            Assert.True(dashboardPage.IsInitialCustomerListWindowDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListSubmitButtonDisplayed());

            //dashboardPage.SetInitialClientAndInventory(initialClient, initialState);
            //dashboardPage.ClickInitialCustomerListSubmitButton();
            dashboardPage.SetInitialInventoryClientAndSubmit(1, 1);

            dashboardPage.Border.WaitUntilHeaderDropdownsPopulated();

            Assert.AreEqual(initialClient, dashboardPage.Border.GetCurrentHeaderClientValue());
            Assert.AreEqual(initialOffice, dashboardPage.Border.GetCurrentProcessingLocationValue());
        }

        [Category("InitialClientStateSelect")]
        [TestCase(Clients.Hertz, "", TestName = "InitialClientStateForm_StateFieldEmpty_FieldErrorDisplayed")]
        [TestCase("", ClientLocationCode.Bradenton, TestName = "InitialClientStateForm_ClientFieldEmpty_FieldErrorDisplayed")]
        [TestCase("", "", TestName = "InitialClientStateForm_BothFieldsEmpty_FieldErrorDisplayed")]
        public void InvalidInitialClientStateSubmitTest(string initialClient, string initialOffice)
        {
            // Remove data from the UserPreferences table so login pop-up will appear
            var user = UserCredentials.AdminUsername;
            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPage.RemoveTestUserPreferences(user);

            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);
            var clientFieldValid = false;
            var stateFieldValid = false;


            loginPage.NavigateToInitialClientStateForm();

            Assert.True(dashboardPage.IsInitialCustomerListWindowDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListSubmitButtonDisplayed());

            dashboardPage.SetInitialClientAndInventory(initialClient, initialOffice);

            if(!string.IsNullOrEmpty(initialClient))
            {
                clientFieldValid = true;
            }

            if(!string.IsNullOrEmpty(initialOffice))
            {
                stateFieldValid = true;
            }

            dashboardPage.ClickInitialCustomerListSubmitButton();

            if (!clientFieldValid)
            {
                Assert.True(dashboardPage.IsInitialClientErrorDisplayed());
            }

            if (!stateFieldValid)
            {
                Assert.True(dashboardPage.IsInitialInventoryErrorDisplayed());
            }
        }

        [Category("InitialClientStateSelect")]
        [TestCase(TestName = "InitialClientStateForm_ClickCancelButton_RedirectToLoginPage")]
        public void CancelInitialClientStateTest()
        {
            // Remove data from the UserPreferences table so login pop-up will appear
            var user = UserCredentials.AdminUsername;
            var loginPageObject = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            loginPageObject.RemoveTestUserPreferences(user);

            var loginPage = new LoginPageObj(Driver, LabelMgmtBaseUrl);
            var dashboardPage = new DashboardPageObj(Driver, LabelMgmtBaseUrl);

            loginPage.NavigateToInitialClientStateForm();

            Assert.True(dashboardPage.IsInitialCustomerListWindowDisplayed());
            Assert.True(dashboardPage.IsInitialCustomerListCancelButtonDisplayed());

            dashboardPage.ClickInitialCustomerListCancelButton();

            Assert.True(loginPage.IsUsernameFieldDisplayed());
            Assert.True(loginPage.IsPasswordFieldDisplayed());
            Assert.True(loginPage.IsLoginButtonDisplayed());
        }
    }
}
