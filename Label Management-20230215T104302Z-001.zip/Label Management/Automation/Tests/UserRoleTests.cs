using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    class UserRoleTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Add Labels page")]
        [TestCase(UserCredentials.SupervisorUsername,UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write Add Labels page")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that InternalUser has authorization to Read and Write Add Labels page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteAddLabels(string user, string pass)
        {
           var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

           Assert.True( userroles.VerifyIsAddLabelsIsDisplayed());

           userroles.ClickOnAddLabels();

            Assert.AreEqual(userroles.VerifyAddLabelsHeader(), "Add Labels");

           userroles.SelectImportProfile();

           Assert.True(userroles.VerifyIsSaveButtonEnable());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write View Bag Labels page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write View bag Labels")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that InternalUser has authorization to Read and Write View bag Labels")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteViewBagLabels(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True( userroles.ClickOnViewBagLabels());

            Assert.True(userroles.ViewBagLabelsButtons());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write View Unit Labels page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write View Unit Labels")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that InternalUser has authorization to Read and Write View Unit Labels")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteViewUnitLabels(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.ClickOnViewUnitLabels());

            Assert.True(userroles.ViewBagUnitButtons());
        }

        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "Verify that external user has  to Read Unit Labels")]

        public void VerifyTheExternalUserHasAutharizationToReadAndWriteViewUnitLabels(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.ClickOnViewUnitLabels());

            Assert.False(userroles.ViewBagUnitButtons());
        }


        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Bulk Processing page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write Bulk Processing page")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that InternalUser has authorization to Read and Write Bulk Processing page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteBulkUpdate(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.ClickOnBulkProcessAndVerifyRunButtons());

        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Invoices page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write Invoices page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteInvoicesPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.ClickOnViewInvoiceAndVerifyViewInvoice());

            Assert.True(userroles.ClickOnBillingSetUpAndVerifyBillingSetUp());

        }
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal User has authorization to Read and Write Invoices page")]

        public void VerifyTheInternalUserHasAutharizationToReadAndWriteInvoicesPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.ClickOnViewInvoiceAndVerifyViewInvoice());

            Assert.True(userroles.ClickOnBillingSetUpAndVerifyBillingSetUp());

        }
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Reports page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write Reports page")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal User has authorization to Read and Write Reports page")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "Verify that External User has authorization to Read and Write Reports page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteReportPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.ClickOnReportAndVerifyReportPage());

        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Logs page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read and Write Logs page")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal user has authorization to Read and Write Logs page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteLogsPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            userroles.ClickOnLogs();

            Assert.True(userroles.VerifyLogDetails());

        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write SortOrders page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteSortOrdersPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            userroles.ClickOnSettingsMenu();

            Assert.True(userroles.VerifySortOrders());

        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Layout page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteLayoutPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            userroles.ClickOnSettingsMenu();

            Assert.True(userroles.VerifyLayoutPage());

        }

        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor has authorization to Read Only Layout page")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal has authorization to Read Only Layout page")]

        public void VerifyTheSupervisorHasAutharizationToReadonlyLayoutPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            userroles.ClickOnSettingsMenu();

            Assert.False(userroles.VerifyLayoutPage());

        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify that Admin has authorization to Read and Write Notifications page")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Superviser has authorization to Read and Write Notifications page")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal User has authorization to Read and Write Notifications page")]

        public void VerifyTheAdminHasAutharizationToReadAndWriteNotificationsPage(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.VerifyNotificationsAccess());

        }

        [TestCase(UserCredentials.AdminUsername,UserCredentials.AdminPassword, TestName = "Verify that admin has authorization to read and write Personal Settings")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "Verify that External User has authorization to read and write Personal Settings")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal User has authorization to read and write Personal Settings")]


        public void VerifyAdminHasAuthariseToReadAndWriteForPersonalSettings(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.VerifyAccessForPersonalSettingsPage());
        }

        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "Verify that external user has denied access for Sort Order Configuration page.")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "Verify that Supervisor user has denied access for Sort Order Configuration page.")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "Verify that Internal user has denied access for Sort Order Configuration page.")]

        public void VerifyExternalUserShouldNotAbleToAccessSortOrders(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.VerifyAccessDeniedForSortOredrPage());
        }

        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "Verify that external user is denied access for Add Labels, Bulk Processing, Logs, Log Details, Notifications page though URL is specified")]

        public void VerifythatexternaluserisdeniedaccessforAddLabelsBulkProcessingLogsLogDetailsNotificationspagethoughURLisspecified(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.VerifyAccessDeniedForSortOredrPage());

            Assert.True(userroles.VerifyAccessDeniedForAddLabel());

            Assert.True(userroles.VerifyAccessDeniedForBulkProcess());

            Assert.True(userroles.VerifyAccessDeniedForLogs());

            Assert.True(userroles.VerifyAccessDeniedForLogDetails());

        }


        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "Verify that external user does not have authorization to Read or make changes in Import Layouts page.")]

        public void VerifyExternalUserAccessDeniedForImportLayout(string user, string pass)
        {
            var userroles = new UserRolesObj(Driver, LabelMgmtBaseUrl);

            userroles.Navigate(user, pass);

            Assert.True(userroles.VerifyAccessDeniedForImportLayout());

        }

        }
}
