using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Assert = NUnit.Framework.Assert;
using System.Threading;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class BulkProcessingPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(UserCredentials.AdminUsername,UserCredentials.AdminPassword, TestName = "VerifyThatBulkProcessingPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyThatBulkProcessingPageIsAccessibleToDifferentUsers")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "VerifyThatBulkProcessingPageIsAccessibleToDifferentUsers")]

        public void VerifyThatBulkProcessingPageIsAccessibleToDifferentUsers(string user, string pass)
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate(user, pass);

            bulkProcessingPage.IsTitleDisplayed();
        }

        [TestCase(TestName = "VerifyPendingBagLabelsAndPendingUnitLabelsShownCorrectly")]

        public void VerifyPendingBagLabelsAndPendingUnitLabelsShownCorrectly()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            Assert.AreEqual(bulkProcessingPage.VerifyPendingBagLabelsCount(),bulkProcessingPage.PendingBagLabelsDBCount());

            Assert.AreEqual(bulkProcessingPage.VerifyPendingUnitLabelsCount(),bulkProcessingPage.PendingUnitLabelsDBCount());

        }

        [TestCase(TestName = "VerifyThatConfirmationMessagesAppearForActivatePendingBagLabelsSelection")]

        public void VerifyThatConfirmationMessagesAppearForActivatePendingBagLabelsSelection()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            
            bulkProcessingPage.CreateDataForActivatependingLabels(false);
            bulkProcessingPage.Navigate();
            bulkProcessingPage.ClickBagLabelsRunButton();

            Assert.IsTrue(bulkProcessingPage.IsConfirmationFormDisplayed());
        }

        [TestCase(TestName = "VerifyThatConfirmationMessagesAppearForActivatePendingUnitLabelsSelection")]
        public void VerifyThatConfirmationMessagesAppearForActivatePendingUnitLabelsSelection()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForActivatependingLabels(true);

            bulkProcessingPage.ClickUnitLabelsRunButton();

            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Warn));

        }

        [TestCase(TestName = "VerifyMessageWhileClickingOnRunButtonOfActivatePendingBagLabels")]
        public void VerifyMessageWhileClickingOnRunButtonOfActivatePendingBagLabels()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForActivatependingLabels(false);

            bulkProcessingPage.ClickBagLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);
        }

        [TestCase(TestName = "VerifyErrorMessageWhileClickingOnRunButtonOfActivatePendingBagLabelsWhenPendingBagLabelsZero")]
        public void VerifyErrorMessageWhileClickingOnRunButtonOfActivatePendingBagLabelsWhenPendingBagLabelsZero()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickBagLabelsRunButton();

            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Warn));
            Assert.AreEqual("There are no records to process.", bulkProcessingPage.GetNotificationMessageText(NotificationType.Warn));
        }

        [TestCase(TestName = "VerifyMessagWhileClickingOnRunButtonOfActivatePendingUnitLabels")]
        public void VerifyMessagWhileClickingOnRunButtonOfActivatePendingUnitLabels()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.CreateDataForActivatependingLabels(true);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickUnitLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

        }


        [TestCase(TestName = "VerifyErrorMessageWhileClickingOnRunButtonOfActivatePendingUnitLabelsWhenPendingUnitLabelsZero")]
        public void VerifyErrorMessageWhileClickingOnRunButtonOfActivatePendingUnitLabelsWhenPendingUnitLabelsZero()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickUnitLabelsRunButton();

            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Warn));
            Assert.AreEqual("There are no records to process.", bulkProcessingPage.GetNotificationMessageText(NotificationType.Warn));
        }

        #region "Set Printed and Active to Closed Status"

        [TestCase(TestName = "VerifyMessagWhileClickingOnRunButtonOfClosePrintedActiveLabels")]

        public void VerifyMessagWhileClickingOnRunButtonOfClosePrintedActiveLabels()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

        }

        [TestCase(TestName = "VerifyPrintedAndActiveLabelsShownCorrectly")]

        public void VerifyPrintedAndActiveLabelsShownCorrectly()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            Assert.AreEqual(bulkProcessingPage.PrintedActiveLabelsDBCount(), bulkProcessingPage.VerifyPrintedAndActiveLabelsCount());
        }

        [TestCase(TestName = "VerifyErrorMessageWhileClickingOnRunButtonOfClosePrintedActiveLabelsWhenPrintedAndActiveLabelsShownZero")]

        public void VerifyErrorMessageWhileClickingOnRunButtonOfClosePrintedActiveLabelsWhenPrintedAndActiveLabelsShownZero()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Warn));
            Assert.AreEqual("There are no records to process.", bulkProcessingPage.GetNotificationMessageText(NotificationType.Warn));
        }

        [TestCase(TestName = "VerifyThatConfirmationMessagesAppearForSetPrintedAndActiveToClosedselectionSelection")]

        public void VerifyThatConfirmationMessagesAppearForSetPrintedAndActiveToClosedSelection()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            Assert.IsTrue(bulkProcessingPage.IsConfirmationFormDisplayed());

        }

        [TestCase(TestName = "VerifyThatPrintedAndActiveLabelsIsUpdatedToClosedSuccessfully")]

        public void VerifyThatPrintedAndActiveLabelsIsUpdatedToClosedSuccessfully()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            bulkProcessingPage.VerifyCloseActiveLabelsInLogsPage();

            bulkProcessingPage.ClickOnNotificationsIcon();

            bulkProcessingPage.VerifyCloseActiveLabelsInNotifications();

            bulkProcessingPage.VerifyLogsPageTotalCountSuccessErrorAndWarnings();

            Assert.AreEqual(0, bulkProcessingPage.PrintedActiveLabelsDBCount());

        }

        [TestCase(TestName = "VerifyThatLogsPageHavingCloseActiveLabelsRecord")]
        public void VerifyLogsPageHavingCloseActiveLabelsRecord()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            Assert.IsTrue(bulkProcessingPage.VerifyCloseActiveLabelsInLogsPage());
        }

        [TestCase(TestName = "VerifyStatusOfTheCloseActiveLabelsInNotification")]
        public void VerifyStatusOfTheCloseActiveLabelsInNotification()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

            bulkProcessingPage.ClickOnNotificationsIcon();

            Assert.IsTrue(bulkProcessingPage.VerifyCloseActiveLabelsInNotifications());
        }

        [TestCase(TestName = "VerifyCloseActiveLabelsJobCounts")]
        public void VerifyCloseActiveLabelsJobCounts()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            bulkProcessingPage.VerifyCloseActiveLabelsInLogsPage();

            Assert.IsTrue(bulkProcessingPage.VerifyLogsPageTotalCountSuccessErrorAndWarnings());

        }

        [TestCase(TestName = "VerifyLogDetailsPage")]
        public void VerifyLogDetailsPage()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            Assert.IsTrue(bulkProcessingPage.VerifyLogDetailsPage());

        }

        [TestCase(TestName = "VerifyCloseActiveLabelsCompletionMessage")]
        public void VerifyCloseActiveLabelsCompletionMessage()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.CreateDataForPrintedAndActiveLabels();

            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClickCloseActiveLabelsRunButton();

            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success);

            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success));

        }
        #endregion

        [TestCase(TestName = "VerifyMessageWhileClickingOnRunButtonOfInvoiceLabelChargesOfBulkProcessingpage_WithRecords")]
        [Category("230758")]
        public void VerifyMessageWhileClickingOnRunButtonOfInvoiceLabelChargesOfBulkProcessingpage_WithRecords()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
           
            bulkProcessingPage.Navigate();


            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();
            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(0, bulkProcessingPage.GetPendingInvoiceLabelCount());

        }

        [TestCase(TestName = "VerifythatConfirmationMessagesAppearForInvoiceLabelChargesSelection")]
        [Category("Smoke"), Category("230759")]
        public void VerifythatConfirmationMessagesAppearForInvoiceLabelChargesSelection()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
                bulkProcessingPage.Navigate();
            }

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();

            Assert.IsTrue(bulkProcessingPage.IsConfirmationFormDisplayed());
        }

        [TestCase(TestName = "VerifyInvoiceLabelChargesShownCorrectly")]
        [Category("Smoke"), Category("230760")]
        public void VerifyInvoiceLabelChargesShownCorrectly()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            Assert.AreEqual(bulkProcessingPage.GetDbCountForPendingInvoiceLabelBulkProcess(), bulkProcessingPage.GetPendingInvoiceLabelCount(),
                "Data mismatch between DB & UI for BulkProcess for Pending label invoice count");
        }

        [TestCase(TestName = "VerifyMessageWhileClickingOnRunButtonOfInvoiceLabelChargesOfBulkProcessingpage_WithNoRecords")]
        [Category("Smoke"), Category("230761")]
        public void VerifyMessageWhileClickingOnRunButtonOfInvoiceLabelChargesOfBulkProcessingpage_WithNoRecords()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            bulkProcessingPage.ClearDbDataForInvoicePendingLabelsBulkProcess();

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            Assert.IsTrue(bulkProcessingPage.IsNotificationMessageDisplayed(NotificationType.Warn));
            Assert.AreEqual(0, bulkProcessingPage.GetPendingInvoiceLabelCount());
        }

        [TestCase(TestName = "VerifythatInvoiceLabelChargesCountAndTotalCountOfLogsPageShouldBeSame")]
        [Category("Smoke"), Category("230762")]
        public void VerifythatInvoiceLabelChargesCountAndTotalCountOfLogsPageShouldBeSame()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
            }

            var currentProcessingCount = bulkProcessingPage.GetPendingInvoiceLabelCount();

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.ClickOnLogsInLeftMenu();
            Assert.AreEqual(currentProcessingCount, bulkProcessingPage.LogPageTotalProcessedCount());
            
        }

        [TestCase(TestName = "VerifyStatusForInvoiceLabelChargesProcessJobOfBulkProcessingpage")]
        [Category("Smoke"), Category("230763")]
        public void VerifyStatusForInvoiceLabelChargesProcessJobOfBulkProcessingpage()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
            }

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.ClickOnLogsInLeftMenu();
            Assert.AreEqual("Pending Invoice Label Action", bulkProcessingPage.GetLogPageProcessName());
        }

        [TestCase(TestName = "VerifyLogsPageHavingInvoiceLabelChargesRecords")]
        [Category("Smoke"), Category("230764")]
        public void VerifyLogsPageHavingInvoiceLabelChargesRecords()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
            }

            var currentProcessingCount = bulkProcessingPage.GetPendingInvoiceLabelCount();

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.ClickOnLogsInLeftMenu();
            Assert.AreEqual(currentProcessingCount, bulkProcessingPage.LogPageTotalProcessedCount());
            Assert.AreEqual(currentProcessingCount, bulkProcessingPage.LogPageSuccessCount() + bulkProcessingPage.LogPageErrorCount() +
                bulkProcessingPage.LogPageWarningCount());

        }

        [TestCase(TestName = "VerifyStatusOfTheInvoiceLabelChargesInNotification")]
        [Category("Smoke"), Category("230765")]
        public void VerifyStatusOfTheInvoiceLabelChargesInNotification()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
            }

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            Assert.AreEqual("Completed", bulkProcessingPage.GetLogPageStatus());

            bulkProcessingPage.ClickOnNotificationsIcon();

            bulkProcessingPage.VerifyCloseActiveLabelsInNotifications();
        }

        [TestCase(TestName = "VerifyTheUpdatedDataWhenClickingOnRunButtonOfInvoiceLabelChargesOfBulkProcessingPage")]
        [Category("Smoke"), Category("230766")]
        public void VerifyTheUpdatedDataWhenClickingOnRunButtonOfInvoiceLabelChargesOfBulkProcessingPage()
        {
            Assert.Inconclusive("Obsolete requirement.");
        }

        [TestCase(TestName = "VerifyLogDetailsPageOfInvoiceLabelChargesProcessJobOfBulkProcessingPage")]
        [Category("Smoke"), Category("230885")]
        public void VerifyLogDetailsPageOfInvoiceLabelChargesProcessJobOfBulkProcessingPage()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
            }

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            bulkProcessingPage.VerifyLogDetailsPage();
        }

        [TestCase(TestName = "VerifyProcessCompletionMessageOfInvoiceLabelChargesProcessJobOfBulkProcessingPage")]
        [Category("Smoke"), Category("230886")]
        public void VerifyProcessCompletionMessageOfInvoiceLabelChargesProcessJobOfBulkProcessingPage()
        {
            var bulkProcessingPage = new BulkProcessingPageObj(Driver, LabelMgmtBaseUrl);
            bulkProcessingPage.Navigate();

            if (bulkProcessingPage.GetPendingInvoiceLabelCount() == 0)
            {
                bulkProcessingPage.CreateDbDataForInvoicePendingLabelsBulkProcess();
            }

            bulkProcessingPage.ClickPendingInvoiceLabelBulkRunButton();
            bulkProcessingPage.ClickAlertConfirmation();

            bulkProcessingPage.ClickOnLogsInLeftMenu();

            Assert.Fail("Success message is not displayed on the Logs pagex. Its failing manually. Need to fix Automation once it works fine manually");
        }
    }
}
