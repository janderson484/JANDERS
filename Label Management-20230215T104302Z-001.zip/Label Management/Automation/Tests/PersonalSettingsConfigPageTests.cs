using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Collections.Generic;
using System.Threading;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class PersonalSettingsConfigPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(TestName = "VerifyDaysOfHistoryForLabelViewInPersonalSettings")]
        [Category("236124")]
        public void VerifyDaysOfHistoryForLabelViewInPersonalSettings()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            Assert.IsTrue(personalSettingsPage.IsDaysOfHistoryLabelViewVisible());
        }

        [TestCase(TestName = "VerifyDefaultHistoryDaysShouldBe90")]
        [Category("236125")]
        public void VerifyDefaultHistoryDaysShouldBe90()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
            Assert.AreEqual(90, personalSettingsPage.GetNoofHistoryDays());
        }

        [TestCase(TestName = "VerifySaveButtonForHistoryDaysSetting")]
        [Category("236127")]
        public void VerifySaveButtonForHistoryDaysSetting()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
            Assert.IsTrue(personalSettingsPage.IsSaveButtonDisplayed());
        }

        [TestCase(TestName = "VerifyStartDateInViewBagLabelsPageShouldBeEqualsHistoryDaysEndDate")]
        [Category("236138")]
        public void VerifyStartDateInViewBagLabelsPageShouldBeEqualsHistoryDaysEndDate()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
            var days = DateTime.Now.Second + 1;

            personalSettingsPage.SetNoofHistoryDays(""+days);
            personalSettingsPage.ClickSave();

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            var startDate = DateTime.Parse(viewBagLabelPage.GetStartDateText());
            var endDate = DateTime.Parse(viewBagLabelPage.GetEndDateText());
            var difference = endDate - startDate;
            Assert.AreEqual(days, difference.Days + 1);

            personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
           
            personalSettingsPage.SetNoofHistoryDays("90");
            personalSettingsPage.ClickSave();
        }

        [TestCase(TestName = "VerifyStartDateInViewUnitLabelsPageShouldBeEqualsHistoryDaysEndDate")]
        [Category("236139"), Category("246021")]
        public void VerifyStartDateInViewUnitLabelsPageShouldBeEqualsHistoryDaysEndDate()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            var days = DateTime.Now.Second + 1;
            personalSettingsPage.SetNoofHistoryDays("" + days);

            var initialRowsPerPage = personalSettingsPage.GetRowsPerPage();

            personalSettingsPage.SelectRowsPerPageByIndex(days % 4);
            var rowsPerPage = personalSettingsPage.GetRowsPerPage();

            personalSettingsPage.ClickSave();

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            var startDate = DateTime.Parse(viewUnitLabelPage.GetStartDateText());
            var endDate = DateTime.Parse(viewUnitLabelPage.GetEndDateText());
            var difference = endDate - startDate;
            Assert.AreEqual(days, difference.Days + 1);

            Assert.AreEqual(rowsPerPage, viewUnitLabelPage.KendoGrid.GetCurrentItemsPerPageDropdownValue());

            personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SetNoofHistoryDays("90");
            personalSettingsPage.SelectRowsPerPageByValue(initialRowsPerPage.ToString());
            personalSettingsPage.ClickSave();
        }

        [TestCase(TestName = "VerifyErrorMessageWithoutHistoryDaysAndAlphabetsAndSpecialCharacters")]
        [Category("236436")]
        public void VerifyErrorMessageWithoutHistoryDaysAndAlphabetsAndSpecialCharacters()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
            personalSettingsPage.SetNoofHistoryDays("@$#$#%");
            personalSettingsPage.ClickSave();
            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Please enter a numeric value", personalSettingsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyIfTheNoOfDaysEnteredIsZeroItShouldThrowAnError")]
        [Category("239139")]
        public void VerifyIfTheNoOfDaysEnteredIsZeroItShouldThrowAnError()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
            personalSettingsPage.SetNoofHistoryDays( "0");
            personalSettingsPage.ClickSave();
            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Days of History should be greater than 0", personalSettingsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyIfTheNoOfDaysEnteredIsLessThanZeroItShouldThrowAnError")]
        [Category("239143")]
        public void VerifyIfTheNoOfDaysEnteredIsLessThanZeroItShouldThrowAnError()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();
            personalSettingsPage.SetNoofHistoryDays("-1");
            personalSettingsPage.ClickSave();
            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Days of History should be greater than 0", personalSettingsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatPersonalSettingsPageCanBeAccessedByAdmin")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyThatPersonalSettingsPageCanBeAccessedBySupervisor")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "VerifyThatPersonalSettingsPageCanBeAccessedByInternal")]
        [TestCase(UserCredentials.ExternalUsername, UserCredentials.ExternalPassword, TestName = "VerifyThatPersonalSettingsPageCanBeAccessedByExternalUser")]
        [Category("235451")]
        public void VerifyThatPersonalSettingsPageCanBeAccessedByAdminSupervisorInternalAndExternalUser(string user,string password)
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate(user,password);

            Assert.IsTrue(personalSettingsPage.IsPrintSortOrderDropdownDisplayed());
            Assert.IsTrue(personalSettingsPage.IsPrintSortOrderSaveButtonDisplayed());
        }

        [TestCase(TestName = "VerifyThatSuccessMessageIsDisplayedWhenSortOrderIsSaved")]
        [Category("235453")]
        public void VerifyThatSuccessMessageIsDisplayedWhenSortOrderIsSaved()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("Delcode");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "EnsureThatPersonalSettingsAreAppliedToTheCorrectUser")]
        [Category("235469")]
        public void EnsureThatPersonalSettingsAreAppliedToTheCorrectUser()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("Delcode");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success), "Default");
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));

            personalSettingsPage.SelectClientFromDropdown();
            personalSettingsPage.ClickApplyButton();
            personalSettingsPage.SelectValuePrintSortOrderDropdownForEnterprise("LabelSortOrder");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(5,TestName = "VerifyThatSortOrderWhichIsEnabledShouldOnlyBeDisplayedInPersonalSettings")]
        [Category("235452")]
        public void VerifyThatSortOrderWhichIsEnabledShouldOnlyBeDisplayedInPersonalSettings(int rownumber)
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("LabelId");
            personalSettingsPage.ClickSavePrintSortOrderButton();
            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));

            personalSettingsPage.NavigateToSortOrders();
            var toggleSwitchInitialValue = personalSettingsPage.IsOnOffInputChecked(rownumber);
            personalSettingsPage.ToggleOnOffToggleByRowNumber(rownumber);

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_LabelSortOrderConfigUpdated, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));
            

            personalSettingsPage.Navigate();
            Assert.AreEqual("", personalSettingsPage.VerifySelectedDropdwonOption());

            personalSettingsPage.NavigateToSortOrders();
            personalSettingsPage.ToggleOnOffToggleByRowNumber(rownumber);
        }

        [TestCase(TestName = "VerifyThatWhenANewSortOrderIsAddedItIsDynamicallyAddedToThePrintSortOrderDropdown")]
        [Category("235456")]

        public void VerifyThatWhenANewSortOrderIsAddedItIsDynamicallyAddedToThePrintSortOrderDropdown()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.NavigateToSortOrders();
            personalSettingsPage.AddNewSortOrderRecord("NotesDescription", "Notes");

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));

            personalSettingsPage.Navigate();
            personalSettingsPage.SelectPrintSortOrderDropdownValue("NotesDescription");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyThatSelectedSortOrderIsReflectedInViewBagLabelsPage")]
        [Category("235454")]

        public void VerifyThatSelectedSortOrderIsReflectedInViewBagLabelsPage()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("LabelId");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success),"Notification");
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            var firstLabelId = viewBagLabelPage.KendoGrid.GetDataCellText(1, 1, 1);
            var secondLabelId = viewBagLabelPage.KendoGrid.GetDataCellText(2, 1, 1);
            Assert.Greater(secondLabelId, firstLabelId);
        }

        [TestCase(TestName = "VerifyThatSelectedSortOrderIsReflectedInViewUnitLabelsPage")]
        [Category("235455")]

        public void VerifyThatSelectedSortOrderIsReflectedInViewUnitLabelsPage()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("LabelId");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            var firstLabelId = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 1, 1);
            var secondLabelId = viewUnitLabelPage.KendoGrid.GetDataCellText(2, 1, 1);
            Assert.Greater(secondLabelId, firstLabelId);
        }

        [TestCase(2,TestName = "EnsureThatTheLabelsAreSortedByDefaultUsingLabelid")]
        [Category("235599")]

        public void EnsureThatTheLabelsAreSortedByDefaultUsingLabelid(int rownumber)
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("DelCode");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            Assert.IsTrue(personalSettingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(personalSettingsPage.Success_UpdatedPersonalSettings, personalSettingsPage.GetNotificationMessageText(NotificationType.Success));

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            var firstDelCode = viewBagLabelPage.KendoGrid.GetDataCellText(1, 9, 1);
            Console.WriteLine(firstDelCode);
            var secondDelCode = viewBagLabelPage.KendoGrid.GetDataCellText(2, 9, 1);
            Assert.Greater(secondDelCode, firstDelCode);

            personalSettingsPage.NavigateToSortOrders();
            var toggleSwitchInitialValue = personalSettingsPage.IsOnOffInputChecked(rownumber);
            personalSettingsPage.ToggleOnOffToggleByRowNumber(rownumber);

            viewBagLabelPage.Navigate();
            var firstLabelId = viewBagLabelPage.KendoGrid.GetDataCellText(1, 1, 1);
            var secondLabelId = viewBagLabelPage.KendoGrid.GetDataCellText(2, 1, 1);
            Assert.Greater(secondLabelId, firstLabelId);
        }

        [TestCase(TestName = "EnsureThatWhenUserSelectsAValueFromPersonalSettingsPageTheValueShouldBeReflectedInItemsPerPageInAllPagesOfLMApplication")]
        [Category("248813")]

        public void EnsureThatWhenUserSelectsAValueFromPersonalSettingsPageTheValueShouldBeReflectedInItemsPerPageInAllPagesOfLMApplication()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);

            personalSettingsPage.Navigate();
            var defaultRowsPerPage = personalSettingsPage.GetRowsPerPage();

            viewBagLabelPage.Navigate();
            var bagLabelsPageCount = viewBagLabelPage.KendoGrid.GetCurrentItemsPerPageDropdownValue();
            viewUnitLabelPage.Navigate();
            var unitlabelPageCount = viewUnitLabelPage.KendoGrid.GetCurrentItemsPerPageDropdownValue();
            Assert.AreEqual(defaultRowsPerPage, bagLabelsPageCount);
            Assert.AreEqual(defaultRowsPerPage, unitlabelPageCount);
        }

        [TestCase(TestName = "EnsureThatwhenTheUserChangesTheValueFromItemsPerPageDropdownTheSameShouldBeReflectedInAllPagesUntilTheSessionIsEnded")]
        [Category("248816")]

        public void EnsureThatwhenTheUserChangesTheValueFromItemsPerPageDropdownTheSameShouldBeReflectedInAllPagesUntilTheSessionIsEnded()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);

            personalSettingsPage.Navigate();
            var defaultRowsPerPage = personalSettingsPage.GetRowsPerPage();

            viewBagLabelPage.Navigate();
            Assert.AreEqual(defaultRowsPerPage, viewBagLabelPage.KendoGrid.GetCurrentItemsPerPageDropdownValue());
            viewBagLabelPage.KendoGrid.SelectItemsPerPageByString("100");
           
            viewUnitLabelPage.Navigate();
            Assert.AreEqual(100, viewUnitLabelPage.KendoGrid.GetCurrentItemsPerPageDropdownValue());
        }

        [TestCase(TestName = "EnsureThatInSortOrderPageIfUsernameFieldIsSelectedUnhandledErrorShouldNotBeEncounteredInViewBagLabelsPage")]
        [Category("262301")]

        public void EnsureThatInSortOrderPageIfUsernameFieldIsSelectedUnhandledErrorShouldNotBeEncounteredInViewLabelsPage()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("UserNameSorting");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            viewBagLabelPage.Navigate();
            viewBagLabelPage.IsViewBagLabelsGridDisplayed();
        }

        [TestCase(TestName = "EnsureThatInSortOrderPageIfUsernameFieldIsSelectedUnhandledErrorShouldNotBeEncounteredInViewUnitLabelsPage")]
        [Category("262301")]

        public void EnsureThatInSortOrderPageIfUsernameFieldIsSelectedUnhandledErrorShouldNotBeEncounteredInViewUnitLabelsPage()
        {
            var personalSettingsPage = new PersonalSettingsConfigPageObj(Driver, LabelMgmtBaseUrl);
            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            personalSettingsPage.Navigate();

            personalSettingsPage.SelectPrintSortOrderDropdownValue("UserNameSorting");
            personalSettingsPage.ClickSavePrintSortOrderButton();

            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.IsViewBagLabelsGridDisplayed();
        }

    }
}
