using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Assert = NUnit.Framework.Assert;
using System.Threading;
using System.Linq;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class PrintSortOrderPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        string sortorderDescription;

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword,TestName = "VerifyThatPrintSortOrderForLabelIsAccessibleToDifferentUsers")]
        public void VerifyThatPrintSortOrderForLabelIsAccessibleToDifferentUsers(string user,string pass)
        {

            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate(user,pass);

            Assert.IsTrue(printSortOrderPage.IsPrintSortOrderGridDisplayed());
        }
        [TestCase(TestName = "VerifyTheGridPaginationOfPrintSortOrderPage")]
        public void VerifyTheGridPaginationOfPrintSortOrderPage()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            //Assert.IsTrue(printSortOrderPage.IsPrintSortOrderGridDisplayed());

            Assert.IsTrue(printSortOrderPage.IsGridPaginationExists());
        }


        [TestCase(TestName = "VerifyTheGridColumnSortingOfPrintSortOrderPage")]
        public void VerifyTheGridColumnSortingOfPrintSortOrderPage()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            Assert.IsTrue(printSortOrderPage.IsPrintSortOrderGridDisplayed());

            Assert.IsTrue(printSortOrderPage.IsActiveSortable());

            Assert.IsTrue(printSortOrderPage.IsDescriptionSortable());

            Assert.IsTrue(printSortOrderPage.IsClientSortable());

            Assert.IsTrue(printSortOrderPage.IsOrderSortable());

        }

        [TestCase(TestName = "VerifyAddingNewSortOrderIsSuccessful")]
        public void VerifyAddingNewSortOrderIsSuccessful()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickAddNewSortOrderButton();

            printSortOrderPage.AddNewSortOrderRecord();

            printSortOrderPage.ClickSaveButton();

            Assert.IsTrue(printSortOrderPage.IsNotificationMessageDisplayed(NotificationType.Success));


        }

        [TestCase(TestName = "VerifyTheEditFunctionality")]
        public void VerifyTheEditFunctionality()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickDescriptionElement();

            printSortOrderPage.ClickEditSortOrderButton();

            printSortOrderPage.EditSortOrderRecord();

            printSortOrderPage.ClickSaveButton();

            Assert.IsTrue(printSortOrderPage.IsNotificationMessageDisplayed(NotificationType.Success));

        }

        [TestCase(TestName = "VerifyThePrintSortOrderDeleteFunctionality")]
        public void VerifyThePrintSortOrderDeleteFunctionality()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickDescriptionElement();

            printSortOrderPage.ClickEditSortOrderButton();

            printSortOrderPage.ClickDeleteButton();

            Assert.IsTrue(printSortOrderPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "EnsureThatASCAndDESCDropdownIsAddedAtSortFieldLevelInAddNewSortOrderWindow")]
        [Category("236076")]
        public void EnsureThatASCAndDESCDropdownIsAddedAtSortFieldLevelInAddNewSortOrderWindow()
        {
            
                var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
                printSortOrderPage.Navigate();
                printSortOrderPage.ClickAddNewSortOrderButton();
                Assert.IsTrue(printSortOrderPage.IsViewSortOrderAddEditWindowDisplayed());
                Assert.IsTrue(printSortOrderPage.IsSortOrderDisplayed());
                var expectedList = new List<string>() { "Ascending", "Descending" };
                Assert.AreEqual(expectedList, printSortOrderPage.SortOrderDropDownValuesList());

        }
        [TestCase(TestName = "EnsureThatASCAndDESCDropdownIsAddedAtEditSortWindow")]
        [Category("236454")]
        public void EnsureThatASCAndDESCDropdownIsAddedAtEditSortWindow()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();
            printSortOrderPage.KendoGrid.ClickDataCellByRowAndColumnNumber(1,1);
            printSortOrderPage.ClickEditSortOrderButton();
            Assert.IsTrue(printSortOrderPage.IsViewSortOrderAddEditWindowDisplayed());
            Assert.IsTrue(printSortOrderPage.IsSortOrderDisplayed());
            var expectedList = new List<string>() { "Ascending", "Descending" };
            Assert.AreEqual(expectedList, printSortOrderPage.SortOrderDropDownValuesList());

        }

        [TestCase(TestName = "VerifyTheDisabledConfigurationsCheckboxIsDisplayed")]
        [Category("242082")]

        public void VerifyTheDisabledConfigurationsCheckboxIsDisplayed()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.KendoGrid.WaitForKendoReadyState();
            Assert.IsTrue(printSortOrderPage.IsShowDisabledConfigurationsCheckboxDisplayed());
        }

        [TestCase(TestName = "VerifyWhenTheUserSelectsTheDisabledConfigurationCheckBoxPerformsRequiredActionAndThenLogsOffTheDisabledCheckboxShouldBeUnselectedByDefault")]
        [Category("242088")]

        public void VerifyWhenTheUserSelectsTheDisabledConfigurationCheckBoxPerformsRequiredActionAndThenLogsOffTheDisabledCheckboxShouldBeUnselectedByDefault()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.CheckShowDisabledConfigurations();
            Assert.IsTrue(printSortOrderPage.VerifyShowDisabledConfigurationsChecked());

            var addLabelsPage = new AddLabelsPageObj(Driver, LabelMgmtBaseUrl);
            addLabelsPage.Navigate();

            printSortOrderPage.Navigate();
            Assert.False(printSortOrderPage.VerifyShowDisabledConfigurationsChecked());
        }

        [TestCase(TestName = "VerifyTheAddSortOrderDialogueBoxHasDropdownsForClientsAndProcessingLocationsAndShouldBeInEnabledState")]
        [Category("242086")]

        public void VerifyTheAddSortOrderDialogueBoxHasDropdownsForClientsAndProcessingLocationsAndShouldBeInEnabledState()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickAddNewSortOrderButton();
            Assert.IsTrue(printSortOrderPage.IsViewSortOrderAddEditWindowDisplayed());

            Assert.IsTrue(printSortOrderPage.VerifyProcessingLocationDropdownValues());
            Assert.IsTrue(printSortOrderPage.VerifyClientDropdownValues());

            printSortOrderPage.ClickCloseModal();
        }

        [TestCase(TestName = "VerifyTheEditSortOrderDialogueBoxHasDropdownsForClientsAndProcessingLocationsAndShouldBeInEnabledState")]
        [Category("242086")]

        public void VerifyTheEditSortOrderDialogueBoxHasDropdownsForClientsAndProcessingLocationsAndShouldBeInEnabledState()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickDescriptionElement();
            printSortOrderPage.ClickEditSortOrderButton();
            Assert.IsTrue(printSortOrderPage.IsViewSortOrderAddEditWindowDisplayed());

            Assert.IsTrue(printSortOrderPage.VerifyProcessingLocationDropdownValues());
            Assert.IsTrue(printSortOrderPage.VerifyClientDropdownValues());

            printSortOrderPage.ClickCloseModal();
        }

        [TestCase(TestName = "VerifyWhenTheUserHasSelectedMultipleClientsOrProcessingLocationsTheGridShouldDisplayAllForTheClientsOrProcessingLocations")]
        [Category("242132")]

        public void VerifyWhenTheUserHasSelectedMultipleClientsOrProcessingLocationsTheGridShouldDisplayAllForTheClientsOrProcessingLocations()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            var processingloc = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            sortorderDescription = "Aaeutomation" + Extensions.GetDateTimeStamp();
            printSortOrderPage.AddNewSortOrderRecordDescription(sortorderDescription,clients,processingloc,"VIN");

            Assert.AreEqual("All", printSortOrderPage.KendoGrid.GetDataCellText(1, 3, 1));
            Assert.AreEqual("All", printSortOrderPage.KendoGrid.GetDataCellText(1, 4, 1));
        }

        [TestCase(1,TestName = "VerifyWhenTheLabelRecordIsDisabledAndTheDisabledConfigurationsCheckboxIsUnselectedTheLabelWhichIsDisabledShouldNotBeShown")]
        [Category("242084")]

        public void VerifyWhenTheLabelRecordIsDisabledAndTheDisabledConfigurationsCheckboxIsUnselectedTheLabelWhichIsDisabledShouldNotBeShown(int rownumber)
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            var description = printSortOrderPage.KendoGrid.GetDataCellText(1, 2, 1);
            var toggleSwitchInitialValue = printSortOrderPage.IsOnOffInputChecked(rownumber);
            printSortOrderPage.ToggleOnOffToggleByRowNumber(rownumber);
            Assert.IsTrue(printSortOrderPage.IsNotificationMessageDisplayed(NotificationType.Success));
            printSortOrderPage.KendoGrid.WaitForKendoReadyState();

            Assert.AreNotEqual(description, printSortOrderPage.KendoGrid.GetColumnDataAsString(2, 1));
        }

        [TestCase(TestName = "VerifyTheEnabledRecordsAreShownOnTopOfTheList")]
        [Category("242085")]

        public void VerifyTheEnabledRecordsAreShownOnTopOfTheList()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            var fullList = printSortOrderPage.GetAllPrintSortOrderconfigsForOrderVerification();
            var expectedList = new List<string>(fullList);

            fullList.Sort();
            Assert.AreEqual( expectedList, fullList);
        }

        [TestCase(1,TestName = "VerifyWhenTheLabelRecordIsDisabledAndTheDisabledConfigurationsCheckboxIsSelectedTheLabelWhichIsDisabledShouldBeShownAtTheBottomOfTheList")]
        [Category("242083")]

        public void VerifyWhenTheLabelRecordIsDisabledAndTheDisabledConfigurationsCheckboxIsSelectedTheLabelWhichIsDisabledShouldBeShownAtTheBottomOfTheList(int rownumber)
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();
            var desc = printSortOrderPage.IsOnOffInputChecked(rownumber);
            printSortOrderPage.ToggleOnOffToggleByRowNumber(rownumber);
            Assert.IsTrue(printSortOrderPage.IsNotificationMessageDisplayed(NotificationType.Success));

            printSortOrderPage.CheckShowDisabledConfigurations();
            int lastgridrownumber = printSortOrderPage.KendoGrid.GetNumberOfDataRows();
            Assert.IsFalse(printSortOrderPage.IsOnOffInputChecked(lastgridrownumber));
        }

        [TestCase(TestName = "VerifyTheClientAndProcessingLocationAreDisplayedAtTheGridAndIsNotBoundToTheHeaderInformation")]
        [Category("242130")]

        public void VerifyTheClientAndProcessingLocationAreDisplayedAtTheGridAndIsNotBoundToTheHeaderInformation()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            //Verifying that the content is not empty.
            Assert.IsTrue(printSortOrderPage.KendoGrid.GetColumnDataAsString(3, 1).Length > 0);

            Assert.IsTrue(printSortOrderPage.KendoGrid.GetColumnDataAsString(4, 1).Length > 0);
        }


        [TestCase(TestName = "VerifyAvailableFieldsInAddSortOrderModal")]
        [Category("240142")]
        public void VerifyAvailableFieldsInAddSortOrderModal()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickAddNewSortOrderButton();

            Assert.AreEqual(SortOrderPageConstants.AllAvailableFields,  printSortOrderPage.GetAvailableFields());

            printSortOrderPage.SendEscKey();
        }

        [TestCase(TestName = "VerifyAvailableFieldsInEditSortOrderModal")]
        [Category("240142")]
        public void VerifyAvailableFieldsInEditSortOrderModal()
        {
            var printSortOrderPage = new PrintSortOrderPageObj(Driver, LabelMgmtBaseUrl);
            printSortOrderPage.Navigate();

            printSortOrderPage.ClickDescriptionElement();
            printSortOrderPage.ClickEditSortOrderButton();

            Assert.AreEqual(SortOrderPageConstants.AllAvailableFields, printSortOrderPage.GetAvailableFields());

            printSortOrderPage.SendEscKey();
        }
    }
}
