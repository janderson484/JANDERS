using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ViewInvoicesPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(TestName = "VerifyWeCannotInvoiceAUnitLabelThatIsNotPrinted")]
        [Category("230505")]
        public void VerifyWeCannotInvoiceAUnitLabelThatIsNotPrinted()
        {
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Unit);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            Assert.AreEqual(ViewUnitLabelsPageObj.Error_SelectActiveOrClosed, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyActiveUnitLabelsAreInvoiced")]
        [Category("230506")]
        public void VerifyActiveUnitLabelsAreInvoiced()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Unit, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.AreEqual(labelInfo.VIN, viewInvoicesPage.KendoGrid.GetDataCellText(1, 2));
            Assert.IsTrue(viewInvoicesPage.KendoGrid.GetDataCellText(1, 4).Length > 1);

        }

        [TestCase(TestName = "VerifyPendingUnitLabelsAreNotInvoiced")]
        [Category("230509")]
        public void VerifyPendingUnitLabelsAreNotInvoiced()
        {
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Pending, LabelType.Unit);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickPendingCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            Assert.AreEqual(ViewUnitLabelsPageObj.Error_SelectActiveOrClosed, viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyClosedUnitLabelsAreInvoiced")]
        [Category("230693")]
        public void VerifyClosedUnitLabelsAreInvoiced()
        {
            DataHelper.CloseAllOpenInvoices();

            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Closed, LabelType.Unit, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            var labelId = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.AreEqual(labelInfo.VIN, viewInvoicesPage.KendoGrid.GetDataCellText(1, 2));
            Assert.IsTrue(viewInvoicesPage.KendoGrid.GetDataCellText(1, 4).Length > 1);
        }

        [TestCase(TestName = "VerifyGridHeadersInViewInvoicesPage")]
        [Category("233682"), Category("233614"), Category("233615"), Category("233681")]
        public void VerifyGridHeadersInViewInvoicesPage()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();

            viewInvoicesPage.SelectInvoiceStatus(false, false, true, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.AreEqual(ViewInvoicePage.Headers.ToList(), viewInvoicesPage.KendoGrid.GetAllHeadersTextList(1));
        }

        [TestCase(TestName = "VerifyClosedBagLabelsAreInvoiced")]
        [Category("230694")]
        public void VerifyClosedBagLabelsAreInvoiced()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Closed, LabelType.Bag, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickClosedCheckbox(true);
            viewBagLabelPage.ClickSearchButton(); 
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.AreEqual(labelInfo.VIN, viewInvoicesPage.KendoGrid.GetDataCellText(1, 2));
            Assert.IsTrue(viewInvoicesPage.KendoGrid.GetDataCellText(1, 4).Length > 1);
        }


        [TestCase(TestName = "VerifyWeCannotInvoiceABagLabelThatIsNotPrinted")]
        [Category("230661")]
        public void VerifyWeCannotInvoiceABagLabelThatIsNotPrinted()
        {
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Bag);

            var viewBagLabelsPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelsPage.Navigate();

            viewBagLabelsPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelsPage.ClickSearchButton();
            viewBagLabelsPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelsPage.ClickInvoiceAndCloseButton();

            Assert.AreEqual(ViewBagLabelsPageObj.Error_SelectActiveOrClosed, viewBagLabelsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyPendingbagLabelsAreNotInvoiced")]
        [Category("230681")]
        public void VerifyPendingBagLabelsAreNotInvoiced()
        {
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Pending, LabelType.Bag);
            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickPendingCheckbox(true);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickInvoiceAndCloseButton();

            Assert.AreEqual(ViewUnitLabelsPageObj.Error_SelectActiveOrClosed, viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(TestName = "VerifyActiveBagLabelsAreInvoiced")]
        [Category("230665")]
        public void VerifyActiveBagLabelsAreInvoiced()
         {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Bag, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.AreEqual(labelInfo.VIN, viewInvoicesPage.KendoGrid.GetDataCellText(1, 2));
            Assert.IsTrue(viewInvoicesPage.KendoGrid.GetDataCellText(1, 4).Length > 1);
        }


        [TestCase(TestName = "VerifyAfterClosingAnInvoiceTheUnitLabelCannotBeChangedToActive")]
        [Category("230702"), Category("233895"), Category("Bug")]
        public void VerifyAfterClosingAnInvoiceTheUnitLabelCannotBeChangedToActive()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(printLabel: true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            var labelId = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickCloseInvoiceButton();
            viewInvoicesPage.ClickConfirmCloseInvoiceButton();

            viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewUnitLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
            viewUnitLabelPage.ClickSaveChangesbutton();
            Assert.AreEqual(1, viewUnitLabelPage.FailedLabelsCount(), "Bug : After closing an invoice we cant mark a label in it as Active.");
        }

        [TestCase(TestName = "VerifyAfterClosingAnInvoiceTheBagLabelCannotBeChangedToActive")]
        [Category("233816"), Category("Bug")]
        public void VerifyAfterClosingAnInvoiceTheBagLabelCannotBeChangedToActive()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Bag, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickCloseInvoiceButton();
            viewInvoicesPage.ClickConfirmCloseInvoiceButton();

            viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();

            viewBagLabelPage.ClickClosedCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.ClickStatus();
            viewBagLabelPage.LabelStatusFieldOption(BagUnitLabelStatus.Active);
            viewBagLabelPage.ClickSaveChangesbutton();
            Assert.AreEqual(1, viewBagLabelPage.FailedLabelsCount());
        }


        [TestCase(TestName = "VerifyWhenClosedUnitLabelIsChangedToPendingThenChargesShouldBeCleared")]
        [Category("233794")]
        public void VerifyWhenClosedUnitLabelIsChangedToPendingThenChargesShouldBeCleared()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(printLabel:true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();
            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            var labelId = viewUnitLabelPage.KendoGrid.GetDataCellText(1, 1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickBulkUpdateButton();
            viewUnitLabelPage.NotesField();
            viewUnitLabelPage.SelectStatusFromDropdown(LabelStatus.Pending);
            viewUnitLabelPage.ClickUpdateButton();
            viewUnitLabelPage.ClickExitButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();
            Assert.AreEqual(0, viewInvoicesPage.KendoGrid.GetNumberOfDataRows(1, true), "Label still shows up in Invoice");
            //Assert.Fail("We have a known bug 233758. Need to add validations after the bugs is closed.");
        }

        [TestCase(TestName = "VerifyWhenClosedBagLabelIsChangedToPendingThenChargesShouldBeCleared")]
        [Category("233817")]
        public void VerifyWhenClosedBagLabelIsChangedToPendingThenChargesShouldBeCleared()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Bag, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            var labelId = viewBagLabelPage.KendoGrid.GetDataCellText(1, 1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            viewBagLabelPage.ClickClosedCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickBulkUpdateButton();
            viewBagLabelPage.NotesField();
            viewBagLabelPage.SelectStatusFromDropdown(LabelStatus.Pending);
            viewBagLabelPage.ClickUpdateButton();
            viewBagLabelPage.ClickExitButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.AreEqual(0, viewInvoicesPage.KendoGrid.GetNumberOfDataRows(1, true), "Label still shows up in Invoice");
            //Assert.Fail("We have a known bug 233758. Need to add validations after the bugs is closed.");
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatThePrintIsDoneWhenThePrintCountIsGreaterthan0AndTheUnitLabelIsInActiveThenInvoiceAndCloseTheSelectedLabel")]
        [Category("231892")]
        public void VerifyThatThePrintIsDoneWhenThePrintCountIsGreaterthan0AndTheUnitLabelIsInActiveThenInvoiceAndCloseTheSelectedLabel(string user, string password)
        {
            var label1 = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Unit, true);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate(user, password);

            viewUnitLabelPage.ClickActiveCheckbox(true);
            viewUnitLabelPage.ClickClosedCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(label1.VIN);
            viewUnitLabelPage.ClickSearchButton();
            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewUnitLabelPage.ClickInvoiceAndCloseButton();
            viewUnitLabelPage.KendoGrid.WaitForSpinningLoadIcon();

            Assert.AreEqual("Yes", viewUnitLabelPage.KendoGrid.GetColumnDataAsString(UnitLabelPageColumnNumbers.Invoiced));
        }

        [TestCase(TestName = "VerifyTheUnitLabelWithStatusPendingCannotBeClosed")]
        [Category("232054")]
        public void VerifyTheUnitLabelWithStatusPendingCannotBeClosed()
        {
            var label1 = DataHelper.InsertLabel(LabelStatusType.Pending, LabelType.Unit);

            var viewUnitLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewUnitLabelPage.Navigate();

            viewUnitLabelPage.ClickPendingCheckbox(true);
            viewUnitLabelPage.EnterSearchTextField(label1.VIN);
            viewUnitLabelPage.ClickSearchButton();

            viewUnitLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewUnitLabelPage.ClickInvoiceAndCloseButton();

            Assert.AreEqual(ViewUnitLabelsPageObj.Error_SelectActiveOrClosed , viewUnitLabelPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatThePrintIsDoneWhenThePrintCountIsGreaterthan0AndTheBagLabelIsInActiveThenInvoiceAndCloseTheSelectedLabel")]
        [Category("232051")]
        public void VerifyThatThePrintIsDoneWhenThePrintCountIsGreaterthan0AndTheBagLabelIsInActiveThenInvoiceAndCloseTheSelectedLabel(string user, string password)
        {
            var label1 = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Unit, true);

            var viewBagLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);
            viewBagLabelPage.EnterSearchTextField(label1.VIN);
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.ClickClosedCheckbox(true);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);

            viewBagLabelPage.ClickInvoiceAndCloseButton();
            viewBagLabelPage.KendoGrid.WaitForSpinningLoadIcon();

            Assert.AreEqual("Closed", viewBagLabelPage.KendoGrid.GetColumnDataAsString(BagLabelPageColumnNumbers.Status));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyTheBagLabelWithStatusPendingCannotBeClosed")]
        [Category("232055")]
        public void VerifyTheBagLabelWithStatusPendingCannotBeClosed(string user, string password)
        {
            var label1 = DataHelper.InsertLabel(LabelStatusType.Pending, LabelType.Bag);

            var viewBagLabelPage = new ViewUnitLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate(user, password);

            viewBagLabelPage.EnterSearchTextField(label1.VIN);
            viewBagLabelPage.ClickPendingCheckbox(true);
            viewBagLabelPage.ClickSearchButton();
            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            Assert.AreEqual(ViewBagLabelsPageObj.Error_SelectActiveOrClosed, viewBagLabelPage.GetNotificationMessageText(NotificationType.Error));
        }


        [TestCase(TestName = "VerifyTheInvoiceDropdownShouldSortTheInvoicesInDescendingOrderInLM")]
        public void VerifyTheInvoiceDropdownShouldSortTheInvoicesInDescendingOrderInLM()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(true, true, true, true);
            var allinvoices = viewInvoicesPage.GetAllAvailableInvoices();

            if(allinvoices[0].EndsWith("Open"))
                allinvoices.RemoveAt(0);

            var clonedList = new List<string>(allinvoices);
            allinvoices.Sort();
            
            Assert.AreEqual(clonedList, allinvoices);
        }


        [TestCase(TestName = "VerifyPrintInvoiceForClosedInvoice")]
        public void VerifyPrintInvoiceForClosedInvoice()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, false, true, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();
            
            viewInvoicesPage.ClickOnPrintInvoiceButton();

            Assert.True(viewInvoicesPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Request to print invoice created successfully!", viewInvoicesPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyPrintInvoiceForVoidedInvoice")]
        public void VerifyPrintInvoiceForVoidedInvoice()
        {
            DataHelper.VoidAllOpenInvoices();
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.SelectInvoiceStatus(false, false, false, true);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickOnPrintInvoiceButton();
            
            Assert.True(viewInvoicesPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(viewInvoicesPage.Success_PrintReqCreated, viewInvoicesPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyPrintInvoiceDownloadsInvoice")]
        [Category("240316")]
        public void VerifyPrintInvoiceDownloadsInvoice()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.DeleteExportedFile();

            viewInvoicesPage.SelectInvoiceStatus(true, true, true, true);
            viewInvoicesPage.SelectInvoiceByindex(3);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickOnPrintInvoiceButton();

            Assert.True(viewInvoicesPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyPrintClosedInvoice")]
        [Category("240383")]
        public void VerifyPrintClosedInvoice()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.DeleteExportedFile();

            viewInvoicesPage.SelectInvoiceStatus(false,false, true, false);
            viewInvoicesPage.SelectInvoiceByindex(3);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickOnPrintInvoiceButton();

            Assert.True(viewInvoicesPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyPrintVoidedInvoice")]
        [Category("240384")]
        public void VerifyPrintVoidedInvoice()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.DeleteExportedFile();

            viewInvoicesPage.SelectInvoiceStatus(false, false, false , true);
            viewInvoicesPage.SelectInvoiceByindex(3);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickOnPrintInvoiceButton();

            Assert.True(viewInvoicesPage.IsNotificationMessageDisplayed(NotificationType.Success));
        }

        [TestCase(TestName = "VerifyExportInvoiceDownloadsInvoice")]
        [Category("233835")]
        public void VerifyExportInvoiceDownloadsInvoice()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            viewInvoicesPage.DeleteExportedFile();

            viewInvoicesPage.SelectInvoiceStatus(true, true, true, true);
            viewInvoicesPage.SelectInvoiceByindex(3);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            viewInvoicesPage.ClickOnExportInvoiceButton();

            Assert.True(viewInvoicesPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual(viewInvoicesPage.Success_AllRowsExported, viewInvoicesPage.GetNotificationMessageText(NotificationType.Success));
            Assert.IsTrue(viewInvoicesPage.ExportDownloadFileExists());
        }

        [TestCase(TestName = "VerifyCloseButtonIsShowingUpOnInvoicePage")]
        [Category("246199")]
        public void VerifyCloseButtonIsShowingUpOnInvoicePage()
        {
            DataHelper.CloseAllOpenInvoices();
            var labelInfo = DataHelper.InsertLabel(LabelStatusType.Active, LabelType.Bag, true);

            var viewBagLabelPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabelPage.Navigate();
            viewBagLabelPage.ClickActiveCheckbox(true);
            viewBagLabelPage.EnterSearchTextField(labelInfo.VIN);
            viewBagLabelPage.ClickSearchButton();

            viewBagLabelPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabelPage.ClickInvoiceAndCloseButton();

            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();
            
            viewInvoicesPage.SelectInvoiceStatus(false, true, false, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            Assert.True(viewInvoicesPage.IsCloseInvoiceButtonDisplayed());
        }

        [TestCase(TestName = "VerifyOriginationFieldIsPopulatedWithProcessingOfficeInformation")]
        [Category("243494")]
        public void VerifyOriginationFieldIsPopulatedWithProcessingOfficeInformation()
        {
            var viewInvoicesPage = new ViewInvoicesPageObj(Driver, LabelMgmtBaseUrl);
            viewInvoicesPage.Navigate();

            viewInvoicesPage.SelectInvoiceStatus(false, false, true, false);
            viewInvoicesPage.SelectInvoiceByindex(1);
            viewInvoicesPage.ClickViewInvoiceDetailsButton();

            var originationColumn = viewInvoicesPage.KendoGrid.GetColumnDataAsList(9);

            Assert.AreEqual(0, originationColumn.Count(i => i.Length == 0));
        }

    }
}
