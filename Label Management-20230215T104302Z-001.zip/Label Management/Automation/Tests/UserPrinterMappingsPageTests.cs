using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class UserPrinterMappingsPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatAssigPrintersPageShouldBeAccessibleToAdminSupervisorInternalUsers")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyThatAssigPrintersPageShouldBeAccessibleToAdminSupervisorInternalUsers")]
        [TestCase(UserCredentials.InternalUsername, UserCredentials.InternalPassword, TestName = "VerifyThatAssigPrintersPageShouldBeAccessibleToAdminSupervisorInternalUsers")]
        [Category("235151")]

        public void VerifyThatAssigPrintersPageShouldBeAccessibleToAdminSupervisorInternalUsers(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user,password);

            Assert.IsTrue(userPrinterMappingsPage.IsAssignPrinterGridDisplayed());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatAssigningAPrinterIssuccessfulWithAdminCredential")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyThatAssigningAPrinterIssuccessfulWithSupervisorCredential")]
        [Category("235153")]

        public void VerifyThatAssigningAPrinterIssuccessfulWithOnlyAdminAndSupervisorCredential(string user,string password)
        {
            var processingloc = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user,password);

            userPrinterMappingsPage.ClickAssignPrinterButton();
            userPrinterMappingsPage.ClickPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.SuperPrinter);
            userPrinterMappingsPage.EnterUserName();
            userPrinterMappingsPage.SelectClientCodeOptions(clients);
            userPrinterMappingsPage.SelectProcessingLocationOptions(processingloc);


            userPrinterMappingsPage.ClickAssignPrinterSaveButton();
            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Printer Assignment Saved Successfully", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername,UserCredentials.AdminPassword, TestName = "VerifyThatErrorMessageIsDisplayedWwhenPrinterAndUserIsNotSelectedFromTheDropdownList")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyThatErrorMessageIsDisplayedWwhenPrinterAndUserIsNotSelectedFromTheDropdownList")]
        [Category("235183")]

        public void VerifyThatErrorMessageIsDisplayedWwhenPrinterAndUserIsNotSelectedFromTheDropdownList(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickAssignPrinterButton();
            userPrinterMappingsPage.ClickAssignPrinterSaveButton();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("UserName Required", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatEditAssignmentIsSuccessfulForAdmin")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyThatEditAssignmentIsSuccessfulForSupervisor")]
        [Category("235187")]

        public void VerifyThatEditAssignmentIsSuccessful(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickAssignprinterGridRow();
            userPrinterMappingsPage.ClickEditAssignmentButton();
            userPrinterMappingsPage.ClickEditAssignmentPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.Canon);
            userPrinterMappingsPage.ClickAssignPrinterSaveButton();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Printer Assignment Saved Successfully", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Success));
        }

        [TestCase(UserCredentials.AdminUsername,UserCredentials.AdminPassword, TestName = "VerifyPaginationOfTheGrid")]
        [TestCase(UserCredentials.SupervisorUsername, UserCredentials.SupervisorPassword, TestName = "VerifyPaginationOfTheGrid")]
        [Category("235189")]

        public void VerifyPaginationOfTheGrid(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            Assert.IsTrue(userPrinterMappingsPage.IsAssignPrinterGridDisplayed());
            Assert.IsTrue(userPrinterMappingsPage.IsGridPaginationExists());
        }

        [TestCase(UserCredentials.AdminUsername,UserCredentials.AdminPassword, TestName = "VerifyThatAllMenuItemsAndHeaderDataInPageAreTranslatedToSpanishWhenLanguageDropdownIsUpdatedAcordingly")]
        [Category("235193")]

        public void VerifyThatAllMenuItemsAndHeaderDataInPageAreTranslatedToSpanishWhenLanguageDropdownIsUpdatedAcordingly(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.SelectSpanishLanguage();
            userPrinterMappingsPage.KendoGrid.WaitForGridAnimation();

            Assert.AreEqual("Asignar impresora", userPrinterMappingsPage.GetAssignPrinterButtonText());
            Assert.AreEqual(" Editar asignación", userPrinterMappingsPage.GetEditAssignmentButtonText());
            Assert.AreEqual("Administrar impresoras", userPrinterMappingsPage.GetManagePrinterButtonText());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatGridHeadersAreSorted")]
        [Category("235198")]

        public void VerifyThatGridHeadersAreSorted(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            ((IJavaScriptExecutor)Driver).ExecuteScript("document.body.style.zoom='75%';");

            Assert.IsTrue(userPrinterMappingsPage.IsAssignPrinterGridDisplayed());

            /*Assert.IsTrue(userPrinterMappingsPage.IsOnOffSortable());

            Assert.IsTrue(userPrinterMappingsPage.IsPrinterNameSortable());

            Assert.IsTrue(userPrinterMappingsPage.IsIPAddressSortable());

            Assert.IsTrue(userPrinterMappingsPage.IsPortNumberSortable());

            Assert.IsTrue(userPrinterMappingsPage.IsClientCodeSortable());

            Assert.IsTrue(userPrinterMappingsPage.IsUserIdSortable());*/
            userPrinterMappingsPage.KendoGrid.PerformSortAllColumnsTest();
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatAUserCannotAssignToTheSamePrinterMultipleTimesForTheSameClient")]
        [Category("235202")]

        public void VerifyThatAUserCannotAssignToTheSamePrinterMultipleTimesForTheSameClient(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickAssignPrinterButton();
            userPrinterMappingsPage.ClickPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.Canon);
            userPrinterMappingsPage.EnterUserName();
            userPrinterMappingsPage.CopyUserNameText();
            userPrinterMappingsPage.ClickAssignPrinterSaveButton();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Printer Assignment Saved Successfully", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Success));

            userPrinterMappingsPage.ClickAssignPrinterButton();
            userPrinterMappingsPage.ClickPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.Canon);
            userPrinterMappingsPage.EnterSameuserNameText();
            userPrinterMappingsPage.ClickAssignPrinterSaveButton();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Duplicate Printer Assignment", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatWhenTheConfigurationForThePrinterIsEnabledOnlyThePrinterShouldBeDisplayedInPrintPreviewPage")]
        [Category("235204")]

        public void VerifyThatWhenTheConfigurationForThePrinterIsEnabledOnlyThePrinterShouldBeDisplayedInPrintPreviewPage(string user, string password)
        {
            var processingloc = new List<string>() { "Select All" };
            var clients = new List<string>() { "Select All" };

            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickAssignPrinterButton();
            userPrinterMappingsPage.ClickPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.ColourPrinter);
            userPrinterMappingsPage.EnterAdminUserName();
            userPrinterMappingsPage.SelectClientFromDropdown();
            userPrinterMappingsPage.SelectClientCodeOptions(clients);
            userPrinterMappingsPage.SelectProcessingLocationOptions(processingloc);

            userPrinterMappingsPage.ClickAssignPrinterSaveButton();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Success));
            Assert.AreEqual("Printer Assignment Saved Successfully", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Success));

            var viewBagLabesPage = new ViewBagLabelsPageObj(Driver, LabelMgmtBaseUrl);
            viewBagLabesPage.UnselectAllCheckbox();
            viewBagLabesPage.ClickActiveCheckbox(true);
            viewBagLabesPage.ClickDataCheckmarkByRowNumber(1);
            viewBagLabesPage.ClickPrintSelected();
            
            var printPreviewPage = new PrintPreviewPageObj(Driver, LabelMgmtBaseUrl);
            Assert.IsTrue(printPreviewPage.GetAvailablePrinters().Contains(PrinterName.ColourPrinter));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatAddPrintersEditPrinterandUserPrinterMappingsButtonIsDisplayedWhenNavigatedToManagePrintersPage")]
        [Category("235601")]

        public void VerifyThatAddPrintersEditPrinterandUserPrinterMappingsButtonIsDisplayedWhenNavigatedToManagePrintersPage(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickManagePrinterButton();

            Assert.IsTrue(userPrinterMappingsPage.IsAddPrinterButtonDisplayed());
            Assert.IsTrue(userPrinterMappingsPage.IsEditPrinterButtonDisplayed());
            Assert.IsTrue(userPrinterMappingsPage.IsUserPrinterMappingsButtonDisplayed());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatWhenUserPrinterMappingsButtonIsClickedUserIsNavigatedToAssignPrinterPage")]
        [Category("235602")]

        public void VerifyThatWhenUserPrinterMappingsButtonIsClickedUserIsNavigatedToAssignPrinterPage(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickManagePrinterButton();
            userPrinterMappingsPage.ClickUserMappingsButton();

            Assert.IsTrue(userPrinterMappingsPage.IsAssignPrinterGridDisplayed());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatWhenAPrinterIsAddedSuccessMessageIsDisplayed")]
        [Category("235604")]

        public void VerifyThatWhenAPrinterIsAddedSuccessMessageIsDisplayed(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickManagePrinterButton();
            userPrinterMappingsPage.ClickAddPrinterButton();

            userPrinterMappingsPage.EnterPrinterName();
            userPrinterMappingsPage.EnterIPAddress();
            userPrinterMappingsPage.EnterPortNumber();
            userPrinterMappingsPage.ClickAddPrinterSaveButon();

            Assert.IsTrue(Extensions.WaitForAndRemoveSuccessPopup(Driver));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatErrorMessageIsDisplayedWhenAllTheFieldsAreNotSpecifiedInAddPrinterPage")]
        [Category("235606")]

        public void VerifyThatErrorMessageIsDisplayedWhenAllTheFieldsAreNotSpecifiedInAddPrinterPage(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickManagePrinterButton();
            userPrinterMappingsPage.ClickAddPrinterButton();
            userPrinterMappingsPage.ClickAddPrinterSaveButon();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Printer Name Required", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Error));

        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatWhenDuplicatePrinterNameIsSpecifiedErrorMessageShouldBeDisplayed")]
        [Category("235610")]

        public void VerifyThatWhenDuplicatePrinterNameIsSpecifiedErrorMessageShouldBeDisplayed(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickManagePrinterButton();
            userPrinterMappingsPage.ClickAddPrinterButton();

            userPrinterMappingsPage.EnterPrinterName();
            userPrinterMappingsPage.CopyPrinterNameText();
            userPrinterMappingsPage.EnterIPAddress();
            userPrinterMappingsPage.EnterPortNumber();
            userPrinterMappingsPage.ClickAddPrinterSaveButon();

            Assert.IsTrue(Extensions.WaitForAndRemoveSuccessPopup(Driver));

            userPrinterMappingsPage.ClickAddPrinterButton();
            userPrinterMappingsPage.EnterSamePrinterNameText();
            userPrinterMappingsPage.EnterIPAddress();
            userPrinterMappingsPage.EnterPortNumber();
            userPrinterMappingsPage.ClickAddPrinterSaveButon();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("A printer with this Display Name already exists.", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Error));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatSuccessMessageIsDisplayedWhenEditingThePrinterDetails")]
        [Category("235611")]

        public void VerifyThatSuccessMessageIsDisplayedWhenEditingThePrinterDetails(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickManagePrinterButton();
            userPrinterMappingsPage.ViewPrinterGridRowClick();
            userPrinterMappingsPage.ClickEditAssignmentButton();
            userPrinterMappingsPage.EditPrinterName();
            userPrinterMappingsPage.ClickAddPrinterSaveButon();
            userPrinterMappingsPage.KendoGrid.WaitForGridAnimation();
            
            Assert.IsTrue(Extensions.WaitForAndRemoveSuccessPopup(Driver));
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatWhenAPrinterIsAddedItIsReflectedInAssignPrinter")]
        [Category("235714")]

        public void VerifyThatWhenAPrinterIsAddedItIsReflectedInAssignPrinter(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.NavigateToUserPrinterMappings();

            userPrinterMappingsPage.ClickManagePrinterButton();
            userPrinterMappingsPage.ClickAddPrinterButton();

            userPrinterMappingsPage.EnterTestPrinterName();
            userPrinterMappingsPage.EnterIPAddress();
            userPrinterMappingsPage.EnterPortNumber();
            userPrinterMappingsPage.ClickAddPrinterSaveButon();

            Assert.IsTrue(Extensions.WaitForAndRemoveSuccessPopup(Driver));

            userPrinterMappingsPage.ClickUserMappingsButton();
            userPrinterMappingsPage.ClickAssignPrinterButton();
            userPrinterMappingsPage.ClickPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.PrinterSample);
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "EnsureThatPrinterDetailsAreSpecificToIndividualClients")]
        [Category("SCRIPT"), Category("235870")]

        public void EnsureThatPrinterDetailsAreSpecificToIndividualClients(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            var PrinterNameForHertz = userPrinterMappingsPage.KendoGrid.GetDataCellText(1, 2);
            userPrinterMappingsPage.SelectClientFromDropdown();
            userPrinterMappingsPage.ClickApplyButton();
            userPrinterMappingsPage.KendoGrid.WaitForGridAnimation();
            var PrinterNameForEnterprise = userPrinterMappingsPage.KendoGrid.GetDataCellText(1, 2);

            Assert.AreNotEqual(PrinterNameForHertz, PrinterNameForEnterprise);
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyThatErrorMessageIsDisplayedWhenUserTriesToAssignTheSamePrinterMultipleTimesInTheEditAssignmentWindow")]
        [Category("235871")]

        public void VerifyThatErrorMessageIsDisplayedWhenUserTriesToAssignTheSamePrinterMultipleTimesInTheEditAssignmentWindow(string user,string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);

            userPrinterMappingsPage.ClickAssignprinterGridRow();
            userPrinterMappingsPage.ClickEditAssignmentButton();
            userPrinterMappingsPage.ClickEditAssignmentPrinterDropdown();
            userPrinterMappingsPage.PrinterDropdownOption(PrinterName.SuperPrinter);
            userPrinterMappingsPage.ClickAssignPrinterSaveButton();

            Assert.IsTrue(userPrinterMappingsPage.IsNotificationMessageDisplayed(NotificationType.Error));
            Assert.AreEqual("Duplicate Printer Assignment", userPrinterMappingsPage.GetNotificationMessageText(NotificationType.Error));
        }
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyShowDisabledConfigurationsLabel")]
        [Category("243851")]
        public void VerifyShowDisabledConfigurationsLabel(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            Assert.True(userPrinterMappingsPage.VerifyShowDisabledConfigurations());
        }
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyShowDisabledConfigurationsCheckBox")]
        [Category("243852")]
        public void VerifyShowDisabledConfigurationsCheckBox(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            Assert.True(userPrinterMappingsPage.CheckShowDisabledConfigurations());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyShowDisabledConfigurationsCheckBoxIsDefaultDeselcte")]
        [Category("246339")]
        public void VerifyShowDisabledConfigurationsCheckBoxIsDefaultDeselcte(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            Assert.IsFalse(userPrinterMappingsPage.CheckShowDisabledConfigurationsIsSelected());
        }

        
        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify enabled records on top of the list in grid")]
        [Category("243853")]
        public void Verifyenabledrecordsontopofthelistingrid(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            Assert.True(userPrinterMappingsPage.VerifyActiveRecordsInTop());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "Verify enabled records on top of the list in grid and then Description Ascending")]
        [Category("243854")]
        public void VerifyenabledrecordsontopofthelistingridAndThenDescriptionAscending(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            userPrinterMappingsPage.VerifySortOrder();
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyClientAndProcessingLocationFieldsDisplay")]
        [Category("243855")]
        public void VerifyClientAndProcessingLocationFieldsDisplay(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            userPrinterMappingsPage.ClickAssignPrinterButton();
           Assert.True(userPrinterMappingsPage.VerifyClientFieldInAssignPrinterPopUp());
           Assert.True( userPrinterMappingsPage.VerifyProcessingLocationCodeDisply());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyClientAndProcessingLocationFieldssAre MultiSelect")]
        [Category("243865")]
        public void VerifyClientAndProcessingLocationFieldsMultiSelect(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            userPrinterMappingsPage.ClickAddPrinterButton();
            Assert.True(userPrinterMappingsPage.VerifyIsClientDropdownMultiSelect());
            Assert.True(userPrinterMappingsPage.VerifyIsProcessingLocationMultiSelect());
        }

        [TestCase(UserCredentials.AdminUsername, UserCredentials.AdminPassword, TestName = "VerifyClientAndProcessingLocationFieldsinGrid")]
        [Category("243855")]
        public void VerifyClientAndProcessingLocationFieldsinGrid(string user, string password)
        {
            var userPrinterMappingsPage = new UserPrinterMappingsPageObj(Driver, LabelMgmtBaseUrl);
            userPrinterMappingsPage.Navigate(user, password);
            userPrinterMappingsPage.VerifyShowDisabledConfigurations();
            Assert.True(userPrinterMappingsPage.VerifyCLientCodeAndProcessinglocationInGrid());
            
        }

    }
}

