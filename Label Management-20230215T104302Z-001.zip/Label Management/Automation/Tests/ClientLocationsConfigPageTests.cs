using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using VM.FleetServices.TnR.LM.Web.Automation.PageObjects;

namespace VM.FleetServices.TnR.LM.Web.Automation.Tests
{
    [TestFixture(typeof(ChromeDriver))]
    public class ClientLocationsConfigPageTests<TWebDriver> : TnrMgmtUiTestBase<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        [TestCase("Hertz", "desc", "address1", "address2", "city", "Florida", true, TestName = "ClientLocationsConfigPage_AddNewClientLocation_Valid")]
        public void ClientLocationsConfigPage_AddNewClientLocation_Valid(string client, string description, string address1, string address2, string city, string stateProvince, bool ticked)
        {
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            var stamp = DateTime.Now.ToString("MMddyyhhmmss");
            clientLocationsPage.ClickAddNewLocationButton();
            clientLocationsPage.AddNewClientLocation(
                description + stamp,
                client,
                address1 + stamp,
                address2 + stamp,
                city + stamp,
                stateProvince,
                ticked);
            clientLocationsPage.ClickSaveButton();
            clientLocationsPage.ClickExitButton();

            clientLocationsPage.KendoGrid.ClickLastPageArrow();
            var lastRowNumber = clientLocationsPage.KendoGrid.GetNumberOfDataRows(1, true);
            description += stamp;
            var tickedYesNoText = ticked ? "Yes" : "No";

            Assert.AreEqual(description, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetDescriptionColumnNumber()));
            Assert.AreEqual(client, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetClientColumnNumber()));
            Assert.AreEqual(stateProvince, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetDmvStateColumnNumber()));
            Assert.AreEqual(tickedYesNoText, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetDisabledColumnNumber()));
        }

        [TestCase("Hertz", "desc", "address1", "address2", "city", "Florida", true, TestName = "ClientLocationsConfigPage_EditClientLocation_Valid")]
        public void ClientLocationsConfigPage_EditClientLocation_Valid(string client, string description, string address1, string address2, string city, string stateProvince, bool ticked)
        {
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            var stamp = DateTime.Now.ToString("MMddyyhhmmss");
            var lastRowNumber = clientLocationsPage.KendoGrid.GetNumberOfDataRows(1, true);
            clientLocationsPage.KendoGrid.ClickDataCellByRowAndColumnNumber(lastRowNumber, 1);
            var currentClient = clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetClientColumnNumber());
            clientLocationsPage.ClickEditSelectedRowButton();
            var otherClient = clientLocationsPage.GetClientDropdownTextOptions().First(x => !x.Equals(currentClient) && !x.Equals(""));
            clientLocationsPage.SendEscapeKeyToModal();
            var currentDisabledValue = clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetDisabledColumnNumber());
            var otherDisabledValue = !currentDisabledValue.Equals("Yes");

            clientLocationsPage.ClickEditSelectedRowButton();
            // Make sure field clears first
            clientLocationsPage.EditExistingClientLocation(
                description: description + stamp,
                client: otherClient,
                disabled: otherDisabledValue);
            clientLocationsPage.ClickSaveButton();
            clientLocationsPage.ClickExitButton();

            description += stamp;
            var tickedYesNoText = otherDisabledValue ? "Yes" : "No";
            // Extra time to allow grid to update with new values
            Thread.Sleep(1000);

            Assert.AreEqual(description, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetDescriptionColumnNumber()));
            Assert.AreEqual(otherClient, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetClientColumnNumber()));
            Assert.AreEqual(tickedYesNoText, clientLocationsPage.KendoGrid.GetDataCellText(lastRowNumber, clientLocationsPage.GetDisabledColumnNumber()));

            //If test left row disabled, then re-enable
            if (tickedYesNoText.Equals("Yes"))
            {
                clientLocationsPage.KendoGrid.ClickDataCellByRowAndColumnNumber(lastRowNumber, 1);
                clientLocationsPage.ClickEditSelectedRowButton();
                // Make sure field clears first
                clientLocationsPage.EditExistingClientLocation(
                    disabled: false);
                clientLocationsPage.ClickSaveButton();
                clientLocationsPage.ClickExitButton();
            }
        }

        [TestCase(TestName = "ClientLocationsConfigPage_AddNewClientLocation_NoSelections_ErrorsDisplayed")]
        public void ClientLocationsConfigPage_AddNewClientLocation_NoSelections_ErrorsDisplayed()
        {
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            clientLocationsPage.ClickAddNewLocationButton();
            clientLocationsPage.ClickSaveButton(expectFail: true);

            Assert.True(clientLocationsPage.AllModalErrorsDisplayed());
            Assert.True(clientLocationsPage.UpdateFailedErrorPopupDisplayed());
        }

        [TestCase(TestName = "ClientLocationsConfigPage_EditClientLocation_NoRowSelected")]
        public void ClientLocationsConfigPage_EditClientLocation_NoRowSelected()
        {
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            clientLocationsPage.ClickEditSelectedRowButton(expectError: true);
            Assert.True(Driver.WaitForAndRemoveErrorPopup());
        }

        #region KendoTests

        [TestCase(TestName = "ClientLocationsPage_AllColumnsSort")]
        public void ClientLocationsPage_AllColumnsSort()
        {
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            clientLocationsPage.KendoGrid.PerformSortAllColumnsTest();
        }

        [TestCase(TestName = "ClientLocationsPage_PageNumberSelection")]
        public void ClientLocationsPage_PageNumberSelection()
        {
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            clientLocationsPage.KendoGrid.PerformPageSelectionTest();
        }

        [TestCase(TestName = "ClientLocationsPage_ItemsPerPageSelector")]
        public void ClientLocationsPage_ItemsPerPageSelector()
        {
            //Do not reuse this method unless you have > 1 grid on single page
            var clientLocationsPage = new ClientLocationsConfigPageObj(Driver, LabelMgmtBaseUrl);
            clientLocationsPage.Navigate();

            clientLocationsPage.KendoGrid.PerformItemsPerPageTest();
        }

        #endregion

    }
}
