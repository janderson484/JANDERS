using System;
using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Web.Automation
{
    public static class DefaultSettings
    {
        public const int ImplicitWait = 10;
    }

    public static class UserCredentials
    {
        public const string AdminUsername = "FSAMSTESTUSER";
        public const string AdminPassword = "P@ssw0rd";

        public const string SupervisorUsername = "FSAMSTESTUSER2";
        public const string SupervisorPassword = "P@ssw0rd";

        public const string InternalUsername = "FSAMSTESTUSER3";
        public const string InternalPassword = "P@ssw0rd";

        public const string ExternalUsername = "FSAMSTESTUSER4";
        public const string ExternalPassword = "P@ssw0rd";
    }

    public static class BulkProcessing
    {
        public const string DmvBulkProcessSuccessMessage = "The request has been submitted";
    }

    public static class Clients
    {
        public const string Hertz = "HERTZ";
        public const string Ehi = "EHI";
    }

    public static class ClientLocationCode
    {
        // Originating Locations
        public const string HertzOrlando = "HERTZ-ORLANDO";

        // Processing Locations
        public const string Bradenton = "FL-BRADENTON";

        public const string Miami = "HERTZ-MIAMI";
    }

    public static class DmvStates
    {
        public const string Florida = "FL";
        public const string Arizona = "AZ";
    }

    public static class Inventories
    {
        public const string FloridaInventory = "FL-INV";
        public const string ArizonaInventory = "AZ-INV";
        public const string UtahInventory = "UT-INV";
    }

    public static class DmvStatus
    {
        public const string DmvPending = "DMVPending";
        public const string DmvCreated = "DMVCreated";
        public const string DmvMissing = "DMVMissing";
    }

    public static class DmvStatusType
    {
        public const string DmvPending = "DMVPending";
        public const string DmvCreated = "DMVCreated";
        public const string DmvMissing = "DMVMissing";
    }

    public static class Notes
    {
        public const string NotesDefault = "Some test comments";
    }

    public static class GridExport
    {
        public static readonly string DownloadPath = $"C:\\Users\\{Environment.UserName}\\Downloads";
        public static readonly string DownloadedFile = $"C:\\Users\\{Environment.UserName}\\Downloads\\Export.xlsx";
        public static readonly string ExportedInvoiceFile = $"C:\\Users\\{Environment.UserName}\\Downloads\\Invoice.xlsx";
        public const int DateIndex = 14;
        public const string ColumnDataType = "System.String";
        public const int AutoSelectRowCount = 3;
        public const int AutoSelectFirstRow = 1;
       
    }

    public static class LogDetailsPageTableHeader
    {
        public static readonly string[] Title = { "Id", "Error Type", "Error Message", "Actual Record", "Created Time" };
        public static readonly string[] Section = {
            "Process Id","Process Name","Process Type",  "File Name",
            "Total Count",  "Successful Count","Error Count","Warning Count",
            "Status","User","Start Time","End Time" };
    }

    public static class LogDetailsPageStatus
    {
        public const string Completed = "Completed";
        public const string CompletedStatusColorClassName = "process-success";
        public const string InProgress = "In Progress";
        public const string Failed = "Failed";
    }

    public static class LogsPage
    {
        public static readonly string[] Headers = {
            "Id","Process Name","Process Type",  "File Name",
            "Total Count",  "Success Count","Error Count","Warning Count",
            "Status","User Name","Start Time","End Time", "Customer",
            "Processing Location", "Inventory Code" };

        public const string SuccessTransaction = "Completed";
        public const string FailedTransaction = "Failed";

        public static List<string> FilterProcessNames = new List<string>()
        {"All Processes", "Export Labels", "Import Labels", "Pending Invoice Label Action", "Pending Non Active Bag Label Action",
            "Pending Non Active Unit Label Action", "Print Bag Labels", "Print Invoice", "Print Unit Labels",
            "Set Printed And Active To Closed Action" };
    }

    public static class ProcessingLocations
    {
        public const string SunshineBradenton = "FL-BRADENTON";
        public const string SunCityAz = "AZ-SUN_CITY";
        public const string SanAntonioTx = "TX-SAN_ANTONIO";
    }


    public static class ProcessType
    {
        public const string BulkProcess = "BulkProcess";
        public const string Import = "Import";
    }

    public static class ProcessName
    {
        public const string ImportLabels = "Import Labels";
    }


    public static class DescriptionText
    {
        // leading space is intentional
        public const string AutomationConfigurationTest = " Automation_Configuration_Test";
        public const string AddLabelsDropdownPlaceholder = "Select Import Profile";
    }

    public static class SQL
    {
        public const string PMSqlDevConnection = "Data Source=tcp:fs-shared-dev-sql.database.windows.net,1433;Initial Catalog=fs-tnrmgmt-dev-db;User Id=TnrMgmtApp;Password=8!wbVCb398Mz2Rge4hU2qtrB;";
        public const string LMSqlDevConnection = "Data Source=tcp:fs-shared-dev-sql.database.windows.net,1433;Initial Catalog=fs-tnrmgmt-lm-dev-db;User Id=TnrMgmtApp;Password=8!wbVCb398Mz2Rge4hU2qtrB;";

        public const string PMSqlQAConnection = "Data Source=tcp:fs-shared-qa-sql.database.windows.net,1433;Initial Catalog=fs-tnrmgmt-pm-qa-db;User Id=TnrMgmtPMApp;Password=ZKCF#ynxF5$9HJ4FQdCw5Pna;";
        public const string LMSqlQAConnection = "Data Source=tcp:fs-shared-qa-sql.database.windows.net,1433;Initial Catalog=fs-tnrmgmt-lm-qa-db;User Id=TnrMgmtLMApp;Password=Fmj9v$CHfkbJP7q99DmWe7UC;";
    }

    public static class SqlStatement
    {
        public const string DeleteLabelImportRecord = "IF EXISTS (Select * From lm.LabelImports Where Description = ' Automation_Configuration_Test') Delete From lm.LabelImports Where Description = ' Automation_Configuration_Test';";
        public const string DeleteSpecificLabelImportRecord = "IF EXISTS (Select * From lm.LabelImports Where Description = '{0}') Delete From lm.LabelImports Where Description = '{0}';";
    }

    public static class SqlSelectDataViewUnitLabels
    {
        public const string SelectLabelRecord = "select LabelId,LabelStatusTypeId,VIN,RIGHT(VIN,6) as VIN_Last6,Unit,BatchNumber,OwningAreaDeliveryCode,Make,Model,Year,Color,CreatedDate,CreatedDate,ModifiedDate,Notes,PrintCount from lm.Labels where labelid = '{0}' and LabelTypeId = '1' order by LabelId";
    }

    public static class SqlSelectDataViewBagLabels
    {
        public const string SelectLabelRecord = "select top 10 LabelId,LabelStatusTypeId,VIN,RIGHT(VIN,6) as VIN_Last6,Unit,BatchNumber,OwningAreaDeliveryCode," +
            "Make,Model,Year,Color,CreatedDate,CreatedDate,ModifiedDate,Notes,PrintCount from lm.Labels where LabelTypeId = 2 order by LabelId desc";
    }

    public static class ViewBagLabelsColumnHeadings
    {
        public static readonly string[] Headers = {
            "Id","Status","Vin","Print Count","User Name","Unit","Batch Number","Delivery Code",
            "Vin_Last6","Make","Model","Year","Color","Invoiced","Total Amount","Debit/Credit","Ship To",
            "Owning Area","Notes","Created Date","Modified Date", };
    }

    public static class ViewBagLabelsSpanishColumnHeadings
    {
        public static readonly string[] Headers = {
            "Identificación","Estado","Vin","Vin_Last6","Unidad","Número de lote","Área de propiedad",
            "Hacer","Modelo","Año","Color","Nombre de usuario","Fecha de creación","Fecha de modificación",
            "Notas","Número de impresiones","Cantidad total","Débito/Crédito","Código de entrega","Envie a", "TBD" };

    }

    public static class ViewInvoicePage
    {
        public static readonly string[] Headers = {"Transaction ID", "Plate Number / VIN", "State", "Amount", "Billing Fee", "Billing Reason", "Created Date",
            "Debit/Credit", "Origination", "Billing Type", "Note", "Customer", "Processing Location", "Inventory Code" };
    }

    public static class BillingFeeConfigurationColumnHeadings
    {
        public static readonly string[] Headers = {
            "On / Off", "Description", "Charge Amount", "Currency Type", "Processing Office", "Billing Fee Type", "Billing Reason Code"};
    }

    public class SortOrderPageConstants
    {
        public static List<string> AllAvailableFields
        {
            get
            {
                return new List<string>
               {
                "Select" , "Id", "Status", "VIN", "VIN_Last6", "Unit", "Batch Number", "Owning Area", "Make", "Model", "Year", "Color", "User Name",
                "Created Date", "Modified Date", "Notes", "Print Count", "Delivery Code", "Ship To"
                };
            }
        }
    }

    public static class PrintSortOrderColumnheadings
    {
        public const string Active = "On / Off";
        public const string Description = "Description";
        public const string Client = "Client";
        public const string Order = "Order";
    }

    public static class LabelStatus
    {
        public const string Active = "ACTIVE";
        public const string Closed = "CLOSED";
        public const string Duplicate = "DUPLICATE";
        public const string Pending = "PENDING";
        public const string Void = "VOID";

    }

    public static class LabelStatusType
    {
        public const int Pending = 1;
        public const int Duplicate = 2;
        public const int Active = 3;
        public const int Closed = 4;
        public const int Void = 5;
    }

    public enum LabelStatusTypeEnum
    {
        Pending, Duplicate, Active, Closed, Void
    }

    /// <summary>
    /// Used to determine type of label
    /// </summary>
    public enum LabelType
    {
        All = 0,
        Unit = 1,
        Bag = 2
    }

    /// <summary>
    /// Used to determine success or failure message
    /// </summary>
    public enum MessageType
    {
        Success,
        Fail
    }

    public enum NotificationType
    {
        Success,
        Error,
        Info,
        Warn
    }

    public static class BagLabelsColumnHeadings
    {
        public const string Id = "Id";
        public const string Status = "Status";
        public const string Vin = "Vin";
        public const string VinLast6 = "Vin_Last6";
        public const string Unit = "Unit";
        public const string BatchNumber = "Batch Number";
        public const string OwningArea = "Owning Area";
        public const string Make = "Make";
        public const string Model = "Model";
        public const string Year = "Year";
        public const string Color = "Color";
        public const string UserName = "User Name";
        public const string CreatedDate = "Created Date";
        public const string ModifiedDate = "Modified Date";
        public const string Notes = "Notes";
        public const string PrintCount = "Print Count";
        public const string TotalAmount = "Total Amount";
        public const string Debit = "Debit/Credit";
        public const string DEliveryCode = "Delivery Code";
        public const string ShipTo = "Ship To";


    }

    public static class PrintLabelsValidations
    {
        public const string RequestToDownload = "Request to download the document initiated";
    }
    public static class PageTitles
    {
        public const string Dashboard = "Welcome to Label Management";
        public const string AddLabels = "Add Labels";
        public const string ViewBagLabels = "View Bag Labels";
        public const string ViewUnitLabels = "View Unit Labels";
        public const string BulkProcessing = "Bulk Processing";
        public const string Reports = "Reports";
        public const string Logs = "Logs";
        public const string ViewInvoices = "Invoices";
        public const string BillingSetup = "Billing Fee Configuration";
        public const string Login = "Login";
    }

    public static class TimeOuts
    {
        public const int AppTimeOut = 240000;
        public const int CountDownTimer = 60000;
        
    }

    public static class BagLabelPageColumnNumbers
    {
        public const int Id = 1;
        public const int Status = 2;
        public const int Vin = 3;
        public const int PrintCount = 4;
        public const int Username = 5;
        public const int Unit = 6;
        public const int BatchNumber = 7;
        public const int DeliveryCode = 8;
        public const int Vin_Last6 = 9;
        public const int Make = 10;
        public const int Model = 11;
        public const int Year = 12;
        public const int Color = 13;
        public const int Invoiced = 14;
        public const int TotalAmount = 15;
        public const int DebitCredit = 16;
        public const int ShipTo = 17;
        public const int OwningArea = 18;
        public const int Notes = 19;
        public const int CreateDate = 20;
        public const int ModifiedDate = 21;
    }

    public static class UnitLabelPageColumnNumbers
    {
        public const int Id = 1;
        public const int Status = 2;
        public const int Vin = 3;
        public const int PrintCount = 4;
        public const int Username = 5;
        public const int Unit = 6;
        public const int BatchNumber = 7;
        public const int DeliveryCode = 8;
        public const int Vin_Last6 = 9;
        public const int Make = 10;
        public const int Model = 11;
        public const int Year = 12;
        public const int Color = 13;
        public const int Invoiced = 14;
        public const int TotalAmount = 15;
        public const int DebitCredit = 16;
        public const int ShipTo = 17;
        public const int OwningArea = 18;
        public const int Notes = 19;
        public const int CreateDate = 20;
        public const int ModifiedDate = 21;
    }
    public static class PrinterName
    {
        public const string DeskPrinter = "Mark Henley - Desk Label Printer";
        public const string TestPrinter = "Test Printer - Not Actual IP";
        public const string SuperPrinter = "SuperPrinter";
        public const string DuplicatePrinter = "Duplicate Test";
        public const string Canon = "Canon";
        public const string PrinterSample = "Printer201";
        public const string ColourPrinter = "ColourPrinter";
    }

    public static class AssignPrinterColumnHeadings
    {
        public const string OnOff = "On/Off";
        public const string PrinterName = "Printer Name";
        public const string IpAddress = "IP Address";
        public const string PortNumber = "Port Number";
        public const string ClientDetails = "Client Code";
        public const string UserId = "User ID";
    }

    public static class BagUnitLabelStatus
    {
        public const string Active = "Active";
        public const string Closed = "Closed";
        public const string Duplicate = "Duplicate";
        public const string Pending = "Pending";
        public const string Void = "Void";

    }

    public static class ExportFileValidations
    {
        public const string ExportCompleted = "Export Labels is completed";
    }
}
