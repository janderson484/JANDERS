using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Web.Automation
{
    public static class UnitLabelPageMessages
    {
        public const string BulkUpdateCompleted = "Bulk update completed successfully.";
        public const string BulkUpdateError_SelectLabels = "Bulk Update Error\r\nPlease select labels for bulk update action";
        public const string AddNotesForBulkUpdate = "Please add note/status for bulk update and try again.";
        public const string PleaseSelectAtleastOneLabelToPrint = "Error: Please select at least one Active labels to print";
        public const string PleaseSelectOnlyActiveLabels = "Error: Please select only Active labels to print";
        public const string SelectActiveOrClosedPrintedNonInvoiced = "Error: Please select only Active/Closed, Printed & Non invoiced labels to invoice";
        public const string PleaseSelectVoidOrClosedLabels = "Error: Please select void or closed label to copy";
        public const string PleaseSelectVoidOrClosedLabels_AtLeast = "Error: Please select at least one void or closed label to copy";
    }

    public static class BagLabelPageMessages
    {
        public const string BulkUpdateCompleted = "Bulk update completed successfully.";


    }

    public static class PrintPrivewPageMessages
    {
        public const string PrintRequestSent = "Print request created successfully";
        public const string NoRecordsToPrint = "No remaining | No more than one record exists to send to printer";
        
    }

}
