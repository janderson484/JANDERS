-- Create lm schema
CREATE SCHEMA [lm]
GO

-- LabelStatusTypes table
CREATE TABLE [lm].[LabelStatusTypes]
(
	[LabelStatusTypeId] [int] IDENTITY(1,1) NOT NULL,
	[DisplayName] [nvarchar](50) NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
 
	CONSTRAINT [PK_LabelStatusTypes] PRIMARY KEY CLUSTERED ([LabelStatusTypeId] ASC)
)
GO

-- LabelTypes table
CREATE TABLE [lm].[LabelTypes]
(
	[LabelTypeId] [int] IDENTITY(1,1) NOT NULL,
	[DisplayName] [nvarchar](50) NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
 
	CONSTRAINT [PK_LabelTypes] PRIMARY KEY CLUSTERED ([LabelTypeId] ASC)
)
GO

-- LabelSortOrders table
CREATE TABLE [lm].[LabelSortOrders]
(
	[LabelSortOrderId] [int] IDENTITY(1,1) NOT NULL,
	[Active] [bit] NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[SortOrder] [nvarchar](max) NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

	CONSTRAINT [PK_LabelSortOrderId] PRIMARY KEY CLUSTERED ([LabelSortOrderId] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Logs table 
CREATE TABLE [lm].[Logs]
(
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[ClientCode] [nvarchar](15) NOT NULL,
	[ProcessingLocationCode] [nvarchar](20) NULL,
	[ProcessName] [nvarchar](100) NOT NULL,
	[ProcessType] [nvarchar](100) NOT NULL,
	[Filename] [nvarchar](1000) NULL,
	[TotalCount] [int] NOT NULL,
	[SuccessfulCount] [int] NOT NULL,
	[ErrorCount] [int] NULL,
	[WarningCount] [int] NULL,
	[Status] [nvarchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ProcessStartDate] [datetime2](7) NOT NULL,
	[ProcessEndDate] [datetime2](7) NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

	CONSTRAINT [PK_LogId] PRIMARY KEY CLUSTERED ([LogId] ASC)
) 
GO

-- LogDetails table
CREATE TABLE [lm].[LogDetails]
(
	[LogDetailsId] [int] IDENTITY(1,1) NOT NULL,
	[LogId] [int] NOT NULL,
	[ErrorType] [nvarchar](100) NOT NULL,
	[ErrorMessage] [nvarchar](max) NULL,
	[ErrorRecord] [nvarchar](1000) NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

    CONSTRAINT [FK_LogDetails_LogId] FOREIGN KEY([LogId]) REFERENCES [lm].[Logs] ([LogId]),
	CONSTRAINT [PK_LogDetailId] PRIMARY KEY CLUSTERED ([LogDetailsId] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- LabelImports table
CREATE TABLE [lm].[LabelImports]
(
	[LabelImportId] [int] IDENTITY(1,1) NOT NULL,
	[StateProvinceCode] [nvarchar](10) NULL,
	[LabelTypeId] [int] NOT NULL,
	[GenerateBagLabels] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
	[StartDate] [datetime2](7) GENERATED ALWAYS AS ROW START CONSTRAINT [LabelImports_StartDate]  DEFAULT (SYSUTCDATETIME()) NOT NULL,
	[EndDate] [datetime2](7) GENERATED ALWAYS AS ROW END CONSTRAINT [LabelImports_EndDate]  DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59')) NOT NULL,
	[Description] [varchar](255) NULL,	
	PERIOD FOR SYSTEM_TIME ([StartDate], [EndDate]),

    CONSTRAINT [FK_LabelImports_LabelTypeId] FOREIGN KEY([LabelTypeId]) REFERENCES [lm].[LabelTypes] ([LabelTypeId]),
	CONSTRAINT [PK_LabelImports] PRIMARY KEY CLUSTERED ([LabelImportId] ASC)
)
WITH (SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [dbo].[LabelImportsHistory]))
GO

-- ImportLabelRequests table
CREATE TABLE [lm].[ImportLabelRequests]
(
	[ImportLabelRequestId] [int] IDENTITY(1,1) NOT NULL,
	[RequestNumber] [int] NOT NULL,
	[LogId] [int] NULL,
	[Active] [bit] NOT NULL,
	[LabelTypeId] [int] NOT NULL,
	[ClientCode] [nvarchar](15) NOT NULL,
	[ProcessingOffice] [nvarchar](20) NOT NULL,
	[ImportConfigurationDescription] [nvarchar](max) NOT NULL,
	[ImportLabelRecord] [nvarchar](max) NOT NULL,
	[GenerateBagFlag] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
	[LabelImportId] [int] NOT NULL,

    CONSTRAINT [FK_ImportLabelRequests_LabelImportId] FOREIGN KEY([LabelImportId]) REFERENCES [lm].[LabelImports] ([LabelImportId]),
    CONSTRAINT [FK_ImportLabelRequests_LogId] FOREIGN KEY([LogId]) REFERENCES [lm].[Logs] ([LogId]),
    CONSTRAINT [FK_ImportLabelRequests_LabelTypeId] FOREIGN KEY([LabelTypeId]) REFERENCES [lm].[LabelTypes] ([LabelTypeId]),
	CONSTRAINT [PK_ImportLabelRequests] PRIMARY KEY CLUSTERED ([ImportLabelRequestId] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Labels table
CREATE TABLE [lm].[Labels]
(
    [LabelId] [int] IDENTITY(1,1) NOT NULL,
	[LabelStatusTypeId] [int] NOT NULL,
	[LabelTypeId] [int] NOT NULL,
	[ClientCode] [nvarchar](15) NOT NULL,
	[StateProvinceCode] [nvarchar](10) NOT NULL,
	[ProcessingLocationCode] [nvarchar](20) NOT NULL,
	[VIN] [nvarchar](50) NOT NULL,
	[Unit] [nvarchar](50) NULL,
	[DeliveryCode] [nvarchar](50) NULL,
	[BatchNumber] [nvarchar](50) NULL,
	[OwningAreaDeliveryCode] [nvarchar](50) NULL,
	[Make] [nvarchar](50) NULL,
	[Model] [nvarchar](50) NULL,
	[Year] [nvarchar](4) NULL,
	[Color] [nvarchar](50) NULL,
	[Notes] [nvarchar](255) NULL,
	[PrintCount] [int] NOT NULL CONSTRAINT [D_Labels_PrintCount]  DEFAULT (0),
	[ShipTo] [nvarchar](50) NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
	[IsPrinted] [bit] NOT NULL CONSTRAINT [[D_Labels_IsPrinted]  DEFAULT (0),	

    CONSTRAINT [FK_Labels_LabelStatusTypeId] FOREIGN KEY([LabelStatusTypeId]) REFERENCES [lm].[LabelStatusTypes] ([LabelStatusTypeId]),
    CONSTRAINT [FK_Labels_LabelTypeId] FOREIGN KEY([LabelTypeId]) REFERENCES [lm].[LabelTypes] ([LabelTypeId]),
	CONSTRAINT [PK_Labels] PRIMARY KEY CLUSTERED ([LabelId] ASC)
)
GO

-- LabelBillings table
CREATE TABLE [lm].[LabelBillings]
(
	[LabelBillingId] [int] IDENTITY(1,1) NOT NULL,
	[LabelId] [int] NOT NULL,
	[BillingFeeId] [int] NOT NULL,
	[ProcessingLocationCode] [nvarchar](20) NOT NULL,
	[InvoiceId] [int] NULL,
	[IsDebit] [bit] NOT NULL,
	[Void] [bit] NOT NULL,
	[BillingAmount] [money] NULL,
	[Comment] [nvarchar](100) NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[StartDate] [datetime2](7) GENERATED ALWAYS AS ROW START CONSTRAINT [LabelBilling_StartDate] DEFAULT (SYSUTCDATETIME()) NOT NULL,
	[EndDate] [datetime2](7) GENERATED ALWAYS AS ROW END CONSTRAINT [LabelBilling_EndDate]  DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59')) NOT NULL,
	PERIOD FOR SYSTEM_TIME ([StartDate], [EndDate]),

    CONSTRAINT [FK_LabelBillings_LabelId] FOREIGN KEY([LabelId]) REFERENCES [lm].[Labels] ([LabelId]),
	CONSTRAINT [PK_LabelBillings] PRIMARY KEY CLUSTERED ([LabelBillingId] ASC)	
) 
WITH (SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [lm].[LabelBillingsHistory]))
GO

-- LabelImportFields table
CREATE TABLE [lm].[LabelImportFields]
(
	[LabelImportFieldId] [int] IDENTITY(1,1) NOT NULL,
	[DisplayName] [nvarchar](50) NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

	CONSTRAINT [PK_LabelImportFields] PRIMARY KEY CLUSTERED ([LabelImportFieldId] ASC) 
)
GO

-- LabelImportFieldsMappings table
CREATE TABLE [lm].[LabelImportFieldsMappings]
(
	[LabelImportFieldsMappingId] [int] IDENTITY(1,1) NOT NULL,
	[LabelImportId] [int] NOT NULL,
	[LabelImportFieldId] [int] NOT NULL,
	[RequiredField] [bit] NOT NULL,
	[FieldOrder] [int] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[StartDate] [datetime2](7) GENERATED ALWAYS AS ROW START CONSTRAINT [LabelImportFieldsMappings_StartDate]  DEFAULT (SYSUTCDATETIME()) NOT NULL,
	[EndDate] [datetime2](7) GENERATED ALWAYS AS ROW END CONSTRAINT [LabelImportFieldsMappings_EndDate]  DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59')) NOT NULL,
	PERIOD FOR SYSTEM_TIME ([StartDate], [EndDate]),

    CONSTRAINT [FK_LabelImportFieldsMappings_LabelImportFieldId] FOREIGN KEY([LabelImportFieldId]) REFERENCES [lm].[LabelImportFields] ([LabelImportFieldId]),
    CONSTRAINT [FK_LabelImportFieldsMappings_LabelImportId] FOREIGN KEY([LabelImportId]) REFERENCES [lm].[LabelImports] ([LabelImportId]),
	CONSTRAINT [PK_LabelImportFieldsMappings] PRIMARY KEY CLUSTERED ([LabelImportFieldsMappingId] ASC)
) 
WITH (SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [lm].[LabelImportFieldsMappingsHistory]))
GO


-- Notifications table
CREATE TABLE [lm].[Notifications]
(
	[NotificationId] [int] IDENTITY(1,1) NOT NULL,
	[LogId] [int] NOT NULL,
	[NotificationType] [varchar](50) NOT NULL,
	[Message] [varchar](1000) NULL,
	[TotalCount] [int] NOT NULL,
	[SuccessCount] [int] NOT NULL,
	[WarningCount] [int] NOT NULL,
	[ErrorCount] [int] NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[IsRead] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,
	[ProcessName] [varchar](50) NULL,

    CONSTRAINT [FK_Notifications_LogId] FOREIGN KEY([LogId]) REFERENCES [lm].[Logs] ([LogId]),
	CONSTRAINT [PK_Notifications] PRIMARY KEY CLUSTERED ([NotificationId] ASC)
)
GO

-- PersonalSettings table
CREATE TABLE [lm].[PersonalSettings]
(
	[PersonalSettingId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](20) NOT NULL,
	[RowsPerPage] [int] NOT NULL,
	[DaysofHistory] [int] NOT NULL,
	[LabelsToPDF] [bit] NOT NULL,
	[LabelsToPrinter] [bit] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[StartDate] [datetime2](7) GENERATED ALWAYS AS ROW START CONSTRAINT [PersonalSettings_StartDate] DEFAULT (SYSUTCDATETIME()) NOT NULL,
	[EndDate] [datetime2](7) GENERATED ALWAYS AS ROW END CONSTRAINT [PersonalSettings_EndDate] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59')) NOT NULL,
	PERIOD FOR SYSTEM_TIME ([StartDate], [EndDate]),
		
	CONSTRAINT [UQ_PersonalSettings_UserId] UNIQUE NONCLUSTERED ([UserId] ASC),	
	CONSTRAINT [PK_PersonalSettings] PRIMARY KEY CLUSTERED ([PersonalSettingId] ASC)
)
WITH (SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [lm].[PersonalSettingsHistory]))
GO

-- Printers table
CREATE TABLE [lm].[Printers]
(
    [PrinterId] [int] IDENTITY(1,1) NOT NULL,
	[DisplayName] [nvarchar](50) NOT NULL,
	[IPAddress] [nvarchar](50) NULL,
	[PortNumber] [nvarchar](10) NULL,
	[Active] [bit] NOT NULL CONSTRAINT D_Printers_Active DEFAULT (1),
	[CreatedUser] [varchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,	
 
	CONSTRAINT [PK_Printer] PRIMARY KEY CLUSTERED ([PrinterId] ASC)
) 
GO

-- PrinterLabelSettings table
CREATE TABLE [lm].[PrinterLabelSettings]
(
	[PrinterLabelSettingId] [int] IDENTITY(1,1) NOT NULL,
	[PrinterId] [int] NOT NULL,
	[LabelTypeId] [int] NOT NULL,
	[VerticalMargin] [decimal](18, 0) NOT NULL,
	[BottomMargin] [decimal](18, 0) NOT NULL,
	[LeftMargin] [decimal](18, 0) NOT NULL,
	[HorizontalMargin] [decimal](18, 0) NOT NULL,
	[CreatedUser] [varchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

    CONSTRAINT [FK_PrinterLabelSettings_LabelTypeId] FOREIGN KEY([LabelTypeId]) REFERENCES [lm].[LabelTypes] ([LabelTypeId]),
    CONSTRAINT [FK_PrinterLabelSettings_PrinterId] FOREIGN KEY([PrinterId]) REFERENCES [lm].[Printers] ([PrinterId]),
	CONSTRAINT [PK_PrinterLabelSettings] PRIMARY KEY CLUSTERED ([PrinterLabelSettingId] ASC)
) 
GO

-- PrinterUsers table
CREATE TABLE [lm].[PrinterUsers]
(
    [PrinterUserId] [int] IDENTITY(1,1) NOT NULL,
	[PrinterId] [int] NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Active] [bit] NOT NULL CONSTRAINT D_PrinterUsers_Active DEFAULT (1),
	[CreatedUser] [varchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,	

    CONSTRAINT [FK_PrinterUsers_PrinterId] FOREIGN KEY([PrinterId]) REFERENCES [lm].[Printers] ([PrinterId]),
	CONSTRAINT [PK_PrinterUsers] PRIMARY KEY CLUSTERED ([PrinterUserId] ASC)
)
GO

-- PrintLabelRequests table
CREATE TABLE [lm].[PrintLabelRequests]
(
	[PrintLabelRequestId] [int] IDENTITY(1,1) NOT NULL,
	[PrinterId] [int] NOT NULL,
	[Request] [nvarchar](max) NOT NULL,
	[PrintStatus] [nvarchar](20) NOT NULL,
	[ClientCode] [nvarchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

    CONSTRAINT [FK_PrintLabelRequests_PrinterId] FOREIGN KEY([PrinterId]) REFERENCES [lm].[Printers] ([PrinterId]),
	CONSTRAINT [PK_PrintLabelRequests] PRIMARY KEY CLUSTERED ([PrintLabelRequestId] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [lm].[PrinterUserClientMappings]
(
	[PrinterUserClientMappingId] [int] IDENTITY(1,1) NOT NULL,
	[PrinterUserId] [int] NOT NULL,
	[ClientCode] [varchar](50) NOT NULL,
	[CreatedUser] [varchar](50) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,

	CONSTRAINT [FK_PrinterUserClientMappings_PrinterUserId] FOREIGN KEY(PrinterUserId) REFERENCES [lm].[PrinterUsers] (PrinterUserId),
	CONSTRAINT [PK_PrinterUserClientMappings] PRIMARY KEY CLUSTERED (PrinterUserClientMappingId ASC)
 )
GO

CREATE TABLE [lm].[PrinterUserProcessingLocationMappings]
(
	[PrinterUserProcessingLocationMappingId] [int] IDENTITY(1,1) NOT NULL,
	[PrinterUserId] [int] NOT NULL,
	[ProcessingLocationCode] [varchar](50) NOT NULL,
	[CreatedUser] [varchar](50) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,

	CONSTRAINT [FK_PrinterUserProcessingLocationMappings_PrinterUserId] FOREIGN KEY(PrinterUserId) REFERENCES [lm].[PrinterUsers] (PrinterUserId),
	CONSTRAINT [PK_PrinterUserProcessingLocationMappings] PRIMARY KEY CLUSTERED (PrinterUserProcessingLocationMappingId ASC)
 )
GO

CREATE TABLE [lm].[LabelImportClientMappings]
(
	[LabelImportClientMappingId] [int] IDENTITY(1,1) NOT NULL,
	[LabelImportId] [int] NOT NULL,
	[ClientCode] [varchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,

    CONSTRAINT [FK_LabelImportClientMappings_LabelImportId] FOREIGN KEY([LabelImportId]) REFERENCES [lm].[LabelImports] ([LabelImportId]),
    CONSTRAINT [PK_LabelImportClientMappingId] PRIMARY KEY CLUSTERED ([LabelImportClientMappingId] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [lm].[LabelImportProcessingLocationMappings]
(
	[LabelImportProcessingLocationMappingId] [int] IDENTITY(1,1) NOT NULL,
	[LabelImportId] [int] NOT NULL,
	[ProcessingLocationCode] [varchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,

    CONSTRAINT [FK_LabelImportProcessingLocationMappings_LabelImportId] FOREIGN KEY([LabelImportId])REFERENCES [lm].[LabelImports] ([LabelImportId]),
    CONSTRAINT [PK_LabelImportProcessingLocationMappingId] PRIMARY KEY CLUSTERED ([LabelImportProcessingLocationMappingId] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [lm].[PersonalSettingSortOrderMappings]
(
	[PersonalSettingSortOrderMappingId] [int] IDENTITY(1,1) NOT NULL,
	[PersonalSettingId] [int] NOT NULL,
	[ClientCode] [varchar](50) NOT NULL,
	[ProcessingLocationCode] [varchar](50) NOT NULL,
	[LabelSortOrderId] [int] NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL,

    CONSTRAINT [UQ_PersonalSettingSortOrderMappings_PersonalSettingId_ClientCode_ProcessingLocationCode] UNIQUE NONCLUSTERED ([PersonalSettingId] ASC,[ClientCode] ASC,	[ProcessingLocationCode] ASC),
    CONSTRAINT [FK_PersonalSettingSortOrderMappings_LabelSortOrderId] FOREIGN KEY([LabelSortOrderId]) REFERENCES [lm].[LabelSortOrders] ([LabelSortOrderId]),
    CONSTRAINT [FK_PersonalSettingSortOrderMappings_PersonalSettingId] FOREIGN KEY([PersonalSettingId]) REFERENCES [lm].[PersonalSettings] ([PersonalSettingId]),
    CONSTRAINT [PK_PersonalSettingSortOrderMappingId] PRIMARY KEY CLUSTERED ([PersonalSettingSortOrderMappingId] ASC)    
) ON [PRIMARY]
GO

CREATE TABLE [lm].[SortOrderClientMappings]
(
	[SortOrderClientMappingId] [int] IDENTITY(1,1) NOT NULL,
	[LabelSortOrderId] [int] NOT NULL,
	[ClientCode] [varchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,

    CONSTRAINT [FK_SortOrderClientMappings_LabelSortOrderId] FOREIGN KEY([LabelSortOrderId]) REFERENCES [lm].[LabelSortOrders] ([LabelSortOrderId]),
    CONSTRAINT [PK_SortOrderClientMappingId] PRIMARY KEY CLUSTERED ([SortOrderClientMappingId] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [lm].[SortOrderProcessingLocationMappings]
(
	[SortOrderProcessingLocationMappingId] [int] IDENTITY(1,1) NOT NULL,
	[LabelSortOrderId] [int] NOT NULL,
	[ProcessingLocationCode] [varchar](50) NOT NULL,
	[CreatedUser] [nvarchar](50) NOT NULL,
	[CreatedDate] [datetime2](7) NOT NULL,
	[ModifiedUser] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,

    CONSTRAINT [FK_SortOrderProcessingLocationMappings_LabelSortOrderId] FOREIGN KEY([LabelSortOrderId]) REFERENCES [lm].[LabelSortOrders] ([LabelSortOrderId]),
    CONSTRAINT [PK_SortOrderProcessingLocationMappingId] PRIMARY KEY CLUSTERED ([SortOrderProcessingLocationMappingId] ASC)
) ON [PRIMARY]
GO

-----------------------------------------------
--- ALTER TABLE STATEMENTS TO ADD FK CONSTRAINTS
-----------------------------------------------


---------------------------------------------------
--- CREATE INDEX STATEMENTS TO ADD FK INDEX COLUMNS
---------------------------------------------------

CREATE INDEX idx_ImportLabelRequests_LogId ON [lm].[ImportLabelRequests] (LogId)
CREATE INDEX idx_ImportLabelRequests_LabelTypeId ON [lm].[ImportLabelRequests] (LabelTypeId)

CREATE INDEX idx_LabelBillings_LabelId ON [lm].[LabelBillings] (LabelId)

CREATE INDEX idx_LabelImports_LabelTypeId ON [lm].[LabelImports] (LabelTypeId)

CREATE INDEX idx_LabelImportFieldsMappings_LabelImportId ON [lm].[LabelImportFieldsMappings] (LabelImportId)
CREATE INDEX idx_LabelImportFieldsMappings_LabelImportFieldId ON [lm].[LabelImportFieldsMappings] (LabelImportFieldId)

CREATE INDEX idx_Labels_LabelStatusTypeId ON [lm].[Labels] (LabelStatusTypeId)
CREATE INDEX idx_Labels_LabelTypeId ON [lm].[Labels] (LabelTypeId)

CREATE INDEX idx_LogDetails_LogId ON [lm].[LogDetails] (LogId)

CREATE INDEX idx_Notifications_LogId ON [lm].[Notifications] (LogId)

CREATE INDEX idx_PrinterLabelSettings_LabelTypeId ON [lm].[PrinterLabelSettings] (LabelTypeId)
CREATE INDEX idx_PrinterLabelSettings_PrinterId ON [lm].[PrinterLabelSettings] (PrinterId)

CREATE INDEX idx_PrinterUsers_PrinterId ON [lm].[PrinterUsers] (PrinterId)

CREATE NONCLUSTERED INDEX [IDX_SortOrderClientMappings_LabelSortOrderId]
ON [lm].[SortOrderClientMappings] (LabelSortOrderId)
GO

CREATE NONCLUSTERED INDEX [IDX_SortOrderProcessingLocationMappings_LabelSortOrderId]
ON [lm].[SortOrderProcessingLocationMappings] (LabelSortOrderId)
GO

CREATE NONCLUSTERED INDEX [IDX_LabelImportClientMappings_LabelImportId]
ON [lm].[LabelImportClientMappings] (LabelImportId)
GO

CREATE NONCLUSTERED INDEX [IDX_LabelImportProcessingLocationMappings_LabelImportId]
ON [lm].[LabelImportProcessingLocationMappings] (LabelImportId)
GO
-----------------------------------------
--- CREATE LM STORED PROCEDURES
-----------------------------------------

GO
CREATE OR ALTER PROCEDURE [lm].[GetLabels]
(
  @ClientCode NVARCHAR(15),  
  @ProcessingLocationCode NVARCHAR(20), 
  @LabelStatusTypes AS NVARCHAR(255) = '',
  @LabelTypeId AS Int,
  @RowsPerPage INT = 25,  
  @PageNumber INT = 1,
  @SearchColumn NVARCHAR(15) = '',
  @SearchText NVARCHAR(MAX) = '',
  @StartDate DATETIME = NULL,
  @EndDate DATETIME = NULL,
  @Printed BIT = 0,
  @SortOrder NVARCHAR(MAX) = NULL
)
AS
BEGIN
DECLARE @cStartDate AS VARCHAR(10) 
DECLARE @cEndDate AS VARCHAR(10) 
SET @cStartDate = (SELECT CONVERT(VARCHAR(10), @StartDate, 101));
IF @EndDate is null
  SET @EndDate = getdate();
SET @cEndDate = (SELECT CONVERT(VARCHAR(10), @EndDate, 101));
IF @SortOrder is null
	SET @SortOrder= 'labelid'
DECLARE @DynamicSQL NVARCHAR(MAX) = '';

SET @DynamicSQL=N'
   With 
   LabelSearch_CTE AS 
   ( 
	SELECT 
	   LBL.[LabelId]
      ,LBL.[LabelTypeId]
	  ,[VIN] AS [Vin] 
	  ,(SELECT RIGHT([VIN],6)) AS [Vin_Last6]
	  ,[Unit]
      ,LBL.[LabelStatusTypeId]
	  ,LBS.DisplayName AS [LabelStatus]
	  ,[BatchNumber]
	  ,[Make]
      ,[Model]
      ,[Year]
      ,[Color]
      ,[Notes]
	  ,LBL.[CreatedUser] AS [UserName]
      ,LBL.[CreatedDate]
	  ,LBL.[ModifiedDate]
	  ,[PrintCount]
	  ,[DeliveryCode]
	  ,[ShipTo]
	  ,[OwningAreaDeliveryCode]
	  ,IIF(LBL.[IsPrinted] = 1, ''Yes'',''No'') AS PrintStatus
  FROM [lm].[Labels] LBL 
	JOIN [lm].[LabelStatusTypes] LBS ON LBL.LabelStatusTypeId = LBS.LabelStatusTypeId 
  WHERE LBL.LabelStatusTypeId IN (SELECT ISNULL(TRY_CONVERT(INT, value),0) from string_split('''+@LabelStatusTypes+''', '',''))
  AND LBL.LabelTypeId = '+CONVERT(nvarchar, @LabelTypeId)+'
  AND LBL.ClientCode = '''+ @ClientCode +''' 
  AND LBL.ProcessingLocationCode = '''+@ProcessingLocationCode +'''
  AND (1= (CASE WHEN '+CONVERT(nvarchar, @Printed)+'=1 THEN (CASE WHEN LBL.PrintCount > 0 THEN 1 ELSE 0 END ) ELSE 1 END))
  AND (1 = (CASE WHEN LEN('''+@SearchText+''') = 0 THEN 1 ELSE 
  (CASE WHEN UPPER('''+@SearchColumn+''') = ''VIN'' THEN ( CASE WHEN LBL.VIN IN (select value from string_split('''+@SearchText+''', '','')) THEN 1 ELSE 0 END) ELSE ( CASE WHEN LBL.BatchNumber IN (select value from string_split('''+@SearchText+''', '','')) THEN 1 ELSE 0 END) END )
  END))
  AND ( (LBL.CreatedDate >= '''+@cStartDate +''' and LBL.CreatedDate < DATEADD(day,1,'''+@cEndDate+''')) 
   OR ('''+@cStartDate +''' IS NULL AND '''+@cEndDate+''' IS NULL)
   OR ('''+@cStartDate+''' IS NULL AND LBL.CreatedDate < DATEADD(day,1,'''+@cEndDate+'''))
   OR ('''+@cEndDate+''' IS NULL AND LBL.CreatedDate >= '''+@cStartDate+''') )
  ),
  Count_CTE  
  AS
  ( SELECT COUNT(*) AS TotalRows 
	FROM LabelSearch_CTE p 
  )
  SELECT  
      [LabelId]
     ,[LabelTypeId]
	 ,[Vin] 
	 ,[Vin_Last6]
	 ,[Unit]
     ,[LabelStatusTypeId]
	 ,[LabelStatus]
	 ,[BatchNumber]
	 ,[Make]
     ,[Model]
     ,[Year]
     ,[Color]
     ,[Notes]
	 ,[UserName]
     ,[CreatedDate]
	 ,[ModifiedDate]
	 ,[PrintCount]
	 ,[DeliveryCode]
	 ,[ShipTo]
	 ,[OwningAreaDeliveryCode]
	 ,[PrintStatus]
	,(Select SUM(IIF(LBL.IsDebit = 1, LBL.BillingAmount, -LBL.BillingAmount)) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND LBL.Void = 0 ) TotalAmount
	,(CASE WHEN (select count (LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 ) = 0 THEN ''No''
      WHEN (Select Count(LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 AND (InvoiceId = 0 OR InvoiceId Is Null)) > 0 THEN ''No'' -- if there is at least one valid non invoiced billing
      ELSE ''Yes''
      END ) Invoiced
     ,(SELECT [TotalRows] from Count_CTE) as TotalRowCount
  FROM LabelSearch_CTE p 
  ORDER BY ' + @SortOrder +'

  OFFSET '+CONVERT(nvarchar, @RowsPerPage)+' * ('+CONVERT(nvarchar, @PageNumber)+'-1) ROWS  
  FETCH NEXT '+CONVERT(nvarchar, @RowsPerPage)+' ROWS ONLY'

  --PRINT  @DynamicSQL;
  EXEC sp_executesql @DynamicSQL;
  END
  -----------------------------------------------------------------------------------
GO

CREATE OR ALTER PROCEDURE [lm].[GetLabels_back]
(
  @ClientCode NVARCHAR(15),  
  @ProcessingLocationCode NVARCHAR(20), 
  @LabelStatusTypes AS NVARCHAR(255) = '',
  @LabelTypeId AS Int,
  @RowsPerPage INT = 25,  
  @PageNumber INT = 1,
  @SearchColumn NVARCHAR(15) = '',
  @SearchText NVARCHAR(MAX) = '',
  @StartDate DATETIME = NULL,
  @EndDate DATETIME = NULL,
  @Printed BIT = 0
)
AS
BEGIN
DECLARE @cStartDate AS VARCHAR(10) 
DECLARE @cEndDate AS VARCHAR(10) 
SET @cStartDate = (SELECT CONVERT(VARCHAR(10), @StartDate, 101));
SET @cEndDate = (SELECT CONVERT(VARCHAR(10), @EndDate, 101));

   With 
   LabelSearch_CTE AS 
   ( 
	SELECT 
	   LBL.[LabelId]
      ,LBL.[LabelTypeId]
	  ,[VIN] AS [Vin] 
	  ,(SELECT RIGHT([VIN],6)) AS [Vin_Last6]
	  ,[Unit]
      ,LBL.[LabelStatusTypeId]
	  ,LBS.DisplayName AS [LabelStatus]
	  ,[BatchNumber]
	  ,[Make]
      ,[Model]
      ,[Year]
      ,[Color]
      ,[Notes]
	  ,LBL.[CreatedUser] AS [UserName]
      ,LBL.[CreatedDate]
	  ,LBL.[ModifiedDate]
	  ,[PrintCount]
	  ,[DeliveryCode]
	  ,[ShipTo]
	  ,[OwningAreaDeliveryCode]
	  ,IIF(LBL.[IsPrinted] = 1, 'Yes','No') AS PrintStatus
  FROM [lm].[Labels] LBL 
	JOIN [lm].[LabelStatusTypes] LBS ON LBL.LabelStatusTypeId = LBS.LabelStatusTypeId 
  WHERE LBL.LabelStatusTypeId IN (SELECT ISNULL(TRY_CONVERT(INT, value),0) from string_split(@LabelStatusTypes, ','))
  AND LBL.LabelTypeId = @LabelTypeId
  AND LBL.ClientCode = @ClientCode 
  AND LBL.ProcessingLocationCode = @ProcessingLocationCode  
  AND (1= (CASE WHEN @Printed=1 THEN (CASE WHEN LBL.PrintCount > 0 THEN 1 ELSE 0 END ) ELSE 1 END))
  AND (1 = (CASE WHEN LEN(@SearchText) = 0 THEN 1 ELSE 
  (CASE WHEN UPPER(@SearchColumn) = 'VIN' THEN ( CASE WHEN LBL.VIN IN (select value from string_split(@SearchText, ',')) THEN 1 ELSE 0 END) ELSE ( CASE WHEN LBL.BatchNumber IN (select value from string_split(@SearchText, ',')) THEN 1 ELSE 0 END) END )
  END))
  --AND (1 = (CASE WHEN LEN(@SearchText) = 0 THEN 1 ELSE 0 END) Or LBL.VIN IN (select value from string_split(@SearchText, ','))) --- VIN 
  --AND (1 = (CASE WHEN LEN(@SearchText) = 0 THEN 1 ELSE 0 END) Or LBL.BatchNumber IN (select value from string_split(@SearchText, ','))) --- BATCH NUMBER
  AND ( (LBL.CreatedDate >= @cStartDate and LBL.CreatedDate < DATEADD(day,1,@cEndDate)) 
   OR (@cStartDate IS NULL AND @cEndDate IS NULL)
   OR (@cStartDate IS NULL AND LBL.CreatedDate < DATEADD(day,1,@cEndDate))
   OR (@cEndDate IS NULL AND LBL.CreatedDate >= @cStartDate) )
  ),
  Count_CTE  
  AS
  ( SELECT COUNT(*) AS TotalRows 
	FROM LabelSearch_CTE p 
  )
  SELECT  
      [LabelId]
     ,[LabelTypeId]
	 ,[Vin] 
	 ,[Vin_Last6]
	 ,[Unit]
     ,[LabelStatusTypeId]
	 ,[LabelStatus]
	 ,[BatchNumber]
	 ,[Make]
     ,[Model]
     ,[Year]
     ,[Color]
     ,[Notes]
	 ,[UserName]
     ,[CreatedDate]
	 ,[ModifiedDate]
	 ,[PrintCount]
	 ,[DeliveryCode]
	 ,[ShipTo]
	 ,[OwningAreaDeliveryCode]
	 ,[PrintStatus]
	,(Select SUM(IIF(LBL.IsDebit = 1, LBL.BillingAmount, -LBL.BillingAmount)) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND LBL.Void = 0 ) TotalAmount
	,(CASE WHEN (select count (LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 ) = 0 THEN 'No'
      WHEN (Select Count(LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 AND (InvoiceId = 0 OR InvoiceId Is Null)) > 0 THEN 'No' -- if there is at least one valid non invoiced billing
      ELSE 'Yes'
      END ) Invoiced
     ,(SELECT [TotalRows] from Count_CTE) as TotalRowCount
  FROM LabelSearch_CTE p 
  ORDER BY LabelId

  OFFSET @RowsPerPage * (@PageNumber-1) ROWS  
  FETCH NEXT @RowsPerPage ROWS ONLY
  END
  -----------------------------------------------------------------------------------
GO

CREATE OR ALTER PROCEDURE [lm].[GetLabels_sort]
(
  @ClientCode NVARCHAR(15),  
  @ProcessingLocationCode NVARCHAR(20), 
  @LabelStatusTypes AS NVARCHAR(255) = '',
  @LabelTypeId AS Int,
  @RowsPerPage INT = 25,  
  @PageNumber INT = 1,
  @SearchColumn NVARCHAR(15) = '',
  @SearchText NVARCHAR(MAX) = '',
  @StartDate DATETIME = NULL,
  @EndDate DATETIME = NULL,
  @Printed BIT = 0,
  @SortOrder NVARCHAR(MAX) = 'labelid'
)
AS
BEGIN
DECLARE @cStartDate AS VARCHAR(10) 
DECLARE @cEndDate AS VARCHAR(10) 
SET @cStartDate = (SELECT CONVERT(VARCHAR(10), @StartDate, 101));
IF @EndDate is null
  SET @EndDate = getdate();
SET @cEndDate = (SELECT CONVERT(VARCHAR(10), @EndDate, 101));
DECLARE @DynamicSQL NVARCHAR(MAX) = '';

SET @DynamicSQL=N'
   With 
   LabelSearch_CTE AS 
   ( 
	SELECT 
	   LBL.[LabelId]
      ,LBL.[LabelTypeId]
	  ,[VIN] AS [Vin] 
	  ,(SELECT RIGHT([VIN],6)) AS [Vin_Last6]
	  ,[Unit]
      ,LBL.[LabelStatusTypeId]
	  ,LBS.DisplayName AS [LabelStatus]
	  ,[BatchNumber]
	  ,[Make]
      ,[Model]
      ,[Year]
      ,[Color]
      ,[Notes]
	  ,LBL.[CreatedUser] AS [UserName]
      ,LBL.[CreatedDate]
	  ,LBL.[ModifiedDate]
	  ,[PrintCount]
	  ,[DeliveryCode]
	  ,[ShipTo]
	  ,[OwningAreaDeliveryCode]
	  ,IIF(LBL.[IsPrinted] = 1, ''Yes'',''No'') AS PrintStatus
  FROM [lm].[Labels] LBL 
	JOIN [lm].[LabelStatusTypes] LBS ON LBL.LabelStatusTypeId = LBS.LabelStatusTypeId 
  WHERE LBL.LabelStatusTypeId IN (SELECT ISNULL(TRY_CONVERT(INT, value),0) from string_split('''+@LabelStatusTypes+''', '',''))
  AND LBL.LabelTypeId = '+CONVERT(nvarchar, @LabelTypeId)+'
  AND LBL.ClientCode = '''+ @ClientCode +''' 
  AND LBL.ProcessingLocationCode = '''+@ProcessingLocationCode +'''
  AND (1= (CASE WHEN '+CONVERT(nvarchar, @Printed)+'=1 THEN (CASE WHEN LBL.PrintCount > 0 THEN 1 ELSE 0 END ) ELSE 1 END))
  AND (1 = (CASE WHEN LEN('''+@SearchText+''') = 0 THEN 1 ELSE 
  (CASE WHEN UPPER('''+@SearchColumn+''') = ''VIN'' THEN ( CASE WHEN LBL.VIN IN (select value from string_split('''+@SearchText+''', '','')) THEN 1 ELSE 0 END) ELSE ( CASE WHEN LBL.BatchNumber IN (select value from string_split('''+@SearchText+''', '','')) THEN 1 ELSE 0 END) END )
  END))
  AND ( (LBL.CreatedDate >= '''+@cStartDate +''' and LBL.CreatedDate < DATEADD(day,1,'''+@cEndDate+''')) 
   OR ('''+@cStartDate +''' IS NULL AND '''+@cEndDate+''' IS NULL)
   OR ('''+@cStartDate+''' IS NULL AND LBL.CreatedDate < DATEADD(day,1,'''+@cEndDate+'''))
   OR ('''+@cEndDate+''' IS NULL AND LBL.CreatedDate >= '''+@cStartDate+''') )
  ),
  Count_CTE  
  AS
  ( SELECT COUNT(*) AS TotalRows 
	FROM LabelSearch_CTE p 
  )
  SELECT  
      [LabelId]
     ,[LabelTypeId]
	 ,[Vin] 
	 ,[Vin_Last6]
	 ,[Unit]
     ,[LabelStatusTypeId]
	 ,[LabelStatus]
	 ,[BatchNumber]
	 ,[Make]
     ,[Model]
     ,[Year]
     ,[Color]
     ,[Notes]
	 ,[UserName]
     ,[CreatedDate]
	 ,[ModifiedDate]
	 ,[PrintCount]
	 ,[DeliveryCode]
	 ,[ShipTo]
	 ,[OwningAreaDeliveryCode]
	 ,[PrintStatus]
	,(Select SUM(IIF(LBL.IsDebit = 1, LBL.BillingAmount, -LBL.BillingAmount)) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND LBL.Void = 0 ) TotalAmount
	,(CASE WHEN (select count (LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 ) = 0 THEN ''No''
      WHEN (Select Count(LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 AND (InvoiceId = 0 OR InvoiceId Is Null)) > 0 THEN ''No'' -- if there is at least one valid non invoiced billing
      ELSE ''Yes''
      END ) Invoiced
     ,(SELECT [TotalRows] from Count_CTE) as TotalRowCount
  FROM LabelSearch_CTE p 
  ORDER BY ' + @SortOrder +'

  OFFSET '+CONVERT(nvarchar, @RowsPerPage)+' * ('+CONVERT(nvarchar, @PageNumber)+'-1) ROWS  
  FETCH NEXT '+CONVERT(nvarchar, @RowsPerPage)+' ROWS ONLY'

  --PRINT  @DynamicSQL;
  EXEC sp_executesql @DynamicSQL;
  END
  -----------------------------------------------------------------------------------
GO

CREATE OR ALTER PROCEDURE [lm].[GetInProgressPrinterJobs]
(
   @clientCode NVARCHAR(20),
   @processName NVARCHAR(50),
   @labelIds NVARCHAR(MAX)
)
AS
BEGIN
   DECLARE @DynamicSQL NVARCHAR(MAX) = '';
   DECLARE @labelId nvarchar(50);
   DECLARE @pos INT;
   DECLARE @len INT;

   SET @pos = 0
   SET @len = 0
   
   SET @DynamicSQL = 'SELECT * FROM LM.PrintLabelRequests WHERE ClientCode = '''+@clientCode+''' AND JSON_VALUE(Request,''$.Action.ActionCode'') ='''+@processName+''' AND ';
   SET @labelIds = @labelIds + ',';

   WHILE CHARINDEX(',', @labelIds, @pos+1)>0
BEGIN
    SET @len = CHARINDEX(',', @labelIds, @pos+1) - @pos
    SET @labelId = SUBSTRING(@labelIds, @pos, @len)
       
    SET @DynamicSQL = @DynamicSQL + '(Request like ''%\['+Convert(nvarchar(20),@labelId)+']%'' ESCAPE ''\'' or Request like ''%\['+Convert(nvarchar(20),@labelId)+','' ESCAPE ''\'' or Request like ''%,'+Convert(nvarchar(20),@labelId)+',%'' or Request like ''%,'+Convert(nvarchar(20),@labelId)+'\]'' ESCAPE ''\'') OR';

    SET @pos = CHARINDEX(',', @labelIds, @pos+@len) +1

END
   
SET @DynamicSQL = SUBSTRING(@DynamicSQL,0,LEN(@DynamicSQL)-2)
--PRINT @DynamicSQL
EXEC sp_executesql @DynamicSQL;
END
GO




