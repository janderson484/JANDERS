

-------------------------------------------------------------------------------------------------------------------------------
  --- UserStory 263655: LM: Order of Bag and Unit Labels Being Searched should be same as displayed on the grid   -- Start ---
-------------------------------------------------------------------------------------------------------------------------------

/****** Object:  StoredProcedure [lm].[GetLabels]    Script Date: 8/22/2022 12:35:38 PM ******/

CREATE NONCLUSTERED INDEX [IDX_Labels_VIN_BatchNumber]
ON [lm].[Labels] ([VIN], [BatchNumber])
INCLUDE ([LabelStatusTypeId],[LabelTypeId],[ClientCode],[ProcessingLocationCode],[CreatedDate],[IsPrinted])
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER   PROCEDURE [lm].[GetLabels]
(
  @ClientCode NVARCHAR(15),  
  @ProcessingLocationCode NVARCHAR(20), 
  @LabelStatusTypes AS NVARCHAR(255) = '',
  @LabelTypeId AS Int,
  @RowsPerPage INT = 25,  
  @PageNumber INT = 1,
  @SearchColumn NVARCHAR(15) = '',
  @SearchText NVARCHAR(MAX) = '',
  @StartDate DATETIME = NULL,
  @EndDate DATETIME = NULL,
  @Printed BIT = 0,
  @SortOrder NVARCHAR(MAX) = NULL,
  @MaintainSearchOrder BIT = 0
)
AS
BEGIN
DECLARE @cStartDate AS VARCHAR(10) 
DECLARE @cEndDate AS VARCHAR(10) 
SET @cStartDate = (SELECT CONVERT(VARCHAR(10), @StartDate, 101));
IF @EndDate is null
  SET @EndDate = getdate();
SET @cEndDate = (SELECT CONVERT(VARCHAR(10), @EndDate, 101));

IF @MaintainSearchOrder = 1 AND LEN(@SearchText) > 0
BEGIN	
	DECLARE @SearchOrderList NVARCHAR(MAX)
	SELECT @SearchOrderList = COALESCE(@SearchOrderList + ', ', '') +  CONCAT('(''', [value], ''',', ROW_NUMBER() over(order by (SELECT 1)), ')') from string_split(@SearchText, ',')

	SET @SortOrder = ' JOIN ( VALUES ' +  @SearchOrderList + ') o(' + @SearchColumn + ', OrderId) ON p.' + @SearchColumn + '= o.' + @SearchColumn + ' ORDER BY o.OrderId'
END
ELSE IF @SortOrder is null
	SET @SortOrder= ' ORDER BY labelid'
ELSE 
	SET @SortOrder= ' ORDER BY ' + @SortOrder


DECLARE @DynamicSQL NVARCHAR(MAX) = '';

SET @DynamicSQL=N'
   With 
   LabelSearch_CTE AS 
   ( 
	SELECT 
	   LBL.[LabelId]
      ,LBL.[LabelTypeId]
	  ,[VIN] AS [Vin] 
	  ,(SELECT RIGHT([VIN],6)) AS [Vin_Last6]
	  ,[Unit]
      ,LBL.[LabelStatusTypeId]
	  ,LBS.DisplayName AS [LabelStatus]
	  ,[BatchNumber]
	  ,[Make]
      ,[Model]
      ,[Year]
      ,[Color]
      ,[Notes]
	  ,LBL.[CreatedUser] AS [UserName]
      ,LBL.[CreatedDate]
	  ,LBL.[ModifiedDate]
	  ,[PrintCount]
	  ,[DeliveryCode]
	  ,[ShipTo]
	  ,[OwningAreaDeliveryCode]
	  ,IIF(LBL.[IsPrinted] = 1, ''Yes'',''No'') AS PrintStatus
  FROM [lm].[Labels] LBL 
	JOIN [lm].[LabelStatusTypes] LBS ON LBL.LabelStatusTypeId = LBS.LabelStatusTypeId 
  WHERE LBL.LabelStatusTypeId IN (SELECT ISNULL(TRY_CONVERT(INT, value),0) from string_split('''+@LabelStatusTypes+''', '',''))
  AND LBL.LabelTypeId = '+CONVERT(nvarchar, @LabelTypeId)+'
  AND LBL.ClientCode = '''+ @ClientCode +''' 
  AND LBL.ProcessingLocationCode = '''+@ProcessingLocationCode +'''
  AND (1= (CASE WHEN '+CONVERT(nvarchar, @Printed)+'=1 THEN (CASE WHEN LBL.PrintCount > 0 THEN 1 ELSE 0 END ) ELSE 1 END))
  AND (1 = (CASE WHEN LEN('''+@SearchText+''') = 0 THEN 1 ELSE 
  (CASE WHEN UPPER('''+@SearchColumn+''') = ''VIN'' THEN ( CASE WHEN LBL.VIN IN (select value from string_split('''+@SearchText+''', '','')) THEN 1 ELSE 0 END) ELSE ( CASE WHEN LBL.BatchNumber IN (select value from string_split('''+@SearchText+''', '','')) THEN 1 ELSE 0 END) END )
  END))
  AND ( (LBL.CreatedDate >= '''+@cStartDate +''' and LBL.CreatedDate < DATEADD(day,1,'''+@cEndDate+''')) 
   OR ('''+@cStartDate +''' IS NULL AND '''+@cEndDate+''' IS NULL)
   OR ('''+@cStartDate+''' IS NULL AND LBL.CreatedDate < DATEADD(day,1,'''+@cEndDate+'''))
   OR ('''+@cEndDate+''' IS NULL AND LBL.CreatedDate >= '''+@cStartDate+''') )
  ),
  Count_CTE  
  AS
  ( SELECT COUNT(*) AS TotalRows 
	FROM LabelSearch_CTE p 
  )
  SELECT  
      [LabelId]
     ,[LabelTypeId]
	 ,p.[Vin] 
	 ,[Vin_Last6]
	 ,[Unit]
     ,[LabelStatusTypeId]
	 ,[LabelStatus]
	 ,p.[BatchNumber]
	 ,[Make]
     ,[Model]
     ,[Year]
     ,[Color]
     ,[Notes]
	 ,[UserName]
     ,[CreatedDate]
	 ,[ModifiedDate]
	 ,[PrintCount]
	 ,[DeliveryCode]
	 ,[ShipTo]
	 ,[OwningAreaDeliveryCode]
	 ,[PrintStatus]
	,(Select SUM(IIF(LBL.IsDebit = 1, LBL.BillingAmount, -LBL.BillingAmount)) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND LBL.Void = 0 ) TotalAmount
	,(CASE WHEN (select count (LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 ) = 0 THEN ''No''
      WHEN (Select Count(LBL.LabelId) from lm.[LabelBillings] LBL where LBL.LabelId = p.LabelId AND Void = 0 AND (InvoiceId = 0 OR InvoiceId Is Null)) > 0 THEN ''No'' -- if there is at least one valid non invoiced billing
      ELSE ''Yes''
      END ) Invoiced
     ,(SELECT [TotalRows] from Count_CTE) as TotalRowCount
  FROM LabelSearch_CTE p 
  ' + @SortOrder +'

  OFFSET '+CONVERT(nvarchar, @RowsPerPage)+' * ('+CONVERT(nvarchar, @PageNumber)+'-1) ROWS  
  FETCH NEXT '+CONVERT(nvarchar, @RowsPerPage)+' ROWS ONLY'

  --PRINT  @DynamicSQL;
  EXEC sp_executesql @DynamicSQL;
  END
  -----------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------
  --- UserStory 263655: LM: Order of Bag and Unit Labels Being Searched should be same as displayed on the grid   -- End ---
-----------------------------------------------------------------------------------------------------------------------------

