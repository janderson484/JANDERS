--------------------
-- SEED DATA
--------------------
SET IDENTITY_INSERT [lm].[LabelStatusTypes] ON 
INSERT [lm].[LabelStatusTypes] ([LabelStatusTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (1, N'Pending', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
INSERT [lm].[LabelStatusTypes] ([LabelStatusTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (2, N'Duplicate', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
INSERT [lm].[LabelStatusTypes] ([LabelStatusTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (3, N'Active', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
INSERT [lm].[LabelStatusTypes] ([LabelStatusTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (4, N'Closed', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
INSERT [lm].[LabelStatusTypes] ([LabelStatusTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (5, N'Void', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
SET IDENTITY_INSERT [lm].[LabelStatusTypes] OFF
GO

SET IDENTITY_INSERT [lm].[LabelTypes] ON 
INSERT [lm].[LabelTypes] ([LabelTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (1, N'Unit', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
INSERT [lm].[LabelTypes] ([LabelTypeId], [DisplayName], [Active], [CreatedUser], [CreatedDate], [ModifiedUser], [ModifiedDate]) VALUES (2, N'Bag', 1, N'SEEDDATA', GETDATE(), N'SEEDDATA', GETDATE())
SET IDENTITY_INSERT [lm].[LabelTypes] OFF
GO

-------------------
-- NON SEED DATA
-------------------

SET IDENTITY_INSERT [lm].[LabelImportFields] ON 
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (1, N'VIN', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (2, N'Unit', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (3, N'Batch_Number', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (4, N'Owning_Area_Delivery_Code', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (5, N'Make', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (6, N'Model', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (7, N'Year', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (8, N'Color', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (9, N'Delivery_Code', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (10, N'Notes', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (11, N'Ship_To', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
INSERT [lm].[LabelImportFields] ([LabelImportFieldId], [DisplayName], [Active], [CreatedUser], [CreatedDate],[ModifiedUser] ,[ModifiedDate]) VALUES (12, N'BLANK_COLUMN', 1, N'TESTDATA', GETDATE(), N'TESTDATA', GETDATE())
SET IDENTITY_INSERT [lm].[LabelImportFields] OFF
GO
