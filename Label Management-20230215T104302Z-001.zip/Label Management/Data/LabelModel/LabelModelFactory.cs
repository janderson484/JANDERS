﻿using System;
using Ats.FleetServices.Core.Data;
using Microsoft.Extensions.DependencyInjection;

namespace VM.FleetServices.TnR.LM.Data.LabelModel
{
    public class LabelModelFactory : IDbModelFactory<ILabelModel>
    {
        private readonly IServiceProvider _serviceProvider;

        public LabelModelFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public ILabelModel Create()
        {
            return _serviceProvider.GetService<ILabelModel>();
        }
    }
}
