﻿using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LabelBillingEntityConfiguration : IEntityConfiguration<LabelBilling>
    {
        public void EntityConfiguration(EntityConfiguration<LabelBilling> config)
        {
            config.ConfigureTable("LabelBillings", t => t.LabelBillingId);
            config.ConfigureProperty(t => t.LabelBillingId, "LabelBillingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LabelId, "LabelId");
            config.ConfigureProperty(t => t.BillingFeeId, "BillingFeeId");
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.InvoiceId, "InvoiceId");
            config.ConfigureProperty(t => t.IsDebit, "IsDebit");
            config.ConfigureProperty(t => t.Void, "Void");
            config.ConfigureProperty(t => t.BillingAmount, "BillingAmount");
            config.ConfigureProperty(t => t.Comment, "Comment", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
        }
    }
}
