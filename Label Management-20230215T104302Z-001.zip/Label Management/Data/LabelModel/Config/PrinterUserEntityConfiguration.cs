using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PrinterUserEntityConfiguration : IEntityConfiguration<PrinterUser>
    {
        public void EntityConfiguration(EntityConfiguration<PrinterUser> config)
        {
            config.ConfigureTable("PrinterUsers", t => t.PrinterUserId);

            config.ConfigureProperty(t => t.PrinterId, "PrinterUserId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.PrinterId, "PrinterId");
            config.ConfigureProperty(t => t.UserName, "UserName", IsRequired.Yes, 50);
           // config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 50);
            //config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
