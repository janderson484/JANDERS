using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LabelEntityConfiguration : IEntityConfiguration<Label>
    {
        public void EntityConfiguration(EntityConfiguration<Label> config)
        {
            config.ConfigureTable("Labels", t => t.LabelId);
            config.ConfigureProperty(t => t.LabelTypeId, "LabelTypeId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LabelStatusTypeId, "LabelStatusTypeId");
            config.ConfigureProperty(t => t.LabelTypeId, "LabelTypeId");
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.StateProvinceCode, "StateProvinceCode", IsRequired.Yes, 10);
            //config.ConfigureProperty(t => t.ClientLocationCode, "ShipTo", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.VIN, "VIN", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.Unit, "Unit", IsRequired.No, 50);
            config.ConfigureProperty(t => t.DeliveryCode, "DeliveryCode", IsRequired.No, 50);
            config.ConfigureProperty(t => t.BatchNumber, "BatchNumber", IsRequired.No, 50);
            config.ConfigureProperty(t => t.OwningAreaDeliveryCode, "OwningAreaDeliveryCode", IsRequired.No, 50);
            config.ConfigureProperty(t => t.Make, "Make", IsRequired.No, 50);
            config.ConfigureProperty(t => t.Model, "Model", IsRequired.No, 50);
            config.ConfigureProperty(t => t.Year, "Year", IsRequired.No, 4);
            config.ConfigureProperty(t => t.Color, "Color", IsRequired.No, 50);
            config.ConfigureProperty(t => t.Notes, "Notes", IsRequired.No, 255);
            config.ConfigureProperty(t => t.PrintCount, "PrintCount");
            config.ConfigureProperty(t => t.ShipTo, "ShipTo", IsRequired.No, 50);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
            config.ConfigureProperty(t => t.IsPrinted, "IsPrinted");
            config.ConfigureNavigationProperty(t => t.LabelBillings, l => l.Label, d => d.LabelId);
        }
    }
}
