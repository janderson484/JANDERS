using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class ImportLabelRequestEntityConfiguration : IEntityConfiguration<ImportLabelRequest>
    {
        public void EntityConfiguration(EntityConfiguration<ImportLabelRequest> config)
        {
            config.ConfigureTable("ImportLabelRequest", t => t.ImportLabelRequestId);

            config.ConfigureProperty(t => t.ImportLabelRequestId, "ImportLabelRequestId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.RequestNumber, "RequestNumber");
            config.ConfigureProperty(t => t.LogId, "LogId");
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.LabelTypeId, "LabelTypeId");
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.ProcessingOffice, "ProcessingOffice", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.LabelImportId, "LabelImportId");
            config.ConfigureProperty(t => t.ImportConfigurationDescription, "ImportConfigurationDescription", IsRequired.Yes, 4000);
            config.ConfigureProperty(t => t.ImportLabelRecord, "ImportLabelRecord", IsRequired.Yes, 200);
            config.ConfigureProperty(t => t.GenerateBagFlag, "GenerateBagFlag");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
