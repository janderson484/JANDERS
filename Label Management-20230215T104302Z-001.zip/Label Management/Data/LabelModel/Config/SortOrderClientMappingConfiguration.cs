using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class SortOrderClientMappingConfiguration : IEntityConfiguration<SortOrderClientMapping>
    {
        public void EntityConfiguration(EntityConfiguration<SortOrderClientMapping> config)
        {
            config.ConfigureTable("SortOrderClientMappings", t => t.SortOrderClientMappingId);
            config.ConfigureProperty(t => t.SortOrderClientMappingId, "SortOrderClientMappingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LabelSortOrderId, "LabelSortOrderId");
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
