﻿using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LabelTypeEntityConfiguration : IEntityConfiguration<LabelType>
    {
        public void EntityConfiguration(EntityConfiguration<LabelType> config)
        {
            config.ConfigureTable("LabelTypes", t => t.LabelTypeId);
            config.ConfigureProperty(t => t.LabelTypeId, "LabelTypeId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.DisplayName, "DisplayName", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
