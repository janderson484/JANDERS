using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PrinterUserProcessingLocationMappingEntityConfiguration : IEntityConfiguration<PrinterUserProcessingLocationMapping>
    {
        public void EntityConfiguration(EntityConfiguration<PrinterUserProcessingLocationMapping> config)
        {

            config.ConfigureTable("PrinterUserProcessingLocationMappings", t => t.PrinterUserProcessingLocationMappingId);

            config.ConfigureProperty(t => t.PrinterUserProcessingLocationMappingId, "PrinterUserProcessingLocationMappingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.PrinterUserId, "PrinterUserId");
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }    
    }
}
