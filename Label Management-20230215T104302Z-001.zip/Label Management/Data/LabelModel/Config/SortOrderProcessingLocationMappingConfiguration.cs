using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class SortOrderProcessingLocationMappingConfiguration : IEntityConfiguration<SortOrderProcessingLocationMapping>
    {
        public void EntityConfiguration(EntityConfiguration<SortOrderProcessingLocationMapping> config)
        {
            config.ConfigureTable("SortOrderProcessingLocationMappings", t => t.SortOrderProcessingLocationMappingId);
            config.ConfigureProperty(t => t.SortOrderProcessingLocationMappingId, "SortOrderProcessingLocationMappingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LabelSortOrderId, "LabelSortOrderId");
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
