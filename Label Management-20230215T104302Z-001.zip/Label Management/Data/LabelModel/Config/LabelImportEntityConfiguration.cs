using Ats.FleetServices.Core.Data;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LabelImportEntityConfiguration : IEntityConfiguration<LabelImport>
    {
        public void EntityConfiguration(EntityConfiguration<LabelImport> config)
        {
            config.ConfigureTable("LabelImports", t => t.LabelImportId);
            config.ConfigureProperty(t => t.LabelImportId, "LabelImportId", ValueGenerated.OnAdd);
           // config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.StateProvinceCode, "StateProvinceCode", IsRequired.Yes, 10);
            //config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.LabelTypeId, "LabelTypeId");
            config.ConfigureProperty(t => t.GenerateBagLabels, "GenerateBagLabels");
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
            config.ConfigureProperty(t => t.Description, "Description", IsRequired.Yes, 255);
        }
    }
}
