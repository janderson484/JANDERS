using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;


namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PersonalSettingEntityConfiguration : IEntityConfiguration<PersonalSetting>
    {
        public void EntityConfiguration(EntityConfiguration<PersonalSetting> config)
        {
            config.ConfigureTable("PersonalSettings", t => t.PersonalSettingId);

            config.ConfigureProperty(t => t.PersonalSettingId, "PersonalSettingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.UserId, "UserId", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.RowsPerPage, "RowsPerPage");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.DaysofHistory, "DaysofHistory");
            config.ConfigureProperty(t => t.LabelsToPDF, "LabelsToPDF");
            config.ConfigureProperty(t => t.LabelsToPrinter, "LabelsToPrinter");
            //config.ConfigureProperty(t => t.StartDate, "StartDate");
            //config.ConfigureProperty(t => t.EndDate, "EndDate");
        }
    }
}
