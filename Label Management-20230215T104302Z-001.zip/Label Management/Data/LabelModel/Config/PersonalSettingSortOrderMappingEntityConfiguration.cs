using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PersonalSettingSortOrderMappingEntityConfiguration : IEntityConfiguration<PersonalSettingSortOrderMapping>
    {
        public void EntityConfiguration(EntityConfiguration<PersonalSettingSortOrderMapping> config)
        {
            config.ConfigureTable("PersonalSettingSortOrderMapping", t => t.PersonalSettingSortOrderMappingId);
            config.ConfigureProperty(t => t.PersonalSettingSortOrderMappingId, "PersonalSettingSortOrderMappingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.PersonalSettingId, "PersonalSettingId");
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.LabelSortOrderId, "LabelSortOrderId");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
