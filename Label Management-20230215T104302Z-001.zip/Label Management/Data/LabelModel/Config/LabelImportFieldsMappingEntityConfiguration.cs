using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LabelImportFieldsMappingEntityConfiguration : IEntityConfiguration<LabelImportFieldsMapping>
    {
        public void EntityConfiguration(EntityConfiguration<LabelImportFieldsMapping> config)
        {
            config.ConfigureTable("LabelImportFieldsMappings", t => t.LabelImportFieldsMappingId);
            config.ConfigureProperty(t => t.LabelImportFieldsMappingId, "LabelImportFieldsMappingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LabelImportFieldId, "LabelImportFieldId");
            config.ConfigureProperty(t => t.LabelImportId, "LabelImportId");
            config.ConfigureProperty(t => t.FieldOrder, "FieldOrder");
            config.ConfigureProperty(t => t.RequiredField, "RequiredField");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
        }
    }
}
