using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LogDetailEntityConfiguration : IEntityConfiguration<LogDetail>
    {
        public void EntityConfiguration(EntityConfiguration<LogDetail> config)
        {
            config.ConfigureTable("LogDetails", t => t.LogDetailsId);

            config.ConfigureProperty(t => t.LogDetailsId, "LogDetailsId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LogId, "LogId");
            config.ConfigureProperty(t => t.ErrorType, "ErrorType", IsRequired.Yes, 100);
            config.ConfigureProperty(t => t.ErrorMessage, "ErrorMessage", IsRequired.Yes, 500);
            config.ConfigureProperty(t => t.ErrorRecord, "ErrorRecord", IsRequired.Yes, 1000);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.CreatedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "ModifiedDate");
        }
    }
}
