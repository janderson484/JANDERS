using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PrinterEntityConfiguration : IEntityConfiguration<Printer>
    {
        public void EntityConfiguration(EntityConfiguration<Printer> config)
        {
            config.ConfigureTable("Printers", t => t.PrinterId);

            config.ConfigureProperty(t => t.PrinterId, "PrinterId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.DisplayName, "DisplayName", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.IPAddress, "IPAddress", IsRequired.No, 50);
            config.ConfigureProperty(t => t.PortNumber, "PortNumber", IsRequired.No, 10);
            config.ConfigureProperty(t => t.Active, "Active");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
