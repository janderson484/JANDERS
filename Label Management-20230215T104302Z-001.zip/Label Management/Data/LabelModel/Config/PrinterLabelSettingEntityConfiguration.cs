using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PrinterLabelSettingEntityConfiguration : IEntityConfiguration<PrinterLabelSetting>
    {
        public void EntityConfiguration(EntityConfiguration<PrinterLabelSetting> config)
        {
            config.ConfigureTable("PrinterLabelSettings", t => t.PrinterLabelSettingId);

            config.ConfigureProperty(t => t.PrinterId, "PrinterLabelSettingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.PrinterId, "PrinterId");
            config.ConfigureProperty(t => t.LabelTypeId, "LabelTypeId");
            config.ConfigureProperty(t => t.VerticalMargin, "VerticalMargin");
            config.ConfigureProperty(t => t.BottomMargin, "BottomMargin");
            config.ConfigureProperty(t => t.LeftMargin, "LeftMargin");
            config.ConfigureProperty(t => t.HorizontalMargin, "HorizontalMargin");
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
