using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class LabelImportProcessingLocationMappingConfiguration : IEntityConfiguration<LabelImportProcessingLocationMapping>
    {
        public void EntityConfiguration(EntityConfiguration<LabelImportProcessingLocationMapping> config)
        {
            config.ConfigureTable("LabelImportProcessingLocationMappings", t => t.LabelImportProcessingLocationMappingId);
            config.ConfigureProperty(t => t.LabelImportProcessingLocationMappingId, "LabelImportProcessingLocationMappingId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.LabelImportId, "LabelImportId");
            config.ConfigureProperty(t => t.ProcessingLocationCode, "ProcessingLocationCode", IsRequired.Yes, 15);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedDate");
        }
    }
}
