using System;
using System.Collections.Generic;
using System.Text;
using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore.Metadata;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Config
{
    public class PrintLabelRequestEntityConfiguration : IEntityConfiguration<PrintLabelRequest>
    {
        public void EntityConfiguration(EntityConfiguration<PrintLabelRequest> config)
        {
            config.ConfigureTable("PrintLabelRequest", t => t.PrintLabelRequestId);

            config.ConfigureProperty(t => t.PrintLabelRequestId, "PrintLabelRequestId", ValueGenerated.OnAdd);
            config.ConfigureProperty(t => t.PrinterId, "PrinterId");
            config.ConfigureProperty(t => t.Request, "Request", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.PrintStatus, "PrintStatus", IsRequired.Yes, 20);
            config.ConfigureProperty(t => t.ClientCode, "ClientCode", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedUser, "CreatedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.ModifiedUser, "ModifiedUser", IsRequired.Yes, 50);
            config.ConfigureProperty(t => t.CreatedDate, "CreatedDate");
            config.ConfigureProperty(t => t.ModifiedDate, "ModifiedUser");
        }
    }
}
