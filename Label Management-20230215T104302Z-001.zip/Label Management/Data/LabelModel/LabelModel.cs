using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.LM.Data.LabelModel.Config;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel
{
    public partial class LabelModel : DbModelBase, ILabelModel
    {
        public LabelModel()
        {

        }

        public LabelModel(DbContextOptions<LabelModel> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("lm");
        }

        protected override void Configure()
        {
            AddEntityTypeConfiguration(new LabelBillingEntityConfiguration());
            AddEntityTypeConfiguration(new LabelEntityConfiguration());
            AddEntityTypeConfiguration(new LabelImportEntityConfiguration());
            AddEntityTypeConfiguration(new LabelImportFieldEntityConfiguration());
            AddEntityTypeConfiguration(new LabelImportFieldsMappingEntityConfiguration());
            AddEntityTypeConfiguration(new LabelStatusTypeEntityConfiguration());
            AddEntityTypeConfiguration(new LabelTypeEntityConfiguration());
            AddEntityTypeConfiguration(new LabelSortOrderEntityConfiguration());
            AddEntityTypeConfiguration(new ImportLabelRequestEntityConfiguration());
            AddEntityTypeConfiguration(new NotificationEntityConfiguration());
            AddEntityTypeConfiguration(new LogEntityConfiguration());
            AddEntityTypeConfiguration(new LogDetailEntityConfiguration());
            AddEntityTypeConfiguration(new PrinterEntityConfiguration());
            AddEntityTypeConfiguration(new PrinterLabelSettingEntityConfiguration());
            AddEntityTypeConfiguration(new PrinterUserEntityConfiguration());
            AddEntityTypeConfiguration(new PersonalSettingEntityConfiguration());
            AddEntityTypeConfiguration(new PrinterUserClientMappingEntityConfiguration());
            AddEntityTypeConfiguration(new PrinterUserProcessingLocationMappingEntityConfiguration());
            AddEntityTypeConfiguration(new SortOrderClientMappingConfiguration());
            AddEntityTypeConfiguration(new SortOrderProcessingLocationMappingConfiguration());
            AddEntityTypeConfiguration(new PersonalSettingSortOrderMappingEntityConfiguration());
            AddEntityTypeConfiguration(new LabelImportClientMappingConfiguration());
            AddEntityTypeConfiguration(new LabelImportProcessingLocationMappingConfiguration());
        }

        public virtual DbSet<Label> Labels { get; set; }
        public virtual DbSet<LabelBilling> LabelBillings { get; set; }
        public virtual DbSet<LabelImportField> LabelImportFields { get; set; }
        public virtual DbSet<LabelImportFieldsMapping> LabelImportFieldsMappings { get; set; }
        public virtual DbSet<LabelImport> LabelImports { get; set; }
        public virtual DbSet<LabelStatusType> LabelStatusTypes { get; set; }
        public virtual DbSet<LabelType> LabelTypes { get; set; }
        public virtual DbSet<LabelSortOrder> LabelSortOrders { get; set; }
        public virtual DbSet<ImportLabelRequest> ImportLabelRequests { get; set; }
        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<Log> Logs { get; set; }
        public virtual DbSet<LogDetail> LogDetails { get; set; }
        public virtual DbSet<Printer> Printers { get; set; }
        public virtual DbSet<PrinterLabelSetting> PrinterLabelSettings { get; set; }
        public virtual DbSet<PrinterUser> PrinterUsers { get; set; }
        public virtual DbSet<PersonalSetting> PersonalSettings { get; set; }
        public virtual DbSet<PrintLabelRequest> PrintLabelRequests { get; set; }
        public virtual DbSet<PrinterUserClientMapping> PrinterUserClientMappings { get; set; }
        public virtual DbSet<PrinterUserProcessingLocationMapping> PrinterUserProcessingLocationMappings { get; set; }
        public virtual DbSet<SortOrderClientMapping> SortOrderClientMappings { get; set; }
        public virtual DbSet<SortOrderProcessingLocationMapping> SortOrderProcessingLocationMappings { get; set; }
        public virtual DbSet<PersonalSettingSortOrderMapping> PersonalSettingSortOrderMappings { get; set; }
        public virtual DbSet<LabelImportClientMapping> LabelImportClientMappings { get; set; }
        public virtual DbSet<LabelImportProcessingLocationMapping> LabelImportProcessingLocationMappings { get; set; }
    }

}
