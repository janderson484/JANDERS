using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class PrinterUserProcessingLocationMapping
    {
        public int PrinterUserProcessingLocationMappingId { get; set; }
        public int PrinterUserId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
