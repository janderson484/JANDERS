using System;
using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class LabelSortOrder
    {
        public int LabelSortOrderId { get; set; }
        public bool Active { get; set; }
        public string Description { get; set; }
        public string SortOrder { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public virtual ICollection<SortOrderClientMapping> SortOrderClientMappings { get; set; }
        public virtual ICollection<SortOrderProcessingLocationMapping> SortOrderProcessingLocationMappings { get; set; }
        public virtual ICollection<PersonalSettingSortOrderMapping> PersonalSettingSortOrderMappings { get; set; }
    }
}
