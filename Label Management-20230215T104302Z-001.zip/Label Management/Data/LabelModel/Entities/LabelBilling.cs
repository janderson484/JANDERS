using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class LabelBilling
    {
        public int LabelBillingId { get; set; }
        public int LabelId { get; set; }
        public int BillingFeeId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int? InvoiceId { get; set; }
        public bool IsDebit { get; set; }
        public bool Void { get; set; }
        public decimal? BillingAmount { get; set; }
        public string Comment { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public virtual Label Label { get; set; }
    }
}
