using System;
using System.ComponentModel.DataAnnotations;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class PrintLabelRequest
    {
        [Key]
        public int PrintLabelRequestId { get; set; }
        public int PrinterId { get; set; }
        public string Request { get; set; }
        public string PrintStatus { get; set; }
        public string ClientCode { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
