using System;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class SortOrderProcessingLocationMapping
    {
        public int SortOrderProcessingLocationMappingId { get; set; }
        public int LabelSortOrderId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public virtual LabelSortOrder LabelSortOrders { get; set; }
    }
}
