using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class PersonalSettingSortOrderMapping
    {
        public int PersonalSettingSortOrderMappingId { get; set; }
        public int PersonalSettingId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int LabelSortOrderId { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual PersonalSetting PersonalSettings { get; set; }
        public virtual LabelSortOrder LabelSortOrders { get; set; }
    }
}
