using System;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class LabelImportFieldsMapping
    {
        public int LabelImportFieldsMappingId { get; set; }
        public int LabelImportId { get; set; }
        public int LabelImportFieldId { get; set; }
        public bool RequiredField { get; set; }
        public int FieldOrder { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
