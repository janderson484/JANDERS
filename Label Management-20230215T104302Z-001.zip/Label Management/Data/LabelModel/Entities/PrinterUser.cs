using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class PrinterUser
    {
        public int PrinterUserId { get; set; }
        public int PrinterId { get; set; }
        public string UserName { get; set; }
       // public string ClientCode { get; set; }
       // public string ProcessingLocationCode { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
