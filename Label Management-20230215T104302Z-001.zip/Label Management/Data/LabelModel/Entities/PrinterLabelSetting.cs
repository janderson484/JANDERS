using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class PrinterLabelSetting
    {
        public int PrinterLabelSettingId { get; set; }
        public int PrinterId { get; set; }
        public int LabelTypeId { get; set; }
        public decimal VerticalMargin { get; set; }
        public decimal BottomMargin { get; set; }
        public decimal LeftMargin { get; set; }
        public decimal HorizontalMargin { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
