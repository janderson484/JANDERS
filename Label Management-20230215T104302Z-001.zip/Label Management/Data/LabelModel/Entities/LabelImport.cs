using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class LabelImport
    {
        public int LabelImportId { get; set; }
       // public string ClientCode { get; set; }
        public string StateProvinceCode { get; set; }
       // public string ProcessingLocationCode { get; set; }
        public int LabelTypeId { get; set; }
        public bool GenerateBagLabels { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string Description { get; set; }
        [NotMapped]
        public string LabelType { get; set; }
        [NotMapped]
        public List<LabelImportField> Labelimportfields { get; set; }
        [NotMapped]
        public List<LabelType> LabelTypes { get; set; }
        [NotMapped]
        public List<LabelImportFieldsMapping> LabelImportFieldMappings { get; set; }
        public virtual ICollection<LabelImportClientMapping> LabelImportClientMappings { get; set; }
        public virtual ICollection<LabelImportProcessingLocationMapping> LabelImportProcessingLocationMappings { get; set; }
    }
}
