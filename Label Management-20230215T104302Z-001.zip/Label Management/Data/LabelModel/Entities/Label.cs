using System;
using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class Label
    {
        public Label()
        {
            LabelBillings = new HashSet<LabelBilling>();
        }
        public int LabelId { get; set; }
        public int LabelStatusTypeId { get; set; }
        public int LabelTypeId { get; set; }
        public string ClientCode { get; set; }
        //public string ClientLocationCode { get; set; }
        public string StateProvinceCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string VIN { get; set; }
        public string Unit { get; set; }
        public string DeliveryCode { get; set; }
        public string BatchNumber { get; set; }
        public string OwningAreaDeliveryCode { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public string Color { get; set; }
        public string Notes { get; set; }
        public int PrintCount { get; set; }
        public bool IsPrinted { get; set; }
        public string ShipTo { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public virtual ICollection<LabelBilling> LabelBillings { get; set; }
    }
}
