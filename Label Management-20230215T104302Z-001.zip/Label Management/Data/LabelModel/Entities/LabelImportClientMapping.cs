using System;

namespace VM.FleetServices.TnR.LM.Data.LabelModel.Entities
{
    public class LabelImportClientMapping
    {
        public int LabelImportClientMappingId { get; set; }
        public int LabelImportId { get; set; }
        public string ClientCode { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public virtual LabelImport LabelImports { get; set; }
    }
}
