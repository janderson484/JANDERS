using Ats.FleetServices.Core.Data;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Data.LabelModel
{
    public interface ILabelModel : IDbModelBase
    {
        DbSet<Label> Labels { get; set; }
        DbSet<LabelBilling> LabelBillings { get; set; }
        DbSet<LabelImportField> LabelImportFields { get; set; }
        DbSet<LabelImportFieldsMapping> LabelImportFieldsMappings { get; set; }
        DbSet<LabelImport> LabelImports { get; set; }
        DbSet<LabelStatusType> LabelStatusTypes { get; set; }
        DbSet<LabelType> LabelTypes { get; set; }
        DbSet<ImportLabelRequest> ImportLabelRequests { get; set; }
        DbSet<Notification> Notifications { get; set; }
        DbSet<Printer> Printers { get; set; }
        DbSet<PrinterUser> PrinterUsers { get; set; }
        DbSet<PrinterLabelSetting> PrinterLabelSettings { get; set; }
        DbSet<PersonalSetting> PersonalSettings { get; set; }
        DbSet<Log> Logs { get; set; }
        DbSet<PrintLabelRequest> PrintLabelRequests { get; set; }
        DbSet<PrinterUserClientMapping> PrinterUserClientMappings { get; set; }
        DbSet<PrinterUserProcessingLocationMapping> PrinterUserProcessingLocationMappings { get; set; }

    }
}
