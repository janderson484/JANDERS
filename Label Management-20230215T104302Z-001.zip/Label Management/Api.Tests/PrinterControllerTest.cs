using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using VM.FleetServices.TnR.LM.Api.Controllers;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations.PrinterService;
using VM.FleetServices.TnR.LM.Business.ServiceBus;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Xunit;

namespace Api.Tests
{
    public class PrinterControllerTest
    {
        #region Setup

        private readonly ILogger<PrinterController> _mockIlogger;
        private readonly Mock<ILabelManagementService> _mockLabelManagementService;
        private readonly Mock<IPrinterService> _mockPrinterService;
        private readonly Mock<IServiceBusService> _mockIServiceBusService;
        private readonly PrinterController _printerController;


        public PrinterControllerTest()
        {
            _mockIlogger = new Mock<ILogger<PrinterController>>().Object;
            _mockPrinterService = new Mock<IPrinterService>();
            _mockIServiceBusService = new Mock<IServiceBusService>();
            _mockLabelManagementService = new Mock<ILabelManagementService>();

            var services = new ServiceCollection();
            services.AddMemoryCache();
            var serviceProvider = services.BuildServiceProvider();

            _printerController = new PrinterController(
                _mockLabelManagementService.Object,
                _mockPrinterService.Object,
                _mockIServiceBusService.Object,
                _mockIlogger
            );


        }
        #endregion

        #region Print Preview

        [Fact(DisplayName = "PrinterControllerTest_GetLabelPrintDataAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLabelPrintDataAsync_LogsReturnedAsync()
        {
            var model = new PrinterLabelSetting()
            {
                PrinterId = 1,
                LabelTypeId = 1,
                VerticalMargin = 10,
                BottomMargin = 10,
                LeftMargin = 10,
                HorizontalMargin = 10
            };

            var updateResponse = await _printerController.UpdatePrinterLabelSettingsAsync(model);
            _mockPrinterService.Verify(x => x.UpdatePrinterLabelSettingsAsync(model), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "PrinterControllerTest_UpdatePrinterLabelSettingsAsync_TestAsync")]
        public async void LabelManagementServiceTest_UpdatePrinterLabelSettingsAsync_LogDetailsReturnedAsync()
        {
            var model = new PrintPreviewViewModel();
            var userPrinterIds = new List<int>();
            userPrinterIds.Add(1);

            var printDataResponse = await _printerController.GetLabelPrintDataAsync(model);
            _mockPrinterService.Verify(x => x.GetUserConfiguredPrintersAsync(model.UserName, model.LabelTypeId,model.ClientCode,model.ProcessingLocation), Times.AtLeastOnce);
            _mockLabelManagementService.Verify(x => x.GetLabelsPrintData(model.LabelIds), Times.AtLeastOnce);
            _mockPrinterService.Verify(x => x.GetPrinterLabelSettingsAsync(userPrinterIds, model.LabelTypeId), Times.AtLeastOnce);
        }

        #endregion

        #region Printer Configuration

        [Fact(DisplayName = "PrinterControllerTest_GetPrinterAssignmentDetailsAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetPrinterAssignmentDetailsAsync_StatusReturnedAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterUserId = 1;
            model.ClientCode = "HERTZ";

            var printDataResponse = await _printerController.GetPrinterAssignmentDetailsAsync(model);
            Assert.NotNull(printDataResponse);
        }

        [Fact(DisplayName = "PrinterControllerTest_AddUpdatePrinterAssignmentSaveAsync_TestAsync")]
        public async void LabelManagementServiceTest_AddUpdatePrinterAssignmentSaveAsync_StatusReturnedAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterId = 1;
            model.DisplayName = "Printer 9";
            model.UserName = "FSAMSTESTUSER";
            model.ClientCode = "HERTZ";

            var printDataResponse = await _printerController.AddUpdatePrinterAssignmentSaveAsync(model);
            Assert.True(printDataResponse.Item1);
        }

        [Fact(DisplayName = "PrinterControllerTest_GetPrinterDetailsAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetPrinterDetailsAsync_StatusReturnedAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterId = 1;
            model.ClientCode = "HERTZ";

            var printDataResponse = await _printerController.GetPrinterDetailsAsync(model);
            Assert.NotNull(printDataResponse);
        }

        [Fact(DisplayName = "PrinterControllerTest_AddUpdatePrinterSaveAsync_TestAsync")]
        public async void LabelManagementServiceTest_AddUpdatePrinterSaveAsync_StatusReturnedAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterId = 1;
            model.DisplayName = "Printer 1";
            model.UserName = "FSAMSTESTUSER";
            model.ClientCode = "HERTZ";
            model.IPAddress = "192.168.11.30";
            model.PortNumber = "23";

            var printDataResponse = await _printerController.AddUpdatePrinterSaveAsync(model);
            Assert.True(printDataResponse.Item1);
        }
        #endregion

    }
}
