using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Api.Controllers;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.ServiceBus;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Xunit;

namespace Api.Tests
{
    public class LabelManagementControllerTest
    {
        #region Setup

        private readonly ILogger<LabelManagementController> _mockIlogger;
        private readonly Mock<ILabelManagementService> _mockLabelManagementService;
        private readonly LabelManagementController _labelManagementController;
        private readonly Mock<IServiceBusService> _mockIServiceBusService;
        private readonly IConfigurationService _configurationService;
        //private readonly Mock<IMemoryCache> _mockIMemoryCache;
        private readonly IMemoryCache _memoryCache;

        public LabelManagementControllerTest()
        {
            _mockIlogger = new Mock<ILogger<LabelManagementController>>().Object;
            _mockLabelManagementService = new Mock<ILabelManagementService>();
            _mockIServiceBusService = new Mock<IServiceBusService>();
            //_mockIMemoryCache = new Mock<IMemoryCache>();

            var services = new ServiceCollection();
            services.AddMemoryCache();
            var serviceProvider = services.BuildServiceProvider();
            _memoryCache = serviceProvider.GetService<IMemoryCache>();

            _labelManagementController = new LabelManagementController(
                _mockLabelManagementService.Object,
                _mockIlogger,
                _mockIServiceBusService.Object,
                _memoryCache,
                _configurationService
            //_mockIMemoryCache.Object
            );


        }
        #endregion

        #region Bulk Processing

        [Fact]
        public async Task Ensure_LabelManagementService_Calls_GetBulkProcessRecordCountTaskAsync_InsideMethod_GetBulkProcessRecordCountsAsync()
        {
            var clientCode = ClientCodes.Hertz.ToString();
            var processingLocation = ProcessingLocations.FlSunshineBradenton.ToString();

            _mockLabelManagementService.Setup(svc => svc.GetBulkProcessRecordCountTaskAsync(clientCode, processingLocation))
                .ReturnsAsync(It.IsAny<BulkProcessViewModel>());
            //Act

            var results = await _labelManagementController.GetBulkProcessRecordCountsAsync(clientCode, processingLocation);

            //Assert
            _mockLabelManagementService.Verify(m => m.GetBulkProcessRecordCountTaskAsync(clientCode, processingLocation), Times.Once);
        }

        [Fact]
        public async Task Ensure_BadRequest_When_ClientCodeIsNull_GetBulkProcessRecordCountsAsync()
        {
            string clientCode = null;
            var processingLocation = ProcessingLocations.FlSunshineBradenton.ToString();

            //Act

            var results = await _labelManagementController.GetBulkProcessRecordCountsAsync(clientCode, processingLocation) as JsonResult;

            //Assert
            var data = (IDictionary<string, object>)new RouteValueDictionary(results.Value);
            Assert.Equal(HttpStatusCode.BadRequest, data["ResponseCode"]);
        }

        [Fact]
        public async Task Ensure_BadRequest_When_ProcessingLocationIsNull_GetBulkProcessRecordCountsAsync()
        {
            var clientCode = ClientCodes.Hertz.ToString();
            string processingLocation = null;

            //Act

            var results = await _labelManagementController.GetBulkProcessRecordCountsAsync(clientCode, processingLocation) as JsonResult;

            //Assert
            var data = (IDictionary<string, object>)new RouteValueDictionary(results.Value);
            Assert.Equal(HttpStatusCode.BadRequest, data["ResponseCode"]);
        }

        [Fact]
        public async Task Ensure_ServiceBusService_Calls_SendMessageAsync_InsideMethod_PerformBulkProcessAsync()
        {
            var jobLog = new VM.FleetServices.TnR.LM.Model.DTO.Log();
            var model = new BulkProcessViewModel();

            _mockIServiceBusService.Setup(svc => svc.SendMessageAsync(jobLog))
                .Returns((Task<TaskStatus>)Task.CompletedTask);
            //Act

            var results = await _labelManagementController.PerformBulkProcessAsync(model) as JsonResult;

            //Assert
            var data = (IDictionary<string, object>)new RouteValueDictionary(results.Value);
            Assert.Equal(HttpStatusCode.Accepted, data["ResponseCode"]);
        }

        #endregion

        #region AddLabels ImportTests

        [Fact(DisplayName = "LabelManagementControllerTest_AddLabelsAsync_TestAsync")]
        public async Task LabelManagementControllerTest_AddLabelsAsync_TestAsync()
        {
            var importOrderList = new List<string>() { "VIN", "Unit", "Batch_Number" };

            var model = new LabelImportViewModel()
            {
                ClientCode = "HERTZ",
                LogId = 1,
                RequestNumber = 1,
                LabelImportId = 45,
                ImportConfigurationDescription = "HERTZ SUNCITY UNIT",
                LabelTypeId = 1,
                ProcessingOffice = ProcessingLocations.FlSunshineBradenton.ToString(),
                ImportOrderList = importOrderList,
                GenerateBagLabels = true,
                LabelData = "5NPEU46F96H147412	FL-23422	AutoTag637437953833305453\n",
                CreatedUser = "TESTUSER",
                CreatedDate = DateTime.Now,
                ModifiedUser = "TESTUSER",
                ModifiedDate = DateTime.Now
            };

            _mockLabelManagementService.Setup(service => service.SubmitImportLabelRequestAsync(model));

            var result = await _labelManagementController.ImportLabelsAsync(model);

            _mockLabelManagementService.Verify(x => x.SubmitImportLabelRequestAsync(model), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "LabelManagementControllerTest_GetLabelsBillingData_TestAsync")]
        public async Task LabelManagementControllerTest_GetLabelsBillingData_TestAsync()
        {
            var labelBilling = CreateLabelBilling();
            var labelIds = new List<int>
            {
                1
            };
            _mockLabelManagementService.Setup(service => service.GetLabelBillingDataAsync(labelIds));

            var result = await _labelManagementController.GetLabelsBillingDataAsync(labelIds);

            _mockLabelManagementService.Verify(x => x.GetLabelBillingDataAsync(labelIds), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "LabelManagementControllerTest_GetLabelsDataAsync_TestAsync")]
        public async Task LabelManagementControllerTest_GetLabelsDataAsync_TestAsync()
        {
            var labelIds = new List<int>
            {
                1
            };
            _mockLabelManagementService.Setup(service => service.GetLabelDataAsync(labelIds));

            var result = await _labelManagementController.GetLabelsDataAsync(labelIds);

            _mockLabelManagementService.Verify(x => x.GetLabelDataAsync(labelIds), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "LabelManagementControllerTest_UpdataLabelBillingAsync_TestAsync")]
        public async Task LabelManagementControllerTest_UpdataLabelBillingAsync_TestAsync()
        {
            var labelBilling = CreateLabelBilling();
            var labelBillingIds = new List<int>
            {
                1
            };
            _mockLabelManagementService.Setup(service => service.UpdateLabelBillingAsync(labelBillingIds, 1));

            var result = await _labelManagementController.UpdataLabelBillingAsync(1,labelBillingIds);

            _mockLabelManagementService.Verify(x => x.UpdateLabelBillingAsync(labelBillingIds, 1), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "LabelManagementControllerTest_PerformBulkInvoiceAsync_TestAsync")]
        public async Task LabelManagementControllerTest_PerformBulkInvoiceAsync_TestAsync()
        {
            var labels = new List<VM.FleetServices.TnR.LM.Model.DTO.Label>();
            var label =  new VM.FleetServices.TnR.LM.Model.DTO.Label()
            {
                LabelId = 1,
                LabelStatusTypeId = 2
            };
            labels.Add(label);
            _mockLabelManagementService.Setup(service => service.BulkInvoiceProcessAsync(labels, "HERTZ", "TestUser"));

            var result = await _labelManagementController.PerformBulkInvoiceAsync(labels, "HERTZ", "TestUser");

            _mockLabelManagementService.Verify(x => x.BulkInvoiceProcessAsync(labels, "HERTZ", "TestUser"), Times.AtLeastOnce);
        }

        /// <summary>
        /// Creates the test label billings.
        /// </summary>
        /// <returns></returns>
        private LabelBilling CreateLabelBilling()
        {
            var labelBilling = new LabelBilling()
            {
                LabelBillingId = 1,
                LabelId = 1,
                BillingAmount = 1,
                IsDebit = true,
                Void = false,
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };
            return labelBilling;
        }
        #endregion

        #region Notifications

        [Fact]
        public async Task Ensure_LabelManagementService_Calls_CreateNotificationsAsync_InsideMethod_CreateNotificationsAsync()
        {
            var testLog = new Log();

            _mockLabelManagementService.Setup(svc => svc.CreateNotificationsAsync(testLog))
                .ReturnsAsync(It.IsAny<NotificationViewModel>());
            //Act

            var results = await _labelManagementController.CreateNotificationsAsync(testLog);

            //Assert
            _mockLabelManagementService.Verify(m => m.CreateNotificationsAsync(testLog), Times.Once);
        }

        [Fact]
        public async Task Ensure_LabelManagementService_Calls_GetNotificationsByUserNameAsync_InsideMethod_GetNotificationsAsync()
        {
            var testUser = "fsamstestuser";

            _mockLabelManagementService.Setup(svc => svc.GetNotificationsByUserNameAsync(testUser))
                .ReturnsAsync(It.IsAny<List<NotificationViewModel>>());
            //Act

            var results = await _labelManagementController.GetNotificationsAsync(testUser);

            //Assert
            _mockLabelManagementService.Verify(m => m.GetNotificationsByUserNameAsync(testUser), Times.Once);
        }

        #endregion

        #region Logs

        [Fact(DisplayName = "LabelManagementControllerTest_GetLogsAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLogsAsync_LogsReturnedAsync()
        {
            var model = new LogSummaryViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                IsAtLeastSupervisor = false,
                TotalCount = 4,
                PageNumber = 1
            };
            var existingLabel = await _labelManagementController.GetLogsAsync(model);
            _mockLabelManagementService.Verify(x => x.GetLogsAsync(model), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "LabelManagementControllerTest_GetLogDetailsAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLogDetailsAsync_LogDetailsReturnedAsync()
        {
            var model = new LogDetailViewModel()
            {
                LogId = 1,
                TotalCount = 4,
                PageNumber = 1
            };
            var existingLabel = await _labelManagementController.GetLogDetailsAsync(model);
            _mockLabelManagementService.Verify(x => x.GetLogDetailsAsync(model), Times.AtLeastOnce);
        }

        #endregion

        #region View Labels

        #region Label Lookups

        [Fact(DisplayName = "LabelManagementControllerTest_GetLabelLookUpsAsync_IsCalledAsync")]
        public async void LabelManagementServiceTest_LabelManagementService_GetLabelLookUpsAsync_IsCalledAsync()
        {
            await _labelManagementController.GetLabelLookUpsAsync();
            _mockLabelManagementService.Verify(lms => lms.GetLabelLookUpsAsync(), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "LabelManagementControllerTest_GetLabelLookUpsAsync_AddsLookupsToCache_IfLookupsNotNullAsync")]
        public async void LabelManagementServiceTest_GetLabelLookUpsAsync_AddsLookupsToCache_IfLookupsNotNullAsync()
        {
            // Arrange

            var testDictionary = new Dictionary<string, object>
            {
                { "testKey", new List<int> { 1, 2, 5 } }
            };

            _mockLabelManagementService
                .Setup(lms => lms.GetLabelLookUpsAsync())
                .ReturnsAsync(testDictionary);

            // Act

            await _labelManagementController.GetLabelLookUpsAsync();

            // Assert

            // Was GetLabelLookUpsAsync called?
            _mockLabelManagementService.Verify(lms => lms.GetLabelLookUpsAsync(), Times.AtLeastOnce);

            // Was labelLookups added to the cache and valid?
            _memoryCache.TryGetValue("LabelLookUps", out Dictionary<string, object> labelLookUps);
            Assert.Equal(testDictionary, labelLookUps);

        }

        #endregion

        #region Get Labels

        [Fact(DisplayName = "LabelManagementControllerTest_GetLabelsAsync_Test")]
        public async Task LabelManagementControllerTest_GetLabelsAsync_TestAsync()
        {
            var model = new SearchLabelViewModel()
            {
                Results = new List<LabelViewModel>
                {
                    new LabelViewModel
                    {
                        LabelStatusTypeId = 1,
                        Vin = "123333333",
                        ClientCode =  ClientCodes.Hertz.GetDescription(),
                        ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
                    }
                }
            };

            _mockLabelManagementService.Setup(service => service.GetLabelsAsync(model));

            var result = await _labelManagementController.GetLabelsAsync(model);

            _mockLabelManagementService.Verify(x => x.GetLabelsAsync(model), Times.AtLeastOnce);
        }



        #endregion


        #endregion

        #region Export Labels

        [Fact(DisplayName = "LabelManagementControllerTest_SubmitExportAllRequestAsync_TestAsync")]
        public async void LabelManagementControllerTest_SubmitExportAllRequestAsync_LogReturnedAsync()
        {
            var model = new ExportLabelViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                UserId = "FSAMSTESTUSER",
                ReportType = Reports.ViewBagLabels,
                SearchCriteria = "",
                TotalCount = 1080
            };
            var result = await _labelManagementController.SubmitExportAllRequestAsync(model);
            _mockLabelManagementService.Verify(m => m.SubmitExportAllRequestAsync(model), Times.Once);
        }

        #endregion

        #region Update Labels

        /// <summary>
        /// Test method to update the label status and notes 
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_UpdateLabels_Test")]
        public async Task LabelManagementControllerTest_UpdateLabels_TestAsync()
        {

            var model = new UpdateLabelsModel()
            {
                LabelsList = new List<LabelViewModel>()
                {
                    new LabelViewModel
                    {
                        LabelStatusTypeId = 1,
                        Vin = "123333333",
                        ClientCode = ClientCodes.Hertz.GetDescription(),
                        ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
                    }
                },
                Userid = "TESTUSER"
            };

            _mockLabelManagementService.Setup(service => service.UpdateLabelsAsync(model))
                .ReturnsAsync(new BulkUpdateResultViewModel()
                {
                    FailedOrders = new List<int>()
                });

            var result = await _labelManagementController.UpdateLabelsAsync(model);

            _mockLabelManagementService.Verify(x => x.UpdateLabelsAsync(model), Times.AtLeastOnce);
        }

        /// <summary>
        /// Test method to ensure voided label billings are obtained when performing a label update
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_UpdateLabelsAsync_GetVoidedBillings_IsCalled_Async")]
        public async Task LabelManagementControllerTest_UpdateLabelsAsync_GetVoidedBillings_IsCalled_Async()
        {
            var model = new UpdateLabelsModel()
            {
                LabelsList = new List<LabelViewModel>()
                {
                    new LabelViewModel
                    {
                        LabelStatusTypeId = 1,
                        Vin = "123333333",
                        ClientCode = ClientCodes.Hertz.GetDescription(),
                        ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
                    }
                },
                Userid = "TESTUSER"
            };

            _mockLabelManagementService.Setup(service => service.UpdateLabelsAsync(model))
                .ReturnsAsync(new BulkUpdateResultViewModel()
                {
                    FailedOrders = new List<int>()
                });

            _mockLabelManagementService.Setup(service => service.GetVoidedLabelBillingsAsync(It.IsAny<List<int>>()));

            await _labelManagementController.UpdateLabelsAsync(model);

            _mockLabelManagementService.Verify(x => x.GetVoidedLabelBillingsAsync(It.IsAny<List<int>>()), Times.AtLeastOnce);
        }

        /// <summary>
        /// Test method to perform bulk update for labels
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_BulkUpdate_Test")]
        public async Task LabelManagementControllerTest_BulkUpdate_TestAsync()
        {
            var model = new BulkUpdateViewModel()
            {
                Labels = new List<int>(),
                TotalLabels = 2,
                LabelsStatusTypeId = 3,
                Notes = "Test Notes",
                ClientCode = "HERTZ"
            };

            _mockLabelManagementService.Setup(service => service.PerformBulkUpdateAsync(model))
                .ReturnsAsync(new BulkUpdateResultViewModel()
                {
                    FailedOrders = new List<int>()
                });

            await _labelManagementController.PerformBulkUpdateAsync(model);

            _mockLabelManagementService.Verify(x => x.PerformBulkUpdateAsync(model), Times.AtLeastOnce);
        }

        /// <summary>
        /// Test method to ensure voided label billings are obtained when performing a bulk update
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_PerformBulkUpdateAsync_GetVoidedBillings_IsCalled_Async")]
        public async Task LabelManagementControllerTest_PerformBulkUpdateAsync_GetVoidedBillings_IsCalled_Async()
        {
            var model = new BulkUpdateViewModel()
            {
                Labels = new List<int>(),
                TotalLabels = 2,
                LabelsStatusTypeId = 3,
                Notes = "Test Notes",
                ClientCode = "HERTZ"
            };

            _mockLabelManagementService.Setup(service => service.PerformBulkUpdateAsync(model))
                .ReturnsAsync(new BulkUpdateResultViewModel()
                {
                    FailedOrders = new List<int>()
                });

            _mockLabelManagementService.Setup(service => service.GetVoidedLabelBillingsAsync(It.IsAny<List<int>>()));

            await _labelManagementController.PerformBulkUpdateAsync(model);

            _mockLabelManagementService.Verify(x => x.GetVoidedLabelBillingsAsync(It.IsAny<List<int>>()), Times.AtLeastOnce);
        }

        #endregion

        #region Label Credits

        /// <summary>
        /// Test method to validate labels 
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_ValidateLabelsToApplyCredits_TestAsync")]
        public async Task LabelManagementControllerTest_ValidateLabelsToApplyCredits_TestAsync()
        {
            var model = new List<int>() { 201, 202, 203 };
            _mockLabelManagementService.Setup(service => service.ValidateLabelsToApplyCreditsAsync(model));

            var result = await _labelManagementController.ValidateLabelsToApplyCreditsAsync(model);

            _mockLabelManagementService.Verify(x => x.ValidateLabelsToApplyCreditsAsync(model), Times.AtLeastOnce);
        }

        /// <summary>
        /// Test method to Apply credit labels
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_ApplyCreditsToLabels_TestAsync")]
        public async Task LabelManagementControllerTest_ApplyCreditsToLabels_TestAsync()
        {
            var model = new CreditLabelRequestModel();
            model.LabelIdList = new List<int>() { 201, 202, 203 };
            model.UserName = "Test User";
            model.InvoiceIdList = new List<int>() { 1, 2, 3 };

            _mockLabelManagementService.Setup(service => service.ApplyCreditsToLabelsAsync(model));

            var result = await _labelManagementController.ApplyCreditsToLabelsAsync(model);

            _mockLabelManagementService.Verify(x => x.ApplyCreditsToLabelsAsync(model), Times.AtLeastOnce);
        }

        #endregion

        #region Move Labels

        /// <summary>
        /// Test method to update label processing office
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_UpdateLabelProcessingOffice_TestAsync")]
        public async Task LabelManagementControllerTest_UpdateLabelProcessingOffice_TestAsync()
        {
            MoveLabelsViewModel model = new MoveLabelsViewModel();
            var labelList = new List<VM.FleetServices.TnR.LM.Model.DTO.Label>();
            var label = new VM.FleetServices.TnR.LM.Model.DTO.Label() { LabelId = 1206};
            labelList.Add(label);
            model.Labels = labelList;
            model.ProcessingLocationOffice = ProcessingLocations.FlSunshineBradenton.ToString();
            
            _mockLabelManagementService.Setup(service => service.UpdateLabelProcessingOfficeAsync(model));

            var result = await _labelManagementController.UpdateLabelProcessingOfficeAsync(model);

            _mockLabelManagementService.Verify(x => x.UpdateLabelProcessingOfficeAsync(model), Times.AtLeastOnce);
        }
        #endregion

        #region Copy Labels

        /// <summary>
        /// Test method to copy labels
        /// </summary>
        [Fact(DisplayName = "LabelManagementControllerTest_CopyLabels_Test")]
        public async Task LabelManagementControllerTest_CopyLabels_TestAsync()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.Label> LabelData = new List<VM.FleetServices.TnR.LM.Model.DTO.Label>();
            Label label = new Label();
            label.LabelId = 13208;
            var model = new CopyLabelsViewModel()
            {
               Labels = LabelData,
               UserName = "FSAMSTESTUSER"
            };

            var result = await _labelManagementController.CopyLabelsAsync(model);

            _mockLabelManagementService.Verify(x => x.CopyLabelsAsync(model), Times.AtLeastOnce);
        }

        #endregion
    }
}
