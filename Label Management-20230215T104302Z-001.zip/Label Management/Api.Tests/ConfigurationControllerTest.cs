using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Api.Controllers;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Xunit;

namespace Api.Tests
{
    public class ConfigurationControllerTest
    {
        #region Setup

        private readonly ILogger<ConfigurationController> _mockIlogger;
        private readonly Mock<IConfigurationService> _mockConfigurationService;
        private readonly ConfigurationController _configurationController;

        public ConfigurationControllerTest()
        {
            _mockIlogger = new Mock<ILogger<ConfigurationController>>().Object;
            _mockConfigurationService = new Mock<IConfigurationService>();
            _configurationController = new ConfigurationController(
                _mockConfigurationService.Object,
                _mockIlogger
            );
        }
        #endregion

        [Fact(DisplayName = "ConfigurationControllerTest_GetImportLayoutsAsync_Test")]
        public async Task ConfigurationControllerTest_GetImportLayoutsAsync_TestAsync()
        {
            var model = new ImportLayoutConfigurationViewModel()
            {
                ImportLayouts = new List<ImportLayoutViewModel>
                {
                    new ImportLayoutViewModel
                    {
                        LabelImportId = 1,
                        Labelimportfields = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>
                        {
                            new VM.FleetServices.TnR.LM.Model.DTO.LabelImportField
                            {
                                LabelImportFieldId = 1
                            }
                        },
                        Active = true
                    }
                }
            };

            var UserProfileSettings = new UserProfileSettingsViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                DmvStateCode = StateProvinces.Florida.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };
            _mockConfigurationService.Setup(service => service.GetImportLayoutsAsync(UserProfileSettings));

            var result = await _configurationController.GetImportLayoutsAsync(UserProfileSettings);

            _mockConfigurationService.Verify(x => x.GetImportLayoutsAsync(UserProfileSettings), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "ConfigurationControllerTest_UpdateImportLayoutStatusAsync_Test")]
        public async Task ConfigurationControllerTest_UpdateImportLayoutStatusAsync_TestAsync()
        {
            var model =   new ImportLayoutViewModel
                    {
                        LabelImportId = 1,
                        Labelimportfields = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>
                        {
                            new VM.FleetServices.TnR.LM.Model.DTO.LabelImportField
                            {
                                LabelImportFieldId = 1
                            }
                        },
                        Active = true
            };

            _mockConfigurationService.Setup(service => service.UpdateImportLayoutStatusAsync(model));

            var result = await _configurationController.UpdateImportLayoutStatusAsync(model);

            _mockConfigurationService.Verify(x => x.UpdateImportLayoutStatusAsync(model), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "ConfigurationControllerTest_GetMasterDataAsync_Test")]
        public async Task ConfigurationControllerTest_GetMasterDataAsync_TestAsync()
        {
            _mockConfigurationService.Setup(service => service.GetMasterDataAsync());

            var result = await _configurationController.GetMasterDataAsync();

            _mockConfigurationService.Verify(x => x.GetMasterDataAsync(), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "ConfigurationControllerTest_GetImportLayoutAsync_Test")]
        public async Task ConfigurationControllerTest_GetImportLayoutAsync_TestAsync()
        {
            _mockConfigurationService.Setup(service => service.GetImportLayoutAsync(1));

            var result = await _configurationController.GetImportLayoutAsync(1);

            _mockConfigurationService.Verify(x => x.GetImportLayoutAsync(1), Times.AtLeastOnce);
        }


        [Fact(DisplayName = "ConfigurationControllerTest_SaveLayoutConfigAsync_Test")]
        public async Task ConfigurationControllerTest_SaveLayoutConfigAsync_TestAsync()
        {
            var model = new ImportLayoutViewModel
            {
                LabelImportId = 1,
                Labelimportfields = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>
                        {
                            new VM.FleetServices.TnR.LM.Model.DTO.LabelImportField
                            {
                                LabelImportFieldId = 1
                            }
                        },
                Active = true
            };

            _mockConfigurationService.Setup(service => service.SaveLayoutConfigAsync(model));

            var result = await _configurationController.SaveLayoutConfigAsync(model);

            _mockConfigurationService.Verify(x => x.SaveLayoutConfigAsync(model), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "ConfigurationControllerTest_UpdateLabelSortOrderAsync_Test")]
        public async Task ConfigurationControllerTest_UpdateLabelSortOrder_TestAsync()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.LabelType> labelOrders = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>();
            VM.FleetServices.TnR.LM.Model.DTO.LabelType label = new VM.FleetServices.TnR.LM.Model.DTO.LabelType();
            label.DisplayName = "VIN";
            labelOrders.Add(label);
            var labelSortOrder = new LabelSortOrderViewModel()
            {
                Active = true,
                SelectedClientCodeList = new List<string>() { "HERTZ" },
                SelectedProcessingLocationCodeList = new List<string>() { ProcessingLocations.FlSunshineBradenton.ToString() },
                LabelSortOrderId = 17,
                Description = "Print Test Orders",
                LabelFieldOrders = labelOrders
            };

            _mockConfigurationService.Setup(service => service.SaveLabelSortOrderAsync(labelSortOrder));

            var result = await _configurationController.SaveLabelSortOrderAsync(labelSortOrder);

            _mockConfigurationService.Verify(x => x.SaveLabelSortOrderAsync(labelSortOrder), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "ConfigurationControllerTest_SaveLabelSortOrderAsync_Test")]
        public async Task ConfigurationControllerTest_SaveLabelSortOrder_TestAsync()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.LabelType> labelOrders = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>();
            VM.FleetServices.TnR.LM.Model.DTO.LabelType label = new VM.FleetServices.TnR.LM.Model.DTO.LabelType();
            label.DisplayName = "VIN";
            labelOrders.Add(label);
            var labelSortOrder = new LabelSortOrderViewModel()
            {
                Active = true,
                SelectedClientCodeList = new List<string>() { "HERTZ" },
                SelectedProcessingLocationCodeList = new List<string>() { ProcessingLocations.FlSunshineBradenton.ToString() },
                LabelSortOrderId = 0,
                Description = "Print Test Orders",
                LabelFieldOrders = labelOrders
            };

            _mockConfigurationService.Setup(service => service.SaveLabelSortOrderAsync(labelSortOrder));

            var result = await _configurationController.SaveLabelSortOrderAsync(labelSortOrder);

            _mockConfigurationService.Verify(x => x.SaveLabelSortOrderAsync(labelSortOrder), Times.AtLeastOnce);
        }

        [Fact(DisplayName = "ConfigurationControllerTest_DeleteLabelSortOrderAsync_Test")]
        public async Task ConfigurationControllerTest_DeleteLabelSortOrder_TestAsync()
        {

            int LabelSortOrderId = 17;
            

           _mockConfigurationService.Setup(service => service.DeleteSortOrderAsync(LabelSortOrderId));

            var result = await _configurationController.DeleteSortOrderAsync(LabelSortOrderId);

            _mockConfigurationService.Verify(x => x.DeleteSortOrderAsync(LabelSortOrderId), Times.AtLeastOnce);
        }

        #region AddLabels Import ConfigurationTests

        [Fact(DisplayName = "ConfigurationControllerTest_GetImportConfigurationsAsync_TestAsync")]
        public async Task ConfigurationControllerTest_GetImportConfigurationsAsync_TestAsync()
        {
            var importId = 37;
            _mockConfigurationService.Setup(service => service.GetImportLayoutAsync(importId));

            var result = await _configurationController.GetImportLayoutAsync(importId);

            _mockConfigurationService.Verify(x => x.GetImportLayoutAsync(importId), Times.AtLeastOnce);
        }

        #endregion

        [Fact(DisplayName = "ConfigurationControllerTest_GetPersonalSettingsAsync_Test")]
        public async Task ConfigurationControllerTest_GetPersonalSettingsAsync_TestAsync()
        {
            string userId = "TestUser";
            string clientCode = "HERTZ";
            string processingCode = ProcessingLocations.FlSunshineBradenton.ToString();
            _mockConfigurationService.Setup(service => service.GetPersonalSettingsAsync(userId, clientCode, processingCode));

            var result = await _configurationController.GetPersonalSettingsAsync(userId, clientCode, processingCode);

            _mockConfigurationService.Verify(x => x.GetPersonalSettingsAsync(userId, clientCode, processingCode), Times.AtLeastOnce);
        }


        [Fact(DisplayName = "ConfigurationControllerTest_SetPersonalSettingsAsync_Test")]
        public async Task ConfigurationControllerTest_SetPersonalSettingsAsync_TestAsync()
        {
            var model = new PersonalSettingsViewModel()
            {
                UserId = "TestUser",
                ClientCode = "HERTZ",
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.ToString(),
                LabelSortOrderId = 17,
            };

            _mockConfigurationService.Setup(service => service.SetPersonalSettingsAsync(model));

            var result = await _configurationController.SetPersonalSettingsAsync(model);

            _mockConfigurationService.Verify(x => x.SetPersonalSettingsAsync(model), Times.AtLeastOnce);
        }
    }
}
