using System;

namespace VM.FleetServices.TnR.LM.Model
{
    public class JavaScriptEnumAttribute : Attribute
    {
    }
}
