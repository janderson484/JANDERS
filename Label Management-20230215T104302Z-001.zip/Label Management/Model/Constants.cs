using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model
{
    public static class ProcessNames
    {
        public const string SendToScheduling = "Send to Scheduling";
        public const string Export = "Export";
        public const string ImportLabels = "Import Labels";
        public const string PendingNonActiveUnitLabelAction = "Pending Non Active Unit Label Action";
        public const string PendingNonActiveBagLabelAction = "Pending Non Active Bag Label Action";
        public const string SetPrintedAndActiveToClosedAction = "Set Printed And Active To Closed Action";
        public const string PendingInvoiceLabelAction = "Pending Invoice Label Action";
        public const string PrintBagLabels = "Print Bag Labels";
        public const string PrintUnitLabels = "Print Unit Labels";
    }
    public static class Reports
    {
        public const string ViewBagLabels = "ViewBagLabels";
        public const string ViewUnitLabels = "ViewUnitLabels";
    }

    public static class PMApiRouteConstants
    {
        public static string CreateInvoiceAsync() => "api/Invoice/CreateInvoiceAsync";
        public static string CreateInvoiceBillingsAsync() => "api/Invoice/CreateInvoiceBillingsAsync";
        public static string GetInvoiceStatusByIds() => "api/Invoice/GetInvoiceStatusByIds";
        public static string DeleteInvoiceBillingsByLineItemId() => "api/Invoice/DeleteInvoiceBillingsByLineItemIdAsync";
        public static string GetBillingLookUps() => "api/Tnr/BillingLookUps";
        public static string GetInvoiceDataToPrint() => "api/Invoice/GetInvoiceDataToPrint";

    }

    public static class PrintInvoiceConfigs
    {
        public const string ToAddressLineFieldGroup = "ToAddressLine";
        public const string FromAddressLineFieldGroup = "FromAddressLine";

        public const string PlateGroupTypeLabel = "PLATE";

        public const int FontSize = 6;
        public const string Font = "Verdana";

        public const int SeparatorLinePadding = 3;

        public const int InvoiceDetailsYCoordinateStartFirstPage = 660; // First page
        public const int InvoiceDetailsYCoordinateStartContinuePage = 760;
        public const int InvoiceDetailRowXCoordinateStart = 25;
        public const int InvoiceSeparatorRowHeight = 12;
        public const int InvoiceDetailRowHeight = 10;
        public const int InvoiceDetailGroupValueStart = 90;

        public const int XCoordinatePageFooter = 550;
        public const int YCoordinatePageFooter = 25;

        public const int MaxInvoiceDetailCommentCharLength = 40;
    }
}
