using System.ComponentModel;

namespace VM.FleetServices.TnR.LM.Model.Enums
{
    public enum StateProvinces
    {
        [Description("FL")] Florida = 1
    }

    public enum ProcessingLocations
    {
        [Description("FL-BRADENTON")] FlSunshineBradenton = 2,
        [Description("AZ-SUN_CITY")] AzSunCity = 3,
        [Description("TX-SAN_ANTONIO")] SanAntonio = 4
    }

    public enum ClientCodes
    {
        [Description("HERTZ")] Hertz = 1,
        [Description("EHI")] Enterprise = 3
    }

    public enum JobLogStatus
    {
        [Description("Ready")] Ready,
        [Description("In Progress")] InProgress,
        [Description("Completed")] Completed,
        [Description("Failed")] Failed
    }

    public enum LogDetailType
    {
        [Description("Error")] Error,
        [Description("Warning")] Warning
    }

    public enum LabelStatusTypes
    {
        [Description("Pending")] Pending = 1,
        [Description("Duplicate")] Duplicate = 2,
        [Description("Active")] Active = 3,
        [Description("Closed")] Closed = 4,
        [Description("Void")] Void = 5
    }

    public enum ProcessTypes
    {
        [Description("BulkProcess")] BulkProcess,
        [Description("FullMatch")] FullMatch,
        [Description("MinimalMatch")] MinimalMatch,
        [Description("Import")] Import,
        [Description("Export")] Export
    }

    public enum BulkProcessTypes
    {
        [Description("Pending Non Active Bag Label Action")] PendingNonActiveBagLabelAction,
        [Description("Pending Non Active Unit Label Action")] PendingNonActiveUnitLabelAction,
        [Description("Set Printed And Active To Closed Action")] SetPrintedAndActiveToClosedAction,
        [Description("Pending Invoice Label Action")] PendingInvoiceLabelAction,
        [Description("Export")] Export
    }

    public enum Labels
    {
        [Description("Id")] LabelId = 1,
        [Description("Status")] LabelStatusTypeId = 2,
        [Description("VIN")] Vin = 4,
        [Description("VIN_Last6")] Vin_Last6 = 5,
        [Description("Unit")] Unit = 6,
        [Description("Batch Number")] BatchNumber = 7,
        [Description("Owning Area")] OwningAreaDeliveryCode = 8,
        [Description("Make")] Make = 9,
        [Description("Model")] Model = 10,
        [Description("Year")] Year = 11,
        [Description("Color")] Color = 12,
        [Description("User Name")] UserName = 13,
        [Description("Created Date")] CreatedDate = 14,
        [Description("Modified Date")] ModifiedDate = 15,
        [Description("Notes")] Notes = 16,
        //[Description("Invoiced")] Invoiced = 17,
        [Description("Print Count")] PrintCount = 18,
        //[Description("Total Amount")] TotalAmount = 19,
        // [Description("Debit/Credit")] DebitCredit = 20,
        [Description("Delivery Code")] DeliveryCode = 21,
        [Description("Ship To")] ShipTo = 22

    }

    public enum Labeltypes
    {
        [Description("Unit")] Unit = 1,
        [Description("Bag")] Bag = 2
    }

    public enum UserPreferenceActionCodes
    {
        [Description("HeaderSelection_LM")] HeaderSelection = 1
    }

    public enum UserActions
    {
        [Description("ViewLabels")] ViewLabels = 1,
        [Description("ClientSelection")] ClientSelection = 2,
        [Description("ViewBagLabels")] ViewBagLabels = 3,
        [Description("ViewUnitLabels")] ViewUnitLabels = 4,
        [Description("Invoice")] Invoice = 5
    }

    public enum LabelSearchColumnTypes
    {
        [Description("Vin")] Vin = 1,
        [Description("Batch")] Batch = 2
    }

    public enum LabelProcessNames
    {
        [Description("Import Labels")] ImportLabels,
        [Description("Export Labels")] ExportLabels,
        [Description("Pending Non Active Bag Label Action")] PendingNonActiveBagLabelAction,
        [Description("Pending Non Active Unit Label Action")] PendingNonActiveUnitLabelAction,
        [Description("Set Printed And Active To Closed Action")] SetPrintedAndActiveToClosedAction,
        [Description("Pending Invoice Label Action")] PendingInvoiceLabelAction,
        [Description("Print Bag Labels")] PrintBagLabels,
        [Description("Print Unit Labels")] PrintUnitLabels,
        [Description("Print Invoice")] PrintInvoice

    }

    public enum InvoiceItemTypes
    {
        [Description("PlateInvoice")] PlateInvoice = 1,
        [Description("LabelInvoice")] LabelInvoice = 2
    }
    //public enum InvoiceStatusTypes
    //{
    //    [Description("Open")] Open = 1,
    //    [Description("Closed")] Closed = 2,
    //    [Description("Void")] Void = 3
    //}

    public enum LabelPrintStatus
    {
        [Description("Ready")] Ready
    }

    public enum RowsPerPage
    {
        [Description("25")] TwentyFive = 25,
        [Description("50")]  Fifty = 50,
        [Description("100")]  OneHundred = 100,
        [Description("150")]  OneFifty = 150
    }
}
