using System.ComponentModel;

namespace VM.FleetServices.TnR.LM.Model.Enums
{
    public enum InvoiceStatusTypes
    {
        [Description("Open")] Open = 1,
        [Description("Closed")] Closed = 2,
        [Description("Void")] Void = 3
    }

    public enum UpdateResultTypes
    {
        [Description("Invoice Name Already Exists")] InvoiceNameExists,
        [Description("Invoice Status is already Closed")] InvoiceAlreadyClosed,
        [Description("Cannot Update a Closed/Voided Invoice")] NonOpenUpdate
    }

    public enum InvoiceContactGroupTypes
    {
        [Description("ProcessingLocations")] ProcessingLocations = 1,
        [Description("Clients")] Clients = 2
    }
}
