using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.Enums
{
    public enum BagLabelProperties
    {
        [Description("DeliveryCode")] DeliveryCode = 1,
        [Description("Model")] Model = 2,
        [Description("Vin")] Vin = 3
    }
}
