using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.Enums
{
    public enum BillingReasonTypes
    {
        //[Description("RECEIVED PLATE")] ReceivedPlate = 1,
        //[Description("REGISTERED PLATE")] RegisteredPlate = 2,
        //[Description("DISCARDED PLATE")] DiscardedPlate = 3,
        [Description("PRINT UNIT LABELS")] PrintUnitLabels = 4,
        [Description("PRINT BAG LABELS")] PrintBagLabels = 5,
        //[Description("EXPEDITE")] Expedite = 6
    }

    public enum BillingTypes
    {
        [Description("Received")] Received = 1,
        [Description("Damaged")] Damaged = 2,
        [Description("Expired")] Expired = 3,
        [Description("Registered")] Registered = 4,
        [Description("Expedite")] Expedite = 5
    }

    public enum BillingItemTypes
    {
        //[Description("Plate")] Plate = 1,
        [Description("Label")] Label = 2,
    }
}
