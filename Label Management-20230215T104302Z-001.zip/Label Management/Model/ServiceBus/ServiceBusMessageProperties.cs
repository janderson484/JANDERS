namespace VM.FleetServices.TnR.LM.Model.ServiceBus
{
    public static class ServiceBusMessageProperties
    {
        // TODO: Confirm which fields will be needed for LM (these are PM fields)
        public const string LogId = "LogId";
        public const string ClientCode = "ClientCode";
        public const string ProcessingLocationCode = "ProcessingLocationCode";
        public const string InventoryCode = "InventoryCode";
        public const string ActionCode = "ActionCode";
        public const string UserName = "UserName";
        public const string ActionDateTime = "ActionDateTime";
        public const string ExportName = "ExportName";
        public const string StartDate = "StartDate";
        public const string EndDate = "EndDate";
        public const string ReportType = "ReportType";
        public const string SearchCriteria = "SearchCriteria";
        public const string PrintLabelRequestId = "PrintLabelRequestId";
        public const string InvoiceID = "InvoiceId";
        public const string ClientId = "ClientId";
        public const string ProcessingLocationId = "ProcessingLocationId";
    }
}
