using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class InvoiceViewModel
    {
        public InvoiceViewModel()
        {
            SearchCriteria = new SearchInvoiceViewModel();
            Results = new List<InvoiceDetailsViewModel>();
        }
        public SearchInvoiceViewModel SearchCriteria { get; set; }
        public IList<InvoiceDetailsViewModel> Results { get; set; }
    }
}
