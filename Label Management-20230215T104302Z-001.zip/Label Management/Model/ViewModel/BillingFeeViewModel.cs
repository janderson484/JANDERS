using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public partial class BillingFeeViewModel
    {
        public int BillingFeeId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }

        [Required(ErrorMessage = "Amount is required")]
        public decimal ChargeAmount { get; set; }

        public string CurrencyType { get; set; }

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool Selected { get; set; } = false;
        public string BillingType { get; set; }
        public string BillingReasonType { get; set; }
        public string BillingItemType { get; set; }
        public string PlateConditionType { get; set; }
        public string ConditionTypeId { get; set; }

        public List<SelectListItem> BillingTypes { get; set; }
        public List<SelectListItem> BillingReasonTypes { get; set; }
        public List<SelectListItem> BillingItemTypes { get; set; }
        public List<SelectListItem> PlateConditionTypes { get; set; }
    }
}
