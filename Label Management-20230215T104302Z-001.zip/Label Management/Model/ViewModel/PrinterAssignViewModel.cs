using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrinterAssignViewModel
    {
        public int PrinterUserId { get; set; }
        public int PrinterId { get; set; }
        public string DisplayName { get; set; }
        public string IPAddress { get; set; }
        public string PortNumber { get; set; }
        public string UserId { get; set; }
        public bool Active { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string UserName { get; set; }
        public string Labeltypes { get; set; }
        public List<string> SelectedLabeltypes { get; set; }
        public List<string> LabelTypeData { get; set; }
        public int LabelTypeId { get; set; }
        public List<SelectListItem> Printers { get; set; }
        public List<string> SelectedClientCodeList { get; set; }
        public List<string> SelectedProcessingLocationCodeList { get; set; }
        public IEnumerable<SelectListItem> ClientCodeList { get; set; }
        public IEnumerable<SelectListItem> ProcessingLocationCodeList { get; set; }

    }
}
