using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrinterAssignmentResponseModel
    {
        public int PrinterUserId { get; set; }
        public int PrinterId { get; set; }
        public string DisplayName { get; set; }
        public string IPAddress { get; set; }
        public string PortNumber { get; set; }
        public bool Active { get; set; }
        public string UserId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public List<string> SelectedClientCodeList { get; set; }
       public List<string> SelectedProcessingLocationCodeList { get; set; }
    }
}
