using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class UnitLabelModel
    {
        public string AreaNumber { get; set; }
        public string UnitNumber { get; set; }
        public string Model { get; set; }
        public string Vin { get; set; }
        public int LabelId { get; set; }
        public string ShipToCode { get; set; }
        public string DeliveryCode { get; set; }
        public string BatchNumber { get; set; }
    }
}
