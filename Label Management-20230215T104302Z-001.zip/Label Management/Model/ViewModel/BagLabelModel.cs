using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class BagLabelModel
    {
        public string DeliveryCode { get; set; }
        public string Model { get; set; }
        public string Vin { get; set; }
        public int LabelId { get; set; }
    }
}
