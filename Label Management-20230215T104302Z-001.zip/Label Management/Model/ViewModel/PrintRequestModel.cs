using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrintRequestModel
    {
        public int LabelTypeId { get; set; }
        public List<int> LabelIds { get; set; }
        public List<byte[]> PrintDocuments { get; set; }
        public DTO.Printer Printer { get; set; }
    }
}
