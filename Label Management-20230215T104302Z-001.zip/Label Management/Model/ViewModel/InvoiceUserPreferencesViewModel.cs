using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class InvoiceUserPreferencesViewModel
    {
        public List<int> SelectedInvoiceStatuses { get; set; } 
    }
}
