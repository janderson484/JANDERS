using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class ImportLayoutConfigurationViewModel : UserProfileSettingsViewModel
    {
        public List<ImportLayoutViewModel> ImportLayouts { get; set; }
        public IEnumerable<SelectListItem> SelectedProcessingLocationList { get; set; }
        public string LabelData { get; set; }
    }
}
