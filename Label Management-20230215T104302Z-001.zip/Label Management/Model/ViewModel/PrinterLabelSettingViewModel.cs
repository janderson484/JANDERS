using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrinterLabelSettingViewModel
    {
        public int PrinterLabelSettingId { get; set; }
        public int PrinterId { get; set; }
        public int LabelTypeId { get; set; }
        public decimal VerticalMargin { get; set; }
        public decimal BottomMargin { get; set; }
        public decimal LeftMargin { get; set; }
        public decimal HorizontalMargin { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
