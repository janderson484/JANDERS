namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class ClientLocationUserPreferencesViewModel
    {
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string UserName { get; set; }
    }
}
