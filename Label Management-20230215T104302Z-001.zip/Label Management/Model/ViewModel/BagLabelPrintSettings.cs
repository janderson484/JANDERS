using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class BagLabelPrintSettings
    {
        // MARGINS

        /// <summary>
        /// The value from the left side of the page(0) working to the right
        /// </summary>
        public int LeftMarginX { get; set; }

        /// <summary>
        /// The value from the bottom of the page(0) working upwards 
        /// </summary>
        public int TopMarginY { get; set; }


        // VIN SPACING

        /// <summary>
        /// The horizontal value determining where the vin should start additional to the left margin value 
        /// </summary>
        public int VinOffSetX { get; set; }

        /// <summary>
        /// The vertical value determining the spacing between the top row and the vin 
        /// </summary>
        public int VinOffSetY { get; set; }


        // MODEL SPACING

        /// <summary>
        /// The horizontal value determining where the vehicle model should start additional to the left margin value 
        /// </summary>
        public int ModelOffSetX { get; set; }

        /// <summary>
        /// The maximum allowed space for the vehicle model value 
        /// </summary>
        public int ModelMaxSpace { get; set; }

        /// <summary>
        /// The maximum allowed string length for the vehicle model value
        /// </summary>
        public int ModelMaxLength { get; set; }

        // LABEL SPACING

        /// <summary>
        /// The horizontal space between the 2 labels on the same row 
        /// </summary>
        public int LabelSpacingX { get; set; }

        /// <summary>
        /// The vertical space between the rows of labels 
        /// </summary>
        public int LabelSpacingY { get; set; }

       
    }
}
