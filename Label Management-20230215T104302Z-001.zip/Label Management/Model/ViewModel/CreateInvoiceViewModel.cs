using System;
using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class CreateInvoiceViewModel
    {
        public int InvoiceStatusTypeId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string InventoryCode { get; set; }
        public string InvoiceName { get; set; }
        public string Comment { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public List<Label> Labels { get; set; }
    }
}
