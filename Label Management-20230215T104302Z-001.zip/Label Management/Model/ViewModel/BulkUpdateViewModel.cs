using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class BulkUpdateViewModel
    {
        public int LabelTypeId { get; set; }
        public int TotalLabels { get; set; }
        public int TotalPassed { get; set; }
        public int TotalFailed { get; set; }
        public int LabelsStatusTypeId { get; set; }
        public string LabelsStatus { get; set; }
        public string Notes { get; set; }
        public List<int> Labels { get; set; }
        public string LogReport { get; set; }
        public string SubmittedLocalDateTime { get; set; }
        public string ClientCode { get; set; }
        public List<SelectInvoiceViewModel> InvoiceList { get; set; }
        
    }
}
