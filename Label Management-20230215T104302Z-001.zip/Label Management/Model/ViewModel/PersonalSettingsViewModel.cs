using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PersonalSettingsViewModel
    {
        public string ClientCode { get; set; }
        //[Display(Name = "Processing Location")]
        //[Required(ErrorMessage = "Processing Location is required.")]
        public string ProcessingLocationCode { get; set; }

        //public IEnumerable<SelectListItem> ProcessingLocationCodeList { get; set; }

        //[Display(Name = "Rows Per Page")]
        //[Required(ErrorMessage = "Rows Per Page is required.")]
        public int RowsPerPage { get; set; }

        public List<SelectListItem> RowsPerPageList { get; set; }
        public string UserId { get; set; }
        public int LabelSortOrderId { get; set; }
        public List<LabelSortOrderViewModel> LabelSortOrders { get; set; }
        public int DaysofHistory { get; set; }
        public bool LabelsToPDF { get; set; }
        public bool LabelsToPrinter { get; set; }
        public bool IsPrintEnabled { get; set; }
    }
}
