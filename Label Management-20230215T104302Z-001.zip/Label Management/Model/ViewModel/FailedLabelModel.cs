using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class FailedLabelModel
    {
        public LabelViewModel Label { get; set; }
        public string ReasonForFailure { get; set; }
    }
}
