using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class BulkUpdateResultViewModel
    {
        public int TotalPassed { get; set; }
        public int TotalFailed { get; set; }
        public string LogReport { get; set; }
        public List<int> FailedOrders { get; set; }
        public List<int> VoidedLabelBillingIds { get; set; }

    }
}
