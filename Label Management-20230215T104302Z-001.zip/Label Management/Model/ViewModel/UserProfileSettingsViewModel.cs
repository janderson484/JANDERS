namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public partial class UserProfileSettingsViewModel
    {
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string InventoryCode { get; set; }
        public string DmvStateCode { get; set; }
        public int DefaultRowsPerPage { get; set; } = 25;
        public int? SelectedRowsPerPage { get; set; }
        public int PageNumber { get; set; } = 1;
        public int TotalCount { get; set; } = 0;
        public bool IncludeDisabled { get; set; }
    }
}
