using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class LabelImportDetailsModel
    {
        public List<string> SelectedClientCodeList { get; set; }
        public List<string> SelectedProcessingLocationCodeList { get; set; }
    }
}
