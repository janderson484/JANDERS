using System;
using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class LabelImportViewModel
    {
        public string ClientCode { get; set; }
        public int LogId { get; set; }
        public int RequestNumber { get; set; }
        public int LabelImportId { get; set; }
        public string ImportConfigurationDescription { get; set; }
        public int LabelTypeId { get; set; }
        public string ProcessingOffice { get; set; }
        public List<string> ImportOrderList { get; set; }
        public bool GenerateBagLabels { get; set; }
        public string LabelData { get; set; }
        public List<Dictionary<string, string>> ImportLabelData { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string DmvStateCode { get; set; }
        public DTO.Log JobLog { get; set; }

    }
}
