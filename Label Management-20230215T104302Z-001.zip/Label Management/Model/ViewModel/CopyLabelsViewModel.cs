using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class CopyLabelsViewModel
    {
        public string ProcessingLocationOffice { get; set; }
        public List<Label> Labels { get; set; }
        public List<SelectListItem> ProcessingLocation { get; set; }
        public string UserName { get; set; }
        public string LogReport { get; set; }
        public int TotalLabels { get; set; }
        public int TotalPassed { get; set; }
        public int TotalFailed { get; set; }

    }
}
