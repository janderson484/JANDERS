using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class LabelViewModel
    {
        public int LabelId { get; set; }
        public int LabelStatusTypeId { get; set; }
        public string LabelStatus { get; set; }
        public LabelStatusType LabelStatusData { get; set; }
        public int LabelTypeId { get; set; }
        public string ClientCode { get; set; }
        //public string ClientLocationCode { get; set; }
        public string StateProvinceCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string Vin { get; set; }
        public int PrintCount { get; set; }
        public string UserName { get; set; }
        public string Unit { get; set; }
        public string BatchNumber { get; set; }
        public string DeliveryCode { get; set; }
        public string Vin_Last6 { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public string Color { get; set; }
        public string Invoiced { get; set; }
        public Nullable<decimal> TotalAmount { get; set; }
        public string DebitOrCredit { get { return TotalAmount != null ? (TotalAmount >= 0 ? "Debit" : "Credit") : string.Empty; } }
        public string ShipTo { get; set; }
        public string OwningAreaDeliveryCode { get; set; }
        public string Notes { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string PrintStatus { get; set; }
        public int TotalRowCount { get; set; }
    }
}
