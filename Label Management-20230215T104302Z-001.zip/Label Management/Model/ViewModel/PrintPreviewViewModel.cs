using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrintPreviewViewModel
    {
        public string UserName { get; set; }
        public int LabelTypeId { get; set; }
        public List<int> LabelIds { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocation { get; set; }
        public UserPrintersViewModel Result { get; set; }
        public IList<LabelViewModel> Labels { get; set; }
    }
}
