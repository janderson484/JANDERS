using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class UserPrintersViewModel
    {
        public string UserName { get; set; }
        public int LabelTypeId { get; set; }
        public IList<Printer> Printers { get; set; }
        public IList<PrinterLabelSetting> PrinterLabelSettings { get; set; }
    }
}
