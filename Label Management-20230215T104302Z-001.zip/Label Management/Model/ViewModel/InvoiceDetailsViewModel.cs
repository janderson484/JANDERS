using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class InvoiceDetailsViewModel
    {
        public int InvoiceId { get; set; }
        public string TransactionId { get; set; }
        public string PlateNumber { get; set; }
        public string State { get; set; }
        public decimal? Amount { get; set; }
        public int BillingFeeId { get; set; }
        public string BillingFee { get; set; }
        public string BillingReason { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsDebit { get; set; }
        public string Origination { get; set; }
        public string BillingItemType { get; set; }
        public string Note { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string InventoryCode { get; set; }
        public int TotalRowCount { get; set; }
    }
}
