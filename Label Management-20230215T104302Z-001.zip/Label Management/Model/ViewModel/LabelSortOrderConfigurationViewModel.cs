using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class LabelSortOrderConfigurationViewModel : UserProfileSettingsViewModel
    {
        public List<LabelSortOrderViewModel> LabelSortOrders { get; set; }
    }
}
