namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class InvoiceStatusTypesViewModel
    {
        public int InvoiceStatusTypeId { get; set; }
        public string DisplayName { get; set; }
        public bool Selected { get; set; } = false;
    }
}
