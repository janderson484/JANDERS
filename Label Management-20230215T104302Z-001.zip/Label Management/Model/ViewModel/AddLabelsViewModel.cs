using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class AddLabelsViewModel : UserProfileSettingsViewModel
    {
        public int LabelImportId { get; set; }
        public int ImportOrder { get; set; }
        public string ImportFieldName { get; set; }
        public bool Required { get; set; }
    }
}
