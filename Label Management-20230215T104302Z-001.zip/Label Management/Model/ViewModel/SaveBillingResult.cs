using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class SaveBillingsResult
    {
        public List<FailedLabelModel> FailedLabels { get; set; }
        public List<LabelViewModel> SuccessLabels { get; set; }
    }
}
