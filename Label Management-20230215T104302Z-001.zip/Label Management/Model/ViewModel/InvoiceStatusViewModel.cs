using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class InvoiceStatusViewModel
    {
        public int InvoiceStatusTypeId { get; set; }
        public string DisplayName { get; set; }
        public bool Active { get; set; }
    }
}
