using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class AddUpdateBillingFeeViewModel
    {
        public int BillingFeeId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int BillingItemTypeId { get; set; }
        public int BillingReasonTypeId { get; set; }
        public int ConditionTypeId { get; set; }
        public int BillingTypeId { get; set; }
        public string DisplayName { get; set; }
        public decimal DefaultAmount { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool Active { get; set; }
    }
}
