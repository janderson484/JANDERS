using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class SelectInvoiceViewModel
    {
        public int InvoiceId { get; set; }
        public string InvoiceName { get; set; }
        public string InvoiceStatus { get; set; }
        public string InvoiceComment { get; set; }
        public DateTime InvoiceCreatedDate { get; set; }
    }
}
