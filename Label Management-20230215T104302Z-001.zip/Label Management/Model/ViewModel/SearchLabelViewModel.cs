using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class SearchLabelViewModel : UserProfileSettingsViewModel
    {
        public SearchLabelViewModel()
        {
            LabelStatusTypes = new List<SelectListItem>();
            
        }

        public IList<LabelViewModel> Results { get; set; }
        public string SearchColumn { get; set; }
        public string SearchTextField { get; set; }
        public bool Search { get; set; }
        public bool ClearSearch { get; set; }
        public bool SelectRowsOnSearch { get; set; }
        public int LabelTypeId { get; set; }
        public string SortOrder { get; set; }
        public string UserId { get; set; }
        public List<SelectListItem> LabelStatusTypes { get; set; }
        public bool Printed { get; set; }
        public string SelectedLabelStatusTypes { get; set; }
        public string GetSelectedLabelStatusTypes()
        {
            var delimitedString = string.Join(",", LabelStatusTypes.Where(t => t.Selected).Select(t => t.Value.ToUpper()));
            return delimitedString;
        }
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        public DateTime? EndDate { get; set; }
        public bool MaintainSearchOrder { get; set; }
    }

    //public class DateLessThanAttribute : ValidationAttribute, IClientModelValidator
    //{
    //    private readonly string _comparisonProperty;

    //    public DateLessThanAttribute(string comparisonProperty)
    //    {
    //        _comparisonProperty = comparisonProperty;
    //    }

    //    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    //    {
    //        ErrorMessage = ErrorMessageString;
    //        if (value != null)
    //        {
    //            var currentValue = (DateTime)value;

    //            var property = validationContext.ObjectType.GetProperty(_comparisonProperty);

    //            if (property == null)
    //                throw new ArgumentException("Property with this name not found");

    //            //var comparisonValue = (DateTime)property.GetValue(validationContext.ObjectInstance);

    //            //if (currentValue > comparisonValue)
    //            //    return new ValidationResult(ErrorMessage);

    //            if (currentValue == Convert.ToDateTime("09/27/2021") )
    //                return new ValidationResult(ErrorMessage);
    //        }

    //        return ValidationResult.Success;
    //    }

    //    public void AddValidation(ClientModelValidationContext context)
    //    {
    //        var error = FormatErrorMessage(context.ModelMetadata.GetDisplayName());
    //        context.Attributes.Add("data-val", "true");
    //        context.Attributes.Add("data-val-error", error);
    //    }
    //}

}
