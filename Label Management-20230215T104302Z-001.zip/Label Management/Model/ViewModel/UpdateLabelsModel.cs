using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class UpdateLabelsModel
    {
        public IEnumerable<LabelViewModel> LabelsList { get; set; }
        public string Userid { get; set; }
        public List<SelectInvoiceViewModel> InvoiceList { get; set; }
    }
}
