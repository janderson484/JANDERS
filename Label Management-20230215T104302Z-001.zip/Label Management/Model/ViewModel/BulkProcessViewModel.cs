using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class BulkProcessViewModel
    {
        public int PendingNonActiveUnitLabelCount { get; set; }
        public int PendingNonActiveBagLabelCount { get; set; }
        public int SetPrintedAndActiveToClosedCount { get; set; }
        public int PendingInvoiceLabelCount { get; set; }
        public string ClientName { get; set; }
        public string DmvStateCode { get; set; }
        public string BulkAction { get; set; }
        public string UserId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string ProcessType { get; set; }
        public int TotalCount { get; set; }
    }
}
