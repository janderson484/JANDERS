using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class ImportLayoutViewModel
    {
        public int LabelImportId { get; set; }
        public string ClientCode { get; set; }
        public string StateProvinceCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int LabelTypeId { get; set; }
        public bool GenerateBagLabels { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string Description { get; set; }
        public string LabelType { get; set; }
        public bool Required { get; set; }
        public List<AddLabelsViewModel> ImportList { get; set; }
        public List<LabelImportField> Labelimportfields { get; set; }
        public List<LabelType> LabelTypes { get; set; }
        public List<LabelImportFieldsMapping> LabelImportFieldMappings { get; set; }
        public IEnumerable<SelectListItem> ClientCodeList { get; set; }
        public List<string> SelectedClientCodeList { get; set; }
        public IEnumerable<SelectListItem> ProcessingLocationCodeList { get; set; }
        public List<string> SelectedProcessingLocationCodeList { get; set; }
        public string UserId { get; set; }

    }
}
