using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class ViewLabelsUserPreferencesViewModel
    {
        public List<int> SelectedLabelStatuses { get; set; }
        public bool IsPrintedSelected { get; set; }
        public bool MaintainSearchOrder { get; set; }
    }
}
