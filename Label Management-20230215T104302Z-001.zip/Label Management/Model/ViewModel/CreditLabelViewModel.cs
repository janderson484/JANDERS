using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class CreditLabelViewModel
    {
        public int LabelId { get; set; }
        public int InvoiceId { get; set; }
    }
}
