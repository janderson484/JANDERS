using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class MoveLabelsViewModel
    {
        public string ProcessingLocationOffice { get; set; }
        public List<Label> Labels { get; set; }
        public List<SelectListItem> ProcessingLocation { get; set; }
        public string UserName { get; set; }
    }
}
