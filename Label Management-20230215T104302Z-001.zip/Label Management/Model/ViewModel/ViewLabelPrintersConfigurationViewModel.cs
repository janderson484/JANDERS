using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class ViewLabelPrintersConfigurationViewModel : UserProfileSettingsViewModel
    {
        public List<PrinterAssignmentResponseModel> Printers { get; set; }
    }
}
