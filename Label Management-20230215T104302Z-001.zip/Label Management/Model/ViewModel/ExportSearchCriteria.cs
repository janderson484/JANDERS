using System;
using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class ExportSearchCriteria
    {
        public string ReportType { get; set; }
        public string SearchCriteria { get; set; }

    }
}
