using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrintLabelRequestViewModel
    {
        public int PrintLabelRequestId { get; set; }
        public Log Log { get; set; }
    }
}
