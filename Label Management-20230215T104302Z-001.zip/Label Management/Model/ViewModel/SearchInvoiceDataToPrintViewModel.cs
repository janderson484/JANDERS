using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public partial class SearchInvoiceDataToPrintViewModel
    {
        public int ClientId { get; set; }
        public int ProcessingLocationId { get; set; }
        public int InvoiceId { get; set; }
        public string InvoiceName { get; set; }
        public string InvoiceComment { get; set; }
        public DateTime InvoiceCreatedDate { get; set; }
        public Contact InvoiceToAddress { get; set; }
        public Contact InvoiceFromAddress { get; set; }
        public List<InvoiceDetailsViewModel> InvoiceDetails { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string StateProvinceCode { get; set; }
        public string UserId { get; set; }
    }
}
