using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class SaveLabelBillingsViewModel
    {
        public List<LabelViewModel> Labels { get; set; }
        public Dictionary<string, object> BillingLookUps { get; set; }
        public string UserId { get; set; }
    }
}
