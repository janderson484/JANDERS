using System;
using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class LogDetailViewModel
    {
        public int LogId { get; set; }
        public Log LogData { get; set; }
        public int RowsPerPage { get; set; } = 25;
        public int PageNumber { get; set; } = 1;
        public IList<LogDetail> Results { get; set; }
        public int TotalCount { get; set; }
    }
}
