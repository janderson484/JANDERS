using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class CustomerListViewModel
    {
        public string ClientCode { get; set; }

        [Display(Name = "Customer")]
        [Required(ErrorMessage = "Please select the Customer.")]
        public IEnumerable<SelectListItem> ClientCodeList { get; set; }

        public string ProcessingLocation { get; set; }

        [Display(Name = "Processing Location")]
        [Required(ErrorMessage = "Please select the Processing Location")]
        public IEnumerable<SelectListItem> ProcessingLocationList { get; set; }
    }
}
