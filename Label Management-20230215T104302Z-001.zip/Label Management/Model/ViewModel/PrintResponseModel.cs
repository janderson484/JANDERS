using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrintResponseModel
    {
        public int LabelTypeId { get; set; }
        public List<int> LabelIds { get; set; }
        public bool HasError { get; set; }
        public string ErrorDescription { get; set; }
        public List<byte[]> PrintDocuments { get; set; }
        public int SuccessCount { get; set; }
        public int ErrorCount { get; set; }
    }
}
