using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace VM.FleetServices.TnR.Model.ViewModel
{
    public class UserPreferenceViewModel
    {
        public string UserName { get; set; }
        public string ActionCode { get; set; }
        public string UserPreference { get; set; }
        public string ClientCode { get; set; }
    }
}
