using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class LabelSortOrderViewModel
    {
        public int LabelSortOrderId { get; set; }
        public bool Active { get; set; }
        public string Description { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string UserId { get; set; }
        public string Order { get; set; }
        public List<LabelImportField> Labelimportfields { get; set; }
        public List<LabelType> LabelFieldOrders { get; set; }
        public List<LabelSortOrderFields> SortOrderFields { get; set; }
        public IEnumerable<SelectListItem> ClientCodeList { get; set; }
        public List<string> SelectedClientCodeList { get; set; }
        public IEnumerable<SelectListItem> ProcessingLocationCodeList { get; set; }
        public List<string> SelectedProcessingLocationCodeList { get; set; }
    }

    public class LabelSortOrderFields
    {
        public string FieldName { get; set; }
        public string Order { get; set; }

    }
}
