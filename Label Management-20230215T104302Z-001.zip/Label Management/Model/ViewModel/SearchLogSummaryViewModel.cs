using System;
using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class SearchLogSummaryViewModel
    {
        public string FileName { get; set; }
        public string LogStatus { get; set; }
        public string ProcessType { get; set; }
        public string ProcessName { get; set; }
        public DateTime ProcessStartDate { get; set; }
        public DateTime? ProcessEndDate { get; set; }
        public bool ShowErrors { get; set; }
        public bool ShowWarnings { get; set; }

    }
}
