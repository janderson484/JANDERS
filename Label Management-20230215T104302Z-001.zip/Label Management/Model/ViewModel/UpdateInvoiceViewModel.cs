using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class UpdateInvoiceViewModel
    {
        public int InvoiceId { get; set; }
        public string InvoiceName { get; set; }
        public int InvoiceStatusTypeId { get; set; }
        public string InvoiceNote { get; set; }
        public DateTime UpdateDate { get; set; }
        public string UpdateUser { get; set; }
        public string UpdateResultMessage { get; set; }
    }
}
