using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class CreditLabelRequestModel
    {
        public IEnumerable<int> LabelIdList { get; set; }
        public IEnumerable<int> InvoiceIdList { get; set; }
        public List<SelectInvoiceViewModel> InvoiceList { get; set; }
        public List<int> VoidLabelBillings { get; set; }
        public string UserName { get; set; }
    }
}
