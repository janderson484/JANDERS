using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class SearchInvoiceViewModel
    {
        public int InvoiceId { get; set; }
        public string ClientCode { get; set; }
        public int InvoiceStatusTypeId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string InvoiceName { get; set; }
        public bool Search { get; set; }
        public int PageNumber { get; set; }
        public UserProfileSettingsViewModel UserProfileSettings { get; set; }
    }
}
