using System;
using System.Collections.Generic;
using System.Text;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Model.ViewModel
{
    public class PrintLabelsViewModel
    {
        public Printer SelectedPrinter { get; set; }
        public PrinterLabelSetting SelectedPrinterLabelSettings { get; set; }
        public List<LabelViewModel> Labels { get; set; }
        public List<int> LabelIds { get; set; }
        public int LabelType { get; set; }
        public int PrintMode { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string UserId { get; set; }
        public int PrintRequestId { get; set; }
    }
}
