using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class InvoiceBilling
    {
        public string InvoiceId { get; set; }
        public string InvoiceItemNumber { get; set; } //Label pk number
        public int InvoiceItemId { get; set; } //label billing pk id
        public int InvoiceItemTypeId { get; set; } //invoice type label/plate
        public int BillingFeeId { get; set; }
        public decimal? BillingAmount { get; set; }
        public string ProcessingLocationCode { get; set; }
        public string StateProvinceCode { get; set; }
        public string ClientLocationCode { get; set; }
        public bool IsDebit { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedUser { get; set; }
    }
}
