using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class PersonalSettingsAndPreferences
    {
        public PersonalSettingsAndPreferences()
        {
            Preferences = new List<UserPreference>();
        }

        public PersonalSetting Settings { get; set; }
        public List<UserPreference> Preferences { get; set; }
    }
}
