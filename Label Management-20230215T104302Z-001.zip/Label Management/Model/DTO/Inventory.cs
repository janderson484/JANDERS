using System;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public partial class Inventory
    {
        public int InventoryId { get; set; }
        public string InventoryCode { get; set; }
        public string DisplayName { get; set; }
        public string StateProvinceCode { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
