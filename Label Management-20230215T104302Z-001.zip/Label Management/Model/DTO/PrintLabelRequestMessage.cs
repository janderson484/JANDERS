using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class PrintLabelRequestMessage
    {
        public int PrintLabelRequestId { get; set; }
    }
}
