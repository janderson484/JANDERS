using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class Printer
    {
        public int PrinterId { get; set; }
        public string DisplayName { get; set; }
        public string IPAddress { get; set; }
        public string PortNumber { get; set; }
        public bool Active { get; set; }
    }
}
