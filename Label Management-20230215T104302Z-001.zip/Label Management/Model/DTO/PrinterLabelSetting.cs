using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class PrinterLabelSetting
    {
        public int PrinterLabelSettingId { get; set; }
        public int PrinterId { get; set; }
        public int LabelTypeId { get; set; }
        public decimal VerticalMargin { get; set; }
        public decimal BottomMargin { get; set; }
        public decimal LeftMargin { get; set; }
        public decimal HorizontalMargin { get; set; }
    }
}
