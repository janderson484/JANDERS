using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class LabelImportConfiguration
    {
        public int LabelImportId { get; set; }
        public string StateProvinceCode { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int LabelTypeId { get; set; }
        public bool GenerateBagLabels { get; set; }
        public string Description { get; set; }
        public int LabelImportFieldId { get; set; }
        public string FieldName { get; set; }
    }
}
