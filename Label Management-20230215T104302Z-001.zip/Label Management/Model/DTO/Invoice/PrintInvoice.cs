using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class PrintInvoice
    {
        public int ProcessingLocationId { get; set; }
        public int InvoiceId { get; set; }
        public string InvoiceName { get; set; }
        public int ClientId { get; set; }
    }
}
