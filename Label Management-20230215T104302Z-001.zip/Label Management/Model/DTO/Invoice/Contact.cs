using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class Contact
    {
        public int ContactId { get; set; }
        public int ContactGroupId { get; set; }
        public int ContactAssignmentId { get; set; }
        public bool Active { get; set; }
        public string ContactName { get; set; }
        public string CompanyClientName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string StateProvinceCode { get; set; }
        public string ZipCode { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }
}
