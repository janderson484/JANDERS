using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class PrintLabelMessageRequest
    {
        public Dictionary<string, string> Action { get; } = new Dictionary<string, string>();
        public Dictionary<string, string> Data { get; } = new Dictionary<string, string>();
        public List<int> LabelIds { get; set; }
        public int LabelType { get; set; }
        public int SelectedPrinterLabelSettingId { get; set; }
        public int SelectedPrinterId { get; set; }
    }
}
