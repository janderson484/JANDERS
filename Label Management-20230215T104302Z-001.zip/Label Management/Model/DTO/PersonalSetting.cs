using System;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public partial class PersonalSetting
    {
        public int PersonalSettingId { get; set; }
        public string UserId { get; set; }
        public string ProcessingLocationCode { get; set; }
        public int RowsPerPage { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
