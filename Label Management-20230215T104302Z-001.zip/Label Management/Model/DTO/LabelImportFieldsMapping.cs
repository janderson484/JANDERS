using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class LabelImportFieldsMapping
    {
        public int LabelImportFieldsMappingId { get; set; }
        public int LabelImportId { get; set; }
        public int LabelImportFieldId { get; set; }
        public bool RequiredField { get; set; }
        public int FieldOrder { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
