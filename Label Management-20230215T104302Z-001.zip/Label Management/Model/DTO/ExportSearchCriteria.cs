using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public partial class ExportSearchCriteria
    {
        public string ReportType { get; set; }
        public string SearchCriteria { get; set; }
    }
}
