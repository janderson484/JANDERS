using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class UserPreference
    {
        public int UserPreferenceId { get; set; }
        public string UserId { get; set; }
        public string ActionCode { get; set; }
        public string ActionPreference { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
