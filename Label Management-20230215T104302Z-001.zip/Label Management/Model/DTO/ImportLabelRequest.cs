using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class ImportLabelRequest
    {
        public int ImportLabelRequestId { get; set; }
        public int RequestNumber { get; set; }
        public int LogId { get; set; }
        public bool Active { get; set; }
        public int LabelTypeId { get; set; }
        public string ClientCode { get; set; }
        public string ProcessingOffice { get; set; }
        public int LabelImportId { get; set; }
        public string ImportConfigurationDescription { get; set; }
        public string ImportLabelRecord { get; set; }
        public bool GenerateBagFlag { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
