using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class BillingLookup
    {
        public List<BillingItemType> BillingItemTypes { get; set; }
        public List<BillingReasonType> BillingReasonTypes { get; set; }
        public List<BillingType> BillingTypes { get; set; }
        public List<BillingFee> BillingFees { get; set; }
        public List<PlateConditionType> PlateConditionTypes { get; set; }
    }


}
