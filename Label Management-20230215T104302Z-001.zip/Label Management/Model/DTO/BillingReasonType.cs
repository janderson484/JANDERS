using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class BillingReasonType
    {
        public int BillingReasonTypeId { get; set; }
        public string DisplayName { get; set; }
        public bool Active { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int BillingItemTypeId { get; set; }
    }
}
