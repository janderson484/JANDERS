using System;
using System.ComponentModel.DataAnnotations;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class PrintLabelRequest
    {
        public int PrintLabelRequestId { get; set; }
        public int PrinterId { get; set; }
        public string Request { get; set; }
        public bool Active { get; set; }
        public string ClientCode { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
