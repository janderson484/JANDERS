using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Model.DTO
{
    public class LabelImportValidationResponse
    {
        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; }
        public string ActualRecord { get; set; }
    }
}
