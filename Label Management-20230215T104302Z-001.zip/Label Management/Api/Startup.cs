using System;
using System.Net.Http;
using Ats.FleetServices.Core.Data;
using AutoMapper;
using IdentityModel.Client;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Core.Common.SignalR;
using VM.FleetServices.TnR.LM.Api.ActionFilters;
using VM.FleetServices.TnR.LM.Api.Security;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations;
using VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService;
using VM.FleetServices.TnR.LM.Business.Integrations.PrinterService;
using VM.FleetServices.TnR.LM.Business.Mapping;
using VM.FleetServices.TnR.LM.Business.ServiceBus;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.SVRS.Common.SignalR;

namespace VM.FleetServices.TnR.LM.Api
{
    public class Startup
    {
        private readonly IConfiguration _config;
        private readonly IHostingEnvironment _env;
        private readonly ILoggerFactory _loggerFactory;

        public Startup(IHostingEnvironment env, IConfiguration config, ILoggerFactory loggerFactory)
        {
            _config = config;
            _env = env;
            _loggerFactory = loggerFactory;

            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //services.AddMvc().AddMvcOptions(options => options.Filters.Add<LoggingActionFilter>()).
            //    SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddRazorPages();

            services.Configure<IISOptions>(options =>
            {
                options.AutomaticAuthentication = false;
                options.ForwardClientCertificate = false;
            });
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddHttpClient();

            services.AddSingleton<IDiscoveryCache>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();
                return new DiscoveryCache(
                    Configuration.GetSection("OpenIdSettings")["Authority"],
                    () => factory.CreateClient());
            });



            // Auto Mapper Configurations
            var mapperConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new LabelManagementMappingProfile());
            });

            IMapper mapper = mapperConfig.CreateMapper();
            services.AddSingleton(mapper);
            services.AddAutoMapper(typeof(Startup));

            //services.AddSingleton<LoggingActionFilter>();

            // Register the IConfiguration instance which MyOptions binds against.
            services.Configure<OpenIdSettings>(options => _config.GetSection("OpenIdSettings").Bind(options));
            services.Configure<PMApiSettings>(options => { _config.GetSection("PMApiSettings").Bind(options); });
            services.Configure<ApiSettings>(options => { _config.GetSection("ApiSettings").Bind(options); });
            services.Configure<Settings>(options => { _config.GetSection("Settings").Bind(options); });
            services.AddSendServiceBusService(Configuration.GetSection("ServiceBusOptions"));

            // claims transformer will load claims from UserInfo endpoint if not provided in Access Token.
            services.AddSingleton<IClaimsTransformation, UserManagerClaimsTransformer>();

            // Configure DbContext & EF cache service.. (All items accessing DbContext must be 'Scoped'                    

            services.AddDbContext<LabelModel>(options =>
            {
                options.UseSqlServer(_config.GetConnectionString("LabelModel"));
                //.EnableQueryCache(settings => _config.GetSection("EFQueryCacheSettings").Bind(settings));
                if (_env.IsDevelopment())
                    options.EnableSensitiveDataLogging();
            });

            services.AddScoped<IAuthService, AuthService>();
            services.AddScoped<IApiClientService, ApiClientService>();
            services.AddScoped<ILabelModel>(provider => provider.GetService<LabelModel>());
            services.AddScoped<IUnitOfWorkService, UnitOfWorkService<LabelModel>>();
            services.AddScoped<IUnitOfWorkService<LabelModel>, UnitOfWorkService<LabelModel>>();
            services.AddScoped<IRepositoryFactory, UnitOfWorkService<LabelModel>>();
            services.AddScoped<IDbModelFactory<ILabelModel>, LabelModelFactory>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddScoped<ILabelManagementService, LabelManagementService>();
            services.AddScoped<IInvoiceService, InvoiceService>();
            services.AddScoped<IConfigurationService, ConfigurationService>();
            services.AddScoped<IPrinterService, PrinterService>();
            services.AddScoped<LoggingActionFilter>();
            //services.AddSingleton<IApiService, ApiService>();
            services.AddSingleton<IServiceBusService, ServiceBusService>();
            services.AddScoped<INotificationService, NotificationService>();



            services.Configure<AuthenticationServiceOptions>(options =>
            {
                options.Authority = _config["AuthenticationServiceOptions:Authority"];
                options.ClientId = _config["AuthenticationServiceOptions:ClientId"];
                options.ClientSecret = _config["AuthenticationServiceOptions:ClientSecret"];
                options.UserName = _config["AuthenticationServiceOptions:UserName"];
                options.PassWord = _config["AuthenticationServiceOptions:PassWord"];
            });

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30);
            });

            // cache in memory
            services.AddMemoryCache();
            // caching response for middleware
            services.AddResponseCaching();


            //Register Swagger

            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("v1", new Info
            //    {
            //        Version = "v1",
            //        Title = "LabelManagement API",
            //        Description = "LabelManagement API using ASP.NET Core",
            //        TermsOfService = "None",
            //        Contact = new Contact() { Name = "Test", Email = "Test@verramobility.com", Url = "www.verramobility.com" }
            //    });
            //});

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(o =>
            {
                o.Authority = _config.GetSection("OpenIdSettings").GetValue<string>("Authority");
                o.Audience = "fstnrlmapi";
                o.RequireHttpsMetadata = false;
            });

            // Configure security policies
            // services.ConfigureSecurityPolicies();
            services.AddApplicationInsightsTelemetry(_config);

            services.AddSignalR();

            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
                builder
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                .WithOrigins("https://localhost:58991");
            }));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }



            app.UseSession();

            app.UseAuthentication();
            app.UseRouting();
            app.UseAuthorization();
            // caching response for middlewares
            app.UseResponseCaching();
            app.UseHttpsRedirection();
            app.UseCors("CorsPolicy");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<NotificationHub>("/notificationHub");
                endpoints.MapControllerRoute("default", "{controller=Api}/{action=Index}/{id?}");
            });
        }
    }
}
