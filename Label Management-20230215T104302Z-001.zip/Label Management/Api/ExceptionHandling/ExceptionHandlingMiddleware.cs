using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;

namespace VM.FleetServices.TnR.LM.Api.ExceptionHandling
{
    /// <summary>
    /// Exception handling middleware for API. If you need to add any custom exception handling for API it goes in here.
    /// </summary>
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;

        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        /// <summary>
        /// Invokes the action method
        /// </summary>
        /// <param name="context">The context.</param>
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception occured: {ex}", ex.Message, ex.StackTrace);
                await HandleExceptionAsync(context, ex);
            }
        }

        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="context">The execution context.</param>
        /// <param name="exception">The exception to handle.</param>
        /// <returns></returns>
        private static Task HandleExceptionAsync(HttpContext context, Exception exception)//, Microsoft.AspNetCore.Hosting.IHostingEnvironment env)
        {
            var message = "An error has occured during the transaction.</br>";
            var statusCode = HttpStatusCode.InternalServerError;
            var statusCodeDetails = GetErrorCode(exception) ?? throw new ArgumentNullException("GetErrorCode(exception)");
            message = $"{message} </br> {((int)statusCodeDetails.Item1).ToString()} - {statusCodeDetails.Item2} </br></br> Please try again.";
            var response = new ServiceResponse<object>() {Data = null, ErrorMessage = message, ResponseCode = statusCode, Exception = exception};
            var result = JsonConvert.SerializeObject(response);
            
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)statusCode;
            return context.Response.WriteAsync(result);
        }



        /// <summary>  
        /// This method will return the status code based on the exception type.  
        /// </summary>  
        /// <param name="exception">Exception</param>  
        /// <returns>HttpStatusCode and error message</returns>  
        private static Tuple<HttpStatusCode, string> GetErrorCode(Exception exception)
        {
            var exceptionType = typeof(Exception);
            if (!Enum.TryParse<Exceptions>(exceptionType.Name, out var tryParseResult)) return new Tuple<HttpStatusCode, string>(HttpStatusCode.InternalServerError, exception.Message);
            switch (tryParseResult)
            {
                case Exceptions.FileNotFoundException:
                    return new Tuple<HttpStatusCode, string>(HttpStatusCode.NotFound, exception.Message);
                case Exceptions.UnauthorizedAccessException:
                    return new Tuple<HttpStatusCode, string>(HttpStatusCode.Unauthorized, exception.Message);

                case Exceptions.NotImplementedException:
                    return new Tuple<HttpStatusCode, string>(HttpStatusCode.NotImplemented, exception.Message);

                case Exceptions.SqlException:
                    return new Tuple<HttpStatusCode, string>(HttpStatusCode.InternalServerError, exception.Message);

                default:
                    return new Tuple<HttpStatusCode, string>(HttpStatusCode.InternalServerError, exception.Message);
            }
        }

        /// <summary>  
        /// Different types of exceptions.  
        /// </summary>  
        public enum Exceptions
        {
            FileNotFoundException = 1,
            UnauthorizedAccessException = 2,
            NotImplementedException = 3,
            SqlException = 4
        }

    }
}
