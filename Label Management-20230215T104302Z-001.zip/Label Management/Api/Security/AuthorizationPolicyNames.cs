// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AuthorizationPolicyNames.cs" company="American Traffic Solutions, Inc.">
//   Copyright 2017 American Traffic Solutions, Inc.
// </copyright>
// <summary>
//   This class contains list of security policy names   
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace VM.FleetServices.TnR.LM.Api.Security
{
    /// <summary>
    /// list of security policy names
    /// </summary>
    public static class AuthorizationPolicyNames
    {
        /// <summary>
        /// Requires a valid ClientCode..
        /// </summary>
        public const string ClientAccessPolicy = nameof(ClientAccessPolicy);

        /// <summary>
        /// 
        /// </summary>
        public const string ClientApplicationAccessPolicy = nameof(ClientApplicationAccessPolicy);

        /// <summary>
        /// 
        /// </summary>
        public const string ApplicationReadPolicy = nameof(ApplicationReadPolicy); // internal, external, supervisor, admin             

        /// <summary>
        /// 
        /// </summary>
        public const string ApplicationAddModifyPolicy = nameof(ApplicationAddModifyPolicy); // internal, supervisor, admin

        /// <summary>
        /// 
        /// </summary>
        public const string ApplicationInvoicePolicy = nameof(ApplicationInvoicePolicy); // supervisor, admin

        /// <summary>
        /// 
        /// </summary>
        public const string ApplicationConfigSettingPolicy = nameof(ApplicationConfigSettingPolicy); // admin
    }
}
