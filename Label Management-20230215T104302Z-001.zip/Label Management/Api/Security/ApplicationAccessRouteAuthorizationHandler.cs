// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApplicationAccessRouteAuthorizationHandler.cs" company="Verra Mobility, Inc.">
//   Copyright 2019 Verra Mobility, Inc.
// </copyright>
// <summary>
//   Checks for a valid ClientCode, role to be present for the controller name in the Request.
// </summary>
// --------------------------------------------------------------------------------------------------------------------


using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.LM.Api.Security
{
    public class ApplicationAccessRouteAuthorizationHandler : AuthorizationHandler<ApplicationAccessRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private const string LABELMANAGEMENT = "LABELMANAGEMENT";

        public ApplicationAccessRouteAuthorizationHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ApplicationAccessRequirement requirement)
        {
            var clientCode = _httpContextAccessor.HttpContext.Request.GetClientCode();
            if (string.IsNullOrEmpty(clientCode))
                return Task.CompletedTask;

            var path = _httpContextAccessor.HttpContext.Request.Path.Value;

            if (string.IsNullOrEmpty(path))
                return Task.CompletedTask;

            var pathSplit = path.Split("/");

            if (pathSplit == null || pathSplit.Length < 2)
                return Task.CompletedTask;

            var applicationType = pathSplit[2]; // get the controller name from httpcontext request.           

            if (string.IsNullOrEmpty(applicationType))
                return Task.CompletedTask;

            var roles = requirement.Role.Split(",");

            for (var i = 0; i < roles.Length; i++)
            {
                var role = roles[i].ToUpper();
                roles[i] = (role == "SUPERVISOR" || role == "ADMIN") ? $"{LABELMANAGEMENT}-{role}".ToUpper() : $"{applicationType}-{roles[i]}".ToUpper();
            }

            /*
            if (context.User.HasAdminRights(clientCode))
            {
                // need to check the claims for a valid action right for the current asset type code
                var allRightsClaims = context.User.FindAll(UserManagerClaimTypes.Rights);
                if (allRightsClaims.Select(rightsClaim => JsonConvert.DeserializeObject<ClientRights>(rightsClaim.Value)).Any(clientRights => clientRights.Rights.Any(r => roles.Contains(r))))
                {
                    context.Succeed(requirement);
                    return Task.CompletedTask;
                }
            }
            */

            // non-admin client
            if (roles.Select(role => context.User.GetClientRight(clientCode, role)).Any(right => right != null))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;

        }
    }
}
