using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.LM.Api.Security
{
    /// <summary>
    /// Requires a valid role for current client.
    /// </summary>
    public class ClientApplicationAccessRequirement : IAuthorizationRequirement
    {
        public ClientApplicationAccessRequirement()
        {
        }

    }
}
