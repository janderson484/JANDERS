using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations.PrinterService;
using VM.FleetServices.TnR.LM.Business.ServiceBus;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrinterController : Controller
    {
        private readonly ILogger _logger;
        private readonly ILabelManagementService _labelManagementService;
        private readonly IServiceBusService _serviceBusService;
        private readonly IPrinterService _printerService;

        public PrinterController(ILabelManagementService labelManagementService, IPrinterService printerService, IServiceBusService serviceBusService, ILogger<PrinterController> logger)
        {
            _logger = logger;
            _labelManagementService = labelManagementService;
            _serviceBusService = serviceBusService;
            _printerService = printerService;
        }

        /// <summary>
        /// Get Label Data for Printing
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetLabelPrintData")]
        public async Task<IActionResult> GetLabelPrintDataAsync(PrintPreviewViewModel model)
        {
            var response = new ServiceResponse<PrintPreviewViewModel>();
            response.Data = model;

            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetLabelPrintDataAsync)} to get print preview data");

                var userPrintersResult = await _printerService.GetUserConfiguredPrintersAsync(model.UserName, model.LabelTypeId,model.ClientCode,model.ProcessingLocation);
                var labelPrintData = _labelManagementService.GetLabelsPrintData(model.LabelIds);

                var userPrinterIds = userPrintersResult.Printers.Select(p => p.PrinterId).ToList();
                var labelSettings = await _printerService.GetPrinterLabelSettingsAsync(userPrinterIds, model.LabelTypeId);

                _logger.LogInformation($"Perform service request perform {nameof(GetLabelPrintDataAsync)} end");

                response.Data.Result = userPrintersResult ?? new UserPrintersViewModel();
                response.Data.Result.PrinterLabelSettings = labelSettings;

                response.Data.Labels = labelPrintData ?? new List<LabelViewModel>();
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"API Controller action method: {nameof(GetLabelPrintDataAsync)} - Error Message: {ex.Message}");
                response.Data = null;
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }

        /// <summary>
        ///  Update a Printer's Label Settings
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("UpdatePrinterLabelSettings")]
        public async Task<IActionResult> UpdatePrinterLabelSettingsAsync(PrinterLabelSetting model)
        {
            var response = new ServiceResponse<PrinterLabelSetting>();
            var updatePrinterLabelSettingsResult = await _printerService.UpdatePrinterLabelSettingsAsync(model);

            if (updatePrinterLabelSettingsResult != null)
            {
                response.Data = updatePrinterLabelSettingsResult;
                response.ResponseCode = HttpStatusCode.OK;
            }
            else
            {
                response.Data = null;
                response.ErrorMessage = "A PrinterService error has occurred.\r\nPlease contact your support representative";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        [HttpPost, Route("PrintLabels")]
        public async Task<IActionResult> PrintLabelsAsync(PrintLabelsViewModel model)
        {
            var response = new ServiceResponse<PrintLabelsViewModel>();

            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(PrintLabelsAsync)} to print label data");
                var processName = model.LabelType == (int)Labeltypes.Unit ? ProcessNames.PrintUnitLabels : ProcessNames.PrintBagLabels;
                var labelIds = await _printerService.GetJobInProgress(model.LabelIds, model.ClientCode, model.SelectedPrinter, processName);
                if (!labelIds.Any())
                {
                    var printLabelRequestModel = await _printerService.SubmitPrintLabelRequestAsync(model);
                    var printLabelRequestMessage = new PrintLabelRequestMessage { PrintLabelRequestId = printLabelRequestModel.PrintLabelRequestId };

                    await _serviceBusService.SendDynamicMessageAsync(printLabelRequestModel.Log, printLabelRequestMessage);

                    response.ResponseCode = HttpStatusCode.OK;
                }
                else
                {
                    response.ErrorMessage = "Already a request in progress for the labelIds " + String.Join(",", labelIds);
                    response.ResponseCode = HttpStatusCode.PreconditionFailed;
                }
                _logger.LogInformation($"Perform service request perform {nameof(PrintLabelsAsync)} end");
            }
            catch (Exception ex)
            {
                _logger.LogError($"API Controller action method: {nameof(PrintLabelsAsync)} - Error Message: {ex.Message}");
                response.Data = null;
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }

        /// <summary>
        /// Get Label Printer Assignments
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetLabelPrinterAssignments")]
        public async Task<ActionResult<ViewLabelPrintersConfigurationViewModel>> GetLabelPrinterAssignmentAsync(UserProfileSettingsViewModel baseRequest)
        {
            var labelPrintData = await _printerService.GetLabelPrinterAssignmentAsync(baseRequest);
            return labelPrintData;
        }


        /// <summary>
        /// Get Label Printer Assignment Details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetPrinterAssignmentDetails")]
        public async Task<ActionResult<PrinterAssignViewModel>> GetPrinterAssignmentDetailsAsync(PrinterAssignViewModel model)
        {
            var labelPrintData = await _printerService.GetPrinterAssignmentDetailsAsync(model);
            return labelPrintData;
        }

        /// <summary>
        /// Add/Update Label Printer Assignments
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("AddUpdatePrinterAssignment")]
        public async Task<Tuple<bool, string>> AddUpdatePrinterAssignmentSaveAsync(PrinterAssignViewModel model)
        {
            try
            {
                var result = await _printerService.AddUpdatePrinterAssignmentSaveAsync(model);

                return new Tuple<bool, string>(result, "Success");
            }
            catch (Exception ex)
            {
                return new Tuple<bool, string>(false, ex.Message);
            }
        }

        /// <summary>
        /// Update Label Printer Assignment Status
        /// </summary>
        /// <param name="model"></param>
        [HttpPost, Route("UpdatePrinterAssignmentStatus")]
        public async Task<bool> UpdatePrinterAssignmentStatusAsync(PrinterAssignViewModel model)
        {

            var result = await _printerService.UpdatePrinterAssignmentStatusAsync(model);
            return result;
        }

        /// <summary>
        /// Get Label Printers
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetLabelPrinters")]
        public async Task<ActionResult<ViewLabelPrintersConfigurationViewModel>> GetLabelPrintersAsync(UserProfileSettingsViewModel baseRequest)
        {
            var labelPrintData = await _printerService.GetLabelPrintersAsync(baseRequest);
            return labelPrintData;
        }

        /// <summary>
        /// Get Label Printer Details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("GetPrinterDetails")]
        public async Task<ActionResult<PrinterAssignViewModel>> GetPrinterDetailsAsync(PrinterAssignViewModel model)
        {
            var labelPrintData = await _printerService.GetPrinterDetailsAsync(model);
            return labelPrintData;
        }


        /// <summary>
        /// Add/Update Label Printers
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("AddUpdatePrinter")]
        public async Task<Tuple<bool, string>> AddUpdatePrinterSaveAsync(PrinterAssignViewModel model)
        {
            PrinterLabelSetting printerLabelSetting = new PrinterLabelSetting();
            try
            {
                var result = await _printerService.AddUpdatePrinterSaveAsync(model);
                return new Tuple<bool, string>(result, "Success");
            }
            catch (Exception ex)
            {
                return new Tuple<bool, string>(false, ex.Message);
            }
        }

        /// <summary>
        /// Update Label Printer Status
        /// </summary>
        /// <param name="model"></param>
        [HttpPost, Route("UpdatePrinterStatus")]
        public async Task<bool> UpdatePrinterStatusAsync(PrinterAssignViewModel model)
        {

            var result = await _printerService.UpdatePrinterStatusAsync(model);
            return result;
        }
    }
}
