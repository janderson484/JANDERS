using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Caching.Memory;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Api.Security;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using System.Net;
using VM.FleetServices.TnR.LM.Business.ServiceBus;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.Core.Common.Extensions;
using Log = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.Log;
using VM.FleetServices.TnR.LM.Model;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VM.FleetServices.TnR.LM.Api.Controllers
{
    [Route("api/[controller]")]
    public class LabelManagementController : Controller
    {
        private readonly ILogger _logger;
        private readonly ILabelManagementService _labelManagementService;
        private readonly IConfigurationService _configurationService;
        private readonly IServiceBusService _serviceBusService;
        private readonly IMemoryCache _cache;

        public LabelManagementController(ILabelManagementService labelManagementService, ILogger<LabelManagementController> logger, IServiceBusService serviceBusService, IMemoryCache cache, IConfigurationService configurationService)
        {
            _logger = logger;
            _labelManagementService = labelManagementService;
            _serviceBusService = serviceBusService;
            _configurationService = configurationService;
            _cache = cache;
        }

        public object ProcessTypes { get; private set; }

        #region BulkProcessing

        /// <summary>
        /// Get Bulk Process pending job counts
        /// </summary>
        /// <param name="client"></param>
        /// <param name="processingLocationCode"></param>
        /// <returns></returns>
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)] // TODO: Determine after LM permissions are fully setup
        [HttpGet, Route("GetBulkProcessRecordCounts/{client}/{processingLocationCode}")]
        public async Task<IActionResult> GetBulkProcessRecordCountsAsync(string client, string processingLocationCode)
        {
            var response = new ServiceResponse<BulkProcessViewModel>();

            if (client.IsNullOrEmpty() || processingLocationCode.IsNullOrEmpty())
            {
                response.ErrorMessage = "Client or Processing Location cannot be null";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(response);
            }

            response.Data = await _labelManagementService.GetBulkProcessRecordCountTaskAsync(client, processingLocationCode);
            response.ResponseCode = HttpStatusCode.Accepted;
            return new JsonResult(response);
        }

        /// <summary>
        /// Sends request to WebJob message queue to run a given Bulk Process
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        //[Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)] // TODO: Determine after LM permissions are fully setup
        [HttpPost, Route("PerformBulkProcess")]
        public async Task<IActionResult> PerformBulkProcessAsync([FromBody] BulkProcessViewModel model)
        {
            var response = new ServiceResponse<string>();
            string bulkAction = null;

            if (model is null || model.ClientName is null)
            {
                response.ErrorMessage = "model cannot be null";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(response);
            }

            try
            {
                foreach (BulkProcessTypes bulkProcessTypes in (BulkProcessTypes[])Enum.GetValues(typeof(BulkProcessTypes)))
                {
                    if (model.BulkAction == bulkProcessTypes.ToString())
                    {
                        bulkAction = bulkProcessTypes.GetDescription();
                    }
                }

                var currentLogDate = DateTime.Now;

                // Create a Log for bulk process manually, until logging is added to LM
                var jobLog = new Model.DTO.Log
                {
                    ClientCode = model.ClientName,
                    ProcessingLocationCode = model.ProcessingLocationCode,
                    ProcessName = bulkAction,
                    ProcessType = model.ProcessType,
                    TotalCount = model.TotalCount,
                    SuccessfulCount = 0,
                    ErrorCount = 0,
                    WarningCount = 0,
                    Status = JobLogStatus.Ready.ToString(),
                    CreatedUser = model.UserId,
                    CreatedDate = currentLogDate,
                    ModifiedUser = model.UserId,
                    ModifiedDate = currentLogDate
                };

                var bulkProcessLog = await _labelManagementService.CreateJobLogTaskAsync(jobLog);
                await _serviceBusService.SendMessageAsync(bulkProcessLog);
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception e)
            {
                _logger.LogError($"Renewals API: {nameof(PerformBulkProcessAsync)} error message - { e.Message }");
                response.ErrorMessage = e.Message;
                throw e;
            }

            return new JsonResult(response);
        }

        #endregion

        #region Search/Import Labels

        /// <summary>
        /// API Controller action to retrieve bag or unit labels data
        /// </summary>
        /// <returns>Json response</returns>
        [HttpPost("GetLabels")]
        public async Task<IActionResult> GetLabelsAsync([FromBody] SearchLabelViewModel searchCriteria)
        {
            var response = new ServiceResponse<SearchLabelViewModel>();
            var sortFields = new List<string>();
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(GetLabelsAsync)} to get bag labels data");
                var labelSortOrder = await _configurationService.GetLabelSortOrderByUserAsync(searchCriteria.UserId,searchCriteria.ClientCode,searchCriteria.ProcessingLocationCode);
                var labelEnum = EnumExtensions.GetAllEnumsWithDescription(typeof(Labels));
                if (labelSortOrder != null && labelSortOrder.Active != false && labelSortOrder.SortOrderFields != null)
                {
                    foreach (var item in labelSortOrder.SortOrderFields)
                    {
                        var sortField = labelEnum.Where(x => x.Value == item.FieldName).FirstOrDefault();
                        sortFields.Add(string.Join(" ", sortField.Key, item.Order));
                    }
                    searchCriteria.SortOrder = string.Join(",", sortFields);
                }
                var bagLabels = await _labelManagementService.GetLabelsAsync(searchCriteria);
                _logger.LogInformation($"Perform service request perform {nameof(GetLabelsAsync)} end");
                response.Data = bagLabels;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Renewals API: {nameof(GetLabelsAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }

        #endregion

        #region Import Labels

        [HttpPost, Route("ImportLabels")]
        public async Task<IActionResult> ImportLabelsAsync([FromBody] LabelImportViewModel model)
        {
            var response = new ServiceResponse<string>();
            try
            {
                var importLabelResponse = await _labelManagementService.SubmitImportLabelRequestAsync(model);
                var messageCaller = _serviceBusService.SendMessageAsync(importLabelResponse.JobLog);

                if (messageCaller.IsCompletedSuccessfully)
                {
                    response.ResponseCode = HttpStatusCode.Accepted;
                }
                else
                {
                    response.ResponseCode = HttpStatusCode.BadRequest;
                    response.ErrorMessage = "There was issue sending message to Queue. \r\nPlease contact your support representative.";
                }
            }
            catch (Exception)
            {
                response.ResponseCode = HttpStatusCode.BadRequest;
                response.ErrorMessage = "There was issue sending message to Queue. \r\nPlease contact your support representative.";
            }

            return new JsonResult(response);
        }


        /// <summary>
        /// API Controller action to retrieve bag or unit labels data
        /// </summary>
        /// <returns>Json response</returns>
        [HttpPost("GetLabelsBillingData")]
        public async Task<IActionResult> GetLabelsBillingDataAsync([FromBody] List<int> labelIds)
        {
            var response = new ServiceResponse<List<LabelBilling>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(GetLabelsBillingDataAsync)} to get labels billings data");
                var labelBillingss = await _labelManagementService.GetLabelBillingDataAsync(labelIds);
                _logger.LogInformation($"Perform service request perform {nameof(GetLabelsBillingDataAsync)} end");
                response.Data = labelBillingss;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(GetLabelsBillingDataAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }


        /// <summary>
        /// API Controller action to retrieve bag or unit labels data
        /// </summary>
        /// <returns>Json response</returns>
        [HttpPost("GetLabelsData")]
        public async Task<IActionResult> GetLabelsDataAsync([FromBody] List<int> labelIds)
        {
            var response = new ServiceResponse<List<Label>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(GetLabelsDataAsync)} to get bag labels data");
                var labels = await _labelManagementService.GetLabelDataAsync(labelIds);
                _logger.LogInformation($"Perform service request perform {nameof(GetLabelsDataAsync)} end");
                response.Data = labels;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(GetLabelsDataAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }


        /// <summary>
        /// API Controller action to update the label billing data
        /// </summary>
        /// <returns>Json response</returns>
        [HttpPost("UpdataLabelBilling")]
        public async Task<bool> UpdataLabelBillingAsync(int invoiceId, [FromBody] List<int> labelBIllingIds)
        {
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(UpdataLabelBillingAsync)} to update label billing data");
                var status = await _labelManagementService.UpdateLabelBillingAsync(labelBIllingIds, invoiceId);
                _logger.LogInformation($"Perform service request perform {nameof(UpdataLabelBillingAsync)} end");
                return status;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(UpdataLabelBillingAsync)} error message - { ex.Message }");
                return false;
            }
        }

        /// <summary>
        /// API Controller action to perform invoice
        /// </summary>
        /// <returns>Json response</returns>
        [HttpPost("PerformBulkInvoice/{clientCode}/{user}")]
        public async Task<IActionResult> PerformBulkInvoiceAsync([FromBody] List<Label> labelsToProcess, string clientCode, string user)
        {
            var response = new ApiResponseDto();
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(PerformBulkInvoiceAsync)} to invoice the labels");
                response = await _labelManagementService.BulkInvoiceProcessAsync(labelsToProcess, clientCode, user);
                _logger.LogInformation($"Perform service request perform {nameof(PerformBulkInvoiceAsync)} end");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(PerformBulkInvoiceAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }
        #endregion

        #region Notification

        [HttpGet, Route("GetNotifications/{userName}")]
        public async Task<IActionResult> GetNotificationsAsync(string userName)
        {
            var response = new ServiceResponse<List<NotificationViewModel>>();
            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetNotificationsAsync)} to get notifications data");
                var logsResult = await _labelManagementService.GetNotificationsByUserNameAsync(userName);
                _logger.LogInformation($"Perform service request perform {nameof(GetNotificationsAsync)} end");

                response.Data = logsResult ?? new List<NotificationViewModel>();
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"API Controller action method: {nameof(GetNotificationsAsync)} - Error Message: {ex.Message}");
                response.Data = null;
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }

        [Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        [HttpPost, Route("CreateNotifications")]
        public async Task<IActionResult> CreateNotificationsAsync(Log log)
        {
            var response = new ServiceResponse<NotificationViewModel>();
            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(CreateNotificationsAsync)} to get notifications data");
                var logsResult = await _labelManagementService.CreateNotificationsAsync(log);
                _logger.LogInformation($"Perform service request perform {nameof(CreateNotificationsAsync)} end");

                response.Data = logsResult ?? new NotificationViewModel();
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"API Controller action method: {nameof(CreateNotificationsAsync)} - Error Message: {ex.Message}");
                response.Data = null;
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }

        #endregion

        #region Logs

        /// <summary>
        /// Api end point to get Logs data based on search criteria
        /// </summary>
        /// <param name="model">model contains search criteria</param>
        /// <returns>returns input model with list of log records</returns>
        [HttpPost, Route("GetLogs")]
        public async Task<IActionResult> GetLogsAsync([FromBody] LogSummaryViewModel model)
        {
            var response = new ServiceResponse<LogSummaryViewModel>();

            if (model == null || string.IsNullOrEmpty(model.ClientCode))
            {
                response.Data = null;
                response.ErrorMessage = "Invalid Input";
                response.ResponseCode = HttpStatusCode.BadRequest;

                _logger.LogError($"{ nameof(GetLogsAsync)} : Invalid request payload to get Logs data.");

                return new JsonResult(response);
            }

            try
            {
                _logger.LogInformation($"Starting Web Api method {nameof(GetLogsAsync)} to get Logs data");
                var logsResult = await _labelManagementService.GetLogsAsync(model);
                _logger.LogInformation($"Perform service request perform {nameof(GetLogsAsync)} end");

                response.Data = logsResult;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception)
            {
                response.Data = null;
                response.ErrorMessage = "An error has occurred.\r\nPlease contact your support representative.";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        /// <summary>
        /// API end point to return log details based on log
        /// </summary>
        /// <param name="model">model contains search criteria</param>
        /// <returns>returns model with log and log details</returns>
        [HttpPost("GetLogDetails")]
        public async Task<IActionResult> GetLogDetailsAsync([FromBody] LogDetailViewModel model)
        {
            var response = new ServiceResponse<LogDetailViewModel>();

            if (model == null || model.LogId == 0)
            {
                response.Data = null;
                response.ErrorMessage = "Invalid input request";
                response.ResponseCode = HttpStatusCode.BadRequest;

                _logger.LogError($"{ nameof(GetLogDetailsAsync)} : Invalid request payload to get Log details.");

                return new JsonResult(response);
            }

            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(GetLogDetailsAsync)} to get Logs data");
                var logDetails = await _labelManagementService.GetLogDetailsAsync(model);
                _logger.LogInformation($"Perform service request perform {nameof(GetLogDetailsAsync)} end");

                response.Data = logDetails;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception)
            {
                response.Data = null;
                response.ErrorMessage = "A renewal service error has occurred.\r\nPlease contact your support representative.";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        /// <summary>
        /// This method is for updating a Job Logs
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>        
        // [Authorize(Policy = AuthorizationPolicyNames.ApplicationAddModifyPolicy)]
        [HttpPost, Route("UpdateJobStatusById")]
        public async Task<IActionResult> UpdateLogStatusByIdAsync([FromBody] Model.DTO.Log model)
        {
            _logger.LogInformation($"API Controller method: {nameof(UpdateLogStatusByIdAsync)} - Updating Job Log status by Id");

            var response = new ServiceResponse<Model.DTO.Log>();

            try
            {
                _logger.LogInformation($"Starting Web API method {nameof(UpdateLogStatusByIdAsync)} to update Job Log by Id");
                var responseData = await _labelManagementService.UpdateLogStatusByIdAsync(model.LogId, model.Status);
                _logger.LogInformation($"Perform service request {nameof(UpdateLogStatusByIdAsync)} end.");

                response.Data = responseData;
                response.ResponseCode = HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"API Contoller action method: {nameof(UpdateLogStatusByIdAsync)} - Error Updating Job Log by Id. Error Message: {ex.Message}");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }

            return new JsonResult(response);
        }

        #endregion

        #region Update Labels

        /// <summary>
        /// This method is for updating a list of labels
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost, Route("UpdateLabels")]
        public async Task<BulkUpdateResultViewModel> UpdateLabelsAsync([FromBody] UpdateLabelsModel request)
        {
            _logger.LogInformation($"API Controller method: {nameof(UpdateLabelsAsync)} - Updating labels");
            _logger.LogInformation($"Starting Web API method {nameof(UpdateLabelsAsync)} to update labels");

            var labelsUpdateResult = await _labelManagementService.UpdateLabelsAsync(request);
            var successfulUpdatedLabels = request.LabelsList.Select(l => l.LabelId).Where(l => labelsUpdateResult.FailedOrders.All(l2 => l2 != l)).ToList();
            labelsUpdateResult.VoidedLabelBillingIds = await _labelManagementService.GetVoidedLabelBillingsAsync(successfulUpdatedLabels);

            _logger.LogInformation($"Perform service request {nameof(UpdateLabelsAsync)} end.");

            return labelsUpdateResult;
        }

        [HttpPost, Route("PerformBulkUpdate")]
        public async Task<BulkUpdateResultViewModel> PerformBulkUpdateAsync([FromBody] BulkUpdateViewModel bulkUpdateModel)
        {
            _logger.LogInformation($"Starting Web Api method { nameof(PerformBulkUpdateAsync)} to perform the bulk update");
            _logger.LogInformation($"Perform bulk update service execution start");

            var bulkUpdateResultViewModel = await _labelManagementService.PerformBulkUpdateAsync(bulkUpdateModel);
            var successfulUpdatedLabels = bulkUpdateModel.Labels.Where(lblId => bulkUpdateResultViewModel.FailedOrders.All(fId => fId != lblId)).ToList();
            bulkUpdateResultViewModel.VoidedLabelBillingIds = await _labelManagementService.GetVoidedLabelBillingsAsync(successfulUpdatedLabels);

            _logger.LogInformation($"Perform bulk update service execution end");

            return bulkUpdateResultViewModel;
        }

        /// <summary>
        /// Gets list of invoice id's associated for all the labels provided
        /// </summary>
        /// <param name="labelIds">list of label id's</param>
        /// <returns>returns list of invoice id's</returns>
        [HttpPost, Route("GetInvoiceIdsForLabels")]
        public async Task<IActionResult> GetInvoiceIdsForLabelsAsync([FromBody] List<int> labelIds)
        {
            var response = new ServiceResponse<IEnumerable<int>>();

            if (labelIds == null || !labelIds.Any())
            {
                response.Data = new List<int>();
                response.ErrorMessage = "Invalid request payload - no records";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(HttpStatusCode.BadRequest);
            }

            try
            {
                response.Data = await _labelManagementService.GetInvoiceIdsForLabelsAsync(labelIds);
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementController)}; Method: {nameof(GetInvoiceIdsForLabelsAsync)}; Error: {e.Message}");
                response.ErrorMessage = $"Error getting invoice ids for labels\r\nError details: {e.Message}";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }


        /// <summary>
        /// Gets invoice status data for all the submitted invoice id's
        /// </summary>
        /// <param name="invoiceIds">list of invoice id's</param>
        /// <returns>returns list of invoice data</returns>
        [HttpPost, Route("GetInvoiceStatusByIds")]
        public async Task<IActionResult> GetInvoiceStatusByIdsAsync([FromBody] List<int> invoiceIds)
        {
            var response = new ServiceResponse<List<SelectInvoiceViewModel>>();

            if (invoiceIds == null || !invoiceIds.Any())
            {
                response.Data = new List<SelectInvoiceViewModel>();
                response.ErrorMessage = "Invalid request payload - no records";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(HttpStatusCode.BadRequest);
            }

            try
            {
                response.Data = await _labelManagementService.GetInvoiceStatusByIdsAsync(invoiceIds);
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementController)}; Method: {nameof(GetInvoiceStatusByIdsAsync)}; Error: {e.Message}");
                response.ErrorMessage = $"Error getting invoice status details for submitted invoice ids\r\nError details: {e.Message}";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        /// <summary>
        /// Deletes invoice billings by line item id
        /// </summary>
        /// <returns>returns list of invoice data</returns>
        [HttpPost, Route("DeleteInvoiceBillingsByLineItemId/{clientCode}/{itemTypeId}")]
        public async Task<IActionResult> DeleteInvoiceBillingsByLineItemIdAsync(string clientCode, int itemTypeId, [FromBody] List<int> billingIds)
        {
            var response = new ServiceResponse<List<SelectInvoiceViewModel>>();

            if (string.IsNullOrWhiteSpace(clientCode) || itemTypeId <= 0 || !billingIds.Any())
            {
                response.Data = new List<SelectInvoiceViewModel>();
                response.ErrorMessage = "Invalid request payload - no records";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(HttpStatusCode.BadRequest);
            }

            try
            {
                await _labelManagementService.DeleteInvoiceBillingsByLineItemIdAsync(clientCode, itemTypeId, billingIds);
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementController)}; Method: {nameof(DeleteInvoiceBillingsByLineItemIdAsync)}; Error: {e.Message}");
                response.ErrorMessage = $"Error deleting invoice billings for submitted billing ids\r\nError details: {e.Message}";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }

            return new JsonResult(response);
        }

        #endregion

        #region Export Labels

        /// <summary>
        /// API action to submit End of Day Process request
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SubmitExportAllRequest")]
        public async Task<IActionResult> SubmitExportAllRequestAsync([FromBody] ExportLabelViewModel model)
        {
            var response = new ServiceResponse<ExportLabelViewModel>();
            var exportSearch = new Model.DTO.ExportSearchCriteria();
            try
            {
                _logger.LogInformation($"Starting Web Api method { nameof(SubmitExportAllRequestAsync)}");
                var res = await _labelManagementService.SubmitExportAllRequestAsync(model);
                exportSearch.ReportType = model.ReportType;
                exportSearch.SearchCriteria = model.SearchCriteria;
                res.ProcessingLocationCode = model.ProcessingLocationCode;
                await _serviceBusService.SendDynamicMessageAsync(res, exportSearch);
                _logger.LogInformation($"Perform service request {nameof(SubmitExportAllRequestAsync)} end");
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Renewals API: {nameof(SubmitExportAllRequestAsync)} error message - { ex.Message }");
                response.ResponseCode = HttpStatusCode.InternalServerError;
                response.ErrorMessage = ex.Message;
            }
            return new JsonResult(response);
        }

        #endregion

        #region Label Credits

        /// <summary>
        /// Validate labels for processing label credits
        /// </summary>
        /// <param name="labels"></param>
        /// <returns></returns>
        [HttpPost, Route("ValidateLabelsToApplyCredits")]
        public async Task<IActionResult> ValidateLabelsToApplyCreditsAsync([FromBody] IEnumerable<int> labels)
        {
            var response = new ServiceResponse<List<CreditLabelViewModel>>();

            if (labels == null || labels.Count() == 0)
            {
                response.Data = null;
                response.ErrorMessage = "Invalid request payload - no records";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(response);
            }

            response.Data = await _labelManagementService.ValidateLabelsToApplyCreditsAsync(labels);
            response.ResponseCode = HttpStatusCode.Accepted;
            return new JsonResult(response);
        }

        /// <summary>
        /// Applied credits to all the listed plates
        /// </summary>
        /// <param name="model">PlateCreditRequestModel model</param>
        /// <returns>returns success or failure</returns>
        [HttpPost, Route("ApplyCreditsToLabels")]
        public async Task<IActionResult> ApplyCreditsToLabelsAsync([FromBody] CreditLabelRequestModel model)
        {
            var response = new ServiceResponse<CreditLabelRequestModel>();

            if (model == null || !model.LabelIdList.Any())
            {
                response.Data = null;
                response.ErrorMessage = "Invalid request payload - no records";
                response.ResponseCode = HttpStatusCode.BadRequest;
                return new JsonResult(response);
            }

            await _labelManagementService.ApplyCreditsToLabelsAsync(model);
            model.VoidLabelBillings = await _labelManagementService.GetVoidedLabelBillingsForCreditLabelsAsync(model.LabelIdList.ToList());
            response.Data = model;
            response.ResponseCode = HttpStatusCode.Accepted;
            return new JsonResult(response);
        }

        #endregion

        #region Lookups

        [HttpGet("GetLabelLookUps")]
        public async Task<ActionResult<Dictionary<string, object>>> GetLabelLookUpsAsync()
        {
            // Return label lookups if existing in cache
            if (_cache.TryGetValue("LabelLookUps", out Dictionary<string, object> labelLookUps))
                return labelLookUps;

            // Get latest lookups from cache 
            labelLookUps = await _labelManagementService.GetLabelLookUpsAsync();

            var options = new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15), //cache will expire in 15 min
                SlidingExpiration = TimeSpan.FromMinutes(5) // cache will expire if inactive for 5 min
            };

            if (labelLookUps != null)
            {
                _cache.Set("LabelLookUps", labelLookUps, options);
            }

            return labelLookUps;
        }

        /// <summary>
        ///  Gets the billing lookup data 
        /// </summary>
        /// <returns>Billing lookups collection</returns>
        [HttpGet, Route("GetBillingLookups")]
        public async Task<IActionResult> GetBillingLookupsAsync()
        {
            var response = new ServiceResponse<BillingLookup>();
            try
            {
                var billingLookupsResult = await _labelManagementService.GetBillingLookupsAsync();
                response.Data = billingLookupsResult;
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementController)}; Method: {nameof(GetBillingLookupsAsync)}; Error: {e.Message}");
                response.ErrorMessage = $"Error getting the billing lookup data\r\nError details: {e.Message}";
                response.ResponseCode = HttpStatusCode.InternalServerError;
            }
            return new JsonResult(response);
        }

        #endregion

        #region Move Labels

        /// <summary>
        /// Update Label Processing Office
        /// </summary>
        /// <param name="model"></param>
        [HttpPost, Route("UpdateLabelProcessingOffice")]
        public async Task<bool> UpdateLabelProcessingOfficeAsync([FromBody] MoveLabelsViewModel model)
        {
            try
            {
                var result = await _labelManagementService.UpdateLabelProcessingOfficeAsync(model);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(UpdateLabelProcessingOfficeAsync)} error message - { ex.Message }");
                return false;
            }
        }

        #endregion

        #region Invoice

        /// <summary>
        /// API for print invoice service bus request
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost, Route("PrintInvoice")]
        public async Task<IActionResult> PrintInvoiceAsync([FromBody] SearchInvoiceDataToPrintViewModel model)
        {
            var response = new ServiceResponse<string>();
            try
            {
                var currentLogDate = DateTime.Now;

                var jobLog = new Model.DTO.Log
                {
                    ProcessName = LabelProcessNames.PrintInvoice.GetDescription(),
                    TotalCount = 1,
                    SuccessfulCount = 0,
                    ErrorCount = 0,
                    WarningCount = 0,
                    Status = JobLogStatus.Ready.ToString(),
                    CreatedUser = model.UserId,
                    CreatedDate = currentLogDate,
                    ModifiedUser = model.UserId,
                    ModifiedDate = currentLogDate,
                    ClientCode = model.ClientCode,
                    ProcessType = BulkProcessTypes.Export.GetDescription(),
                    ProcessingLocationCode = model.ProcessingLocationCode
                };

                var log = await _labelManagementService.CreateJobLogTaskAsync(jobLog);
                await _serviceBusService.SendDynamicMessageAsync(log, new PrintInvoice() { InvoiceId = model.InvoiceId, ClientId = model.ClientId, ProcessingLocationId = model.ProcessingLocationId });
                response.ResponseCode = HttpStatusCode.Accepted;
            }
            catch (Exception)
            {
                response.ResponseCode = HttpStatusCode.BadRequest;
                response.ErrorMessage = "There was issue sending message to Queue. \r\nPlease contact your support representative.";
            }
            return new JsonResult(response);
        }


        #endregion

        #region Copy Labels

        /// <summary>
        /// Copy label data
        /// </summary>
        /// <param name="model"></param>
        [HttpPost, Route("CopyLabelsAsync")]
        public async Task<CopyLabelsViewModel> CopyLabelsAsync([FromBody] CopyLabelsViewModel model)
        {
            try
            {
                var result = await _labelManagementService.CopyLabelsAsync(model);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(CopyLabelsAsync)} error message - { ex.Message }");
            }
            return model;
        }

        #endregion

        #region Billings

        /// <summary>
        ///  Gets the billing reason type 
        /// </summary>
        [HttpPost, Route("GetBillingReasonType")]
        public async Task<bool> GetBillingReasonTypeAsync([FromBody] LabelViewModel model)
        {
            try
            {
                Label labelEntity = new Label();
                labelEntity.LabelTypeId = model.LabelTypeId;
                var result = await _labelManagementService.GetBillingReasonTypeAsync(model);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label API: {nameof(GetBillingReasonTypeAsync)} error message - { ex.Message }");
                return false;
            }

        }

        #endregion

    }
}
