using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Api.ActionFilters;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Api.Controllers
{
    [ServiceFilter(typeof(LoggingActionFilter))]
    [Route("api/[controller]")]
    [ApiController]
    public class ConfigurationController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IConfigurationService _configService;

        public ConfigurationController(IConfigurationService configService, ILogger<ConfigurationController> logger)
        {
            _logger = logger;
            _configService = configService;
        }

        [HttpPost, Route("GetImportLayouts")]
        public async Task<ActionResult<ImportLayoutConfigurationViewModel>> GetImportLayoutsAsync([FromBody] UserProfileSettingsViewModel baseRequest)
        {
            var billingFeeConfigurations = await _configService.GetImportLayoutsAsync(baseRequest);
            return billingFeeConfigurations;
        }

        [HttpPost, Route("UpdateImportLayoutStatus")]
        public async Task<bool> UpdateImportLayoutStatusAsync([FromBody] ImportLayoutViewModel model)
        {

            var result = await _configService.UpdateImportLayoutStatusAsync(model);
            return result;
        }

        [HttpGet("GetMasterData")]
        public async Task<ActionResult<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>>> GetMasterDataAsync()
        {
            return await _configService.GetMasterDataAsync();
        }

        [HttpGet, Route("GetImportLayout/{id}")]
        public async Task<IActionResult> GetImportLayoutAsync(int id)
        {
            var response = new ServiceResponse<ImportLayoutViewModel>
            {
                Data = await _configService.GetImportLayoutAsync(id),
                ResponseCode = HttpStatusCode.OK
            };
            return new JsonResult(response);
        }

        [HttpPost, Route("SaveLayoutConfig")]
        public async Task<Tuple<bool, string>> SaveLayoutConfigAsync([FromBody] ImportLayoutViewModel model)
        {
            try
            {
                var result = await _configService.SaveLayoutConfigAsync(model);
                return new Tuple<bool, string>(result, "Add/Edit import layout success");
            }
            catch (Exception ex)
            {
                return new Tuple<bool, string>(false, ex.Message);
            }
        }

        [HttpPost, Route("GetImportTypes")]
        public async Task<IActionResult> GetImportTypesAsync([FromBody] UserProfileSettingsViewModel profileSettings)
        {
            var response = new ServiceResponse<ImportLayoutConfigurationViewModel>
            {
                Data = await _configService.GetImportTypesAsync(profileSettings),
                ResponseCode = HttpStatusCode.OK
            };
            return new JsonResult(response);
        }

        [HttpPost, Route("GetLabelType")]
        public async Task<IActionResult> GetLabelTypeAsync([FromBody] AddLabelsViewModel model)
        {
            var response = new ServiceResponse<ImportLayoutConfigurationViewModel>
            {
                Data = await _configService.GetLabelTypeAsync(model),
                ResponseCode = HttpStatusCode.OK
            };
            return new JsonResult(response);
        }

        #region Print Sort Order

        [HttpPost, Route("GetLabelSortOrder")]
        public async Task<ActionResult<LabelSortOrderConfigurationViewModel>> GetLabelSortOrderAsync([FromBody] UserProfileSettingsViewModel baseRequest)
        {
            var labelSortOrderConfigurations = await _configService.GetLabelSortOrderAsync(baseRequest);
            return labelSortOrderConfigurations;
        }

        [HttpGet("GetLabelData")]
        public async Task<ActionResult<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>>> GetLabelDataAsync()
        {
            return await _configService.GetLabelDataAsync();
        }

        [HttpGet, Route("GetSortOrder/{id}")]
        public async Task<IActionResult> GetSortOrderAsync(int id)
        {
            var response = new ServiceResponse<LabelSortOrderViewModel>
            {
                Data = await _configService.GetLabelSortOrderAsync(id),
                ResponseCode = HttpStatusCode.OK
            };
            return new JsonResult(response);
        }

        [HttpPost, Route("SaveLabelSortOrder")]
        public async Task<Tuple<bool, string>> SaveLabelSortOrderAsync([FromBody] LabelSortOrderViewModel model)
        {
            try
            {
                var result = await _configService.SaveLabelSortOrderAsync(model);
                return new Tuple<bool, string>(result, "Add/Edit import layout success");
            }
            catch (Exception ex)
            {
                return new Tuple<bool, string>(false, ex.Message);
            }
        }

        [HttpGet, Route("DeleteLabelSortOrder/{id}")]
        public async Task<bool> DeleteSortOrderAsync(int id)
        {
            var result = await _configService.DeleteSortOrderAsync(id);
            return result;
        }

        [HttpPost, Route("UpdateSortOrderStatus")]
        public async Task<bool> UpdateLabelSortOrderStatusAsync([FromBody] LabelSortOrderViewModel model)
        {

            var result = await _configService.UpdateLabelSortOrderStatusAsync(model);
            return result;
        }

        [HttpGet, Route("GetAllLabelSortOrders/{clientCode}/{processingCode}")]
        public async Task<List<LabelSortOrderViewModel>> GetAllLabelSortOrdersAsync(string clientCode, string processingCode)
        {
            var result = await _configService.GetAllLabelSortOrderAsync(clientCode, processingCode);
            return result;
        }

        [HttpGet, Route("GetPersonalSettings/{userId}/{clientCode}/{processingCode}")]
        public async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync(string userId, string clientCode, string processingCode)
        {
            var result = await _configService.GetPersonalSettingsAsync(userId, clientCode, processingCode);
            var rowsPerPage = EnumExtensions.GetAllEnumsWithDescription(typeof(RowsPerPage));

            if (result != null && rowsPerPage != null)
            {
                result.RowsPerPageList = rowsPerPage.Select(
                x => new SelectListItem
                {
                    Text = x.Value,
                    Value = x.Value
                }).ToList();
            }
            return result;
        }

        [HttpPost, Route("SetPersonalSettings")]
        public async Task<bool> SetPersonalSettingsAsync(PersonalSettingsViewModel model)
        {
            var result = await _configService.SetPersonalSettingsAsync(model);
            return result;
        }
        #endregion
    }
}
