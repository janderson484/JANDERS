using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace VM.FleetServices.TnR.LM.Api.Controllers
{
    [Authorize]
    [Produces("application/json")]
    [Route("api")]
    [ApiController]
    public class ApiIndexController : Controller
    {
        #region Fields

        private readonly ILogger<ApiIndexController> _logger;

        #endregion

        #region Constructor

        /// <summary>
        /// 
        /// </summary>
        /// <param name="injectedService"></param>
        /// <param name="logger"></param>
        public ApiIndexController(ILogger<ApiIndexController> logger)
        {
            _logger = logger;
        }

        #endregion

        #region GET /api
        /// <summary>
        /// Gets the different API endpoints
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Produces(typeof(JsonResult))]
        public IActionResult Index()
        {
            return Json("Api");
        }

        #endregion

    }
}
