using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.Data.ExtensionMethods;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Net;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService;
using Newtonsoft.Json.Linq;
using System.Reflection;

namespace VM.FleetServices.TnR.LM.Business
{
    public class LabelManagementService : ILabelManagementService
    {
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILogger<LabelManagementService> _logger;
        private readonly IInvoiceService _invoiceService;
        private readonly IMapper _mapper;

        public LabelManagementService(IUnitOfWorkService<LabelModel> unitOfWorkService, ILogger<LabelManagementService> logger, IInvoiceService invoiceService, IMapper mapper)
        {
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _invoiceService = invoiceService;
            _mapper = mapper;
        }

        #region Lookups

        public async Task<Dictionary<string, object>> GetLabelLookUpsAsync()
        {
            var lookups = new Dictionary<string, object>();

            _logger.LogInformation($"Getting label lookups: , {nameof(GetLabelLookUpsAsync)}");

            var labelStatusTypes = await _unitOfWorkService.GetRepositoryAsync<LabelStatusType>().GetListAsync();
            var labelTypes = await _unitOfWorkService.GetRepositoryAsync<LabelType>().GetListAsync();

            _logger.LogInformation($"Mapping label lookup entities to models: , {nameof(GetLabelLookUpsAsync)}");

            lookups.Add("LabelStatusTypes", _mapper.Map<List<Model.DTO.LabelStatusType>>(labelStatusTypes));
            lookups.Add("LabelTypes", _mapper.Map<List<Model.DTO.LabelType>>(labelTypes));

            return lookups;
        }

        #endregion

        #region Get Labels

        public async Task<SearchLabelViewModel> GetLabelsAsync(SearchLabelViewModel searchCriteria)
        {

            try
            {
                if (searchCriteria.Search)
                {
                    // Need to ensure the page number starts at 1 for a new search (Search button clicked)
                    // because the offset must be 0 so that the query wont skip any results unexpectedly
                    searchCriteria.PageNumber = 1;
                }

                var results = await _unitOfWorkService.Context.LoadStoredProc("GetLabels")
                    .WithSqlParam("@ClientCode", searchCriteria.ClientCode)
                    .WithSqlParam("@ProcessingLocationCode", searchCriteria.ProcessingLocationCode)
                    .WithSqlParam("@LabelStatusTypes", searchCriteria.SelectedLabelStatusTypes)
                    .WithSqlParam("@LabelTypeId", searchCriteria.LabelTypeId)
                    .WithSqlParam("@RowsPerPage", searchCriteria.DefaultRowsPerPage)
                    .WithSqlParam("@PageNumber", searchCriteria.PageNumber)
                    .WithSqlParam("@SearchColumn", searchCriteria.SearchColumn.IsNullOrEmpty() ? "VIN" : searchCriteria.SearchColumn)
                    .WithSqlParam("@SearchText", string.IsNullOrWhiteSpace(searchCriteria.SearchTextField) ? string.Empty : searchCriteria.SearchTextField)
                    .WithSqlParam("@StartDate", searchCriteria.StartDate)
                    .WithSqlParam("@EndDate", searchCriteria.EndDate)
                    .WithSqlParam("@Printed", searchCriteria.Printed ? 1 : 0)
                    .WithSqlParam("@SortOrder", Convert.ToString(searchCriteria.SortOrder))
                    .WithSqlParam("@MaintainSearchOrder", searchCriteria.MaintainSearchOrder ? 1 : 0)
                    .ExecuteStoredProcedureAsync<LabelViewModel>();

                searchCriteria.Results = results;
                searchCriteria.TotalCount = (results.Count == 0) ? 0 : results.First().TotalRowCount;

            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetLabelsAsync)}; Error: {e.Message}");
                throw;
            }

            return searchCriteria;
        }

        #endregion

        /// <summary>
        /// Get Label Data by given list of Label IDs
        /// </summary>
        /// <param name="labelIds"></param>
        /// <returns></returns>
        public List<LabelViewModel> GetLabelsPrintData(List<int> labelIds)
        {
            var labelDataResult = new List<LabelViewModel>();
            try
            {
                _logger.LogInformation($"Method {nameof(GetLabelsAsync)} : Retrieving Label Datas");

                //var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(a => labelIds.Contains(a.LabelId));
                var labelData = labelIds.Select(x => _unitOfWorkService.Context.Labels.FirstOrDefault(r => r.LabelId == x)).ToList();

                var labelStatuses = _unitOfWorkService.Context.LabelStatusTypes.ToList();

                var labels = from label in labelData
                             select new LabelViewModel
                             {
                                 ClientCode = label.ClientCode,
                                 ProcessingLocationCode = label.ProcessingLocationCode,
                                 LabelId = label.LabelId,
                                 Vin = label.VIN,
                                 Vin_Last6 = label.VIN.Substring((label.VIN.Length - 6), 6),
                                 Unit = label.Unit,
                                 LabelStatusTypeId = label.LabelStatusTypeId,
                                 LabelStatus = labelStatuses?.FirstOrDefault(x => x.LabelStatusTypeId == label.LabelStatusTypeId)?.DisplayName,
                                 BatchNumber = label.BatchNumber,
                                 Make = label.Make,
                                 Model = label.Model,
                                 Year = label.Year,
                                 Color = label.Color,
                                 Notes = label.Notes,
                                 UserName = label.CreatedUser,
                                 CreatedDate = label.CreatedDate,
                                 ModifiedDate = label.ModifiedDate,
                                 PrintCount = label.PrintCount,
                                 DeliveryCode = label.DeliveryCode,
                                 ShipTo = label.ShipTo,
                                 OwningAreaDeliveryCode = label.OwningAreaDeliveryCode,
                                 PrintStatus = label.IsPrinted ? "Yes" : "No"
                             };

                labelDataResult = labels.ToList();

                return labelDataResult;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(GetLabelsAsync)} error message - { ex.Message }");
                throw ex;
            }
        }


        /// <summary>
        /// Get Label data based on Label IDs in given Print Label Request
        /// </summary>
        /// <param name="printLabelRequestId"></param>
        /// <returns></returns>
        public List<LabelViewModel> GetLabelsPrintData(int printLabelRequestId)
        {
            var labelDataResult = new List<LabelViewModel>();
            try
            {
                _logger.LogInformation($"Method {nameof(GetLabelsAsync)} : Retrieving Label Datas");

                var printLabelRequest = _unitOfWorkService.Context.PrintLabelRequests.FirstOrDefault(pr => pr.PrintLabelRequestId == printLabelRequestId);
                var printLabelMessageRequest = JsonConvert.DeserializeObject<DTO.PrintLabelMessageRequest>(printLabelRequest.Request);

                var labelData = printLabelMessageRequest.LabelIds.Select(x => _unitOfWorkService.Context.Labels.FirstOrDefault(r => r.LabelId == x)).ToList();

                var labelStatuses = _unitOfWorkService.Context.LabelStatusTypes.ToList();

                var labels = from label in labelData
                             select new LabelViewModel
                             {
                                 ClientCode = label.ClientCode,
                                 ProcessingLocationCode = label.ProcessingLocationCode,
                                 LabelId = label.LabelId,
                                 Vin = label.VIN,
                                 Vin_Last6 = label.VIN.Substring((label.VIN.Length - 6), 6),
                                 Unit = label.Unit,
                                 LabelStatusTypeId = label.LabelStatusTypeId,
                                 LabelStatus = labelStatuses?.FirstOrDefault(x => x.LabelStatusTypeId == label.LabelStatusTypeId)?.DisplayName,
                                 BatchNumber = label.BatchNumber,
                                 Make = label.Make,
                                 Model = label.Model,
                                 Year = label.Year,
                                 Color = label.Color,
                                 Notes = label.Notes,
                                 UserName = label.CreatedUser,
                                 CreatedDate = label.CreatedDate,
                                 ModifiedDate = label.ModifiedDate,
                                 PrintCount = label.PrintCount,
                                 DeliveryCode = label.DeliveryCode,
                                 ShipTo = label.ShipTo,
                                 OwningAreaDeliveryCode = label.OwningAreaDeliveryCode,
                                 PrintStatus = label.IsPrinted ? "Yes" : "No"
                             };

                labelDataResult = labels.ToList();

                return labelDataResult;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(GetLabelsAsync)} error message - { ex.Message }");
                throw ex;
            }
        }

        /// <summary>
        /// Service method to get labels billing for the invoice
        /// </summary>
        /// <param name="labelIds">input criteria</param>
        /// <returns>returns model with labels billing data</returns>
        public async Task<List<DTO.LabelBilling>> GetLabelBillingDataAsync(List<int> labelIds)
        {
            try
            {
                _logger.LogInformation($"Method {nameof(GetLabelsAsync)} : Retrieving Label Datas");
                var labelBillingData = await _unitOfWorkService.GetRepositoryAsync<LabelBilling>().GetListAsync(a => labelIds.Contains(a.LabelId) && (a.InvoiceId == null || a.InvoiceId == 0) && !a.Void);
                var labelBillingDto = labelBillingData.Any() ? _mapper.Map<List<DTO.LabelBilling>>(labelBillingData) : new List<DTO.LabelBilling>();
                return labelBillingDto;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(GetLabelBillingDataAsync)} error message - { ex.Message }");
                throw ex;
            }
        }

        /// <summary>
        /// Service method to get labels for the invoice
        /// </summary>
        /// <param name="labelIds">input criteria</param>
        /// <returns>returns model with labels data</returns>
        public async Task<List<DTO.Label>> GetLabelDataAsync(List<int> labelIds)
        {
            try
            {
                _logger.LogInformation($"Method {nameof(GetLabelsAsync)} : Retrieving Label Datas");
                var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(a => labelIds.Contains(a.LabelId));
                var labels = from label in labelData
                             select new DTO.Label
                             {
                                 LabelId = label.LabelId,
                                 BatchNumber = label.BatchNumber,
                                 StateProvinceCode = label.StateProvinceCode,
                                 ProcessingLocationCode = label.ProcessingLocationCode,
                                 VIN = label.VIN
                             };

                return labels.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(GetLabelBillingDataAsync)} error message - { ex.Message }");
                throw ex;
            }
        }

        /// <summary>
        /// Service method to update label billings
        /// </summary>
        /// <param name="labelBillings">input criteria</param>
        /// <param name="invoiceId">input criteria</param>
        /// <returns>returns status</returns>
        public async Task<bool> UpdateLabelBillingAsync(List<int> labelBillingIds, int invoiceId)
        {
            try
            {
                _logger.LogInformation($"Method {nameof(UpdateLabelBillingAsync)} : Updates Label Billing Datas");
                var labelBillingData = await _unitOfWorkService.GetRepositoryAsync<LabelBilling>().GetListAsync(a => labelBillingIds.Contains(a.LabelBillingId));
                if (labelBillingData != null && labelBillingData.Any())
                {
                    labelBillingData.ForEach(x => x.InvoiceId = invoiceId);
                    _unitOfWorkService.Context.LabelBillings.UpdateRange(labelBillingData);
                    _unitOfWorkService.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(UpdateLabelBillingAsync)} error message - { ex.Message }");
                throw ex;
            }
        }

        /// <summary>
        /// Service method to update label 
        /// </summary>
        /// <param name="labelIds">input criteria</param>
        /// <returns>returns status</returns>
        public async Task<bool> UpdateLabelStatusAsync(List<int> labelIds)
        {
            try
            {
                _logger.LogInformation($"Method {nameof(UpdateLabelStatusAsync)} : Updates Label Datas");
                var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(a => labelIds.Contains(a.LabelId));
                if (labelData != null && labelData.Any())
                {
                    labelData.ForEach(x => x.LabelStatusTypeId = (int)LabelStatusTypes.Closed);
                    _unitOfWorkService.Context.Labels.UpdateRange(labelData);
                    _unitOfWorkService.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(UpdateLabelStatusAsync)} error message - { ex.Message }");
                throw ex;
            }
        }

        /// <summary>
        /// Service method to update invoice
        /// </summary>
        /// <param name="labels">input criteria</param>
        /// <param name="user">input criteria</param>
        /// <returns>returns status</returns>
        public async Task<DTO.ApiResponseDto> BulkInvoiceProcessAsync(List<DTO.Label> labels, string clientCode, string user)
        {
            var response = new DTO.ApiResponseDto();
            try
            {
                _logger.LogInformation($"Method {nameof(BulkInvoiceProcessAsync)} : performing invoice process");
                var labelEntities = _mapper.Map<List<Label>>(labels);
                response = await PerformBulkInvoiceAsync(clientCode, user, labelEntities);
                _logger.LogInformation($"Method {nameof(BulkInvoiceProcessAsync)} : after performing invoice process");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(BulkInvoiceProcessAsync)} error message - { ex.Message }");
                throw ex;
            }
        }

        #region BulkProcess

        /// <summary>
        /// Gets the Bulk Process counts for each specified Job
        /// </summary>
        /// <param name="client"></param>
        /// <param name="processingLocationCode"></param>
        /// <returns></returns>
        public async Task<BulkProcessViewModel> GetBulkProcessRecordCountTaskAsync(string client, string processingLocationCode)
        {
            try
            {
                var pendingNonActiveUnitLabels = await GetPendingNonActiveLabelsForBulkProcessAsync(client, processingLocationCode, (int)Labeltypes.Unit);
                var pendingNonActiveBagLabels = await GetPendingNonActiveLabelsForBulkProcessAsync(client, processingLocationCode, (int)Labeltypes.Bag);
                var pendingInvoicePendingLabels = await GetInvoicePendingLabelsForBulkProcessAsync(client);
                var closeActivePrintedLabelsForBulkProcessAsync = await CloseActivePrintedLabelsForBulkProcessAsync(client, processingLocationCode);

                var model = new BulkProcessViewModel
                {
                    PendingNonActiveUnitLabelCount = pendingNonActiveUnitLabels.Count,
                    PendingNonActiveBagLabelCount = pendingNonActiveBagLabels.Count,
                    PendingInvoiceLabelCount = pendingInvoicePendingLabels.Count,
                    SetPrintedAndActiveToClosedCount = closeActivePrintedLabelsForBulkProcessAsync.Count
                };

                return model;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetBulkProcessRecordCountTaskAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets list of Labels for a specified type that are not in void status
        /// </summary>
        /// <param name="clientCode"></param>
        /// <param name="processingLocationCode"></param>
        /// <param name="labelTypeId"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        public async Task<IPaginate<Label>> GetPendingNonActiveLabelsForBulkProcessAsync(string clientCode, string processingLocationCode, int labelTypeId, int batchSize = 20)
        {
            try
            {
                var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>()
                                                        .GetListAsync(
                                                            d => d.ClientCode == clientCode
                                                            && d.ProcessingLocationCode == processingLocationCode
                                                            && d.LabelStatusTypeId == (int)LabelStatusTypes.Pending
                                                            && d.LabelTypeId == labelTypeId,
                                                            size: batchSize);

                return labelData;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetPendingNonActiveLabelsForBulkProcessAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets list of Labels for a specified type that are currently in Pending status
        /// </summary>
        /// <param name="clientCode"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        public async Task<IPaginate<LabelBilling>> GetInvoicePendingLabelsForBulkProcessAsync(string clientCode, int batchSize = 20)
        {
            try
            {
                var labelBilling = await (from x in _unitOfWorkService.Context.Labels.Where(p => p.ClientCode.Equals(clientCode) && p.LabelStatusTypeId != (int)LabelStatusTypes.Void && p.PrintCount != 0) 
                                    join y in _unitOfWorkService.Context.LabelBillings.Where(pb => pb.InvoiceId == null && !pb.Void) on x.LabelId equals y.LabelId
                                    select y).ToListAsync();

                var labelBillingData = labelBilling.ToPaginate(0, batchSize);

                return labelBillingData;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetInvoicePendingLabelsForBulkProcessAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Get list of Active Labels by Label VINs
        /// </summary>
        /// <param name="labelIds"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        public async Task<IPaginate<Label>> GetActiveLabelsByVinsAsync(string clientCode, string processingLocationCode, List<string> labelVins, int batchSize = 20)
        {
            try
            {
                var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>()
                                                        .GetListAsync(
                                                            d => d.LabelStatusTypeId == (int)LabelStatusTypes.Active
                                                            && labelVins.Contains(d.VIN),
                                                            size: batchSize);

                return labelData;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetPendingNonActiveLabelsForBulkProcessAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        public async Task<IPaginate<Label>> CloseActivePrintedLabelsForBulkProcessAsync(string clientCode, string processingLocationCode, int batchSize = 20)
        {
            try
            {
                var labelToClose = await _unitOfWorkService.GetRepositoryAsync<Label>()
                                                        .GetListAsync(
                                                            d => d.ClientCode == clientCode
                                                            && d.ProcessingLocationCode == processingLocationCode
                                                            && d.LabelStatusTypeId == (int)LabelStatusTypes.Active
                                                            && d.IsPrinted == true
                                                            && d.PrintCount > 0,
                                                            size: batchSize);

                return labelToClose;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetPendingNonActiveLabelsForBulkProcessAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Updates existing log record counts. If remainingCount == 0, then updates to Complete status
        /// </summary>
        /// <param name="log">Existing Log to be updated</param>
        /// <param name="totalProcessedCount">Accumulative count of records processed</param>
        /// <param name="remainingCount">Count of records remaining</param>
        /// <param name="fileName"></param>
        public async Task<Log> UpdateLogStatusAsync(Log log, int totalProcessedCount, int remainingCount, string fileName = "")
        {
            log.SuccessfulCount = totalProcessedCount;

            if (!fileName.IsNullOrEmpty())
            {
                log.Filename = fileName;
            }
            if (remainingCount == 0)
            {
                log.Status = JobLogStatus.Completed.GetDescription();
                log.ProcessEndDate = DateTime.Now;
            }

            _logger.LogInformation($"Method: {nameof(UpdateLogStatusAsync)} - Updated {log.Status} log - {log.ProcessName} action - " +
                                   $"{totalProcessedCount} processed, {remainingCount} remaining.");

            _unitOfWorkService.GetRepositoryAsync<Log>().UpdateAsync(log);
            _unitOfWorkService.SaveChanges();
            await Task.Yield();
            return log;
        }


        /// <summary>
        /// Updates Log to In Progress once records have begun processing
        /// </summary>
        /// <param name="log">Existing Log to be updated</param>
        /// <param name="remainingCount">Total count of records to be processed</param>
        public async Task CreateInProgressLogAsync(Log log, int remainingCount)
        {
            log.Status = JobLogStatus.InProgress.GetDescription();

            _unitOfWorkService.GetRepositoryAsync<Log>().UpdateAsync(log);
            _unitOfWorkService.SaveChanges();

            await Task.Yield();

            _logger.LogInformation($"Method: {nameof(CreateInProgressLogAsync)} - Created {log.Status} log created for {log.ProcessName} action - " +
                                   $"{remainingCount} to process.");
        }

        /// <summary>
        /// Updates an existing Log row to Failed status
        /// </summary>
        /// <param name="log">Existing Log records to be updated</param>
        public async Task<Log> CreateLogFailedAsync(Log log)
        {
            log.Status = JobLogStatus.Failed.GetDescription();
            log.ErrorCount = log.TotalCount - log.SuccessfulCount;
            log.ProcessEndDate = DateTime.Now;

            _logger.LogInformation($"Method: {nameof(CreateLogFailedAsync)} - Created {log.Status} log for {log.ProcessName} action.");

            _unitOfWorkService.GetRepositoryAsync<Log>().UpdateAsync(log);
            _unitOfWorkService.SaveChanges();

            await Task.Yield();
            return log;
        }

        /// <summary>
        /// Create individual LogDetails for Failed labels
        /// </summary>
        /// <param name="log">LogId associated with plate update attempt</param>
        /// <param name="labelList">labels associated with label update attempt</param>
        /// <param name="errorMessage">Error message to attach to Failed records</param>
        public async Task CreateLogDetailsErrorsAsync(Log log, string errorMessage, IPaginate<Label> labelList = null, IPaginate<LabelBilling> labelBillingList = null)
        {
            var currentLogDate = DateTime.Now;

            if (labelList != null)
            {
                var labels = labelList.Items.ToList();

                var logDetails = labels.Select(label => new LogDetail()
                {
                    LogId = log.LogId,
                    ErrorRecord = Convert.ToString(label.LabelId),
                    ErrorType = log.ProcessName,
                    ErrorMessage = errorMessage,
                    CreatedUser = log.CreatedUser,
                    CreatedDate = currentLogDate,
                    ModifiedUser = log.CreatedUser,
                    ModifiedDate = currentLogDate,
                    Active = true
                }).ToList();
                await _unitOfWorkService.GetRepositoryAsync<LogDetail>().AddAsync(logDetails.ToArray());
                _unitOfWorkService.SaveChanges();
                _logger.LogInformation($"Method: {nameof(CreateLogDetailsErrorsAsync)} - Created {log.ProcessName} LogDetails for {logDetails.Count} records.");
            }
            if (labelBillingList != null)
            {
                var labelBillings = labelBillingList.Items.ToList();

                var logDetails = labelBillings.Select(labelBilling => new LogDetail()
                {
                    LogId = log.LogId,
                    ErrorRecord = "LabelBillingId-"+labelBilling.LabelBillingId+"; LabelId-"+labelBilling.LabelId,
                    ErrorType = log.ProcessName,
                    ErrorMessage = errorMessage,
                    CreatedUser = log.CreatedUser,
                    CreatedDate = currentLogDate,
                    ModifiedUser = log.CreatedUser,
                    ModifiedDate = currentLogDate,
                    Active = true
                }).ToList();
                await _unitOfWorkService.GetRepositoryAsync<LogDetail>().AddAsync(logDetails.ToArray());
                _unitOfWorkService.SaveChanges();
                _logger.LogInformation($"Method: {nameof(CreateLogDetailsErrorsAsync)} - Created {log.ProcessName} LogDetails for {logDetails.Count} records.");
            }

            else
            {
                var logDetails = new LogDetail()
                {
                    LogId = log.LogId,
                    ErrorRecord = string.Empty,
                    ErrorType = log.ProcessName,
                    ErrorMessage = errorMessage,
                    CreatedUser = log.CreatedUser,
                    CreatedDate = currentLogDate,
                    ModifiedUser = log.CreatedUser,
                    ModifiedDate = currentLogDate,
                    Active = true
                };
                await _unitOfWorkService.GetRepositoryAsync<LogDetail>().AddAsync(logDetails);
                _unitOfWorkService.SaveChanges();
                _logger.LogInformation($"Method: {nameof(CreateLogDetailsErrorsAsync)} - Created {log.ProcessName} LogDetails for {(labelList!= null ? labelList.Count : labelBillingList.Count)} records.");
            }

        }

        /// <summary>
        /// Perform invoice for labels
        /// </summary>
        /// <param name="labelsToProcess">label list</param>
        /// <param name="clientCode">client code</param>
        /// <param name="user">user</param>
        public async Task<DTO.ApiResponseDto> PerformBulkInvoiceAsync(string clientCode, string user, IList<Label> labelsToProcess = null, IList<LabelBilling> labelBillingsToProcess = null)
        {
            if ((labelsToProcess == null || labelsToProcess.Count == 0) && (labelBillingsToProcess == null || labelBillingsToProcess.Count == 0))
                throw new ArgumentNullException(nameof(labelsToProcess));
            var serviceResponse = new DTO.ApiResponseDto();
            try
            {
                var response = await _invoiceService.CreateInvoiceAsync(clientCode, user);
                var result = response != null ? response.Content.ReadAsAsync<ServiceResponse<DTO.Invoice>>().Result : new ServiceResponse<DTO.Invoice>();
                if (response != null && response.IsSuccessStatusCode && result.ResponseCode == HttpStatusCode.OK && result.Data != null)
                {
                    List<DTO.LabelBilling> labelBillings = null;
                    if (labelBillingsToProcess == null)
                    {
                        labelBillings = await GetLabelBillingDataAsync(labelsToProcess.Select(x => x.LabelId).ToList());
                    }
                    else
                    {
                        labelBillings = labelBillingsToProcess.Any() ? _mapper.Map<List<DTO.LabelBilling>>(labelBillingsToProcess) : new List<DTO.LabelBilling>();
                        labelsToProcess = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(a => labelBillings.Select(x=>x.LabelId).Contains(a.LabelId));
                    }
                    var invoiceBillings = await CreateInvoiceBillingModelAsync(labelsToProcess, user, labelBillings);
                    var billingResponse = await _invoiceService.CreateInvoiceBillingsAsync(invoiceBillings, result.Data.InvoiceId);
                    var billingResult = billingResponse != null ? billingResponse.Content.ReadAsAsync<ServiceResponse<List<int>>>().Result : new ServiceResponse<List<int>>();

                    if (billingResponse != null && billingResponse.IsSuccessStatusCode && billingResult.ResponseCode == HttpStatusCode.OK)
                    {
                        var billingUpdateResult = await UpdateLabelBillingAsync(invoiceBillings.Select(x => x.InvoiceItemId).ToList(), result.Data.InvoiceId);
                        if (billingUpdateResult)
                        {
                            await UpdateLabelStatusAsync(labelsToProcess.Select(x => x.LabelId).ToList());
                        }
                        serviceResponse.ResponseCode = billingUpdateResult ? billingResult.ResponseCode : HttpStatusCode.NoContent;
                        serviceResponse.ErrorMessage = billingUpdateResult ? "Invoice processed successfully" : "Something went wrong while updating label billing";
                    }
                    else
                    {
                        serviceResponse.ResponseCode = billingResult.ResponseCode;
                        serviceResponse.ErrorMessage = billingResult.ErrorMessage;
                        _logger.LogError($"Method: {nameof(PerformBulkInvoiceAsync)} - A error occurred while calling the create invoice billing api in invoice service.\r\n " + serviceResponse.ErrorMessage);
                    }
                }
                else
                {

                    serviceResponse.ResponseCode = result.ResponseCode;
                    serviceResponse.ErrorMessage = result.ErrorMessage;
                    _logger.LogError($"Method: {nameof(PerformBulkInvoiceAsync)} - A error occurred while calling the create invoice api in invoice service.\r\n " + serviceResponse.ErrorMessage);
                }
                return serviceResponse;
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(PerformBulkInvoiceAsync)} - A critical error occurred during InvoicePendingPlateAction.\r\n " +
                                 $"Message: {e.Message} ");
                throw e;
            }
        }

        private async Task<List<DTO.InvoiceBilling>> CreateInvoiceBillingModelAsync(IList<Label> label, string user, List<DTO.LabelBilling> labelBilling)
        {
            var invoiceBillings = new List<DTO.InvoiceBilling>();

            var billingLookups = await GetBillingLookupsAsync();

            var labelBillingItemType = billingLookups.BillingItemTypes.SingleOrDefault(bt => bt.DisplayName == BillingItemTypes.Label.GetDescription());

            if (label != null && labelBilling.Any())
            {
                invoiceBillings = (from x in labelBilling
                                   select new DTO.InvoiceBilling
                                   {
                                       InvoiceItemId = x.LabelBillingId,
                                       InvoiceItemNumber = label.Where(y => y.LabelId == x.LabelId).Select(x => x.VIN).FirstOrDefault(),
                                       InvoiceItemTypeId = labelBillingItemType.BillingItemTypeId,
                                       BillingFeeId = x.BillingFeeId,
                                       BillingAmount = x.BillingAmount,
                                       ProcessingLocationCode = label.Where(y => y.LabelId == x.LabelId).Select(x => x.ProcessingLocationCode).FirstOrDefault(),
                                       ClientLocationCode = x.ProcessingLocationCode,
                                       StateProvinceCode = label.Where(y => y.LabelId == x.LabelId).Select(x => x.StateProvinceCode).FirstOrDefault(),
                                       IsDebit = x.IsDebit,
                                       CreatedDate = DateTime.Now,
                                       CreatedUser = user
                                   }).ToList();
            }
            return invoiceBillings;
        }

        #endregion

        #region ImportLabels

        /// <summary>
        /// Submit the create labels requests
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<LabelImportViewModel> SubmitImportLabelRequestAsync(LabelImportViewModel model)
        {
            var importLabelRequest = new List<ImportLabelRequest>();
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var currentLogDate = DateTime.Now;

                    var log = new DTO.Log
                    {
                        ProcessName = ProcessNames.ImportLabels,
                        TotalCount = model.ImportLabelData.Count,
                        SuccessfulCount = 0,
                        ErrorCount = 0,
                        WarningCount = 0,
                        Status = JobLogStatus.Ready.ToString(),
                        CreatedUser = model.CreatedUser,
                        CreatedDate = currentLogDate,
                        ModifiedUser = model.CreatedUser,
                        ModifiedDate = currentLogDate,
                        ClientCode = model.ClientCode,
                        ProcessingLocationCode = model.ProcessingOffice,
                        ProcessType = ProcessTypes.Import.GetDescription()
                    };

                    //Create job log entry
                    var logEntity = await CreateJobLogTaskAsync(log);
                    model.JobLog = logEntity;
                    //Gets the max import group id 
                    var importLabelGroup = await _unitOfWorkService.Context.ImportLabelRequests.OrderByDescending(x => x.RequestNumber).FirstOrDefaultAsync();
                    var importLabelRequestNumber = (importLabelGroup != null) ? importLabelGroup.RequestNumber + 1 : 1; //setting the import group id to 1 if importLabelGroup is null
                    model.LogId = logEntity.LogId;
                    model.RequestNumber = importLabelRequestNumber;

                    foreach (var row in model.ImportLabelData)
                    {
                        importLabelRequest.Add(new ImportLabelRequest()
                        {
                            RequestNumber = importLabelRequestNumber,
                            LogId = model.LogId,
                            LabelTypeId = model.LabelTypeId,
                            ClientCode = model.ClientCode,
                            ProcessingOffice = model.ProcessingOffice,
                            LabelImportId = model.LabelImportId,
                            ImportConfigurationDescription = model.ImportConfigurationDescription,
                            ImportLabelRecord = JsonConvert.SerializeObject(row),
                            GenerateBagFlag = model.GenerateBagLabels,
                            Active = true,
                            CreatedUser = model.CreatedUser,
                            CreatedDate = model.CreatedDate,
                            ModifiedUser = model.ModifiedUser,
                            ModifiedDate = model.ModifiedDate
                        });
                    }
                    await _unitOfWorkService.Context.AddRangeAsync(importLabelRequest);
                    _unitOfWorkService.SaveChanges();
                    scope.Complete();
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(SubmitImportLabelRequestAsync)}; Error: {e.Message}");
                throw e;
            }
            return model;
        }

        /// <summary>
        /// Gets the import layout details
        /// </summary>
        /// <param name="logId"></param>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        public async Task<List<DTO.ImportLabelRequest>> GetImportLabelDetailsAsync(int logId, string clientCode)
        {
            var importLabelRequest = new List<DTO.ImportLabelRequest>();
            try
            {
                var entityLabelRequest = await _unitOfWorkService.GetRepositoryAsync<ImportLabelRequest>().GetListAsync(x => x.LogId == logId && x.ClientCode.Equals(clientCode));
                importLabelRequest = _mapper.Map<List<DTO.ImportLabelRequest>>(entityLabelRequest);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetImportLabelDetailsAsync)}; Error: {ex.Message}");
                throw ex;
            }
            return importLabelRequest;
        }

        /// <summary>
        /// Validates the input import label request for duplicates by VIN and Label status
        /// </summary>
        /// <param name="importLabels"></param>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        public async Task<DTO.LabelImportValidationResponse> ValidateImportLabelRequestAsync(List<DTO.ImportLabelRequest> importLabels, string clientCode)
        {
            var response = new DTO.LabelImportValidationResponse() { IsValid = true };
            var vins = new List<string>();
            var validationKey = Labels.Vin.GetDescription();
            var generateBagLabel = importLabels.FirstOrDefault().GenerateBagFlag;
            var requestLabelTypeId = importLabels.FirstOrDefault().LabelTypeId;
            var labelTypeId = new List<int>();

            try
            {
                if (requestLabelTypeId == (int)Labeltypes.Unit && generateBagLabel)
                {
                    labelTypeId.AddRange(new List<int>() { (int)Labeltypes.Unit, (int)Labeltypes.Bag });
                }
                else
                {
                    labelTypeId.Add(requestLabelTypeId);
                }

                foreach (var item in importLabels)
                {
                    var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(item.ImportLabelRecord);
                    if (values.ContainsKey(validationKey))
                    {
                        vins.Add(values.GetValueOrDefault(validationKey));
                    }
                }

                var labels = await _unitOfWorkService.Context.Labels.Where(x => x.ClientCode.Equals(clientCode) && x.LabelStatusTypeId == (int)LabelStatusTypes.Active
                && labelTypeId.Contains(x.LabelTypeId) && vins.Contains(x.VIN)).ToListAsync();

                if (labels != null && labels.Any())
                {
                    response.IsValid = false;
                    response.ActualRecord = string.Join(",", labels.Select(x => x.VIN).Distinct().ToList());
                    response.ErrorMessage = $"Duplicate labels found with Active status for {Enum.GetName(typeof(Labeltypes), requestLabelTypeId)} Labels.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(ValidateImportLabelRequestAsync)}; Error: {ex.Message}");
                throw ex;
            }
            return response;
        }

        /// <summary>
        /// Add labels to entity
        /// </summary>
        /// <param name="labels"></param>
        /// <returns></returns>
        public async Task AddLabelsAsync(List<Label> entityLabels)
        {
            try
            {
                //Saves the label object to entity
                await _unitOfWorkService.Context.AddRangeAsync(entityLabels);
                await _unitOfWorkService.Context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(AddLabelsAsync)}; Error: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// Deletes the import label request details
        /// </summary>
        /// <param name="logId"></param>
        /// <returns></returns>
        public async Task DeleteImportLabelRequestAsync(int logId)
        {
            try
            {
                var importRequest = await _unitOfWorkService.Context.ImportLabelRequests.Where(x => x.LogId == logId).ToListAsync();
                _unitOfWorkService.Context.ImportLabelRequests.RemoveRange(importRequest);
                await _unitOfWorkService.Context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(DeleteImportLabelRequestAsync)}; Error: {ex.Message}");
                throw ex;
            }
        }

        #endregion

        #region Notifications

        /// <summary>
        /// Gets the five most recent notifications for the user by username
        /// </summary>
        /// <param name="userName">UserName</param>
        /// <returns>List of notifications</returns>
        public async Task<List<NotificationViewModel>> GetNotificationsByUserNameAsync(string userName)
        {
            _logger.LogInformation($"Getting last 5 notifications for user: , {nameof(GetNotificationsByUserNameAsync)}");

            var notifications = new List<NotificationViewModel>();

            try
            {
                var result = await _unitOfWorkService.GetRepositoryAsync<Notification>().GetListAsync(x => x.UserName.ToUpper().Equals(userName.ToUpper()),
                                                                                                      x => x.OrderByDescending(n => n.NotificationId),
                                                                                                      size: 5);

                var response = new List<NotificationViewModel>();

                if (result != null && result.Items.Count > 0)
                {
                    foreach (var item in result.Items)
                    {
                        var notificationViewModel = new NotificationViewModel
                        {
                            LogId = item.LogId,
                            NotificationId = item.NotificationId,
                            ErrorCount = item.ErrorCount,
                            TotalCount = item.TotalCount,
                            SuccessCount = item.SuccessCount,
                            WarningCount = item.WarningCount,
                            UserName = item.CreatedUser,
                            NotificationType = item.NotificationType,
                            CreatedDate = item.CreatedDate,
                            CreatedUser = item.CreatedUser,
                            ModifiedDate = item.ModifiedDate,
                            ModifiedUser = item.ModifiedUser,
                            IsRead = item.IsRead,
                            Message = item.Message,
                            LastRefreshDate = DateTime.Now.ToString("g")

                        };

                        response.Add(notificationViewModel);

                    }

                }

                return response;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetNotificationsByUserNameAsync)}; Error: {e.Message}");
                return null;
            }
        }

        /// <summary>
        /// Maps the passed log object to NotificationViewModel
        /// </summary>
        /// <param name="log">Log object to convert</param>
        /// <returns>NotificationViewModel Object</returns>
        private NotificationViewModel MapLogToNotificationViewModel(Log log)
        {
            _logger.LogInformation($"MapLogToNotificationViewModel: , {nameof(MapLogToNotificationViewModel)}");

            try
            {
                var notification = new NotificationViewModel()
                {
                    LogId = log.LogId,
                    ErrorCount = log.ErrorCount,
                    TotalCount = log.TotalCount,
                    SuccessCount = log.SuccessfulCount,
                    WarningCount = log.WarningCount,
                    UserName = log.CreatedUser,
                    NotificationType = log.ProcessName,
                    CreatedDate = log.ProcessEndDate ?? DateTime.Now,
                    CreatedUser = log.CreatedUser,
                    ModifiedUser = log.CreatedUser,
                    ModifiedDate = log.ProcessEndDate ?? DateTime.Now,
                    Message = log.Filename,
                    IsRead = false,
                    LogStatus = log.Status
                };

                return notification;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(MapLogToNotificationViewModel)}; Error: {e.Message}");
                return null;
            }
        }

        /// <summary>
        /// Maps the passed NotificationViewModel list object to Notification entity list
        /// </summary>
        /// <param name="notificationsToSave">NotificationViewModel list to translate</param>
        /// <returns>Translated Notification entity list</returns>
        private Notification MapNotificationViewModelToEntity(NotificationViewModel notificationsToSave)
        {
            _logger.LogInformation($"MapNotificationViewModelToEntity: , {nameof(MapNotificationViewModelToEntity)}");

            var notifications = new Notification();

            try
            {

                notifications.LogId = notificationsToSave.LogId.GetValueOrDefault();
                notifications.ErrorCount = notificationsToSave.ErrorCount;
                notifications.TotalCount = notificationsToSave.TotalCount;
                notifications.SuccessCount = notificationsToSave.SuccessCount;
                notifications.WarningCount = notificationsToSave.WarningCount;
                notifications.UserName = notificationsToSave.UserName;
                notifications.NotificationType = notificationsToSave.NotificationType;
                notifications.CreatedDate = notificationsToSave.CreatedDate;
                notifications.CreatedUser = notificationsToSave.CreatedUser;
                notifications.ModifiedDate = notificationsToSave.ModifiedDate;
                notifications.ModifiedUser = notificationsToSave.ModifiedUser;
                notifications.IsRead = notificationsToSave.IsRead;
                notifications.Message = notificationsToSave.Message;
                        
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(MapNotificationViewModelToEntity)}; Error: {e.Message}");
                throw;
            }
            return notifications;
        }

        /// <summary>
        /// Create and send notifications
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        public async Task<NotificationViewModel> CreateNotificationsAsync(Log log)
        {
            _logger.LogInformation($"CreateNotificationsAsync , {nameof(CreateNotificationsAsync)}");

            var notificationsToCreate = MapLogToNotificationViewModel(log);

            if (notificationsToCreate != null)
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    try
                    {
                        var notificationEntitiesToSave = MapNotificationViewModelToEntity(notificationsToCreate);
                        _unitOfWorkService.GetRepositoryAsync<Notification>().UpdateAsync(notificationEntitiesToSave);
                        _unitOfWorkService.SaveChanges();

                        scope.Complete();
                        await Task.Yield();
                    }
                    catch (Exception e)
                    {
                        _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(CreateNotificationsAsync)}; Error: {e.Message}");
                        throw e;
                    }
                    finally
                    {
                        scope.Dispose();
                    }
                }
            }

            return notificationsToCreate;
        }
        #endregion

        #region Export Labels

        /// <summary>
        /// Create service bus request for End of day process
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<DTO.Log> SubmitExportAllRequestAsync(ExportLabelViewModel model)
        {
            Log result = new Log();
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var currentLogDate = DateTime.Now;
                    // create log
                    var log = new Log
                    {
                        ProcessName = LabelProcessNames.ExportLabels.GetDescription(),
                        TotalCount = model.TotalCount,
                        SuccessfulCount = 0,
                        ErrorCount = 0,
                        WarningCount = 0,
                        Status = JobLogStatus.Ready.ToString(),
                        CreatedUser = model.UserId,
                        CreatedDate = currentLogDate,
                        ModifiedUser = model.UserId,
                        ModifiedDate = currentLogDate,
                        ProcessStartDate = currentLogDate,
                        ClientCode = model.ClientCode,
                        ProcessType = ProcessTypes.Export.ToString(),
                    };



                    // await _unitOfWorkService.GetRepositoryAsync<Log>().AddAsync(_mapper.Map<Log>(log));
                    await _unitOfWorkService.Context.AddAsync(_mapper.Map<Log>(log));
                    // Save changes to DB
                    _unitOfWorkService.SaveChanges();
                    result = log;
                    // Create message and send it to Azure Service Bus.
                    //var request = _mapper.Map<DTO.ExportSearchCriteria>(model);
                    scope.Complete();
                }
                return _mapper.Map<DTO.Log>(result);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(LabelManagementService)} - method {nameof(SubmitExportAllRequestAsync)}: {ex.Message}");
                throw ex;
            }
        }



        /// <summary>
        /// Gets list of Labels for a specified type that are currently in Pending status
        /// </summary>
        /// <param name="clientCode"></param>
        /// <param name="processingLocationCode"></param>
        /// <param name="labelTypeId"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        public async Task<SearchLabelViewModel> GetLabelsForExportAsync(SearchLabelViewModel searchCriteria)
        {
            IPaginate<Label> labelData;
            try
            {
                _logger.LogInformation($"Method {nameof(GetLabelsAsync)} : Retrieving Label Datas");
                labelData = await _unitOfWorkService.GetRepositoryAsync<Label>()
                .GetListAsync(
                a => a.ClientCode.Equals(searchCriteria.ClientCode)
                && a.LabelTypeId == searchCriteria.LabelTypeId
                && a.ProcessingLocationCode.Equals(searchCriteria.ProcessingLocationCode),
                orderBy: o => o.OrderBy(a => a.LabelId),
                index: searchCriteria.PageNumber,
                size: searchCriteria.DefaultRowsPerPage
                );
                var labelStatuses = _unitOfWorkService.Context.LabelStatusTypes.ToList();
                var labels = from label in labelData.Items
                             select new LabelViewModel
                             {
                                 LabelId = label.LabelId,
                                 Vin = label.VIN,
                                 Vin_Last6 = label.VIN.Substring((label.VIN.Length - 6), 6),
                                 Unit = label.Unit,
                                 LabelStatusTypeId = label.LabelStatusTypeId,
                                 LabelStatus = labelStatuses?.FirstOrDefault(x => x.LabelStatusTypeId == label.LabelStatusTypeId)?.DisplayName,
                                 BatchNumber = label.BatchNumber,
                                 Make = label.Make,
                                 Model = label.Model,
                                 Year = label.Year,
                                 Color = label.Color,
                                 Notes = label.Notes,
                                 UserName = label.CreatedUser,
                                 CreatedDate = label.CreatedDate,
                                 ModifiedDate = label.ModifiedDate,
                                 PrintCount = label.PrintCount,
                                 DeliveryCode = label.DeliveryCode,
                                 ShipTo = label.ShipTo,
                                 OwningAreaDeliveryCode = label.OwningAreaDeliveryCode,
                                 PrintStatus = label.IsPrinted ? "Yes" : "No"
                             };
                searchCriteria.Results = labels.ToList();
                return searchCriteria;
            }
            catch (Exception ex)




            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetPendingNonActiveLabelsForBulkProcessAsync)}; Error: {ex.Message}");
                throw;
            }
        }




        #endregion

        #region Logs

        /// <summary>
        /// Gets list of Logs based on model properties
        /// </summary>
        /// <param name="model">Model containing Client, State, UserId, and UserAccessLevel</param>
        /// <returns>List of Log based on search criteria</returns>
        public async Task<LogSummaryViewModel> GetLogsAsync(LogSummaryViewModel model)
        {
            try
            {

                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {

                    IPaginate<Log> result;

                    if (model.IsAtLeastSupervisor)
                    {
                        result = await _unitOfWorkService.GetRepositoryAsync<Log>().GetListAsync(
                                            x => x.ClientCode.Equals(model.ClientCode) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.FileName) || x.Filename.Contains(model.LogSearchCriteria.FileName)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.LogStatus) || x.Status.Replace(" ", "").Equals(model.LogSearchCriteria.LogStatus.Replace(" ", ""))) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessType) || x.ProcessType.Equals(model.LogSearchCriteria.ProcessType)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessName) || x.ProcessName.Equals(model.LogSearchCriteria.ProcessName)) &&
                                            (model.LogSearchCriteria.ProcessStartDate == null || model.LogSearchCriteria.ProcessStartDate == DateTime.MinValue || x.ProcessStartDate >= model.LogSearchCriteria.ProcessStartDate) &&
                                            (model.LogSearchCriteria.ProcessEndDate == null || model.LogSearchCriteria.ProcessEndDate == DateTime.MinValue || x.ProcessEndDate <= model.LogSearchCriteria.ProcessEndDate || x.ProcessEndDate == null) &&
                                            ((!model.LogSearchCriteria.ShowErrors && !model.LogSearchCriteria.ShowWarnings) ||
                                            ((model.LogSearchCriteria.ShowErrors && x.ErrorCount > 0) ||
                                            (model.LogSearchCriteria.ShowWarnings && x.WarningCount > 0))),
                                            y => y.OrderByDescending(x => x.LogId),
                                            index: model.PageNumber - 1,
                                            size: model.RowsPerPage);
                    }
                    else
                    {
                        result = await _unitOfWorkService.GetRepositoryAsync<Log>().GetListAsync(
                                        x => x.ClientCode.Equals(model.ClientCode) && x.CreatedUser.Equals(model.UserId) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.FileName) || x.Filename.Contains(model.LogSearchCriteria.FileName)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.LogStatus) || x.Status.Replace(" ", "").Equals(model.LogSearchCriteria.LogStatus.Replace(" ", ""))) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessType) || x.ProcessType.Equals(model.LogSearchCriteria.ProcessType)) &&
                                            (string.IsNullOrEmpty(model.LogSearchCriteria.ProcessName) || x.ProcessName.Equals(model.LogSearchCriteria.ProcessName)) &&
                                            (model.LogSearchCriteria.ProcessStartDate == null || model.LogSearchCriteria.ProcessStartDate == DateTime.MinValue || x.ProcessStartDate >= model.LogSearchCriteria.ProcessStartDate) &&
                                            (model.LogSearchCriteria.ProcessEndDate == null || model.LogSearchCriteria.ProcessEndDate == DateTime.MinValue || x.ProcessEndDate <= model.LogSearchCriteria.ProcessEndDate || x.ProcessEndDate == null) &&
                                           ((!model.LogSearchCriteria.ShowErrors && !model.LogSearchCriteria.ShowWarnings) ||
                                            ((model.LogSearchCriteria.ShowErrors && x.ErrorCount > 0) ||
                                            (model.LogSearchCriteria.ShowWarnings && x.WarningCount > 0))),
                                        y => y.OrderByDescending(x => x.LogId),
                                        index: model.PageNumber - 1,
                                        size: model.RowsPerPage);
                    }

                    if (result != null && result.Items.Count > 0)
                    {
                        model.Results = _mapper.Map<List<Model.DTO.Log>>(result.Items.ToList());
                        model.TotalCount = result.Count;
                    }
                    else
                    {
                        // If the results is null then kendo will throw an exception (Slice) because it cannot parse a null data value
                        model.Results = new List<Model.DTO.Log>();
                    }
                }

                return model;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetLogsAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Service to get Log details based on log id
        /// </summary>
        /// <param name="model">LogDetailViewModel</param>
        /// <returns>returns model with Log and Log details information</returns>
        public async Task<DTO.Log> GetLogStatusAsync(int logid)
        {
            var result = new Log();
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    result = await _unitOfWorkService.GetRepositoryAsync<Log>().SingleAsync(a => a.LogId == logid);
                    return _mapper.Map<DTO.Log>(result);
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetLogDetailsAsync)}; Error: {e.Message}");
            }
            return _mapper.Map<DTO.Log>(result);
        }

        /// <summary>
        /// Service to get Log details based on log id
        /// </summary>
        /// <param name="model">LogDetailViewModel</param>
        /// <returns>returns model with Log and Log details information</returns>
        public async Task<LogDetailViewModel> GetLogDetailsAsync(LogDetailViewModel model)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {

                    var result = await _unitOfWorkService.GetRepositoryAsync<LogDetail>().GetListAsync(
                                    a => a.LogId == model.LogId,
                                    x => x.OrderByDescending(a => a.LogDetailsId),
                                    index: model.PageNumber - 1,
                                    size: model.RowsPerPage
                    );

                    if (result != null && result.Items != null)
                    {
                        model.Results = _mapper.Map<List<Model.DTO.LogDetail>>(result.Items.ToList());
                        model.TotalCount = result.Count;
                    }

                    if (model.LogData == null)
                    {
                        var log = await _unitOfWorkService.GetRepositoryAsync<Log>().SingleAsync(a => a.LogId == model.LogId);
                        model.LogData = _mapper.Map<Model.DTO.Log>(log);
                    }

                    if (model.Results == null)
                    {
                        // If the results is null then kendo will throw an exception (Slice) because it cannot parse a null data value
                        model.Results = new List<Model.DTO.LogDetail>();
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetLogDetailsAsync)}; Error: {e.Message}");
            }

            return model;
        }


        /// <summary>
        /// Updates the log status by ID
        /// </summary>
        /// <param name="logId"></param>
        /// <param name="logStatus"></param>
        /// <returns></returns>
        public async Task<DTO.Log> UpdateLogStatusByIdAsync(int logId, string logStatus)
        {
            DTO.Log log = null;
            try
            {
                var logEntity = _unitOfWorkService.Context.Logs.Where(x => x.LogId == logId).SingleOrDefault();
                if (logEntity == null)
                {
                    _logger.LogInformation($"Log record not found for { logId }");
                    return log;
                }
                else
                {
                    logEntity.Status = logStatus;

                    if (logStatus == JobLogStatus.Completed.GetDescription() || logStatus == JobLogStatus.Failed.GetDescription())
                    {
                        logEntity.ProcessEndDate = DateTime.Now;
                    }

                    _unitOfWorkService.Context.Logs.Update(logEntity);                   
                    await _unitOfWorkService.Context.SaveChangesAsync();

                    if (logEntity.ProcessName == ProcessNames.PrintBagLabels || logEntity.ProcessName == ProcessNames.PrintUnitLabels)
                    {
                        AbortPrintLabelRequest(logEntity.LogId);
                    }

                    log = _mapper.Map<DTO.Log>(logEntity);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error updating log record for {logId}. Error message: {ex.Message} ");
                throw ex;
            }
            return log;
        }

        private void AbortPrintLabelRequest(int logId)
        {
            try
            {
                var printLabelRequests = _unitOfWorkService.Context.PrintLabelRequests.FromSqlRaw(@"SELECT plr.* FROM [lm].[PrintLabelRequests] as plr CROSS APPLY OPENJSON(Request, '$.Action') WITH (LogId INT '$.LogId') as Logs
                        WHERE Logs.LogId = {0}", logId).ToList();

                if (printLabelRequests != null && printLabelRequests.Any())
                {
                    _unitOfWorkService.Context.PrintLabelRequests.RemoveRange(printLabelRequests.ToArray());
                    _unitOfWorkService.Context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(AbortPrintLabelRequest)}; Error: {e.Message}");
            }
        }

        /// <summary>
        /// Gets Log row based on LogId
        /// </summary>
        /// <param name="logId">LogId of desired Log row</param>
        /// <returns>Log entity</returns>
        public async Task<Log> GetLogAsync(int logId)
        {
            var log = new Log();
            try
            {
                log = await _unitOfWorkService.Context.Logs.Where(l => l.LogId == logId).FirstOrDefaultAsync();
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetLogAsync)}; Error: {e.Message}");
            }
            return log;
        }

        /// <summary>
        /// Updates the log and log details
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        public async Task<DTO.Log> UpdateLogStatusAsync(DTO.Log log, List<DTO.LogDetail> logDetails)
        {
            try
            {
                var logEntity = await _unitOfWorkService.Context.Logs.Where(x => x.LogId == log.LogId).SingleOrDefaultAsync();
                if (logEntity == null)
                {
                    _logger.LogInformation($"Log record not found for { log.LogId }");
                    return log;
                }

                logEntity.TotalCount = (log.TotalCount > 0) ? log.TotalCount : logEntity.TotalCount;
                logEntity.SuccessfulCount = (log.SuccessfulCount > 0) ? log.SuccessfulCount : logEntity.SuccessfulCount;
                logEntity.Filename = (!string.IsNullOrEmpty(log.Filename)) ? log.Filename : logEntity.Filename;
                logEntity.WarningCount = (log.WarningCount > 0) ? log.WarningCount : logEntity.WarningCount;
                logEntity.ErrorCount = (log.ErrorCount > 0) ? log.ErrorCount : logEntity.ErrorCount;
                logEntity.Status = (!string.IsNullOrEmpty(log.Status)) ? log.Status : logEntity.Status;
                logEntity.ProcessEndDate = log.ProcessEndDate;
                logEntity.ProcessName = log.ProcessName;
                if ((logEntity.ErrorCount > 0 || logEntity.WarningCount > 0) && logDetails != null && logDetails.Count > 0)
                {
                    logEntity.LogDetails = _mapper.Map<List<LogDetail>>(logDetails);
                }
                _unitOfWorkService.Context.Logs.Update(logEntity);
                await _unitOfWorkService.Context.SaveChangesAsync();
                log = _mapper.Map<DTO.Log>(logEntity);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(UpdateLogStatusAsync)}; Error: {ex.Message}");
                throw;
            }
            return log;
        }

        #endregion

        #region Update Labels
        public async Task<BulkUpdateResultViewModel> PerformBulkUpdateAsync(BulkUpdateViewModel bulkUpdateModel)
        {
            var bulkUpdateResultViewModel = new BulkUpdateResultViewModel
            {
                TotalPassed = 0,
                TotalFailed = 0,
                LogReport = string.Empty,
                FailedOrders = new List<int>()
            };

            // labels Error Report and Main Report
            var labelErrorsReport = new StringBuilder();
            var mainReport = new StringBuilder();

            try
            {
                // Perform Bulk Update
                if (bulkUpdateModel.Labels.Count <= 0)
                    throw new Exception("The total labels for bulk update cannot be zero!");

                // Error and Success results queues
                var errorLabels = new List<Label>();
                var successLabels = new List<Label>();

                mainReport.AppendLine($"BULK UPDATE REPORT LOG<br/>");
                mainReport.AppendLine("<hr/>");

                // 1. Get the labels current values
                var latestLabelsData = await _unitOfWorkService.GetRepositoryAsync<Label>()
                    .GetListAsync(
                        o => bulkUpdateModel.Labels.Contains(o.LabelId),
                        o => o.OrderBy(a => a.LabelId), size: bulkUpdateModel.Labels.Count * 2);

                // 2. Perform the validation on each label against the rules
                foreach (var labelData in latestLabelsData.Items)
                {
                    //validate the rules for status update
                    var validationMessageStatus = bulkUpdateModel.LabelsStatusTypeId != 0
                                                ? await ValidateLabelsStatusUpdateAsync(labelData, bulkUpdateModel.LabelsStatusTypeId, bulkUpdateModel.InvoiceList)
                                                : string.Empty;
                    if (string.IsNullOrEmpty(validationMessageStatus))
                    {
                        mainReport.AppendLine($"LabelId: {labelData.LabelId} <br/>");
                        if (bulkUpdateModel.LabelsStatusTypeId != 0)
                        {
                            labelData.LabelStatusTypeId = bulkUpdateModel.LabelsStatusTypeId;
                            mainReport.AppendLine($"Label Status was updated successfully to value {bulkUpdateModel.LabelsStatus}.<br/>");
                        }
                        if (!string.IsNullOrEmpty(bulkUpdateModel.Notes))
                        {
                            labelData.Notes = bulkUpdateModel.Notes;
                            mainReport.AppendLine($"Notes was updated successfully to value { bulkUpdateModel.Notes}.<br/>");
                        }
                        // Valid?
                        successLabels.Add(labelData);
                    }
                    else
                    {
                        // Invalid?
                        // Failed Validation - add to error labels queue and append to log
                        errorLabels.Add(labelData);
                        labelErrorsReport.AppendLine($"LabelId: {labelData.LabelId}<br/>");
                        if (!string.IsNullOrEmpty(validationMessageStatus))
                        {
                            labelErrorsReport.AppendLine($"Validation error message for {labelData.LabelId} is {validationMessageStatus}.<br/>");
                        }
                    }
                }
                // 3. Update the success labels
                if (successLabels.Any())
                {
                    _unitOfWorkService.GetRepositoryAsync<Label>().UpdateAsync(successLabels.ToArray());
                    _unitOfWorkService.SaveChanges();
                }
                // 4. Create final log report with totals attached of passed and failed labels
                mainReport.Append(labelErrorsReport.ToString());
                mainReport.AppendLine("<hr/>");
                mainReport.AppendLine($"Total success: {successLabels.Count}<br/>");
                mainReport.AppendLine($"Total failed: {errorLabels.Count}<br/>");
                mainReport.AppendLine($"Total Labels: {bulkUpdateModel.Labels.Count}<br/>");
                mainReport.AppendLine("<br/>");
                mainReport.AppendLine("End of report</p></br>");

                bulkUpdateResultViewModel = new BulkUpdateResultViewModel
                {
                    TotalPassed = successLabels.Count,
                    TotalFailed = errorLabels.Count,
                    LogReport = mainReport.ToString(),
                    FailedOrders = errorLabels.Select(label => label.LabelId).ToList()
                };
            }
            catch (Exception e)
            {
                _logger.LogError($"<p>Service: {nameof(LabelManagementService)}; Method: {nameof(PerformBulkUpdateAsync)}; Critical Error: {e.Message}");
                mainReport.AppendLine($"An error has occurred performing the bulk update for {bulkUpdateModel.TotalLabels} labels<br/>");
                mainReport.AppendLine("Please try submitting the bulk update again.\r\nPlease contact your local support team if you continue to receive this error<br/>");
                mainReport.AppendLine($"Detailed message is: {e.Message}</p>");
                bulkUpdateResultViewModel.FailedOrders = bulkUpdateModel.Labels; // All labels failed in this case
                bulkUpdateResultViewModel.LogReport = mainReport.ToString();
                bulkUpdateResultViewModel.TotalFailed = bulkUpdateModel.TotalLabels;
                bulkUpdateResultViewModel.TotalPassed = 0;
            }

            return bulkUpdateResultViewModel;
        }

        /// <summary>
        /// Determines if the label status can be changed
        /// </summary>
        /// <param name="currentLabelDatabaseEntity">The latest label from database that should be updated</param>
        /// <param name="desiredLabelStatusId">The desired label status id that was submitted for updating</param>
        /// <param name="billingLookUps">A list of pre-cached billing lookup data</param>
        /// <param name="invoiceList"></param>
        /// <returns>The validation message: default is empty</returns>
        private async Task<string> ValidateLabelsStatusUpdateAsync(Label currentLabelDatabaseEntity, int desiredLabelStatusId, IReadOnlyCollection<SelectInvoiceViewModel> invoiceList = null)
        {
            var billingLookUps = await GetBillingLookupsAsync();
            // DENY: When current status is void
            //----------------------------------

            if (currentLabelDatabaseEntity.LabelStatusTypeId == (int)LabelStatusTypes.Void)
            {
                // If the latest label has a status of void then deny the update
                // A user cannot change a labels status from void to something else
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(ValidateLabelsStatusUpdateAsync)}; Error: Cannot change a voided label.");
                return "Cannot change a voided label.";
            }

            // DENY: When another active label exists with same vin and label type
            //--------------------------------------------------------------------

            if (desiredLabelStatusId == (int)LabelStatusTypes.Active &&
                _unitOfWorkService.Context.Labels.FirstOrDefault(x => x.VIN == currentLabelDatabaseEntity.VIN &&
                                                                      x.LabelStatusTypeId == (int)LabelStatusTypes.Active &&
                                                                      x.LabelId != currentLabelDatabaseEntity.LabelId &&
                                                                      x.LabelTypeId == currentLabelDatabaseEntity.LabelTypeId) != null)
            {
                // If there is another label that exists with an active status
                // with the same vin and label type then deny
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(ValidateLabelsStatusUpdateAsync)}; Error: Active Label Already Exists");
                return $"An active label already exists for {currentLabelDatabaseEntity.VIN}.";
            }

            // SETTING: To void updates charge to void
            //----------------------------------------

            if (desiredLabelStatusId == (int)LabelStatusTypes.Void)
            {
                // Setting a label to void will update the billing to void
                VoidLabelBillings(currentLabelDatabaseEntity.LabelId, currentLabelDatabaseEntity.CreatedUser);
                return string.Empty;
            }

            // DENY: When a label has an active charge on a closed invoice and changing to pending or duplicate
            // SETTING: To void updates charge to void if not on a closed invoice
            //-------------------------------------------------------------------

            if (desiredLabelStatusId == (int)LabelStatusTypes.Pending || desiredLabelStatusId == (int)LabelStatusTypes.Duplicate)
            {
                LabelBilling labelBillingOnClosedInvoice = null;

                if (invoiceList != null && invoiceList.Count() > 0)
                {
                    // Does an active billing configuration exist for the label type
                    var billingFeeConfig = VerifyBillingConfiguration(currentLabelDatabaseEntity, billingLookUps);

                    if (billingFeeConfig == null)
                    {
                        return "No active billing configuration exists for this label type.\r\nPlease add a billing fee configuration for the label type.";
                    }

                    // Check if the label has a charge on a closed invoice and deny if it does                   
                    var closedInvoiceList = invoiceList.Where(i => i.InvoiceStatus.ToUpper() == InvoiceStatusTypes.Closed.GetDescription().ToUpper())
                        .Select(i => i.InvoiceId).ToList();

                    labelBillingOnClosedInvoice = await (from lb in _unitOfWorkService.Context.LabelBillings
                                                         where lb.LabelId == currentLabelDatabaseEntity.LabelId && lb.InvoiceId > 0 && !lb.Void
                                                               && closedInvoiceList.Contains(lb.InvoiceId ?? 0)
                                                         select lb).FirstOrDefaultAsync();
                }

                if (labelBillingOnClosedInvoice != null)
                {
                    // This label has a charge associated with a closed invoice.
                    return "Active labels can only be moved to duplicate or pending if the invoice is not closed.";
                }

                // Setting a label to pending or duplicate will update the billing to void 
                VoidLabelBillings(currentLabelDatabaseEntity.LabelId, currentLabelDatabaseEntity.CreatedUser);
                return string.Empty;
            }

            // DENY: When a label has an active charge on a closed invoice and changing to closed to active
            //-------------------------------------------------------------------

            if (currentLabelDatabaseEntity.LabelStatusTypeId == (int)LabelStatusTypes.Closed && desiredLabelStatusId == (int)LabelStatusTypes.Active)
            {
                LabelBilling labelBillingOnClosedInvoice = null;

                if (invoiceList != null && invoiceList.Count() > 0)
                {
                    // Does an active billing configuration exist for the label type
                    var billingFeeConfig = VerifyBillingConfiguration(currentLabelDatabaseEntity, billingLookUps);

                    if (billingFeeConfig == null)
                    {
                        return "No active billing configuration exists for this label type.\r\nPlease add a billing fee configuration for the label type.";
                    }

                    // Check if the label has a charge on a closed invoice and deny if it does                   
                    var closedInvoiceList = invoiceList.Where(i => i.InvoiceStatus.ToUpper() == InvoiceStatusTypes.Closed.GetDescription().ToUpper())
                        .Select(i => i.InvoiceId).ToList();

                    labelBillingOnClosedInvoice = await (from lb in _unitOfWorkService.Context.LabelBillings
                                                         where lb.LabelId == currentLabelDatabaseEntity.LabelId && lb.InvoiceId > 0 && !lb.Void
                                                               && closedInvoiceList.Contains(lb.InvoiceId ?? 0)
                                                         select lb).FirstOrDefaultAsync();
                }

                if (labelBillingOnClosedInvoice != null)
                {
                    // This label has a charge associated with a closed invoice.
                    return "Closed Labels cannot be changed to Active if they have charges on a Closed Invoice";
                }
            }

            //There's a bulk process that allows a label to be moved from ACTIVE to CLOSED - commented out here
            //This rule might need to be brought back in by business later
            //if (desiredLabelStatusId == (int)LabelStatusTypes.Closed)
            //{
            //    // Check if the label has any billings that are not voided, if it does then it cannot be closed until invoiced
            //    var labelBilling = GetLabelBillings(currentLabelDatabaseEntity.LabelId);
            //    if (labelBilling.Any())
            //    {
            //        return "Once a label has an associated charge, it must be invoiced before it can be closed";
            //    }
            //}

            return string.Empty;
        }

        /// <summary>
        /// Checks for an active billing fee configuration for a label type
        /// </summary>
        /// <param name="labelEntity">A label entity that's used for verification</param>
        /// <param name="billingLookUps">A collection of billing lookup data that is validated</param>
        /// <returns>An existing billing fee configuration</returns>
        private DTO.BillingFee VerifyBillingConfiguration(Label labelEntity, DTO.BillingLookup billingLookUps)
        {
            // Verifies if a billing fee configuration exists for a label type

            if (labelEntity == null || billingLookUps == null)
                return null;
            if (labelEntity.LabelTypeId == 0)
                return null;

            var billingFees = billingLookUps.BillingFees;

            if (billingFees.Count <= 0)
                return null;

            var billingItemTypes = billingLookUps.BillingItemTypes;

            var labelBillingItemType = billingItemTypes.SingleOrDefault(bt => bt.DisplayName == BillingItemTypes.Label.GetDescription());

            if (labelBillingItemType == null)
                return null;

            var billingReasonTypeId = (labelEntity.LabelTypeId == (int)Labeltypes.Bag) ? (int)BillingReasonTypes.PrintBagLabels
                                                                                       : (int)BillingReasonTypes.PrintUnitLabels;

            var billingFeeConfig = billingFees.FirstOrDefault(bf => bf.ClientCode == labelEntity.ClientCode &&
                                                              bf.ProcessingLocationCode == labelEntity.ProcessingLocationCode &&
                                                              //Not sure about this one, Is there billing type for labels
                                                              //bf.BillingTypeId == ? && 
                                                              bf.BillingReasonTypeId == billingReasonTypeId &&
                                                              bf.BillingItemTypeId == labelBillingItemType.BillingItemTypeId &&
                                                              bf.Active);

            return billingFeeConfig;
        }

        /// <summary>
        /// Gets a list of label billings for a label id that is not void
        /// </summary>
        /// <param name="labelId">The label id to void billings for</param>
        /// <returns>Label Billing</returns>
        public IQueryable<LabelBilling> GetLabelBillings(int labelId)
        {
            if (labelId <= 0)
                throw new ArgumentOutOfRangeException(nameof(labelId));

            var labelBilling = _unitOfWorkService.Context.LabelBillings.Where(lb => lb.LabelId == labelId && !lb.Void);
            return labelBilling;
        }

        /// <summary>
        /// Gets a list of label billings by label id, then voids the label billings for the list
        /// </summary>
        /// <param name="labelId">The label id to void billings for</param>
        /// <param name="userId">The user id that is voiding the billings</param>
        /// <returns>Boolean result</returns>
        public bool VoidLabelBillings(int labelId, string userId)
        {
            if (labelId <= 0)
                throw new ArgumentOutOfRangeException(nameof(labelId));

            if (string.IsNullOrWhiteSpace(userId))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(userId));

            var labelBillingsToVoid = GetLabelBillings(labelId);
            if (labelBillingsToVoid.Any())
            {
                return VoidLabelBillings(labelBillingsToVoid.ToList(), userId);
            }

            return true;
        }

        /// <summary>
        /// Gets invoice status data for all the submitted invoice id's
        /// </summary>
        /// <param name="invoiceIds"></param>
        /// <returns>List of SelectInvoiceViewModel</returns>
        public async Task<List<SelectInvoiceViewModel>> GetInvoiceStatusByIdsAsync(List<int> invoiceIds)
        {
            if (invoiceIds == null)
                throw new ArgumentNullException(nameof(invoiceIds));

            ServiceResponse<List<SelectInvoiceViewModel>> invoiceDetailsResult;
            try
            {
                var invoiceDetailsResponse = await _invoiceService.GetInvoiceStatusByIdsAsync(invoiceIds);

                invoiceDetailsResult = invoiceDetailsResponse != null ? invoiceDetailsResponse.Content.ReadAsAsync<ServiceResponse<List<SelectInvoiceViewModel>>>().Result
                    : new ServiceResponse<List<SelectInvoiceViewModel>>();

                if (invoiceDetailsResponse != null && invoiceDetailsResponse.IsSuccessStatusCode
                                                   && invoiceDetailsResult.ResponseCode == HttpStatusCode.Accepted
                                                   && invoiceDetailsResult.Data != null)
                {
                    return invoiceDetailsResult.Data;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetInvoiceStatusByIdsAsync)}; Error: {ex.Message}");
                throw;
            }

            return invoiceDetailsResult.Data;
        }

        /// <summary>
        /// Deletes invoice billings by line item
        /// </summary>
        /// <param name="clientCode">The client code</param>
        /// <param name="itemTypeId">The item type</param>
        /// <param name="billingIds">A list of billing ids for billings to delete</param>
        /// <returns></returns>
        public async Task<string> DeleteInvoiceBillingsByLineItemIdAsync(string clientCode, int itemTypeId, List<int> billingIds)
        {
            if (string.IsNullOrWhiteSpace(clientCode))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(clientCode));

            if (itemTypeId <= 0)
                throw new ArgumentOutOfRangeException(nameof(itemTypeId));

            ServiceResponse<string> deleteInvoiceBillingsResult;
            try
            {
                var deleteInvoiceBillingsResponse = await _invoiceService.DeleteInvoiceBillingsByLineItemIdAsync(clientCode, itemTypeId, billingIds);

                deleteInvoiceBillingsResult = deleteInvoiceBillingsResponse != null ? deleteInvoiceBillingsResponse.Content.ReadAsAsync<ServiceResponse<string>>().Result
                   : new ServiceResponse<string>();

                if (deleteInvoiceBillingsResponse != null && deleteInvoiceBillingsResponse.IsSuccessStatusCode
                                                          && deleteInvoiceBillingsResult.ResponseCode == HttpStatusCode.Accepted)
                {
                    return deleteInvoiceBillingsResult.Data;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetInvoiceStatusByIdsAsync)}; Error: {ex.Message}");
                throw;
            }

            return deleteInvoiceBillingsResult.Data;

        }

        /// <summary>
        /// Gets billing lookups
        /// </summary>
        /// <returns></returns>
        public async Task<DTO.BillingLookup> GetBillingLookupsAsync()
        {
            var billingLookup = new DTO.BillingLookup();
            try
            {
                var billingLookupsResponse = await _invoiceService.GetBillingLookupsAsync();

                var billingLookupsResult = billingLookupsResponse != null ? billingLookupsResponse.Content.ReadAsAsync<ServiceResponse<Dictionary<string, object>>>().Result
                    : new ServiceResponse<Dictionary<string, object>>();

                if (billingLookupsResponse != null && billingLookupsResponse.IsSuccessStatusCode
                                                   && billingLookupsResult.ResponseCode == HttpStatusCode.Accepted
                                                   && billingLookupsResult.Data != null)
                {
                    var result = billingLookupsResponse.Content.ReadAsStringAsync().Result;
                    var lookups = JsonConvert.DeserializeObject<ServiceResponse<Dictionary<string, object>>>(result);
                    if (lookups != null)
                    {
                        billingLookup.BillingItemTypes = ((JArray)lookups.Data["billingItemTypes"]).ToObject<List<DTO.BillingItemType>>().Where(a => a.Active == true).Select(x => x).ToList();
                        billingLookup.BillingReasonTypes = ((JArray)lookups.Data["billingReasonTypes"]).ToObject<List<DTO.BillingReasonType>>().Where(a => a.Active == true).Select(x => x).ToList();
                        billingLookup.BillingTypes = ((JArray)lookups.Data["billingTypes"]).ToObject<List<DTO.BillingType>>().Where(a => a.Active == true).Select(x => x).ToList();
                        billingLookup.BillingFees = ((JArray)lookups.Data["billingFees"]).ToObject<List<DTO.BillingFee>>().Where(a => a.Active == true).Select(x => x).ToList();
                        billingLookup.PlateConditionTypes = ((JArray)lookups.Data["plateConditionTypes"]).ToObject<List<DTO.PlateConditionType>>().Where(a => a.Active == true).Select(x => x).ToList();
                    }
                }
                return billingLookup;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetBillingLookupsAsync)}; Error: {ex.Message}");
                throw;
            }

        }



        /// <summary>
        /// Voids the label billings
        /// </summary>
        /// <param name="labelBillings">A list of label billings to void</param>
        /// <param name="userId">The user id that is voiding the billings</param>
        /// <returns>Boolean result</returns>
        public bool VoidLabelBillings(List<LabelBilling> labelBillings, string userId)
        {
            try
            {
                var dateNow = DateTime.Now;
                labelBillings.ForEach(lb => { lb.Void = true; lb.InvoiceId = null; lb.CreatedUser = userId; lb.CreatedDate = dateNow; });
                _unitOfWorkService.GetRepositoryAsync<LabelBilling>().UpdateAsync(labelBillings.ToArray());
                _unitOfWorkService.Context.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(VoidLabelBillings)}; Error: {ex.Message}");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Creates job logs
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        public async Task<DTO.Log> CreateJobLogTaskAsync(DTO.Log log)
        {
            var logEntity = _mapper.Map<Log>(log);
            try
            {
                logEntity.ProcessStartDate = DateTime.Now;
                await _unitOfWorkService.Context.Logs.AddAsync(logEntity);
                await _unitOfWorkService.Context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(CreateJobLogTaskAsync)}; Error: {ex.Message}");
                throw ex;
            }
            return _mapper.Map<DTO.Log>(logEntity);
        }


        /// <summary>
        /// Update list of label data in repository
        /// </summary>
        /// <param name="updatedLabels"></param>
        /// <returns></returns>
        public async Task<BulkUpdateResultViewModel> UpdateLabelsAsync(UpdateLabelsModel updatedLabels)
        {
            var bulkUpdateResultViewModel = new BulkUpdateResultViewModel
            {
                TotalPassed = 0,
                TotalFailed = 0,
                LogReport = string.Empty,
                FailedOrders = new List<int>()
            };

            // Error and Success results queues
            var errorLabels = new List<Label>();
            var successLabels = new List<Label>();

            // labels Error Report and Main Report
            var labelErrorsReport = new StringBuilder();
            var mainReport = new StringBuilder();
            mainReport.AppendLine($"UPDATE REPORT LOG<br/>");
            mainReport.AppendLine("<hr/>");
            var updatedLabelsIdList = updatedLabels.LabelsList.Select(x => x.LabelId).ToList();

            // 1. Get the labels current values
            var latestLabelsData = _unitOfWorkService.Context.Labels.Where(x => updatedLabelsIdList.Contains(x.LabelId))?.ToList();
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                try
                {
                    foreach (var currentLabelEntity in latestLabelsData)
                    {
                        var updatedLabel = updatedLabels.LabelsList.Single(o => o.LabelId.Equals(currentLabelEntity.LabelId));
                        var desiredLabelStatus = updatedLabel.LabelStatusData.LabelStatusTypeId;

                        //Validate the rules for status update
                        currentLabelEntity.CreatedUser = updatedLabels.Userid;

                        var validationMessageStatus = currentLabelEntity.LabelStatusTypeId != desiredLabelStatus
                            ? await ValidateLabelsStatusUpdateAsync(currentLabelEntity, desiredLabelStatus, updatedLabels.InvoiceList)
                            : string.Empty;

                        if (string.IsNullOrEmpty(validationMessageStatus))
                        {
                            mainReport.AppendLine($"LabelId: {currentLabelEntity.LabelId} <br/>");
                            if (currentLabelEntity.LabelStatusTypeId != updatedLabel.LabelStatusData.LabelStatusTypeId)
                            {
                                mainReport.AppendLine($"Label Status was updated successfully to value {updatedLabel.LabelStatusData.DisplayName}.<br/>");
                            }
                            if (currentLabelEntity.Notes != updatedLabel.Notes)
                            {
                                mainReport.AppendLine($"Notes was updated successfully to value {updatedLabel.Notes}.<br/>");
                            }
                            currentLabelEntity.LabelStatusTypeId = desiredLabelStatus;
                            currentLabelEntity.Notes = updatedLabel.Notes;
                            // Valid?
                            successLabels.Add(currentLabelEntity);
                        }
                        else
                        {
                            // Invalid?
                            // Failed Validation - add to error labels queue and append to log
                            errorLabels.Add(currentLabelEntity);
                            labelErrorsReport.AppendLine($"LabelId: {currentLabelEntity.LabelId}<br/>");
                            if (!string.IsNullOrEmpty(validationMessageStatus))
                            {
                                labelErrorsReport.AppendLine($"Validation error message for {currentLabelEntity.LabelId} is {validationMessageStatus}.<br/>");
                            }
                        }
                    }
                    // 3. Update the success labels
                    if (successLabels.Any())
                    {
                        _unitOfWorkService.GetRepositoryAsync<Label>().UpdateAsync(successLabels.ToArray());
                        _unitOfWorkService.SaveChanges();
                    }

                    scope.Complete();

                    // 4. Create final log report with totals attached of passed and failed labels
                    mainReport.Append(labelErrorsReport.ToString());
                    mainReport.AppendLine("<hr/>");
                    mainReport.AppendLine($"Total success: {successLabels.Count}<br/>");
                    mainReport.AppendLine($"Total failed: {errorLabels.Count}<br/>");
                    mainReport.AppendLine($"Total Labels: {updatedLabels.LabelsList.Count()}<br/>");
                    mainReport.AppendLine("<br/>");
                    mainReport.AppendLine("End of report</p></br>");
                    bulkUpdateResultViewModel = new BulkUpdateResultViewModel
                    {
                        TotalPassed = successLabels.Count,
                        TotalFailed = errorLabels.Count,
                        LogReport = mainReport.ToString(),
                        FailedOrders = errorLabels.Select(label => label.LabelId).ToList()
                    };
                }
                catch (Exception e)
                {
                    _logger.LogError($"<p>Service: {nameof(LabelManagementService)}; Method: {nameof(UpdateLabelsAsync)}; Critical Error: {e.Message}");
                    mainReport.AppendLine($"An error has occurred performing the update for {updatedLabels.LabelsList.Count()} labels<br/>");
                    mainReport.AppendLine("Please try submitting the update again.\r\nPlease contact your local support team if you continue to receive this error<br/>");
                    mainReport.AppendLine($"Detailed message is: {e.Message}</p>");
                    bulkUpdateResultViewModel.FailedOrders = updatedLabelsIdList; // All labels failed in this case
                    bulkUpdateResultViewModel.LogReport = mainReport.ToString();
                    bulkUpdateResultViewModel.TotalFailed = updatedLabels.LabelsList.Count();
                    bulkUpdateResultViewModel.TotalPassed = 0;
                }
                finally
                {
                    scope.Dispose();
                }

            }

            return bulkUpdateResultViewModel;
        }

        /// <summary>
        /// Gets a list of LabelBillingIds that are Voided and not invoiced for a given list of label ids
        /// </summary>
        /// <param name="labelIds">A collection of label ids</param>
        /// <returns>List of label ids</returns>
        public async Task<List<int>> GetVoidedLabelBillingsAsync(List<int> labelIds)
        {
            return await _unitOfWorkService.Context.LabelBillings.Where(x => labelIds.Contains(x.LabelId) && (x.InvoiceId == null || x.InvoiceId == 0) && x.Void)
                .Select(x => x.LabelBillingId).ToListAsync();
        }

        /// <summary>
        /// Service method to get list of invoice id's associated with, for all the provided label id's
        /// </summary>
        /// <param name="labels">List of label id's</param>
        /// <returns>List of invoice id's</returns>
        public async Task<List<int>> GetInvoiceIdsForLabelsAsync(List<int> labels)
        {
            try
            {
                return await _unitOfWorkService.Context.LabelBillings.Where(lbl => labels.Contains(lbl.LabelId) && lbl.InvoiceId != null)
                                                                     .Select(a => a.InvoiceId.Value).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(GetInvoiceIdsForLabelsAsync)}; Error: {ex.Message}");
                throw;
            }
        }
        #endregion

        #region Billing

        /// <summary>
        /// Saves the label billings
        /// </summary>
        /// <param name="labels">A list of labels to insert charges for</param>
        /// <param name="billingLookUps">The latest billing lookups collection</param>
        /// <param name="userId">The user that will be associated with these charges</param>
        /// <returns>SaveBillingsResult containing the success and failure results</returns>
        public async Task<SaveBillingsResult> SaveLabelBillingsAsync(List<LabelViewModel> labels, string userId)
        {
            var billingLookUps = await GetBillingLookupsAsync();

            var saveBillingResult = new SaveBillingsResult()
            {
                FailedLabels = new List<FailedLabelModel>(),
                SuccessLabels = new List<LabelViewModel>()
            };

            try
            {
                if (labels == null)
                    throw new ArgumentNullException(nameof(labels));
                if (billingLookUps == null)
                    throw new ArgumentNullException(nameof(billingLookUps));
                if (string.IsNullOrWhiteSpace(userId))
                    throw new ArgumentException("Value cannot be null or whitespace.", nameof(userId));

                // Validate billing fees is configured
                var billingFees = billingLookUps.BillingFees;

                if(billingFees.Count <= 0)
                    throw new ArgumentException("There are no billing fees configured. The billing fees lookups collection is null or empty!", "billingFees");

                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    foreach (var label in labels)
                    {
                        // Get the latest status on the label, It has to be ACTIVE.
                        // The label might have changed by another user since this call was made but would likely never happen
                        var currentLabelFromDb = _unitOfWorkService.Context.Labels.Where(lbl => lbl.LabelId == label.LabelId)
                            .Include(lbl => lbl.LabelBillings).FirstOrDefault();
                        if (currentLabelFromDb.LabelStatusTypeId != (int)LabelStatusTypes.Active)
                        {
                            saveBillingResult.FailedLabels.Add(new FailedLabelModel
                            {
                                Label = label,
                                ReasonForFailure = "The label status must be set to ACTIVE to create a charge."
                            });
                            continue;
                        }
                        if (label.ClientCode == null)
                        {
                            saveBillingResult.FailedLabels.Add(new FailedLabelModel
                            {
                                Label = label,
                                ReasonForFailure = "The label Client Code is NULL"
                            });
                            continue;
                        }
                        if (label.ProcessingLocationCode == null)
                        {
                            saveBillingResult.FailedLabels.Add(new FailedLabelModel
                            {
                                Label = label,
                                ReasonForFailure = "The label Processing Location Code is NULL"
                            });
                            continue;
                        }

                        // Check if the label has an existing charge
                        var billingReasonTypeId = (currentLabelFromDb.LabelTypeId == (int)Labeltypes.Bag) ? (int)BillingReasonTypes.PrintBagLabels
                                                                                                          : (int)BillingReasonTypes.PrintUnitLabels;

                        //var labelActiveCharge = await (from lblBil in _unitOfWorkService.Context.LabelBillings
                        //                                   //join bf in billingFees on lblBil.BillingFeeId equals bf.BillingFeeId
                        //                               where lblBil.LabelId == label.LabelId && !lblBil.Void
                        //                               //    bf.BillingReasonTypeId == billingReasonTypeId &&
                        //                               //  bf.ClientCode == label.ClientCode && bf.ProcessingLocationCode == label.ProcessingLocationCode
                        //                               select lblBil).ToListAsync();


                        var labelActiveCharge = (from lblBil in currentLabelFromDb.LabelBillings
                                                 join bf in billingFees on lblBil.BillingFeeId equals bf.BillingFeeId
                                                 where !lblBil.Void && bf.BillingReasonTypeId == billingReasonTypeId &&
                                                 bf.ClientCode == label.ClientCode && bf.ProcessingLocationCode == label.ProcessingLocationCode
                                                 select lblBil).ToList();


                        if (labelActiveCharge.Count > 0)
                        {
                            // There's an existing charge, cannot add another
                            saveBillingResult.FailedLabels.Add(new FailedLabelModel
                            {
                                Label = label,
                                ReasonForFailure = "The label has an existing charge.\r\nA new charge cannot be created if one already exists."
                            });
                        }
                        else
                        {

                            try
                            {

                                var billingFeeConfig = VerifyBillingConfiguration(currentLabelFromDb, billingLookUps);

                                if (billingFeeConfig != null)
                                {
                                    // Add the new charge for the label
                                    await _unitOfWorkService.GetRepositoryAsync<LabelBilling>()
                                        .AddAsync(new LabelBilling()
                                        {
                                            BillingAmount = billingFeeConfig.DefaultAmount,
                                            BillingFeeId = billingFeeConfig.BillingFeeId,
                                            LabelId = currentLabelFromDb.LabelId,
                                            IsDebit = true,
                                            Comment = billingFeeConfig.DisplayName,
                                            CreatedDate = DateTime.Now,
                                            CreatedUser = userId,
                                            ProcessingLocationCode = currentLabelFromDb.ProcessingLocationCode,
                                        });

                                    saveBillingResult.SuccessLabels.Add(label);
                                }
                                else
                                {
                                    // There's an existing charge, cannot add another
                                    saveBillingResult.FailedLabels.Add(new FailedLabelModel
                                    {
                                        Label = label,
                                        ReasonForFailure = "No active billing configuration exists for this label type.\r\nPlease add a billing fee configuration for the label type."
                                    });
                                }
                            }
                            catch (Exception ex)
                            {
                                // Handle some other error for the label here and continue
                                saveBillingResult.FailedLabels.Add(new FailedLabelModel
                                {
                                    Label = label,
                                    ReasonForFailure = $"An unexpected error occurred creating a charge for the label\r\nError details: {ex.Message}"
                                });
                            }
                        }
                    }

                    _unitOfWorkService.SaveChanges();
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(SaveLabelBillingsAsync)}; Error: {ex.Message}");
                throw;
            }

            return saveBillingResult;
        }

        /// <summary>
        /// Verify Billing Reason Types
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> GetBillingReasonTypeAsync(LabelViewModel model)
        {
            Label labelEntity = new Label();
            labelEntity.LabelTypeId = model.LabelTypeId;
            labelEntity.ClientCode = model.ClientCode;
            labelEntity.ProcessingLocationCode = model.ProcessingLocationCode;

            var billingLookUps = await GetBillingLookupsAsync();
           
            // Validate billing fees is configured
            var billingFees = billingLookUps.BillingFees;

            if (billingFees == null || billingFees.Count <= 0)
            {
                return false;
            }

            var billingFeeConfig = VerifyBillingConfiguration(labelEntity, billingLookUps);

            if(billingFeeConfig != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

            #endregion

            #region Credit Labels


            /// <summary>
            /// Validates the label to apply credit
            /// </summary>
            /// <param name="labels"></param>
            /// <param name="clientCode"></param>
            /// <returns></returns>
            public async Task<List<CreditLabelViewModel>> ValidateLabelsToApplyCreditsAsync(IEnumerable<int> labels)
        {
            try
            {
                var labelsToApplyCredits = new List<CreditLabelViewModel>();

                var unvoidedLabelBillingsForLabels = await (from l in _unitOfWorkService.Context.Labels
                                                            join lb in _unitOfWorkService.Context.LabelBillings on l.LabelId equals lb.LabelId
                                                            where l.LabelStatusTypeId != (int)LabelStatusTypes.Void && l.PrintCount > 0 && labels.Contains(l.LabelId) && !lb.Void
                                                            select lb).ToListAsync();

                var debitLabelBillingsForLabels = unvoidedLabelBillingsForLabels.Where(dpb => dpb.IsDebit).ToList();

                foreach (var debitLabelBilling in debitLabelBillingsForLabels)
                {
                    var currentCreditCharge = unvoidedLabelBillingsForLabels.Where(cpb => !cpb.IsDebit && cpb.LabelId == debitLabelBilling.LabelId && cpb.BillingFeeId == debitLabelBilling.BillingFeeId).ToList();

                    if (currentCreditCharge.Count == 0)
                    {
                        labelsToApplyCredits.Add(new CreditLabelViewModel { LabelId = debitLabelBilling.LabelId, InvoiceId = debitLabelBilling.InvoiceId.GetValueOrDefault() });
                    }
                }

                return labelsToApplyCredits;

            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(ValidateLabelsToApplyCreditsAsync)}; Error: {ex.Message}");
                throw ex;
            }
        }


        /// <summary>
        /// Apply credits to labels 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task ApplyCreditsToLabelsAsync(CreditLabelRequestModel model)
        {
            try
            {
                // 1. Get labels with associated billing charges
                var labels = await _unitOfWorkService.Context.Labels.Where(l => model.LabelIdList.Contains(l.LabelId))
                                        .Include(l => l.LabelBillings).ToListAsync();

                // 2. Update the platesWithBillings object to update plate status and billing charge information
                foreach (var label in labels)
                {

                    var dtime = DateTime.Now;

                    // set void to true for all the label charges without invoice
                    await VoidLabelBillingsAsync(label.LabelBillings.Where(a => (a.InvoiceId == null || a.InvoiceId == 0) && !a.Void).ToList(), model.UserName);

                    // set void to true for all the label charges with open invoice
                    await VoidLabelBillingsAsync(label.LabelBillings.Where(a => (a.InvoiceId != null || a.InvoiceId != 0) && !a.Void && model.InvoiceList.Where(p => p.InvoiceStatus.ToUpper() == InvoiceStatusTypes.Open.GetDescription().ToUpper()).Select(p => p.InvoiceId).ToList().Contains(a.InvoiceId.GetValueOrDefault())).ToList(), model.UserName);

                    // create credit charges for closed invoice
                    var currentPlateBillingsDebits = label.LabelBillings.Where(a => (a.InvoiceId != null || a.InvoiceId != 0) && a.IsDebit && !a.Void && model.InvoiceList.Where(
                           p => p.InvoiceStatus.ToUpper() == Model.Enums.InvoiceStatusTypes.Closed.GetDescription().ToUpper()).Select(p => p.InvoiceId).ToList().Contains(a.InvoiceId.Value)).ToList();

                    var isCreditCharged = await CreateCreditChargeAsync(currentPlateBillingsDebits, model.UserName);

                    // set plate status to closed if credits are charged
                    if (isCreditCharged)
                        label.LabelStatusTypeId = (int)LabelStatusTypes.Closed;

                    label.CreatedUser = model.UserName;
                    label.CreatedDate = dtime;
                    _unitOfWorkService.GetRepositoryAsync<Label>().UpdateAsync(label);
                }

                // 3. call the save method to save changes to db.                    
                _unitOfWorkService.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(ApplyCreditsToLabelsAsync)}; Error: {ex.Message}");
                throw ex;
            }
        }


        /// <summary>
        /// Voids the label billings
        /// </summary>
        /// <param name="labelBillings"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<bool> VoidLabelBillingsAsync(List<LabelBilling> labelBillings, string userId)
        {
            try
            {
                if (labelBillings.Any())
                {
                    var dt = DateTime.Now;
                    labelBillings.ForEach(x => { x.Void = true; x.InvoiceId = null; x.CreatedUser = userId; x.CreatedDate = dt; });
                    _unitOfWorkService.GetRepositoryAsync<LabelBilling>().UpdateAsync(labelBillings.ToArray());
                    await _unitOfWorkService.Context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(VoidLabelBillingsAsync)}; Error: {ex.Message}");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Creates credit charges for closed invoices
        /// </summary>
        /// <param name="labelBillings"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<bool> CreateCreditChargeAsync(List<LabelBilling> labelBillings, string userId)
        {
            var comment = "Credits applied";
            try
            {
                if (labelBillings.Any())
                {
                    var labelBillingEntity = new List<LabelBilling>();
                    var labelBillingLabelIdList = labelBillings.Select(l => l.LabelId).ToList();

                    var labelBillingsEntities = await _unitOfWorkService.Context.LabelBillings.Where(a => !a.IsDebit && !a.Void && labelBillingLabelIdList.Contains(a.LabelId)).ToListAsync();

                    var currentCreditCharges = labelBillingsEntities.Where(a => labelBillings.Any(pb => pb.LabelId == a.LabelId && pb.BillingFeeId == a.BillingFeeId)).ToList();

                    foreach (var labelBilling in labelBillings)
                    {
                        var currentCreditCharge = currentCreditCharges.Where(a => a.LabelId == labelBilling.LabelId && a.BillingFeeId == labelBilling.BillingFeeId).ToList();

                        if(currentCreditCharge.Count == 0)
                        {
                            labelBillingEntity.Add(new LabelBilling()
                            {
                                BillingAmount = labelBilling.BillingAmount,
                                BillingFeeId = labelBilling.BillingFeeId,
                                Comment = comment,
                                CreatedDate = DateTime.Now,
                                CreatedUser = userId,
                                IsDebit = false,
                                Void = false,
                                InvoiceId = null,
                                LabelId = labelBilling.LabelId,
                                ProcessingLocationCode = labelBilling.ProcessingLocationCode
                            });
                        }
                    }

                    //Saves the entity object
                    await _unitOfWorkService.Context.AddRangeAsync(labelBillingEntity.ToArray());
                    await _unitOfWorkService.Context.SaveChangesAsync();
                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(CreateCreditChargeAsync)}; Error: {ex.Message}");
                return false;
            }
            return false;
        }

        /// <summary>
        /// Gets a list of LabelBillingIds that are Voided 
        /// </summary>
        /// <param name="labelIds"></param>
        /// <returns></returns>
        public async Task<List<int>> GetVoidedLabelBillingsForCreditLabelsAsync(List<int> labelIds)
        {
            return await _unitOfWorkService.Context.LabelBillings.Where(x => labelIds.Contains(x.LabelId) && (x.InvoiceId == null || x.InvoiceId == 0) && x.Void && x.IsDebit).Select(x => x.LabelBillingId).ToListAsync();
        }

        #endregion

        #region Move Labels

        /// <summary>
        /// updates  the label processing office
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> UpdateLabelProcessingOfficeAsync(MoveLabelsViewModel model)
        {
            try
            {
                var labelIds = model.Labels.Select(x => x.LabelId).ToList();
                var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(x => labelIds.Contains(x.LabelId));
                if(labelData != null && labelData.Count > 0)
                {
                    if(labelData.ElementAtOrDefault(0).ProcessingLocationCode.ToLower().Trim() == model.ProcessingLocationOffice.ToLower().Trim())
                    {
                        return false;
                    }
                    labelData.ForEach(x => { x.ProcessingLocationCode = model.ProcessingLocationOffice; x.ModifiedDate = DateTime.Now; x.ModifiedUser = model.UserName;});
                } 
                _unitOfWorkService.Context.Labels.UpdateRange(labelData);
                _unitOfWorkService.SaveChanges();
               
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(UpdateLabelProcessingOfficeAsync)}; Error: {ex.Message}");
                throw ex;
            }
            return true;
        }

        #endregion

        #region Copy Labels

        /// <summary>
        /// Copy label data
        /// </summary>
        /// <param name="model"></param>
        /// <returns>CopyLabelsViewModel</returns>
        public async Task<CopyLabelsViewModel> CopyLabelsAsync(CopyLabelsViewModel model)
        {
            CopyLabelsViewModel response = new CopyLabelsViewModel();

            // labels Error Report and Main Report
            var labelErrorsReport = new StringBuilder();
            var mainReport = new StringBuilder();
            var errorLabels = new List<Label>();
            var successLabels = new List<Label>();
            mainReport.AppendLine($"COPY LABELS REPORT LOG<br/>");
            mainReport.AppendLine("<hr/>");

            try
            {
                var labelIds = model.Labels.Select(x => x.LabelId).ToList();
                var labelData = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(x => labelIds.Contains(x.LabelId));
                var labelVinList = await _unitOfWorkService.GetRepositoryAsync<Label>().GetListAsync(x => (labelData.Select(x => x.VIN).ToList()).Contains(x.VIN));

                if (labelData != null && labelData.Count > 0)
                {
                    foreach (var label in labelData)
                    {
                        var vinStatus = labelVinList.Where(x => x.VIN == label.VIN && x.LabelStatusTypeId == 3 && x.LabelTypeId == label.LabelTypeId).ToList();
                        var successVin = successLabels.Where(x => x.VIN == label.VIN).ToList();

                        if ((vinStatus != null && vinStatus.Count > 0) || (successVin != null && successVin.Count > 0))
                        {
                            errorLabels.Add(label);
                            labelErrorsReport.AppendLine($"LabelId: {label.LabelId}<br/>");
                            labelErrorsReport.AppendLine($"Active labels already exists for the VIN: {label.VIN}.<br/>");
                        }
                        else
                        {                            
                            successLabels.Add(label);
                            labelErrorsReport.AppendLine($"LabelId: {label.LabelId}<br/>");
                            labelErrorsReport.AppendLine($"Label copied successfully. <br/>");
                            await _unitOfWorkService.GetRepositoryAsync<Label>()
                                       .AddAsync(new Label()
                                       {
                                           LabelStatusTypeId = (int)LabelStatusTypes.Active,
                                           LabelTypeId = label.LabelTypeId,
                                           ClientCode = label.ClientCode,
                                           StateProvinceCode = label.StateProvinceCode,
                                           ProcessingLocationCode = label.ProcessingLocationCode,
                                           VIN = label.VIN,
                                           Unit = label.Unit,
                                           DeliveryCode = label.DeliveryCode,
                                           BatchNumber = label.BatchNumber,
                                           OwningAreaDeliveryCode = label.OwningAreaDeliveryCode,
                                           Make = label.Make,
                                           Model = label.Model,
                                           Year = label.Year,
                                           Color = label.Color,
                                           Notes = label.Notes,
                                           ShipTo = label.ShipTo,
                                           PrintCount = 0,
                                           CreatedUser = label.CreatedUser,
                                           CreatedDate = label.CreatedDate,
                                           ModifiedUser = model.UserName,
                                           ModifiedDate = DateTime.Now,
                                           LabelBillings = label.LabelBillings,
                                       });
                        }
                    }
                }
                else
                {
                    labelErrorsReport.AppendLine($"Label data not found<br/>");
                }

                // 3. Save the success labels
                if (successLabels.Any())
                {
                    _unitOfWorkService.SaveChanges();
                }

                response.TotalPassed = successLabels.Count;
                response.TotalFailed = errorLabels.Count;
                response.TotalLabels = labelData.Count;

                // 4. Create final log report with totals attached of passed and failed labels
                mainReport.Append(labelErrorsReport.ToString());
                mainReport.AppendLine("<hr/>");
                mainReport.AppendLine($"Total Success: {successLabels.Count}<br/>");
                mainReport.AppendLine($"Total Failed: {errorLabels.Count}<br/>");
                mainReport.AppendLine($"Total Labels: {labelData.Count}<br/>");
                mainReport.AppendLine("<br/>");
                mainReport.AppendLine("End of report</p></br>");
                mainReport.AppendLine("<br/>");
                mainReport.AppendLine($"Submit Date:{DateTime.Now}");
                response.LogReport = mainReport.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(LabelManagementService)}; Method: {nameof(CopyLabelsAsync)}; Error: {ex.Message}");
                throw ex;
            }

            return response;
        }

        #endregion
    }

}
