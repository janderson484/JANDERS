using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Business
{
    public class ConfigurationService : IConfigurationService
    {
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILogger<ConfigurationService> _logger;
        private readonly IMapper _mapper;

        public ConfigurationService(IUnitOfWorkService<LabelModel> unitOfWorkService, ILogger<ConfigurationService> logger, IMapper mapper)
        {
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _mapper = mapper;
        }

        /// <summary>
        /// Gets the import layout configurations 
        /// </summary>
        /// <param name="baseRequest"></param>
        /// <returns>import layout configuration view model</returns>
        public async Task<ImportLayoutConfigurationViewModel> GetImportLayoutsAsync(UserProfileSettingsViewModel baseRequest)
        {
            // Move to parameter after adding dropdown
            var importLayouts = new ImportLayoutConfigurationViewModel() { TotalCount = 0 };
            var importLayoutConfigs = new List<ImportLayoutViewModel>();
            try
            {
                var rowsPerPage = (baseRequest.SelectedRowsPerPage == null || baseRequest.SelectedRowsPerPage == 0) ? baseRequest.DefaultRowsPerPage : (int)baseRequest.SelectedRowsPerPage;
                List<bool> isActive = new List<bool>();
                isActive.Add(true);
                if (baseRequest.IncludeDisabled)
                    isActive.Add(false);
                var labelImportsList = await _unitOfWorkService.Context.LabelImports.Where(x => isActive.Contains(x.Active)).ToListAsync();
                importLayoutConfigs = await GetLabelImportListAsync(labelImportsList.Skip((baseRequest.PageNumber - 1) * rowsPerPage).Take(rowsPerPage).ToList(), baseRequest.DmvStateCode);
                importLayouts.ImportLayouts = _mapper.Map<List<ImportLayoutViewModel>>(importLayoutConfigs);
                importLayouts.TotalCount = labelImportsList.Count;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetImportLayoutsAsync)}; Error: {e.Message}");
                throw;
            }
            return importLayouts;
        }

        /// <summary>
        /// updates  the import layout configuration status 
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> UpdateImportLayoutStatusAsync(ImportLayoutViewModel model)
        {
            var importLayout = await _unitOfWorkService.Context.LabelImports.FirstOrDefaultAsync(x => x.LabelImportId == model.LabelImportId);
            if (importLayout != null)
            {
                importLayout.Active = model.Active;
                importLayout.ModifiedDate = DateTime.UtcNow;
                importLayout.ModifiedUser = model.UserId;
                _unitOfWorkService.GetRepositoryAsync<LabelImport>().UpdateAsync(importLayout);
                _unitOfWorkService.SaveChanges();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets the master data configurations
        /// </summary>
        /// <returns>dictionary</returns>
        public async Task<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>> GetMasterDataAsync()
        {
            try
            {
                var importFields = await _unitOfWorkService.Context.LabelImportFields.Where(x => x.Active).ToListAsync();
                var labelType = await _unitOfWorkService.Context.LabelTypes.Where(x => x.Active).ToListAsync();
                return new Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>(_mapper.Map<List<Model.DTO.LabelImportField>>(importFields), _mapper.Map<List<Model.DTO.LabelType>>(labelType));
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetMasterDataAsync)}; Error: {e.Message}");
                return null;
            }
        }

        /// <summary>
        /// Gets the master data configurations
        /// </summary>
        /// <returns>dictionary</returns>
        public async Task<ImportLayoutViewModel> GetImportLayoutAsync(int id)
        {
            try
            {
                var labelImportLayout = await _unitOfWorkService.Context.LabelImports.Where(x => x.LabelImportId == id).ToListAsync();
                var fieldMappings = await _unitOfWorkService.Context.LabelImportFieldsMappings.Where(x => x.LabelImportId == id).ToListAsync();
                if (labelImportLayout != null)
                {
                    var result = (await GetLabelImportListAsync(labelImportLayout)).FirstOrDefault();
                    result.LabelImportFieldMappings = fieldMappings.Any() ? _mapper.Map<List<Model.DTO.LabelImportFieldsMapping>>(fieldMappings).OrderBy(x => x.FieldOrder).ToList() : null;
                    return result;
                }
                return null;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetImportLayoutAsync)}; Error: {e.Message}");
                return null;
            }
        }

        /// <summary>
        /// Add/Update the import layout configuration status 
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> SaveLayoutConfigAsync(ImportLayoutViewModel model)
        {
            try
            {
                if (model.LabelImportId == 0)
                {
                    var labelImport = _mapper.Map<LabelImport>(model);
                    var labelImportFieldMapping = _mapper.Map<List<LabelImportFieldsMapping>>(model.LabelImportFieldMappings);
                    var isDescriptionExist = _unitOfWorkService.Context.LabelImports.Any(x => x.Description.Replace(" ", "").ToLower() == model.Description.Replace(" ", "").ToLower());
                    if (isDescriptionExist)
                    {
                        throw new Exception("Cannot have duplicate description.");
                    }
                    labelImport.CreatedDate = DateTime.UtcNow;
                    labelImport.ModifiedDate = DateTime.UtcNow;
                    labelImport.CreatedUser = model.UserId;
                    labelImport.ModifiedUser = model.UserId;
                    labelImportFieldMapping.ForEach(x => x.CreatedDate = DateTime.UtcNow);
                    labelImportFieldMapping.ForEach(x => x.CreatedUser = model.UserId);

                    await _unitOfWorkService.Context.AddAsync(labelImport);
                    _unitOfWorkService.SaveChanges();
                    labelImportFieldMapping.ForEach(x => x.LabelImportId = labelImport.LabelImportId);
                    await _unitOfWorkService.GetRepositoryAsync<LabelImportFieldsMapping>().AddAsync(labelImportFieldMapping);
                    model.LabelImportId = labelImport.LabelImportId;
                    await AddLabelImportMappingAsync(model);
                    return true;
                }
                var importLayout = await _unitOfWorkService.Context.LabelImports.FirstOrDefaultAsync(x => x.LabelImportId == model.LabelImportId);
                var importLayoutImportFieldMapping = await _unitOfWorkService.Context.LabelImportFieldsMappings.Where(x => x.LabelImportId == model.LabelImportId).ToListAsync();
                if (importLayout != null)
                {
                    var isDescriptionExist = _unitOfWorkService.Context.LabelImports.Any(x => x.Description.Replace(" ", "").ToLower() == model.Description.Replace(" ", "").ToLower() && x.LabelImportId != model.LabelImportId);
                    if (isDescriptionExist)
                    {
                        throw new Exception("Cannot have duplicate description.");
                    }
                    importLayout.Description = model.Description;
                    importLayout.LabelTypeId = model.LabelTypeId;
                    importLayout.GenerateBagLabels = model.GenerateBagLabels;
                    importLayout.Active = model.Active;
                    importLayout.ModifiedUser = model.UserId;
                    importLayout.ModifiedDate = DateTime.UtcNow;
                    _unitOfWorkService.GetRepositoryAsync<LabelImport>().UpdateAsync(importLayout);

                    var deleteFieldMappingRecord = _unitOfWorkService.Context.LabelImportFieldsMappings.Where(x => x.LabelImportId == model.LabelImportId);
                    _unitOfWorkService.Context.LabelImportFieldsMappings.RemoveRange(deleteFieldMappingRecord);
                    _unitOfWorkService.Context.SaveChanges();

                    var labelImportFieldMapping = _mapper.Map<List<LabelImportFieldsMapping>>(model.LabelImportFieldMappings);
                    labelImportFieldMapping.ForEach(x => x.LabelImportFieldsMappingId = 0);
                    labelImportFieldMapping.ForEach(x => x.CreatedDate = DateTime.UtcNow);
                    labelImportFieldMapping.ForEach(x => x.CreatedUser = model.UserId);
                    labelImportFieldMapping.ForEach(x => x.LabelImportId = importLayout.LabelImportId);
                    await _unitOfWorkService.GetRepositoryAsync<LabelImportFieldsMapping>().AddAsync(labelImportFieldMapping);
                    await DeleteAddLabelImportMappingAsync(model);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(ImportLayoutViewModel)}; Error: {e.Message}");
                throw e;
            }
        }

        #region Print Sort Order


        /// <summary>
        /// Gets the label sort order
        /// </summary>
        /// <param name="baseRequest"></param>
        /// <returns>label sort order configuration view model</returns>
        public async Task<LabelSortOrderConfigurationViewModel> GetLabelSortOrderAsync(UserProfileSettingsViewModel baseRequest)
        {
            var labelSortOrder = new LabelSortOrderConfigurationViewModel() { TotalCount = 0 };
            var rowsPerPage = baseRequest.SelectedRowsPerPage == 0 ? baseRequest.DefaultRowsPerPage : (int)baseRequest.SelectedRowsPerPage;
            try
            {
                List<bool> isActive = new List<bool>();
                isActive.Add(true);
                if (baseRequest.IncludeDisabled)
                    isActive.Add(false);
                var labelSortOrderList = await _unitOfWorkService.Context.LabelSortOrders.Where(x => isActive.Contains(x.Active)).ToListAsync();
                var pagedResult = await GetLabelSortOrderListAsync(labelSortOrderList);

                foreach (var order in pagedResult)
                {
                    order.SortOrderFields = JsonConvert.DeserializeObject<List<LabelSortOrderFields>>(order.Order);
                    order.Order = string.Join(", ", order.SortOrderFields.Select(x => x.FieldName).ToList());
                }

                labelSortOrder.LabelSortOrders = _mapper.Map<List<LabelSortOrderViewModel>>(pagedResult);
                labelSortOrder.TotalCount = labelSortOrderList.ToList().Count;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetLabelSortOrderAsync)}; Error: {e.Message}");
                throw;
            }
            return labelSortOrder;
        }

        /// <summary>
        /// Gets the labels data
        /// </summary>
        /// <returns>dictionary</returns>
        public async Task<LabelSortOrderViewModel> GetLabelSortOrderAsync(int id)
        {
            LabelSortOrderViewModel model = new LabelSortOrderViewModel();
            try
            {
                var labelSortOrderModel = await _unitOfWorkService.Context.LabelSortOrders.Where(x => x.LabelSortOrderId == id).ToListAsync();
                var labelSortOrderConfigs = (await GetLabelSortOrderListAsync(labelSortOrderModel)).FirstOrDefault();

                if (labelSortOrderConfigs != null)
                {
                    labelSortOrderConfigs.SortOrderFields = JsonConvert.DeserializeObject<List<LabelSortOrderFields>>(labelSortOrderConfigs.Order);
                    return labelSortOrderConfigs;
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetImportLayoutAsync)}; Error: {e.Message}");
            }
            return model;
        }


        public async Task<LabelSortOrderViewModel> GetLabelSortOrderByUserAsync(string userId, string clientCode, string processingCode)
        {
            LabelSortOrderViewModel model = new LabelSortOrderViewModel();
            try
            {
                var personalSetting = await GetPersonalSettingsAsync(userId, clientCode, processingCode);
                if (personalSetting != null)
                {
                    model = await GetLabelSortOrderAsync(personalSetting.LabelSortOrderId);
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetLabelSortOrderByUserAsync)}; Error: {e.Message}");
            }
            return model;
        }

        /// <summary>
        /// Gets the labels
        /// </summary>
        /// <returns>dictionary</returns>
        public async Task<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>> GetLabelDataAsync()
        {
            try
            {
                var labelsList = (typeof(Labels)).
                    GetAllEnumsWithDescription();
                var listname = typeof(VM.FleetServices.TnR.LM.Data.LabelModel.Entities.Label).GetProperties();

                var importFields = from colums in labelsList
                                   select new LabelImportField() { DisplayName = colums.Value };

                var labelType = await _unitOfWorkService.Context.LabelTypes.Where(x => x.Active).ToListAsync();
                return new Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>(_mapper.Map<List<Model.DTO.LabelImportField>>(importFields), _mapper.Map<List<Model.DTO.LabelType>>(labelType));
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetMasterDataAsync)}; Error: {e.Message}");
                return null;
            }
        }

        /// <summary>
        /// Add/Update the label sort order
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> SaveLabelSortOrderAsync(LabelSortOrderViewModel model)
        {
            try
            {
                if (model.LabelSortOrderId == 0)
                {
                    LabelSortOrder labelSort = new LabelSortOrder();
                    var isDescriptionExist = _unitOfWorkService.Context.LabelSortOrders.Any(x => x.Description.Replace(" ", "").ToLower() == model.Description.Replace(" ", "").ToLower());
                    if (isDescriptionExist)
                    {
                        throw new Exception("Cannot have duplicate description.");
                    }

                    labelSort.CreatedDate = DateTime.UtcNow;
                    labelSort.CreatedUser = model.UserId;
                    var labelSortModel = EditLabelSortOrder(model, labelSort);
                    await _unitOfWorkService.Context.AddAsync(labelSortModel);
                    _unitOfWorkService.Context.SaveChanges();
                    model.LabelSortOrderId = _unitOfWorkService.Context.LabelSortOrders.Where(x => x.Description == model.Description).Select(x => x.LabelSortOrderId).FirstOrDefault();
                    await AddLabelSortOrderMappingAsync(model);
                    return true;
                }
                var labelSortOrder = await _unitOfWorkService.Context.LabelSortOrders.FirstOrDefaultAsync(x => x.LabelSortOrderId == model.LabelSortOrderId);

                if (labelSortOrder != null)
                {
                    var isDescriptionExist = _unitOfWorkService.Context.LabelSortOrders.Any(x => x.Description.Replace(" ", "").ToLower() == model.Description.Replace(" ", "").ToLower() && x.LabelSortOrderId != model.LabelSortOrderId);
                    if (isDescriptionExist)
                    {
                        throw new Exception("Cannot have duplicate description.");
                    }
                    var labelSortModel = EditLabelSortOrder(model, labelSortOrder);
                    _unitOfWorkService.GetRepositoryAsync<LabelSortOrder>().UpdateAsync(labelSortModel);
                    await DeleteLabelSortOrderMappingAsync(model.LabelSortOrderId);
                    await AddLabelSortOrderMappingAsync(model);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(LabelSortOrderViewModel)}; Error: {e.Message}");
                throw e;
            }
        }

        /// <summary>
        /// updates  the label sort order
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> DeleteSortOrderAsync(int id)
        {
            try
            {
                var labelSortOrder = await _unitOfWorkService.Context.LabelSortOrders.FirstOrDefaultAsync(x => x.LabelSortOrderId == id);
                if (labelSortOrder != null)
                {
                    await DeleteLabelSortOrderMappingAsync(id);
                    _unitOfWorkService.Context.LabelSortOrders.Remove(labelSortOrder);
                    _unitOfWorkService.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(DeleteSortOrderAsync)}; Error: {e.Message}");
                throw e;
            }
        }

        /// <summary>
        /// updates  the label sort order status
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> UpdateLabelSortOrderStatusAsync(LabelSortOrderViewModel model)
        {
            var labelSortOrder = await _unitOfWorkService.Context.LabelSortOrders.FirstOrDefaultAsync(x => x.LabelSortOrderId == model.LabelSortOrderId);
            if (labelSortOrder != null)
            {
                labelSortOrder.Active = model.Active;
                _unitOfWorkService.GetRepositoryAsync<LabelSortOrder>().UpdateAsync(labelSortOrder);
                _unitOfWorkService.SaveChanges();
                return true;
            }
            return false;
        }
        #endregion

        /// <summary>
        /// Gets the import configuration types
        /// </summary>
        /// <param name="profileSettingsViewModel"></param>
        /// <returns>Initial import types for configuration dropdown</returns>
        public async Task<ImportLayoutConfigurationViewModel> GetImportTypesAsync(UserProfileSettingsViewModel profileSettingsViewModel)
        {
            var importLayouts = new ImportLayoutConfigurationViewModel() { TotalCount = 0 };
            try
            {
                var labelImportsList = await (from x in _unitOfWorkService.Context.LabelImports.Where(x => x.Active == true)
                                              join y in _unitOfWorkService.Context.LabelImportClientMappings.Where(a => a.ClientCode == profileSettingsViewModel.ClientCode) on x.LabelImportId equals y.LabelImportId
                                              join z in _unitOfWorkService.Context.LabelImportProcessingLocationMappings.Where(b => b.ProcessingLocationCode == profileSettingsViewModel.ProcessingLocationCode) on x.LabelImportId equals z.LabelImportId
                                              select x).ToListAsync();
                importLayouts.ImportLayouts = await GetLabelImportListAsync(labelImportsList, profileSettingsViewModel.DmvStateCode);
                importLayouts.TotalCount = labelImportsList.Count();

            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetImportTypesAsync)}; Error: {e.Message}");
                throw;
            }
            return importLayouts;
        }

        /// <summary>
        /// Gets remaining view data, based on configuration dropdown selection
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<ImportLayoutConfigurationViewModel> GetLabelTypeAsync(AddLabelsViewModel model)
        {
            var labelImportFields = await GetLabelImportFieldsMappingsAsync(model);
            var importLayouts = new ImportLayoutConfigurationViewModel() { TotalCount = 0 };
            try
            {
                var labelImportsList = await _unitOfWorkService.Context.LabelImports.Where(x => x.LabelImportId.Equals(model.LabelImportId)).ToListAsync();
                importLayouts.ImportLayouts = await GetLabelImportListAsync(labelImportsList, model.DmvStateCode);
                importLayouts.ImportLayouts.ForEach(x => x.ImportList = labelImportFields);
                importLayouts.ImportLayouts.ForEach(x => x.Required = model.Required);
                importLayouts.TotalCount = labelImportsList.Count();
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetLabelTypeAsync)}; Error: {e.Message}");
                throw;
            }
            return importLayouts;
        }

        public async Task<List<AddLabelsViewModel>> GetLabelImportFieldsMappingsAsync(AddLabelsViewModel model)
        {
            try
            {
                var result = await (from fields in _unitOfWorkService.Context.LabelImportFields
                                    join mappings in _unitOfWorkService.Context.LabelImportFieldsMappings on fields.LabelImportFieldId equals mappings.LabelImportFieldId
                                    where mappings.LabelImportId.Equals(model.LabelImportId)
                                    && fields.Active.Equals(true)
                                    orderby mappings.FieldOrder ascending
                                    select new AddLabelsViewModel() { LabelImportId = mappings.LabelImportId, ImportOrder = mappings.FieldOrder, ImportFieldName = fields.DisplayName, Required = mappings.RequiredField }).ToListAsync();

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetLabelImportFieldsMappingsAsync)}; Error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets the label sort order
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns>label sort order configuration view model</returns>
        public async Task<List<LabelSortOrderViewModel>> GetAllLabelSortOrderAsync(string clientCode, string ProcessingCode)
        {
            try
            {
                var labelSortOrder = await (from x in _unitOfWorkService.Context.LabelSortOrders.Where(x => x.Active == true)
                                            join y in _unitOfWorkService.Context.SortOrderClientMappings.Where(a => a.ClientCode == clientCode) on x.LabelSortOrderId equals y.LabelSortOrderId
                                            join z in _unitOfWorkService.Context.SortOrderProcessingLocationMappings.Where(b => b.ProcessingLocationCode == ProcessingCode) on x.LabelSortOrderId equals z.LabelSortOrderId
                                            select x).ToListAsync();

                var labelSortOrderConfigs = await GetLabelSortOrderListAsync(labelSortOrder);

                foreach (var order in labelSortOrderConfigs)
                {
                    order.SortOrderFields = JsonConvert.DeserializeObject<List<LabelSortOrderFields>>(order.Order);
                    order.Order = string.Join(", ", order.SortOrderFields.Select(x => x.FieldName).ToList());
                }
                return labelSortOrderConfigs;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetAllLabelSortOrderAsync)}; Error: {e.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets the personal settings
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="clientCode"></param>
        /// <param name="processingCode"></param>
        /// <returns>users personal settings</returns>
        public async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync(string userId, string clientCode, string processingCode)
        {
            if (string.IsNullOrWhiteSpace(clientCode))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(clientCode));
            if (string.IsNullOrWhiteSpace(processingCode))
                throw new ArgumentException("Value cannot be null or whitespace.", nameof(processingCode));

            var personalSettingsViewModel = new PersonalSettingsViewModel()
            {
                LabelSortOrderId = 0,
                DaysofHistory = 0,
                LabelsToPDF = false,
                LabelsToPrinter = false,
                RowsPerPage = (int)RowsPerPage.TwentyFive
            };

            try
            {
                var settings = await _unitOfWorkService.Context.PersonalSettings.FirstOrDefaultAsync(x => x.UserId == userId);

                // There might not be settings available for a first time user!
                // Return a default model so nothing breaks
                if (settings == null)
                    return personalSettingsViewModel;

                var settingMappings = await (from x in _unitOfWorkService.Context.PersonalSettingSortOrderMappings
                                             where x.PersonalSettingId == settings.PersonalSettingId && x.ClientCode == clientCode && x.ProcessingLocationCode == processingCode
                                             select x).FirstOrDefaultAsync();
                personalSettingsViewModel.LabelSortOrderId = settingMappings?.LabelSortOrderId ?? 0;
                personalSettingsViewModel.DaysofHistory = settings.DaysofHistory;
                personalSettingsViewModel.LabelsToPDF = settings.LabelsToPDF;
                personalSettingsViewModel.LabelsToPrinter = settings.LabelsToPrinter;
                personalSettingsViewModel.RowsPerPage = settings.RowsPerPage == 0 ? (int)RowsPerPage.TwentyFive : settings.RowsPerPage;

                return personalSettingsViewModel;

            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetPersonalSettingsAsync)}; Error: {e.Message}");
                throw;
            }
        }

        /// <summary>
        /// sets the personal settings
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Set users personal settings</returns>
        public async Task<bool> SetPersonalSettingsAsync(PersonalSettingsViewModel model)
        {
            try
            {
                var settings = _unitOfWorkService.Context.PersonalSettings.Where(x => x.UserId == model.UserId);
                var settingMappings = await (from x in settings
                                             join y in _unitOfWorkService.Context.PersonalSettingSortOrderMappings on x.PersonalSettingId equals y.PersonalSettingId
                                             where y.ClientCode == model.ClientCode && y.ProcessingLocationCode == model.ProcessingLocationCode
                                             select y).FirstOrDefaultAsync();
                if (settingMappings == null)
                {
                    if (settings.Count() == 0)
                    {
                        var newSettings = new PersonalSetting()
                        {
                            UserId = model.UserId,
                            CreatedUser = model.UserId,
                            CreatedDate = DateTime.UtcNow,
                            RowsPerPage = model.RowsPerPage,
                            DaysofHistory = model.DaysofHistory,
                            LabelsToPDF = model.LabelsToPDF,
                            LabelsToPrinter = model.LabelsToPrinter
                        };
                        await _unitOfWorkService.Context.AddAsync(newSettings);
                        await _unitOfWorkService.Context.SaveChangesAsync();
                    }
                    var personalSettingId = _unitOfWorkService.Context.PersonalSettings.FirstOrDefault(x => x.UserId == model.UserId).PersonalSettingId;
                    var newPersonalSettingsMappings = new PersonalSettingSortOrderMapping()
                    {
                        PersonalSettingId = personalSettingId,
                        ClientCode = model.ClientCode,
                        ProcessingLocationCode = model.ProcessingLocationCode,
                        LabelSortOrderId = model.LabelSortOrderId,
                        CreatedUser = model.UserId,
                        CreatedDate = DateTime.UtcNow,
                        ModifiedUser = model.UserId,
                        ModifiedDate = DateTime.UtcNow,
                    };
                    await _unitOfWorkService.Context.AddAsync(newPersonalSettingsMappings);
                }
                else
                {
                    settingMappings.LabelSortOrderId = model.LabelSortOrderId;
                    settingMappings.ModifiedUser = model.UserId;
                    settingMappings.ModifiedDate = DateTime.UtcNow;

                    var personalSettings = settings.FirstOrDefault();
                    personalSettings.RowsPerPage = model.RowsPerPage;
                    personalSettings.DaysofHistory = model.DaysofHistory;
                    personalSettings.LabelsToPDF = model.LabelsToPDF;
                    personalSettings.LabelsToPrinter = model.LabelsToPrinter;

                    _unitOfWorkService.Context.Update(personalSettings);
                    _unitOfWorkService.Context.Update(settingMappings);
                }
                await _unitOfWorkService.Context.SaveChangesAsync();
                return true;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(GetPersonalSettingsAsync)}; Error: {e.Message}");
                throw;
            }
        }


        private async Task<List<LabelSortOrderViewModel>> GetLabelSortOrderListAsync(List<LabelSortOrder> entityModel)
        {
            var sortOrderClientMapping = await _unitOfWorkService.Context.SortOrderClientMappings.ToListAsync();
            var sortOrderProcessingLocationMapping = await _unitOfWorkService.Context.SortOrderProcessingLocationMappings.ToListAsync();
            return (from lso in entityModel
                    select new LabelSortOrderViewModel()
                    {
                        LabelSortOrderId = lso.LabelSortOrderId,
                        Active = lso.Active,
                        Description = lso.Description,
                        Order = lso.SortOrder,
                        SelectedClientCodeList = sortOrderClientMapping.Where(soc => soc.LabelSortOrderId == lso.LabelSortOrderId).Select(y => y.ClientCode).ToList(),
                        SelectedProcessingLocationCodeList = sortOrderProcessingLocationMapping.Where(sop => sop.LabelSortOrderId == lso.LabelSortOrderId).Select(z => z.ProcessingLocationCode).ToList(),
                    }).OrderByDescending(x => x.Active).ThenBy(x => x.Description).ToList();
        }

        private LabelSortOrder EditLabelSortOrder(LabelSortOrderViewModel model, LabelSortOrder entityModel)
        {
            var dataAsString = JsonConvert.SerializeObject(model.SortOrderFields);
            entityModel.ModifiedDate = DateTime.UtcNow;
            entityModel.ModifiedUser = model.UserId;
            entityModel.Description = model.Description;
            entityModel.Active = model.Active;
            entityModel.SortOrder = dataAsString;
            return entityModel;
        }

        private async Task DeleteLabelSortOrderMappingAsync(int labelSortOrderId)
        {
            var sortOrderClientMappingList = await _unitOfWorkService.Context.SortOrderClientMappings.Where(x => x.LabelSortOrderId == labelSortOrderId).ToListAsync();
            var sortOrderProcessingLocationMappingList = await _unitOfWorkService.Context.SortOrderProcessingLocationMappings.Where(x => x.LabelSortOrderId == labelSortOrderId).ToListAsync();
            var personalSettingSortOrderMappingList = await _unitOfWorkService.Context.PersonalSettingSortOrderMappings.Where(x => x.LabelSortOrderId == labelSortOrderId).ToListAsync();

            _unitOfWorkService.Context.SortOrderClientMappings.RemoveRange(sortOrderClientMappingList);
            _unitOfWorkService.Context.SortOrderProcessingLocationMappings.RemoveRange(sortOrderProcessingLocationMappingList);
            _unitOfWorkService.Context.PersonalSettingSortOrderMappings.RemoveRange(personalSettingSortOrderMappingList);
            _unitOfWorkService.SaveChanges();
        }

        private async Task AddLabelSortOrderMappingAsync(LabelSortOrderViewModel model)
        {
            List<SortOrderClientMapping> sortOrderClientMapping = model.SelectedClientCodeList.Select(x => new SortOrderClientMapping
            {
                LabelSortOrderId = model.LabelSortOrderId,
                ClientCode = x.ToString(),
                CreatedUser = model.UserId,
                CreatedDate = DateTime.Now,
                ModifiedUser = model.UserId,
                ModifiedDate = DateTime.Now,
            }).ToList();
            List<SortOrderProcessingLocationMapping> sortOrderProcessingLocationMapping = model.SelectedProcessingLocationCodeList.Select(x => new SortOrderProcessingLocationMapping
            {
                LabelSortOrderId = model.LabelSortOrderId,
                ProcessingLocationCode = x.ToString(),
                CreatedUser = model.UserId,
                CreatedDate = DateTime.Now,
                ModifiedUser = model.UserId,
                ModifiedDate = DateTime.Now,
            }).ToList();

            await _unitOfWorkService.Context.AddRangeAsync(sortOrderClientMapping);
            await _unitOfWorkService.Context.AddRangeAsync(sortOrderProcessingLocationMapping);
            _unitOfWorkService.SaveChanges();
        }

        private async Task<List<ImportLayoutViewModel>> GetLabelImportListAsync(List<LabelImport> entityModel, string dmvStateCode = "")
        {
            var clientMapping = await _unitOfWorkService.Context.LabelImportClientMappings.ToListAsync();
            var processingLocationMapping = await _unitOfWorkService.Context.LabelImportProcessingLocationMappings.ToListAsync();
            return (from y in entityModel
                    select new ImportLayoutViewModel()
                    {
                        StateProvinceCode = dmvStateCode,
                        LabelImportId = y.LabelImportId,
                        Active = y.Active,
                        GenerateBagLabels = y.GenerateBagLabels,
                        CreatedUser = y.CreatedUser,
                        CreatedDate = y.CreatedDate,
                        Description = y.Description,
                        LabelTypeId = y.LabelTypeId,
                        LabelType = y.LabelTypeId != 0 ? _unitOfWorkService.Context.LabelTypes.FirstOrDefault(x => x.LabelTypeId == y.LabelTypeId).DisplayName : string.Empty,
                        SelectedClientCodeList = clientMapping.Where(soc => soc.LabelImportId == y.LabelImportId).Select(y => y.ClientCode).ToList(),
                        SelectedProcessingLocationCodeList = processingLocationMapping.Where(sop => sop.LabelImportId == y.LabelImportId).Select(z => z.ProcessingLocationCode).ToList(),
                    }).OrderByDescending(x => x.Active).ThenBy(x => x.Description).ToList();
        }

        private async Task DeleteAddLabelImportMappingAsync(ImportLayoutViewModel model)
        {
            var oldClientMappingList = await _unitOfWorkService.Context.LabelImportClientMappings.Where(x => x.LabelImportId == model.LabelImportId).ToListAsync();
            var oldProcessingLocationMappingList = await _unitOfWorkService.Context.LabelImportProcessingLocationMappings.Where(x => x.LabelImportId == model.LabelImportId).ToListAsync();

            var removeClientList = oldClientMappingList.Where(x => !model.SelectedClientCodeList.Contains(x.ClientCode)).ToList();
            var removeProcessingList = oldProcessingLocationMappingList.Where(x => !model.SelectedProcessingLocationCodeList.Contains(x.ProcessingLocationCode)).ToList();

            _unitOfWorkService.Context.LabelImportClientMappings.RemoveRange(removeClientList);
            _unitOfWorkService.Context.LabelImportProcessingLocationMappings.RemoveRange(removeProcessingList);
            _unitOfWorkService.SaveChanges();

            model.SelectedClientCodeList = model.SelectedClientCodeList.Where(x => !oldClientMappingList.Select(x => x.ClientCode).Contains(x)).ToList();
            model.SelectedProcessingLocationCodeList = model.SelectedProcessingLocationCodeList.Where(x => !oldProcessingLocationMappingList.Select(x => x.ProcessingLocationCode).Contains(x)).ToList();
            await AddLabelImportMappingAsync(model);
        }

        private async Task AddLabelImportMappingAsync(ImportLayoutViewModel model)
        {
            List<LabelImportClientMapping> clientMapping = model.SelectedClientCodeList.Select(x => new LabelImportClientMapping
            {
                LabelImportId = model.LabelImportId,
                ClientCode = x.ToString(),
                CreatedUser = model.UserId,
                CreatedDate = DateTime.Now,
                ModifiedUser = model.UserId,
                ModifiedDate = DateTime.Now,
            }).ToList();
            List<LabelImportProcessingLocationMapping> processingLocationMapping = model.SelectedProcessingLocationCodeList.Select(x => new LabelImportProcessingLocationMapping
            {
                LabelImportId = model.LabelImportId,
                ProcessingLocationCode = x.ToString(),
                CreatedUser = model.UserId,
                CreatedDate = DateTime.Now,
                ModifiedUser = model.UserId,
                ModifiedDate = DateTime.Now,
            }).ToList();

            await _unitOfWorkService.Context.AddRangeAsync(clientMapping);
            await _unitOfWorkService.Context.AddRangeAsync(processingLocationMapping);
            _unitOfWorkService.SaveChanges();
        }
    }
}
