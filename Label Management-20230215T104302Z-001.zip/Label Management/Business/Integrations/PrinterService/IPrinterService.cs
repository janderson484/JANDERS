using System.Collections.Generic;
using System.Threading.Tasks;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Business.Integrations.PrinterService
{
    public interface IPrinterService
    {
        Task<UserPrintersViewModel> GetUserConfiguredPrintersAsync(string userName, int labelTypeId, string clientCode, string processingLocationCode);
        Task<List<Model.DTO.PrinterLabelSetting>> GetPrinterLabelSettingsAsync(List<int> printerIds, int labelTypeId);
        Task<Model.DTO.PrinterLabelSetting> UpdatePrinterLabelSettingsAsync(Model.DTO.PrinterLabelSetting labelSetting);
        void TestPrinterConnection(Model.DTO.Printer printer);
        Task<PrintLabelRequestViewModel> SubmitPrintLabelRequestAsync(PrintLabelsViewModel model);
        Task<List<int>> GetJobInProgress(List<int> labelsIds, string clientCode, LM.Model.DTO.Printer selectedPrinter, string processName);
        Task<PrintResponseModel> PrintDocumentAsync(int printLabelRequestId, bool isPrintNeeded, bool isPdfNeeded);
        Task<ViewLabelPrintersConfigurationViewModel> GetLabelPrinterAssignmentAsync(UserProfileSettingsViewModel baseRequest);
        Task<PrinterAssignViewModel> GetPrinterAssignmentDetailsAsync(PrinterAssignViewModel model);
        Task<bool> AddUpdatePrinterAssignmentSaveAsync(PrinterAssignViewModel model);
        Task<bool> UpdatePrinterAssignmentStatusAsync(PrinterAssignViewModel model);
        Task<ViewLabelPrintersConfigurationViewModel> GetLabelPrintersAsync(UserProfileSettingsViewModel baseRequest);
        Task<PrinterAssignViewModel> GetPrinterDetailsAsync(PrinterAssignViewModel model);
        Task<bool> AddUpdatePrinterSaveAsync(PrinterAssignViewModel model);
        Task<bool> UpdatePrinterStatusAsync(PrinterAssignViewModel model);
        Task<bool> InsertPrinterLabelSettingsAsync(PrinterLabelSettingViewModel labelSetting);
        Task<List<DTO.Label>> IncrementLabelPrintCountsAsync(List<int> labelIds);
        void DeletePrintRequest(int printLabelRequestId);
    }
}
