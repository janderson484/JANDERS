using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Threading.Tasks;
using Aspose.Pdf;
using Aspose.Pdf.Text;
using AutoMapper;
using Honeywell.Connection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Log = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.Log;
using Printer = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.Printer;
using PrinterLabelSetting = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrinterLabelSetting;
using PrintLabelRequest = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrintLabelRequest;
using Aspose.Pdf.Forms;
using Aspose.BarCode.Generation;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.Core.Common.Data.ExtensionMethods;
using System.Transactions;

namespace VM.FleetServices.TnR.LM.Business.Integrations.PrinterService
{
    public class PrinterService : IPrinterService
    {
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILogger<PrinterService> _logger;
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly IAuthService _authenticationService;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly HttpClient _httpClient;
        private readonly IMapper _mapper;

        public PrinterService(IUnitOfWorkService<LabelModel> unitOfWorkService,
                              ILogger<PrinterService> logger, IServiceScopeFactory serviceScopeFactory,
                              IAuthService authenticationService,
                              IHttpClientFactory httpClientFactory, IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IMapper mapper)
        {
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
            _mapper = mapper;

            /*
            // Initialize Aspose license object
            var license = new Aspose.Pdf.License();
            var barcodeLicense = new Aspose.BarCode.License();
            // Set license
            license.SetLicense("VM.FleetServices.TnR.LM.Business.Aspose.Total.lic");
            barcodeLicense.SetLicense("VM.FleetServices.TnR.LM.Business.Aspose.Total.lic");
            */

            _serviceScopeFactory = serviceScopeFactory;
            _authenticationService = authenticationService;
            _apiSettings = apiSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
            _httpClient = httpClientFactory.CreateClient();
        }

        /// <summary>
        /// Get Printers for a given User
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="labelTypeId"></param>
        /// <returns></returns>
        public async Task<UserPrintersViewModel> GetUserConfiguredPrintersAsync(string userName, int labelTypeId, string clientCode, string processingLocationCode)
        {
            var printers = new UserPrintersViewModel();

            try
            {
                var userPrinters = await (from u in _unitOfWorkService.Context.PrinterUsers
                                         join c in _unitOfWorkService.Context.PrinterUserClientMappings on u.PrinterUserId equals c.PrinterUserId
                                         join p in _unitOfWorkService.Context.PrinterUserProcessingLocationMappings on u.PrinterUserId equals p.PrinterUserId
                                         where u.UserName.Equals(userName) && u.Active && c.ClientCode.Equals(clientCode) && p.ProcessingLocationCode.Equals(processingLocationCode)
                                         select u).ToListAsync() ;

                //var userPrinters = await _unitOfWorkService.GetRepositoryAsync<PrinterUser>().GetListAsync(x => x.UserName.Equals(userName) && x.Active == true);
                var userPrinterIds = userPrinters.Select(x => x.PrinterId).ToList();

                var userDocTypePrinters = await _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().GetListAsync(x => x.LabelTypeId.Equals(labelTypeId) && userPrinterIds.Contains(x.PrinterId));
                var docTypePrinterIds = userDocTypePrinters.Select(x => x.PrinterId).ToList();

                var results = await _unitOfWorkService.GetRepositoryAsync<Printer>().GetListAsync(x => docTypePrinterIds.Contains(x.PrinterId));
                printers.Printers = _mapper.Map<List<Model.DTO.Printer>>(results);
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetUserConfiguredPrintersAsync)}; Error: {e.Message}");
                printers.Printers = null;
            }

            return printers;
        }

        /// <summary>
        /// Get Label Settings for a given Printer
        /// </summary>
        /// <param name="printerIds"></param>
        /// <param name="labelTypeId"></param>
        /// <returns></returns>
        public async Task<List<Model.DTO.PrinterLabelSetting>> GetPrinterLabelSettingsAsync(List<int> printerIds, int labelTypeId)
        {
            var printerLabelSettings = new List<Model.DTO.PrinterLabelSetting>();

            try
            {
                var results = await _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().GetListAsync(x => x.LabelTypeId.Equals(labelTypeId) && printerIds.Contains(x.PrinterId));
                printerLabelSettings = _mapper.Map<List<Model.DTO.PrinterLabelSetting>>(results);
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetUserConfiguredPrintersAsync)}; Error: {e.Message}");
                printerLabelSettings = null;
            }

            return printerLabelSettings;
        }

        /// <summary>
        /// Update a given Printer's Label Settings
        /// </summary>
        /// <param name="labelSetting"></param>
        /// <returns></returns>
        public async Task<Model.DTO.PrinterLabelSetting> UpdatePrinterLabelSettingsAsync(Model.DTO.PrinterLabelSetting labelSetting)
        {
            Model.DTO.PrinterLabelSetting response;

            try
            {
                var printerLabelSetting = await _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().SingleAsync(a => a.PrinterLabelSettingId == labelSetting.PrinterLabelSettingId);

                printerLabelSetting.VerticalMargin = labelSetting.VerticalMargin;
                printerLabelSetting.BottomMargin = labelSetting.BottomMargin;
                printerLabelSetting.LeftMargin = labelSetting.LeftMargin;
                printerLabelSetting.HorizontalMargin = labelSetting.HorizontalMargin;

                _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().UpdateAsync(printerLabelSetting);
                _unitOfWorkService.SaveChanges();

                response = _mapper.Map<Model.DTO.PrinterLabelSetting>(printerLabelSetting);
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetUserConfiguredPrintersAsync)}; Error: {e.Message}");
                throw;
            }

            return response;
        }

        public void TestPrinterConnection(Model.DTO.Printer printer)
        {
            try
            {
                ConnectionBase conn = Connection_TCP.CreateClient(printer.IPAddress, Int32.Parse(printer.PortNumber));
                conn.Open();
                conn.Close();
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(TestPrinterConnection)}; Error: {e.Message}");
                throw;
            }
        }

        /// <summary>
        /// To submit print label request
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<PrintLabelRequestViewModel> SubmitPrintLabelRequestAsync(PrintLabelsViewModel model)
        {
            try
            {
                var printLabelRequestModel = new PrintLabelRequestViewModel();

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();

                    var nonActiveLabels = context.Labels.Where(lbl => model.LabelIds.Contains(lbl.LabelId) && lbl.LabelStatusTypeId != (int)LabelStatusTypes.Active).ToList();

                    if (nonActiveLabels.Count > 0)
                        throw new Exception("One or more of the labels in this print request are in a non-Active status");

                    var currentLogDate = DateTime.Now;

                    var log = new Model.DTO.Log
                    {
                        ProcessName = model.LabelType == (int)Labeltypes.Unit? ProcessNames.PrintUnitLabels : ProcessNames.PrintBagLabels,
                        TotalCount = model.LabelIds.Count(),
                        SuccessfulCount = 0,
                        ErrorCount = 0,
                        WarningCount = 0,
                        Status = JobLogStatus.Ready.ToString(),
                        CreatedUser = model.UserId,
                        CreatedDate = currentLogDate,
                        ModifiedUser = model.UserId,
                        ModifiedDate = currentLogDate,
                        ProcessStartDate = currentLogDate,
                        ClientCode = model.ClientCode,
                        ProcessType = ProcessTypes.Export.ToString(),
                        ProcessingLocationCode = model.ProcessingLocationCode
                    };

                    // create log
                    var logEntity = await InsertLogAsync(context, log);

                    log.LogId = logEntity.LogId;

                    var msg = CreateDynamicJsonMessageForSendLabels(logEntity, model);

                    var printLabelRequest = new PrintLabelRequest
                    {
                        Request = msg,
                        PrinterId = model.SelectedPrinter.PrinterId,
                        PrintStatus = LabelPrintStatus.Ready.ToString(),
                        ClientCode = model.ClientCode,
                        CreatedUser = model.UserId,
                        ModifiedUser = model.UserId,
                        CreatedDate = DateTime.Now,
                        ModifiedDate = DateTime.Now
                    };

                    await context.PrintLabelRequests.AddAsync(printLabelRequest);
                    await context.SaveChangesAsync();

                    printLabelRequestModel.Log = log;
                    printLabelRequestModel.PrintLabelRequestId = printLabelRequest.PrintLabelRequestId;

                    return printLabelRequestModel;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(SubmitPrintLabelRequestAsync)}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// check any job is running
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<List<int>> GetJobInProgress(List<int> labelsIds, string clientCode,LM.Model.DTO.Printer selectedPrinter ,string processName)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();
                    var labelIds = new List<int>();

                    var printer = await _unitOfWorkService.Context.PrintLabelRequests.Where(x => x.PrinterId == selectedPrinter.PrinterId).FirstOrDefaultAsync();

                    if (printer != null)
                    {
                        throw new Exception("Already a request in progress for the selected printer");
                    }

                    var existingPrintingRequest = await _unitOfWorkService.Context.LoadStoredProc("GetInProgressPrinterJobs")
                   .WithSqlParam("@clientCode", clientCode)
                   .WithSqlParam("@processName", processName)
                   .WithSqlParam("@labelIds", string.Join(",", labelsIds))
                   .ExecuteStoredProcedureAsync<PrintLabelRequest>();

                    if (existingPrintingRequest.Any())
                    {
                        var logIds = existingPrintingRequest.Select(x => JsonConvert.DeserializeObject<Model.DTO.PrintLabelMessageRequest>(x.Request).Action[ServiceBusMessageProperties.LogId])?.ToList();
                        var logInprogressOrReady = logIds.Any() ? context.Logs.Where(x => (logIds.Contains(Convert.ToString(x.LogId)) && (x.Status == JobLogStatus.Ready.ToString() || x.Status == JobLogStatus.InProgress.ToString()) && x.ProcessEndDate == null))?.Select(z => z.LogId).ToList() : new List<int>();
                        if (logInprogressOrReady.Any())
                        {
                            var requests = existingPrintingRequest.Where(x => logInprogressOrReady.Contains(Convert.ToInt32(JsonConvert.DeserializeObject<Model.DTO.PrintLabelMessageRequest>(x.Request).Action[ServiceBusMessageProperties.LogId]))).ToList();
                            var result = requests.Select(x => JsonConvert.DeserializeObject<Model.DTO.PrintLabelMessageRequest>(x.Request)).ToList();
                            labelIds = result.SelectMany(x => x.LabelIds).Where(x => labelsIds.Contains(x)).ToList();
                        }
                    }

                    return labelIds.Distinct().ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(GetJobInProgress)}: {ex.Message}");
                throw ex;
            }
        }

        private async Task<Log> InsertLogAsync(ILabelModel context, Model.DTO.Log log)
        {
            var logEntity = _mapper.Map<Log>(log);

            try
            {
                log.ProcessStartDate = DateTime.Now;
                await context.Logs.AddAsync(logEntity);
                await context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(InsertLogAsync)}; Error: {ex.Message}");
                throw;
            }

            return logEntity;
        }

        private string CreateDynamicJsonMessageForSendLabels(Log log, PrintLabelsViewModel model)
        {
            var messageDictionary = new Model.DTO.PrintLabelMessageRequest();

            messageDictionary.Data.Add(ServiceBusMessageProperties.ClientCode, log.ClientCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.UserName, log.CreatedUser);
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionCode, log.ProcessName);
            messageDictionary.Action.Add(ServiceBusMessageProperties.LogId, log.LogId.ToString());
            messageDictionary.LabelIds = model.LabelIds;
            messageDictionary.LabelType = model.LabelType;
            messageDictionary.SelectedPrinterLabelSettingId = model.SelectedPrinterLabelSettings.PrinterLabelSettingId;
            messageDictionary.SelectedPrinterId = model.SelectedPrinter.PrinterId;
            var msgText = JsonConvert.SerializeObject(messageDictionary);
            return msgText;
        }

        /// <summary>
        /// Get Label Printer Assignment
        /// </summary>
        /// <returns>ViewLabelPrintersConfigurationViewModel</returns>
        public async Task<ViewLabelPrintersConfigurationViewModel> GetLabelPrinterAssignmentAsync(UserProfileSettingsViewModel baseRequest)
        {
            var rowsPerPage = baseRequest.SelectedRowsPerPage == 0 ? baseRequest.DefaultRowsPerPage : (int)baseRequest.SelectedRowsPerPage;
            var printers = new ViewLabelPrintersConfigurationViewModel() { TotalCount = 0 };
            var res = new List<PrinterAssignmentResponseModel>();

            try
            {
                var results = await _unitOfWorkService.GetRepositoryAsync<Printer>().GetListAsync();
                if (!baseRequest.IncludeDisabled)
                {
                    res = await (from p in _unitOfWorkService.Context.Printers
                                 join u in _unitOfWorkService.Context.PrinterUsers on p.PrinterId equals u.PrinterId
                                 where p.PrinterId.Equals(u.PrinterId)// && u.ClientCode.Equals(baseRequest.ClientCode) && u.ProcessingLocationCode.Equals(baseRequest.ProcessingLocationCode)
                                                                      && u.Active
                                 select new PrinterAssignmentResponseModel() { PrinterUserId = u.PrinterUserId, PrinterId = p.PrinterId, DisplayName = p.DisplayName, IPAddress = p.IPAddress, PortNumber = p.PortNumber, Active = u.Active, UserId = u.UserName }).OrderBy(a=>a.DisplayName).ToListAsync();
                }
                else
                {
                    res = await (from p in _unitOfWorkService.Context.Printers
                                 join u in _unitOfWorkService.Context.PrinterUsers on p.PrinterId equals u.PrinterId
                                 where p.PrinterId.Equals(u.PrinterId) // && u.ClientCode.Equals(baseRequest.ClientCode) && u.ProcessingLocationCode.Equals(baseRequest.ProcessingLocationCode)
                                 select new PrinterAssignmentResponseModel() { PrinterUserId = u.PrinterUserId, PrinterId = p.PrinterId, DisplayName = p.DisplayName, IPAddress = p.IPAddress, PortNumber = p.PortNumber, Active = u.Active, UserId = u.UserName }).OrderByDescending(x => x.Active).ThenBy(a => a.DisplayName).ToListAsync();
                }

                foreach(var printer in res)
                {
                    printer.SelectedClientCodeList = await _unitOfWorkService.Context.PrinterUserClientMappings.Where(a => a.PrinterUserId.Equals(printer.PrinterUserId)).Select(x => x.ClientCode).ToListAsync();
                    printer.ClientCode = string.Join(", ", printer.SelectedClientCodeList);
                    printer.SelectedProcessingLocationCodeList = await _unitOfWorkService.Context.PrinterUserProcessingLocationMappings.Where(a => a.PrinterUserId.Equals(printer.PrinterUserId)).Select(x => x.ProcessingLocationCode).ToListAsync();
                    printer.ProcessingLocationCode = string.Join(", ", printer.SelectedProcessingLocationCodeList);
                }


                printers.TotalCount = res.Count;

                printers.Printers = res.Skip((baseRequest.PageNumber - 1) * rowsPerPage).Take(rowsPerPage).ToList();

            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetLabelPrinterAssignmentAsync)}; Error: {e.Message}");
                printers.Printers = null;
            }

            return printers;
        }

        /// <summary>
        /// Get Label Assignment Details
        /// </summary>
        /// <param name="model"></param>
        /// <param name="PrinterAssignViewModel"></param>
        /// <returns></returns>
        public async Task<PrinterAssignViewModel> GetPrinterAssignmentDetailsAsync(PrinterAssignViewModel model)
        {
            var printerAssignmentDetailsViewModel = new PrinterAssignViewModel();

            try
            {
                var res = await (from p in _unitOfWorkService.Context.Printers
                                 join u in _unitOfWorkService.Context.PrinterUsers on p.PrinterId equals u.PrinterId
                                 where u.PrinterUserId.Equals(model.PrinterUserId) //&& u.Active == true
                                 select new PrinterAssignViewModel() { PrinterUserId = u.PrinterUserId, PrinterId = p.PrinterId, DisplayName = p.DisplayName, UserId = u.UserName, Active = u.Active }).ToListAsync();

                if (model.PrinterUserId != 0 && res.Count > 0)
                {

                    foreach (var printerAssignment in res)
                    {
                        printerAssignment.SelectedClientCodeList = _unitOfWorkService.Context.PrinterUserClientMappings.Where(a => a.PrinterUserId == printerAssignment.PrinterUserId).Select(x => x.ClientCode).ToList();
                        printerAssignment.SelectedProcessingLocationCodeList = _unitOfWorkService.Context.PrinterUserProcessingLocationMappings.Where(a => a.PrinterUserId == printerAssignment.PrinterUserId).Select(x => x.ProcessingLocationCode).ToList();
                    }
                    printerAssignmentDetailsViewModel.PrinterId = res.FirstOrDefault().PrinterId;
                    printerAssignmentDetailsViewModel.PrinterUserId = res.FirstOrDefault().PrinterUserId;
                    printerAssignmentDetailsViewModel.DisplayName = res.FirstOrDefault().DisplayName;
                    printerAssignmentDetailsViewModel.UserId = res.FirstOrDefault().UserId;
                    printerAssignmentDetailsViewModel.Active = res.FirstOrDefault().Active;
                    printerAssignmentDetailsViewModel.SelectedClientCodeList = res.FirstOrDefault().SelectedClientCodeList;
                    printerAssignmentDetailsViewModel.SelectedProcessingLocationCodeList = res.FirstOrDefault().SelectedProcessingLocationCodeList;
                }
                var results = await (from p in _unitOfWorkService.Context.Printers
                                     where p.Active == true
                                     select new SelectListItem { Text = p.DisplayName, Value = p.PrinterId.ToString() }).ToListAsync();

                printerAssignmentDetailsViewModel.Printers = results;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetPrinterAssignmentDetailsAsync)}; Error: {e.Message}");
                printerAssignmentDetailsViewModel.Printers = null;
            }

            return printerAssignmentDetailsViewModel;
        }

        /// <summary>
        /// Add/Update Label Printer Assignment
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> AddUpdatePrinterAssignmentSaveAsync(PrinterAssignViewModel model)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var isUserExist = await _unitOfWorkService.Context.PrinterUsers.Where(x => x.UserName.Trim().ToLower() == model.UserId.Trim().ToLower() && x.PrinterId == model.PrinterId).ToListAsync();

                if (isUserExist != null && isUserExist.Count > 0)
                {
                    if (model.PrinterUserId == 0 || model.PrinterUserId != isUserExist.FirstOrDefault().PrinterUserId)
                    {
                        throw new Exception("Cannot have duplicate printer.");
                    }
                }
                if (model.PrinterUserId == 0)
                {
                    PrinterUser assignPrinter = new PrinterUser();

                    assignPrinter.PrinterId = model.PrinterId;
                    assignPrinter.UserName = model.UserId;
                    //assignPrinter.ClientCode = model.ClientCode;
                    //assignPrinter.ProcessingLocationCode = model.ProcessingLocationCode;
                    assignPrinter.Active = true;
                    assignPrinter.CreatedUser = model.UserName;
                    assignPrinter.CreatedDate = DateTime.UtcNow;
                    assignPrinter.ModifiedUser = model.UserName;
                    assignPrinter.ModifiedDate = DateTime.UtcNow;

                        await _unitOfWorkService.GetRepositoryAsync<PrinterUser>().AddAsync(assignPrinter);
                    _unitOfWorkService.Context.SaveChanges();

                    var clientMappings = new List<PrinterUserClientMapping>();

                    foreach(var client in model.SelectedClientCodeList)
                    {
                        var clientPrinterUserMapping = new PrinterUserClientMapping();

                        clientPrinterUserMapping.ClientCode = client;
                        clientPrinterUserMapping.PrinterUserId = assignPrinter.PrinterUserId;
                        clientPrinterUserMapping.CreatedUser = model.UserName;
                        clientPrinterUserMapping.CreatedDate = DateTime.UtcNow;
                        clientPrinterUserMapping.ModifiedUser = model.UserName;
                        clientPrinterUserMapping.ModifiedDate = DateTime.UtcNow;
                        clientMappings.Add(clientPrinterUserMapping);
                    }

                        await _unitOfWorkService.GetRepositoryAsync<PrinterUserClientMapping>().AddAsync(clientMappings.ToArray());
                        _unitOfWorkService.SaveChanges();

                        var processingLocationMappings = new List<PrinterUserProcessingLocationMapping>();

                        foreach (var processingLocation in model.SelectedProcessingLocationCodeList)
                        {
                            var processingLocationPrinterUserMapping = new PrinterUserProcessingLocationMapping();

                            processingLocationPrinterUserMapping.ProcessingLocationCode = processingLocation;
                            processingLocationPrinterUserMapping.PrinterUserId = assignPrinter.PrinterUserId;
                            processingLocationPrinterUserMapping.CreatedUser = model.UserName;
                            processingLocationPrinterUserMapping.CreatedDate = DateTime.UtcNow;
                            processingLocationPrinterUserMapping.ModifiedUser = model.UserName;
                            processingLocationPrinterUserMapping.ModifiedDate = DateTime.UtcNow;
                            processingLocationMappings.Add(processingLocationPrinterUserMapping);
                        }

                        await _unitOfWorkService.GetRepositoryAsync<PrinterUserProcessingLocationMapping>().AddAsync(processingLocationMappings.ToArray());
                        _unitOfWorkService.SaveChanges();
                }
                else
                {
                    var assignPrinter = await _unitOfWorkService.Context.PrinterUsers.FirstOrDefaultAsync(x => x.PrinterUserId == model.PrinterUserId);
                    var printerUserClientMappings = await _unitOfWorkService.Context.PrinterUserClientMappings.Where(x => x.PrinterUserId == model.PrinterUserId).Select(a=>a.ClientCode).ToListAsync();
                    var printerUserProcessingLocationMappings = await _unitOfWorkService.Context.PrinterUserProcessingLocationMappings.Where(x => x.PrinterUserId == model.PrinterUserId).Select(a=>a.ProcessingLocationCode).ToListAsync();

                    var clientsToAdd = model.SelectedClientCodeList.Where(a => !printerUserClientMappings.Contains(a)).ToList();
                    var clientsToDelete = printerUserClientMappings.Where(a => !model.SelectedClientCodeList.Contains(a)).ToList();

                    var processingLocaionsToAdd = model.SelectedProcessingLocationCodeList.Where(a => !printerUserProcessingLocationMappings.Contains(a)).ToList();
                    var processingLocationsToDelete = printerUserProcessingLocationMappings.Where(a => !model.SelectedProcessingLocationCodeList.Contains(a)).ToList();



                    if (assignPrinter != null)
                    {
                        assignPrinter.PrinterId = model.PrinterId;
                        assignPrinter.UserName = model.UserId;
                        assignPrinter.Active = model.Active;
                        assignPrinter.ModifiedUser = model.UserName;
                        assignPrinter.ModifiedDate = DateTime.UtcNow;
                        _unitOfWorkService.GetRepositoryAsync<PrinterUser>().UpdateAsync(assignPrinter);
                        _unitOfWorkService.SaveChanges();

                        var clientDeleteEntity = _unitOfWorkService.Context.PrinterUserClientMappings.Where(a => clientsToDelete.Contains(a.ClientCode) && a.PrinterUserId.Equals(assignPrinter.PrinterUserId));
                            var clientAddEntity = new List<PrinterUserClientMapping>();
                            foreach(var client in clientsToAdd)
                            {
                                var clientPrinterUserMapping = new PrinterUserClientMapping();

                                clientPrinterUserMapping.ClientCode = client;
                                clientPrinterUserMapping.PrinterUserId = assignPrinter.PrinterUserId;
                                clientPrinterUserMapping.CreatedUser = model.UserName;
                                clientPrinterUserMapping.CreatedDate = DateTime.UtcNow;
                                clientPrinterUserMapping.ModifiedUser = model.UserName;
                                clientPrinterUserMapping.ModifiedDate = DateTime.UtcNow;
                                clientAddEntity.Add(clientPrinterUserMapping);
                            }

                            await _unitOfWorkService.GetRepositoryAsync<PrinterUserClientMapping>().AddAsync(clientAddEntity.ToArray());
                            _unitOfWorkService.GetRepositoryAsync<PrinterUserClientMapping>().DeleteAsync(clientDeleteEntity.ToArray());


                            var processingLocationDeleteEntity = _unitOfWorkService.Context.PrinterUserProcessingLocationMappings.Where(a => processingLocationsToDelete.Contains(a.ProcessingLocationCode) && a.PrinterUserId.Equals(assignPrinter.PrinterUserId));
                            var processingLocationAddEntity = new List<PrinterUserProcessingLocationMapping>();

                            foreach (var processingLocation in processingLocaionsToAdd)
                            {
                                var processingLocationPrinterUserMapping = new PrinterUserProcessingLocationMapping();

                                processingLocationPrinterUserMapping.ProcessingLocationCode = processingLocation;
                                processingLocationPrinterUserMapping.PrinterUserId = assignPrinter.PrinterUserId;
                                processingLocationPrinterUserMapping.CreatedUser = model.UserName;
                                processingLocationPrinterUserMapping.CreatedDate = DateTime.UtcNow;
                                processingLocationPrinterUserMapping.ModifiedUser = model.UserName;
                                processingLocationPrinterUserMapping.ModifiedDate = DateTime.UtcNow;
                                processingLocationAddEntity.Add(processingLocationPrinterUserMapping);
                            }
                            await _unitOfWorkService.GetRepositoryAsync<PrinterUserProcessingLocationMapping>().AddAsync(processingLocationAddEntity.ToArray());
                            _unitOfWorkService.GetRepositoryAsync<PrinterUserProcessingLocationMapping>().DeleteAsync(processingLocationDeleteEntity.ToArray());

                            _unitOfWorkService.SaveChanges();


                        }
                }
                     
                    scope.Complete();
                    return true;
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(LabelSortOrderViewModel)}; Error: {e.Message}");
                throw e;
            }
        }

        /// <summary>
        /// updates  the printer assignment status
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> UpdatePrinterAssignmentStatusAsync(PrinterAssignViewModel model)
        {
            var assignPrinterViewModel = await _unitOfWorkService.Context.PrinterUsers.FirstOrDefaultAsync(x => x.PrinterUserId == model.PrinterUserId);
            if (assignPrinterViewModel != null)
            {
                assignPrinterViewModel.Active = model.Active;
                _unitOfWorkService.GetRepositoryAsync<PrinterUser>().UpdateAsync(assignPrinterViewModel);
                _unitOfWorkService.SaveChanges();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Get Label Printers
        /// </summary>
        /// <returns>ViewLabelPrintersConfigurationViewModel</returns>
        public async Task<ViewLabelPrintersConfigurationViewModel> GetLabelPrintersAsync(UserProfileSettingsViewModel baseRequest)
        {
            var rowsPerPage = baseRequest.SelectedRowsPerPage == 0 ? baseRequest.DefaultRowsPerPage : (int)baseRequest.SelectedRowsPerPage;
            var printers = new ViewLabelPrintersConfigurationViewModel() { TotalCount = 0 };
            var res = new List<PrinterAssignmentResponseModel>();

            try
            {
                var results = await _unitOfWorkService.GetRepositoryAsync<Printer>().GetListAsync();

                if (!baseRequest.IncludeDisabled)
                {
                    res = await (from p in _unitOfWorkService.Context.Printers
                                 where p.Active
                                 select new PrinterAssignmentResponseModel() { PrinterId = p.PrinterId, DisplayName = p.DisplayName, IPAddress = p.IPAddress, PortNumber = p.PortNumber, Active = p.Active }).OrderBy(a=>a.DisplayName).ToListAsync();
                }
                else
                {
                    res = await (from p in _unitOfWorkService.Context.Printers                                 
                                 select new PrinterAssignmentResponseModel() { PrinterId = p.PrinterId, DisplayName = p.DisplayName, IPAddress = p.IPAddress, PortNumber = p.PortNumber, Active = p.Active }).OrderByDescending(x => x.Active).ThenBy(a => a.DisplayName).ToListAsync();
                }
                printers.TotalCount = res.Count;

                printers.Printers = res.Skip((baseRequest.PageNumber - 1) * rowsPerPage).Take(rowsPerPage).ToList();

            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetLabelPrinterAssignmentAsync)}; Error: {e.Message}");
                printers.Printers = null;
            }

            return printers;
        }

        /// <summary>
        /// Get Label Printer Assignment Details
        /// </summary>
        /// <param name="model"></param>
        /// <param name="PrinterAssignViewModel"></param>
        /// <returns></returns>
        public async Task<PrinterAssignViewModel> GetPrinterDetailsAsync(PrinterAssignViewModel model)
        {
            var printerDetailsViewModel = new PrinterAssignViewModel();

            try
            {
                var res = await (from p in _unitOfWorkService.Context.Printers
                                 where p.PrinterId.Equals(model.PrinterId)
                                 select new PrinterAssignViewModel() { PrinterId = p.PrinterId, DisplayName = p.DisplayName, IPAddress = p.IPAddress, PortNumber = p.PortNumber, Active = p.Active }).ToListAsync();

                if (model.PrinterId != 0 && res.Count > 0)
                {
                    printerDetailsViewModel.PrinterId = res.FirstOrDefault().PrinterId;
                    printerDetailsViewModel.DisplayName = res.FirstOrDefault().DisplayName;
                    printerDetailsViewModel.IPAddress = res.FirstOrDefault().IPAddress;
                    printerDetailsViewModel.PortNumber = res.FirstOrDefault().PortNumber;
                    printerDetailsViewModel.Active = res.FirstOrDefault().Active;

                    var labelTypeIds = _unitOfWorkService.Context.PrinterLabelSettings.Where(a => a.PrinterId.Equals(res.FirstOrDefault().PrinterId)).Select(x => x.LabelTypeId).ToList();
                    
                    printerDetailsViewModel.SelectedLabeltypes = _unitOfWorkService.Context.LabelTypes.Where(x => labelTypeIds.Contains(x.LabelTypeId)).Select(a => a.DisplayName).ToList();
                }
                printerDetailsViewModel.LabelTypeData = _unitOfWorkService.Context.LabelTypes.Where(x => x.Active).Select(a => a.DisplayName).ToList();
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(GetPrinterDetailsAsync)}; Error: {e.Message}");
            }

            return printerDetailsViewModel;
        }

        /// <summary>
        /// Add/Update the label printer
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> AddUpdatePrinterSaveAsync(PrinterAssignViewModel model)
        {
            try
            {
                var selectedLabelTypes = new List<string>();
                var selectedLabelTypeIds = new List<int>();
                if (model.SelectedLabeltypes.Count > 0)
                {
                    if (model.SelectedLabeltypes[0] !=null)
                    selectedLabelTypes = model.SelectedLabeltypes[0].Split(',')?.ToList();
                }

                selectedLabelTypeIds = _unitOfWorkService.Context.LabelTypes.Where(x => selectedLabelTypes.Contains(x.DisplayName)).Select(a => a.LabelTypeId).ToList();


                PrinterLabelSettingViewModel printerLabelSetting = new PrinterLabelSettingViewModel();

                var printMatchByDisplayName = _unitOfWorkService.Context.Printers.Where(x => x.DisplayName.Trim().ToLower() == model.DisplayName.Trim().ToLower()).ToList();
                if ((printMatchByDisplayName.Count > 0 && model.PrinterId == 0) || (printMatchByDisplayName.Count > 0 && model.PrinterId != 0 && printMatchByDisplayName.FirstOrDefault().PrinterId != model.PrinterId ))
                {
                    throw new Exception(PrinterConfigurationValidationErrors.DisplayNameNotUnique);
                }

                var printerMatchByIpAddressPortNumber = _unitOfWorkService.Context.Printers.Where(x => (x.IPAddress.Trim().ToLower() == model.IPAddress.Trim().ToLower()) && (x.PortNumber.Trim().ToLower() == model.PortNumber.Trim().ToLower())).ToList();
                if ((printerMatchByIpAddressPortNumber.Count > 0 && model.PrinterId == 0) || (printerMatchByIpAddressPortNumber.Count > 0 && model.PrinterId != 0 && printerMatchByIpAddressPortNumber.FirstOrDefault().PrinterId != model.PrinterId))
                {
                    throw new Exception(PrinterConfigurationValidationErrors.IPAddressPortNumberNotUnique);
                }

                if (model.PrinterId == 0)
                {
                    Printer printerViewModel = new Printer();

                    printerViewModel.DisplayName = model.DisplayName;
                    printerViewModel.IPAddress = model.IPAddress;
                    printerViewModel.PortNumber = model.PortNumber;
                    printerViewModel.Active = true;
                    printerViewModel.CreatedUser = model.UserName;
                    printerViewModel.CreatedDate = DateTime.UtcNow;
                    printerViewModel.ModifiedUser = model.UserName;
                    printerViewModel.ModifiedDate = DateTime.UtcNow;
                    printerLabelSetting.VerticalMargin = 0;
                    printerLabelSetting.HorizontalMargin = 0;

                    await _unitOfWorkService.GetRepositoryAsync<Printer>().AddAsync(printerViewModel);
                    _unitOfWorkService.SaveChanges();

                    var printerList = _unitOfWorkService.Context.Printers.OrderBy(x => x.CreatedDate).ToList();
                    var id = printerList.LastOrDefault().PrinterId;
                    if (id != 0)
                    {
                        if (selectedLabelTypes.Count > 0)
                        {
                            foreach (var labelTypeId in selectedLabelTypeIds)
                            {
                                printerLabelSetting.PrinterId = id;
                                printerLabelSetting.LabelTypeId = labelTypeId;
                                printerLabelSetting.CreatedUser = model.UserName;
                                printerLabelSetting.CreatedDate = DateTime.UtcNow;
                                var result = InsertPrinterLabelSettingsAsync(printerLabelSetting);
                            }
                        }
                        //printerLabelSetting.LabelTypeId = 2;
                        //result = InsertPrinterLabelSettingsAsync(printerLabelSetting);
                    }
                    return true;
                }
                else
                {
                    var printerViewModel = await _unitOfWorkService.Context.Printers.FirstOrDefaultAsync(x => x.PrinterId == model.PrinterId);
                    var printerLabelSettingModel = await _unitOfWorkService.Context.PrinterLabelSettings.Where(x => x.PrinterId == model.PrinterId).ToListAsync();
                    if (printerViewModel != null)
                    {
                        printerViewModel.DisplayName = model.DisplayName;
                        printerViewModel.IPAddress = model.IPAddress;
                        printerViewModel.PortNumber = model.PortNumber;
                        printerViewModel.Active = model.Active;
                        printerViewModel.ModifiedUser = model.UserName;
                        printerViewModel.ModifiedDate = DateTime.UtcNow;

                        _unitOfWorkService.GetRepositoryAsync<Printer>().UpdateAsync(printerViewModel);
                        _unitOfWorkService.SaveChanges();
                        if (selectedLabelTypes.Count > 0)
                        {
                            var labelIdsToDelete = printerLabelSettingModel.Where(a => !selectedLabelTypeIds.Contains(a.LabelTypeId)).Select(x => x.LabelTypeId).ToList();
                            var labelIdsToUpdate = printerLabelSettingModel.Where(a => selectedLabelTypeIds.Contains(a.LabelTypeId)).Select(x => x.LabelTypeId).ToList();
                            var labelIdsToAdd = selectedLabelTypeIds.Where(a => !labelIdsToDelete.Contains(a) && !labelIdsToUpdate.Contains(a)).ToList();

                            foreach (var printerSetting in printerLabelSettingModel)
                            {
                                if (labelIdsToUpdate.Contains(printerSetting.LabelTypeId))
                                {                                   
                                    printerSetting.ModifiedDate = DateTime.UtcNow;
                                    printerSetting.ModifiedUser = model.UserName;

                                    _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().UpdateAsync(printerSetting);
                                    _unitOfWorkService.SaveChanges();
                                }

                               if (labelIdsToDelete.Contains(printerSetting.LabelTypeId))
                                {
                                    _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().DeleteAsync(printerSetting);
                                    _unitOfWorkService.SaveChanges();
                                }
                            }

                            foreach(var labelTypeId in labelIdsToAdd)
                            {
                                PrinterLabelSettingViewModel printerSetting = new PrinterLabelSettingViewModel();

                                printerSetting.VerticalMargin = 0;
                                printerSetting.HorizontalMargin = 0;

                                printerSetting.PrinterId = model.PrinterId;
                                printerSetting.LabelTypeId = labelTypeId;
                                printerSetting.CreatedUser = model.UserName;
                                printerSetting.CreatedDate = DateTime.UtcNow;
                                var result = InsertPrinterLabelSettingsAsync(printerSetting);
                            }
                            
                        }
                        else
                        {
                            _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().DeleteAsync(printerLabelSettingModel.ToArray());
                            _unitOfWorkService.SaveChanges();

                        }
                        return true;
                    }
                }

                return false;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(ConfigurationService)}; Method: {nameof(LabelSortOrderViewModel)}; Error: {e.Message}");
                throw e;
            }
        }

        /// <summary>
        /// updates  the printer assignment status
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public async Task<bool> UpdatePrinterStatusAsync(PrinterAssignViewModel model)
        {
            var printerViewModel = await _unitOfWorkService.Context.Printers.FirstOrDefaultAsync(x => x.PrinterId == model.PrinterId);
            if (printerViewModel != null)
            {
                printerViewModel.Active = model.Active;
                _unitOfWorkService.GetRepositoryAsync<Printer>().UpdateAsync(printerViewModel);
                _unitOfWorkService.SaveChanges();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Insert a given Printer's Label Settings
        /// </summary>
        /// <param name="labelSetting"></param>
        /// <returns></returns>
        public async Task<bool> InsertPrinterLabelSettingsAsync(PrinterLabelSettingViewModel labelSetting)
        {
            PrinterLabelSetting printerLabelSetting = new PrinterLabelSetting();

            try
            {
                printerLabelSetting.VerticalMargin = labelSetting.VerticalMargin;
                printerLabelSetting.HorizontalMargin = labelSetting.HorizontalMargin;
                printerLabelSetting.PrinterId = labelSetting.PrinterId;
                printerLabelSetting.LabelTypeId = labelSetting.LabelTypeId;
                printerLabelSetting.CreatedUser = labelSetting.CreatedUser;
                printerLabelSetting.CreatedDate = DateTime.UtcNow;
                printerLabelSetting.ModifiedUser = labelSetting.CreatedUser;
                printerLabelSetting.ModifiedDate = DateTime.UtcNow;

                await _unitOfWorkService.GetRepositoryAsync<PrinterLabelSetting>().AddAsync(printerLabelSetting);
                _unitOfWorkService.SaveChanges();

                return true;
            }
            catch (Exception e)
            {
                _logger.LogError($"Service: {nameof(PrinterService)}; Method: {nameof(InsertPrinterLabelSettingsAsync)}; Error: {e.Message}");
                throw;
            }

        }

        #region Print Unit/Bag Labels

        /// <summary>
        /// Gets the label print request
        /// </summary>
        /// <param name="printLabelRequestId">The print label request id primary key used to get selected print labels</param>
        private PrintLabelMessageRequest GetLabelPrintRequest(int printLabelRequestId)
        {
            try
            {
                if (printLabelRequestId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(printLabelRequestId));

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();
                    var printLabelRequest = context.PrintLabelRequests.FirstOrDefault(lr => lr.PrintLabelRequestId == printLabelRequestId);

                    if (printLabelRequest == null)
                        throw new Exception($"A print labels request was not found for printLabelRequestId:{printLabelRequestId}");

                    var printLabelMessageRequest = JsonConvert.DeserializeObject<PrintLabelMessageRequest>(printLabelRequest.Request);

                    return printLabelMessageRequest;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(GetLabelPrintRequest)}: {ex.Message}");
                throw;
            }

        }

        /// <summary>
        /// Gets the selected bag labels in temporary storage for printing
        /// </summary>
        /// <param name="printRequest">The print label request object</param>
        private List<BagLabelModel> GetBagLabelPrintData(PrintLabelMessageRequest printRequest)
        {
            try
            {
                if (printRequest == null)
                    throw new ArgumentNullException(nameof(printRequest));

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();

                    var bagLabelsData = context.Labels.Where(lbl => printRequest.LabelIds.Contains(lbl.LabelId)).ToList().OrderBy(li => printRequest.LabelIds.IndexOf(li.LabelId));

                    var nonActiveBagLabels = bagLabelsData.Where(lbl => lbl.LabelStatusTypeId != (int)LabelStatusTypes.Active).ToList();

                    if (nonActiveBagLabels.Count > 0)
                        throw new Exception("Unable to print non-Active Labels.");

                    // TODO: Sort bagLabelsData to match order in printRequest.LabelIds

                    //To Do: Modify the printRequest Object
                    var bagLabelsToPrint = bagLabelsData.Select(x => new BagLabelModel()
                        {
                            LabelId = x.LabelId,
                            Vin = x.VIN,
                            DeliveryCode = x.DeliveryCode,
                            Model = x.Model
                        });

                    return bagLabelsToPrint.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(GetBagLabelPrintData)}: {ex.Message}");
                throw;
            }

        }

        /// <summary>
        /// Creates a bag labels document for printing
        /// </summary>
        /// <param name="bagLabelsToPrint"></param>
        /// <returns>Byte array of the print document</returns>
        private byte[] CreateBagLabelsPrintDocument(List<BagLabelModel> bagLabelsToPrint)
        {
            try
            {
                if (bagLabelsToPrint == null)
                    throw new ArgumentNullException(nameof(bagLabelsToPrint), "Value cannot be null.");

                if (bagLabelsToPrint.Count == 0)
                    throw new ArgumentException("Value cannot be an empty collection.", nameof(bagLabelsToPrint));

                // Label layout settings constants
                var printSettings = new BagLabelPrintSettings()
                {
                    LeftMarginX = 38,
                    TopMarginY = 736,
                    VinOffSetX = 10,
                    VinOffSetY = 65,
                    LabelSpacingX = 300,
                    LabelSpacingY = 144,
                    ModelOffSetX = 70,
                    ModelMaxSpace = 147,
                    ModelMaxLength = 13
                };

                // Initialize document object
                var pdfDocument = new Document();
                var labelSkipCount = 0;

                // Calculate number of pages
                // 10 labels fit on a page, 2 labels side by side, 5 rows of labels per page

                const int labelsPerPage = 10;
                var bagLabelCount = bagLabelsToPrint.Count;
                var totalPagesPre = (int)(Math.Ceiling(Convert.ToDecimal(bagLabelCount / labelsPerPage)));
                var totalPages = (bagLabelCount % labelsPerPage) == 0 ? totalPagesPre : totalPagesPre + 1;

                // Get the embedded font to use for the labels
                const string arialRoundedMtBoldFont = "VM.FleetServices.TnR.LM.Business.Fonts.ARLRDBD.TTF";
                var thisAssembly = Assembly.GetExecutingAssembly();
                Font arialFont;

                using (var fontStream = thisAssembly.GetManifestResourceStream(arialRoundedMtBoldFont))
                {
                    arialFont = FontRepository.OpenFont(fontStream, FontTypes.TTF);
                    arialFont.IsEmbedded = true;
                }

                for (var pageCount = 0; pageCount < totalPages; pageCount++)
                {
                    // Create a new page
                    var pdfPage = pdfDocument.Pages.Add();
                    var textBuilder = new TextBuilder(pdfPage);
                    var topMarginYCounter = printSettings.TopMarginY;
                    var labelCounter = 0;

                    // Get the next 2 labels
                    var currentLabels = bagLabelsToPrint.Skip(labelSkipCount).Take(2).ToList();
                    while (currentLabels.Any())
                    {
                        // Create rows of 2 labels per row

                        //1st Label on row
                        var firstLabelFragments = CreateLabelFragments(currentLabels.First(),
                            printSettings.LeftMarginX,
                            topMarginYCounter,
                            printSettings,
                            arialFont);
                        foreach (var textFragment in firstLabelFragments)
                        {
                            textBuilder.AppendText(textFragment);
                        }

                        if (currentLabels.Count == 2)
                        {
                            //2nd Label on row
                            var secondLabelFragments = CreateLabelFragments(currentLabels.Last(),
                                printSettings.LeftMarginX + printSettings.LabelSpacingX,
                                topMarginYCounter,
                                printSettings,
                                arialFont);
                            foreach (var textFragment in secondLabelFragments)
                            {
                                textBuilder.AppendText(textFragment);
                            }

                            labelCounter += 1;
                        }

                        //Ensure skip count and label count are incremented prior to the loop exit check
                        labelSkipCount += 2;
                        labelCounter += 1;

                        if (labelCounter == 10)
                        {
                            // Created 10 labels so proceed to new page
                            break;
                        }

                        currentLabels = bagLabelsToPrint.Skip(labelSkipCount).Take(2).ToList();
                        topMarginYCounter -= printSettings.LabelSpacingY;
                    }
                }

                var memStream = new MemoryStream();
                pdfDocument.Save(memStream);
                var arr = memStream.ToArray();
                return arr;


            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(CreateBagLabelsPrintDocument)}: {ex.Message}");
                throw;
            }

        }

        /// <summary>
        /// Creates text fragments representing label properties 
        /// </summary>
        /// <param name="bagLabelModel">The label model to create text fragments for</param>
        /// <param name="leftMarginX">The left margin</param>
        /// <param name="topMarginY">The top margin</param>
        /// <param name="printSettings">A Print settings object</param>
        /// <param name="labelFont">A label font to use</param>
        /// <returns>List of Text Fragments</returns>
        private static IEnumerable<TextFragment> CreateLabelFragments(BagLabelModel bagLabelModel, int leftMarginX, int topMarginY, BagLabelPrintSettings printSettings, Font labelFont)
        {
            // 2 Labels fit side by side`
            // 3 text fragments per label
            // 1st Fragment and 2nd Fragment represents 1 row of label data (1st Fragment = Lbl1DeliveryCode  2nd Fragment = Lbl1Model) 
            // 3rd Fragment represents 1 row of label data (3rd Fragment = lbl1_9DigitVin)

            var labelTextFragments = new List<TextFragment>();

            // Label 1st Row
            //      Delivery Code:
            var lblDeliveryCodeFragment = CreateLabelPropertyFragment(
                                              BagLabelProperties.DeliveryCode.GetDescription(),
                                              bagLabelModel.LabelId,
                                              bagLabelModel.DeliveryCode,
                                              leftMarginX,
                                              topMarginY);

            lblDeliveryCodeFragment.TextState.Font = labelFont;
            lblDeliveryCodeFragment.TextState.FontSize = 19;
            lblDeliveryCodeFragment.TextState.ForegroundColor = Color.FromRgb(System.Drawing.Color.Black);

            //      Vehicle Model:
            // Ensure the vehicle model is centered based on the length of the value
            var adjModelOffSet = GetCenterVehicleModelOffSetValue(bagLabelModel, printSettings);
            var lblModelFragment = CreateLabelPropertyFragment(
                                        BagLabelProperties.Model.GetDescription(),
                                        bagLabelModel.LabelId,
                                        bagLabelModel.Model,
                                        leftMarginX + adjModelOffSet,
                                        topMarginY);

            lblModelFragment.TextState.FontSize = 19;
            lblModelFragment.TextState.Font = labelFont;
            lblModelFragment.TextState.ForegroundColor = Color.FromRgb(System.Drawing.Color.Black);

            // Label 2nd Row (Vin)
            var vin9 = bagLabelModel.Vin.Trim().Substring(bagLabelModel.Vin.Length - 9);
            var vinFormatted = $"{vin9.Substring(0, 3)}-{vin9.Substring(3)}";
            var lblVinFragment = CreateLabelPropertyFragment(
                                      BagLabelProperties.Vin.GetDescription(),
                                      bagLabelModel.LabelId,
                                      vinFormatted,
                                      leftMarginX + printSettings.VinOffSetX,
                                      topMarginY - printSettings.VinOffSetY);

            lblVinFragment.TextState.FontSize = 38;
            lblVinFragment.TextState.Font = labelFont;
            lblVinFragment.TextState.ForegroundColor = Color.FromRgb(System.Drawing.Color.Black);

            labelTextFragments.Add(lblDeliveryCodeFragment);
            labelTextFragments.Add(lblModelFragment);
            labelTextFragments.Add(lblVinFragment);

            return labelTextFragments;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="property"></param>
        /// <param name="labelId">The label id</param>
        /// <param name="labelPropertyValue">The property value to print on the label</param>
        /// <param name="leftMarginX">The left margin</param>
        /// <param name="topMarginY">The top margin</param>
        /// <returns>Text Fragment</returns>
        private static TextFragment CreateLabelPropertyFragment(string property, int labelId, string labelPropertyValue, int leftMarginX, int topMarginY)
        {
            if (string.IsNullOrWhiteSpace(labelPropertyValue))
                throw new ArgumentException($"Value cannot be empty for property: {property.ToUpper()}, labelId: {labelId}.", nameof(labelPropertyValue));

            var labelFragment = new TextFragment(labelPropertyValue) { Position = new Position(leftMarginX, topMarginY) };
            return labelFragment;
        }

        /// <summary>
        /// Calculates what the center offset should be for a vehicle model  
        /// </summary>
        /// <param name="bagLabelModel">The label model to be printed</param>
        /// <param name="printSettings">The print settings coordinates</param>
        /// <returns>The center offset value for the vehicle model </returns>
        private static int GetCenterVehicleModelOffSetValue(BagLabelModel bagLabelModel, BagLabelPrintSettings printSettings)
        {
            if (string.IsNullOrWhiteSpace(bagLabelModel.Model))
                throw new ArgumentException($"Value cannot be empty for property: MODEL, labelId: {bagLabelModel.LabelId}.", nameof(bagLabelModel.Model));

            var vehicleModel = bagLabelModel.Model;

            // The final calculated value for the vehicle to be centered
            var adjModelOffSet = 0;

            // The additional amount to be added to the print settings vehicle model offset value
            var modelStartX = 0;

            if (string.IsNullOrWhiteSpace(vehicleModel))
                return adjModelOffSet;

            // Trim to max allowed length
            var modelLength = bagLabelModel.Model.Trim().Length;
            if (modelLength > printSettings.ModelMaxLength)
            {
                bagLabelModel.Model = bagLabelModel.Model.Substring(0, printSettings.ModelMaxLength - 1);
            }
            else
            {
                // Calculate the center for the vehicle model
                var wordTotalPts = bagLabelModel.Model.Length * 13; // (13 pts per char approx.)
                if (wordTotalPts > printSettings.ModelMaxSpace)
                {
                    modelStartX = 0;
                }
                else
                {
                    modelStartX = (printSettings.ModelMaxSpace - wordTotalPts) / 2;
                }

            }

            adjModelOffSet = printSettings.ModelOffSetX + modelStartX;
            bagLabelModel.Model = bagLabelModel.Model.ToUpper();

            return adjModelOffSet;
        }

        /// <summary>
        /// Get Label Settings by LabelSettingsId
        /// </summary>
        /// <param name="printerLabelSettingId"></param>
        /// <returns>PrinterLabelSetting model</returns>
        internal Model.DTO.PrinterLabelSetting GetPrinterLabelSettingsById(int printerLabelSettingId,int labelTypeId)
        {
            try
            {
                if (printerLabelSettingId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(printerLabelSettingId));

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();
                    var results = context.PrinterLabelSettings.FirstOrDefault(ls => ls.PrinterLabelSettingId == printerLabelSettingId && ls.LabelTypeId== labelTypeId);

                    if (results == null)
                        throw new Exception($"Print labels settings were not found for printerLabelSettingId:{printerLabelSettingId}");

                    var printerLabelSettings = _mapper.Map<Model.DTO.PrinterLabelSetting>(results);

                    return printerLabelSettings;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(GetPrinterLabelSettingsById)}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Get Unit Label data needed for printing
        /// </summary>
        /// <param name="printRequest"></param>
        /// <returns>List of UnitLabelModel</returns>
        private List<UnitLabelModel> GetUnitLabelPrintData(PrintLabelMessageRequest printRequest, bool errorOnNonActiveLabels = true)
        {
            try
            {
                if (printRequest == null)
                    throw new ArgumentNullException(nameof(printRequest));

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();

                    var unitLabelsData = context.Labels.Where(lbl => printRequest.LabelIds.Contains(lbl.LabelId)).ToList().OrderBy(li => printRequest.LabelIds.IndexOf(li.LabelId));

                    if (errorOnNonActiveLabels)
                    {
                        var nonActiveUnitLabels = unitLabelsData.Where(lbl => lbl.LabelStatusTypeId != (int)LabelStatusTypes.Active).ToList();

                        if (nonActiveUnitLabels.Count > 0)
                            throw new Exception("Unable to print non-Active Labels.");
                    }

                    //To Do: Modify the printRequest Object
                    var unitLabelsToPrint = unitLabelsData.Select(x => new UnitLabelModel()
                        {
                            LabelId = x.LabelId,
                            Vin = x.VIN,
                            DeliveryCode = x.DeliveryCode,
                            ShipToCode = x.ShipTo,
                            Model = x.Model,
                            AreaNumber = x.OwningAreaDeliveryCode,
                            UnitNumber = x.Unit,
                            BatchNumber = x.BatchNumber
                        });

                    return unitLabelsToPrint.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(GetUnitLabelPrintData)}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Create Unit Label pdf document from given list of Unit Labels and converts it to a byte array
        /// </summary>
        /// <param name="unitLabelsToPrint"></param>
        /// <returns>Byte Array of UnitLabel pdf Document</returns>
        private byte[] CreateUnitLabelsPdfDocument(List<UnitLabelModel> unitLabelsToPrint, Model.DTO.PrinterLabelSetting labelSettings)
        {
            try
            {
                using (var pdfForm = new Aspose.Pdf.Facades.Form())
                {
                    var asm = Assembly.GetExecutingAssembly();
                    using (var unitLabelFormStream = asm.GetManifestResourceStream("VM.FleetServices.TnR.LM.Business.UnitLabelFormTemplate.pdf"))
                    {
                        MemoryStream pdfFormStream;
                        Document pdfDocument;
                        Page pdfPage;
                        IList<Aspose.Pdf.Forms.Field> barcodeFields;
                        ImageStamp barcodeStamp;
                        MemoryStream memStream;

                        double verticalCropTrimAdjust;

                        string owningAreaLeadingZeros;
                        string section1BarcodeData;
                        string section1BarcodeLabel;
                        string section2BarcodeData;
                        string section2BarcodeLabel;
                        string section3QrCodeData;
                        string section3QrCodeLabel;

                        //Contains the documents(pages) that will later be merged into one final pdf
                        var documentsList = new List<Document>();

                        // Create a new page for each unit label model
                        foreach (UnitLabelModel unitLabel in unitLabelsToPrint)
                        {
                            pdfForm.BindPdf(unitLabelFormStream);

                            // Fill Label Form Text Fields
                            // Text Fragment #1 - Model
                            pdfForm.FillField("Model", unitLabel.Model);

                            // Text Fragment #2 - Label ID
                            pdfForm.FillField("LabelId", unitLabel.LabelId.ToString());

                            // Text Fragment #3 - ShipTo Code
                            pdfForm.FillField("ShipToCode", unitLabel.ShipToCode);

                            // Text Fragment #4 - Delivery Code
                            pdfForm.FillField("DeliveryCode", unitLabel.DeliveryCode);

                            // Text Fragment #5 - Batch Number
                            pdfForm.FillField("BatchNumber", unitLabel.BatchNumber);

                            pdfFormStream = new MemoryStream();
                            pdfForm.Save(pdfFormStream);

                            pdfDocument = new Document(pdfFormStream);
                            pdfPage = pdfDocument.Pages[1];

                            // Adjustment needed due to cropped form for 4" x 6" label sheet
                            verticalCropTrimAdjust = pdfPage.CropBox.LLY;

                            barcodeFields = pdfPage.FieldsInTabOrder;

                            owningAreaLeadingZeros = "00000" + unitLabel.AreaNumber;
                            section1BarcodeData = owningAreaLeadingZeros.Substring(owningAreaLeadingZeros.Length - 5) + unitLabel.UnitNumber;
                            section1BarcodeLabel = unitLabel.AreaNumber + "-" + unitLabel.UnitNumber + "*";
                            section2BarcodeData = unitLabel.Vin;
                            section2BarcodeLabel = unitLabel.Vin + " *";
                            section3QrCodeData = unitLabel.Vin;
                            section3QrCodeLabel = unitLabel.Vin.Substring(unitLabel.Vin.Length - 9) + "*";

                            // SECTION 1 - Interleaved 2 of 5
                            // Barcode #1
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Interleaved2of5, barcodeFields[0], section1BarcodeData, 18, section1BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Barcode #2
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Interleaved2of5, barcodeFields[1], section1BarcodeData, 18, section1BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Barcode #3
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Interleaved2of5, barcodeFields[2], section1BarcodeData, 18, section1BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Barcode #4
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Interleaved2of5, barcodeFields[3], section1BarcodeData, 18, section1BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // SECTION 2 - Code 39
                            // Barcode #5
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Code39Standard, barcodeFields[4], section2BarcodeData, 20, section2BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Barcode #6
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Code39Standard, barcodeFields[5], section2BarcodeData, 20, section2BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Barcode #7
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.Code39Standard, barcodeFields[6], section2BarcodeData, 20, section2BarcodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);


                            // Section 3 - QR CODES
                            // Barcode #8
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.QR, barcodeFields[7], section3QrCodeData, 5, section3QrCodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Barcode #9
                            barcodeStamp = CreateBarcodeStamp(EncodeTypes.QR, barcodeFields[8], section3QrCodeData, 5, section3QrCodeLabel, labelSettings, verticalCropTrimAdjust);
                            pdfPage.AddStamp(barcodeStamp);

                            // Save page to document list
                            pdfDocument.Flatten();
                            pdfDocument.Save();
                            documentsList.Add(pdfDocument);
                        }

                        // Construct the final document
                        var mainPdfDocument = new Document();
                        foreach (var document in documentsList)
                        {
                            mainPdfDocument.Pages.Add(document.Pages[1]);
                        }

                        memStream = new MemoryStream();
                        mainPdfDocument.Save(memStream);

                        return memStream.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(CreateUnitLabelsPdfDocument)}: {ex.Message}");
                throw;
            }

        }

        private byte[] CreateUnitLabelsPrintDocumentInDPL(UnitLabelModel unitLabelToPrint, Model.DTO.PrinterLabelSetting labelSettings)
        {
            try
            {
                byte[] printData = null;
                var docDPL = new Honeywell.Printer.DocumentDPL();
                var paramDPL = new Honeywell.Printer.ParametersDPL();

                string owningAreaLeadingZeros;
                string section1BarcodeData;
                string section1BarcodeLabel;
                string section2BarcodeData;
                string section2BarcodeLabel;
                string section3QrCodeData;
                string section3QrCodeLabel;

                var pointsPerInch = 100;

                //TODO: Define units of these margins from UI to provice proper conversion
                // For testing treat them as mm, convert at 1 mm = 0.0394 in
                var labelSettingsHorizontalMarginInches = labelSettings.HorizontalMargin * (decimal)0.0394;
                var labelSettingsVerticalMarginInches = labelSettings.VerticalMargin * (decimal)0.0394;

                // UX is col of top left corner, leftmost col of page is at 0
                // UY is row of top left corner, bottommost row of page is at 0
                // Cut is the cutmark on the precut label sheets
                // Label is the text string label for a barcode/QR Code

                /*
                * Section 1 - Barcode Coordinates, Size, Type Configuration (measured in inches, coverted to points)
                */
                var section1BarcodeType = "d"; // Interleaved 2 of 5

                var section1BarcodeHeight = (decimal)0.5;
                var section1BarcodeWidth = (decimal)1.5;

                var section1Barcode1CutUX = (decimal)0.375;
                var section1Barcode1CutUY = (decimal)5.75;
                var section1Barcode2CutUX = (decimal)2.125;
                var section1Barcode2CutUY = (decimal)5.75;
                var section1Barcode3CutUX = (decimal)0.375;
                var section1Barcode3CutUY = (decimal)5.0625;
                var section1Barcode4CutUX = (decimal)2.125;
                var section1Barcode4CutUY = (decimal)5.0625;

                var section1BarcodeHorizontalMargin = (decimal)0.3125 + labelSettingsHorizontalMarginInches;
                var section1BarcodeVerticalMargin = (decimal)0.125 - labelSettingsVerticalMarginInches;
                var section1BarcodeLabelHorizontalMargin = (decimal)0.4375 + labelSettingsHorizontalMarginInches;
                var section1BarcodeLabelVerticalMargin = (decimal)0 - labelSettingsVerticalMarginInches;

                // TOP LEFT SECTION 1 Barcode
                var barcode1UX = (int)Math.Round((section1Barcode1CutUX + section1BarcodeHorizontalMargin) * pointsPerInch);
                var barcode1UY = (int)Math.Round((section1Barcode1CutUY + section1BarcodeVerticalMargin - section1BarcodeHeight) * pointsPerInch);
                var barcode1LabelUX = (int)Math.Round((section1Barcode1CutUX + section1BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode1LabelUY = (int)Math.Round((section1Barcode1CutUY + section1BarcodeLabelVerticalMargin - section1BarcodeHeight) * pointsPerInch);

                // BOTTOM LEFT SECTION 1 Barcode
                var barcode2UX = (int)Math.Round((section1Barcode2CutUX + section1BarcodeHorizontalMargin) * pointsPerInch);
                var barcode2UY = (int)Math.Round((section1Barcode2CutUY + section1BarcodeVerticalMargin - section1BarcodeHeight) * pointsPerInch);
                var barcode2LabelUX = (int)Math.Round((section1Barcode2CutUX + section1BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode2LabelUY = (int)Math.Round((section1Barcode2CutUY + section1BarcodeLabelVerticalMargin - section1BarcodeHeight) * pointsPerInch);

                // TOP RIGHT SECTION 1 Barcode
                var barcode3UX = (int)Math.Round((section1Barcode3CutUX + section1BarcodeHorizontalMargin) * pointsPerInch);
                var barcode3UY = (int)Math.Round((section1Barcode3CutUY + section1BarcodeVerticalMargin - section1BarcodeHeight) * pointsPerInch);
                var barcode3LabelUX = (int)Math.Round((section1Barcode3CutUX + section1BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode3LabelUY = (int)Math.Round((section1Barcode3CutUY + section1BarcodeLabelVerticalMargin - section1BarcodeHeight) * pointsPerInch);

                // BOTTOM RIGHT SECTION 1 Barcode
                var barcode4UX = (int)Math.Round((section1Barcode4CutUX + section1BarcodeHorizontalMargin) * pointsPerInch);
                var barcode4UY = (int)Math.Round((section1Barcode4CutUY + section1BarcodeVerticalMargin - section1BarcodeHeight) * pointsPerInch);
                var barcode4LabelUX = (int)Math.Round((section1Barcode4CutUX + section1BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode4LabelUY = (int)Math.Round((section1Barcode4CutUY + section1BarcodeLabelVerticalMargin - section1BarcodeHeight) * pointsPerInch);


                /*
                * Section 2 - Barcode Coordinates, Size, Type Configuration (measured in inches, coverted to points)
                */
                var section2BarcodeType = "a"; // Code 3 of 9

                var section2BarcodeHeight = (decimal)0.75;
                var section2BarcodeWidth = (decimal)3.0;

                var section2Barcode1CutUX = (decimal)0.5;
                var section2Barcode1CutUY = (decimal)4.375;
                var section2Barcode2CutUX = (decimal)0.5;
                var section2Barcode2CutUY = (decimal)3.375;
                var section2Barcode3CutUX = (decimal)0.5;
                var section2Barcode3CutUY = (decimal)2.4375;

                var section2BarcodeHorizontalMargin = (decimal)0.1875 + labelSettingsHorizontalMarginInches;
                var section2BarcodeVerticalMargin = (decimal)0.1875 - labelSettingsVerticalMarginInches;
                var section2BarcodeLabelHorizontalMargin = (decimal)0.875 + labelSettingsHorizontalMarginInches;
                var section2BarcodeLabelVerticalMargin = (decimal)0 - labelSettingsVerticalMarginInches;

                // TOP SECTION 2 Barcode
                var barcode5UX = (int)Math.Round((section2Barcode1CutUX + section2BarcodeHorizontalMargin) * pointsPerInch);
                var barcode5UY = (int)Math.Round((section2Barcode1CutUY + section2BarcodeVerticalMargin - section2BarcodeHeight) * pointsPerInch);
                var barcode5LabelUX = (int)Math.Round((section2Barcode1CutUX + section2BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode5LabelUY = (int)Math.Round((section2Barcode1CutUY + section2BarcodeLabelVerticalMargin - section2BarcodeHeight) * pointsPerInch);

                // MIDDLE SECTION 2 Barcode
                var barcode6UX = (int)Math.Round((section2Barcode2CutUX + section2BarcodeHorizontalMargin) * pointsPerInch);
                var barcode6UY = (int)Math.Round((section2Barcode2CutUY + section2BarcodeVerticalMargin - section2BarcodeHeight) * pointsPerInch);
                var barcode6LabelUX = (int)Math.Round((section2Barcode2CutUX + section2BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode6LabelUY = (int)Math.Round((section2Barcode2CutUY + section2BarcodeLabelVerticalMargin - section2BarcodeHeight) * pointsPerInch);

                // BOTTOM SECTOIN 2 Barcode
                var barcode7UX = (int)Math.Round((section2Barcode3CutUX + section2BarcodeHorizontalMargin) * pointsPerInch);
                var barcode7UY = (int)Math.Round((section2Barcode3CutUY + section2BarcodeVerticalMargin - section2BarcodeHeight) * pointsPerInch);
                var barcode7LabelUX = (int)Math.Round((section2Barcode3CutUX + section2BarcodeLabelHorizontalMargin) * pointsPerInch);
                var barcode7LabelUY = (int)Math.Round((section2Barcode3CutUY + section2BarcodeLabelVerticalMargin - section2BarcodeHeight) * pointsPerInch);


                /*
                * Section 3 - QR Code Coordinates, Size, Type Configuration (measured in inches, coverted to points)
                */
                var section3QrCodeHeight = (decimal)1.25;
                var section3QrCodeWidth = (decimal)0.9375;

                var section3QrCode1CutUX = (decimal)0.5;
                var section3QrCode1CutUY = (decimal)1.4375;
                var section3QrCode2CutUX = (decimal)2.5;
                var section3QrCode2CutUY = (decimal)1.4375;

                var section3QrCodeHorizontalMargin = (decimal)0.156 + labelSettingsHorizontalMarginInches;
                var section3QrCodeVerticalMargin = (decimal)0.25 - labelSettingsVerticalMarginInches;
                var section3QrCodeLabelHorizontalMargin = (decimal)0.25 + labelSettingsHorizontalMarginInches;
                var section3QrCodeLabelVerticalMargin = (decimal)0.125 - labelSettingsVerticalMarginInches;

                var qrCode1UX = (int)Math.Round((section3QrCode1CutUX + section3QrCodeHorizontalMargin) * pointsPerInch);
                var qrCode1UY = (int)Math.Round((section3QrCode1CutUY + section3QrCodeVerticalMargin - section3QrCodeHeight) * pointsPerInch);
                var qrCode1LabelUX = (int)Math.Round((section3QrCode1CutUX + section3QrCodeLabelHorizontalMargin) * pointsPerInch);
                var qrCode1LabelUY = (int)Math.Round((section3QrCode1CutUY + section3QrCodeLabelVerticalMargin - section3QrCodeHeight) * pointsPerInch);

                var qrCode2UX = (int)Math.Round((section3QrCode2CutUX + section3QrCodeHorizontalMargin) * pointsPerInch);
                var qrCode2UY = (int)Math.Round((section3QrCode2CutUY + section3QrCodeVerticalMargin - section3QrCodeHeight) * pointsPerInch);
                var qrCode2LabelUX = (int)Math.Round((section3QrCode2CutUX + section3QrCodeLabelHorizontalMargin) * pointsPerInch);
                var qrCode2LabelUY = (int)Math.Round((section3QrCode2CutUY + section3QrCodeLabelVerticalMargin - section3QrCodeHeight) * pointsPerInch);

                /*
                 * SECTION 4 - Text Only Element Coordinates (measured in inches, coverted to points)
                 */
                var modelFieldUX = (int)Math.Round(((decimal)1.7 + labelSettingsHorizontalMarginInches) * pointsPerInch);
                var modelFieldUY = (int)Math.Round(((decimal)1.125 - labelSettingsVerticalMarginInches) * pointsPerInch);

                var labelIdFieldUX = (int)Math.Round(((decimal)1.7 + labelSettingsHorizontalMarginInches) * pointsPerInch);
                var labelIdFieldUY = (int)Math.Round(((decimal)0.925 - labelSettingsVerticalMarginInches) * pointsPerInch);

                var shipToCodeFieldUX = (int)Math.Round(((decimal)1.7 + labelSettingsHorizontalMarginInches) * pointsPerInch);
                var shipToCodeFieldUY = (int)Math.Round(((decimal)0.725 - labelSettingsVerticalMarginInches) * pointsPerInch);

                var deliveryCodeFieldUX = (int)Math.Round(((decimal)1.7 + labelSettingsHorizontalMarginInches) * pointsPerInch);
                var deliveryCodeFieldUY = (int)Math.Round(((decimal)0.525 - labelSettingsVerticalMarginInches) * pointsPerInch);

                var batchNumberFieldUX = (int)Math.Round(((decimal)1.7 + labelSettingsHorizontalMarginInches) * pointsPerInch);
                var batchNumberFieldUY = (int)Math.Round(((decimal)0.325 - labelSettingsVerticalMarginInches) * pointsPerInch);


                /*
                 * Add Barcodes, QR Codes, and Text Elements to Documents
                 */
                // Barcode and Label data
                owningAreaLeadingZeros = "00000" + unitLabelToPrint.AreaNumber;
                section1BarcodeData = owningAreaLeadingZeros.Substring(owningAreaLeadingZeros.Length - 5) + unitLabelToPrint.UnitNumber;
                section1BarcodeLabel = unitLabelToPrint.AreaNumber + "-" + unitLabelToPrint.UnitNumber + "*";
                section2BarcodeData = unitLabelToPrint.Vin;
                section2BarcodeLabel = unitLabelToPrint.Vin + " *";
                section3QrCodeData = unitLabelToPrint.Vin;
                section3QrCodeLabel = unitLabelToPrint.Vin.Substring(unitLabelToPrint.Vin.Length - 9) + "*";


                // Section 1 Barcodes
                paramDPL = new Honeywell.Printer.ParametersDPL();

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 20;
                paramDPL.HorizontalMultiplier = 2;
                docDPL.WriteBarCode(section1BarcodeType, section1BarcodeData, barcode1UY, barcode1UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section1BarcodeLabel, 2, barcode1LabelUY, barcode1LabelUX);

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 20;
                paramDPL.HorizontalMultiplier = 3;
                docDPL.WriteBarCode(section1BarcodeType, section1BarcodeData, barcode2UY, barcode2UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section1BarcodeLabel, 2, barcode2LabelUY, barcode2LabelUX);

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 20;
                paramDPL.HorizontalMultiplier = 4;
                docDPL.WriteBarCode(section1BarcodeType, section1BarcodeData, barcode3UY, barcode3UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section1BarcodeLabel, 2, barcode3LabelUY, barcode3LabelUX);

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 20;
                paramDPL.HorizontalMultiplier = 5;
                docDPL.WriteBarCode(section1BarcodeType, section1BarcodeData, barcode4UY, barcode4UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section1BarcodeLabel, 2, barcode4LabelUY, barcode4LabelUX);

                // Section 2 Barcodes
                paramDPL = new Honeywell.Printer.ParametersDPL();

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 30;
                paramDPL.HorizontalMultiplier = 1;
                docDPL.WriteBarCode(section2BarcodeType, section2BarcodeData, barcode5UY, barcode5UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section2BarcodeLabel, 2, barcode5LabelUY, barcode5LabelUX);

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 30;
                paramDPL.HorizontalMultiplier = 1;
                docDPL.WriteBarCode(section2BarcodeType, section2BarcodeData, barcode6UY, barcode6UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section2BarcodeLabel, 2, barcode6LabelUY, barcode6LabelUX);

                paramDPL.IsUnicode = false;
                paramDPL.WideBarWidth = 5;
                paramDPL.NarrowBarWidth = 2;
                paramDPL.SymbolHeight = 30;
                paramDPL.HorizontalMultiplier = 1;
                docDPL.WriteBarCode(section2BarcodeType, section2BarcodeData, barcode7UY, barcode7UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section2BarcodeLabel, 2, barcode7LabelUY, barcode7LabelUX);

                // Section 3 QR Codes
                paramDPL = new Honeywell.Printer.ParametersDPL();

                paramDPL.WideBarWidth = 6;
                paramDPL.NarrowBarWidth = 6;
                paramDPL.SymbolHeight = 80;
                docDPL.WriteBarCodeQRCode(section3QrCodeData, false, 2, "H", "4", "M", "A", qrCode1UY, qrCode1UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section3QrCodeLabel, 2, qrCode1LabelUY, qrCode1LabelUX);

                paramDPL.WideBarWidth = 6;
                paramDPL.NarrowBarWidth = 6;
                paramDPL.SymbolHeight = 80;
                docDPL.WriteBarCodeQRCode(section3QrCodeData, false, 2, "H", "4", "M", "A", qrCode2UY, qrCode2UX, paramDPL);
                docDPL.WriteTextInternalBitmapped(section3QrCodeLabel, 2, qrCode2LabelUY, qrCode2LabelUX);

                // Text Fields
                var maxTextFieldLength = 12;
                var unitLabelModelText = unitLabelToPrint?.Model ?? "";
                var unitLabelLabelIdText = unitLabelToPrint.LabelId.ToString();
                var unitLabelShipToCodeText = unitLabelToPrint?.ShipToCode ?? "";
                var unitLabelDeliveryCodeText = unitLabelToPrint?.DeliveryCode ?? "";
                var unitLabelBatchNumberText = unitLabelToPrint?.BatchNumber ?? "";

                docDPL.WriteTextInternalBitmapped(unitLabelModelText.Substring(0, Math.Min(unitLabelModelText.Length, maxTextFieldLength)), 2, modelFieldUY, modelFieldUX);
                docDPL.WriteTextInternalBitmapped(unitLabelLabelIdText.Substring(0, Math.Min(unitLabelLabelIdText.Length, maxTextFieldLength)), 2, labelIdFieldUY, labelIdFieldUX);
                docDPL.WriteTextInternalBitmapped(unitLabelShipToCodeText.Substring(0, Math.Min(unitLabelShipToCodeText.Length, maxTextFieldLength)), 2, shipToCodeFieldUY, shipToCodeFieldUX);
                docDPL.WriteTextInternalBitmapped(unitLabelDeliveryCodeText.Substring(0, Math.Min(unitLabelDeliveryCodeText.Length, maxTextFieldLength)), 2, deliveryCodeFieldUY, deliveryCodeFieldUX);
                docDPL.WriteTextInternalBitmapped(unitLabelBatchNumberText.Substring(0, Math.Min(unitLabelBatchNumberText.Length, maxTextFieldLength)), 2, batchNumberFieldUY, batchNumberFieldUX);

                printData = docDPL.GetDocumentData();
                return printData;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(CreateUnitLabelsPdfDocument)}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Creates a BarCode Image Stamp to append to Label document
        /// </summary>
        /// <param name="barcodeType"></param>
        /// <param name="barcodeFormField"></param>
        /// <param name="barcodeText"></param>
        /// <param name="captionFontSize"></param>
        /// <param name="captionText"></param>
        /// <param name="labelSettings"></param>
        /// <param name="verticalTrimAdjust"></param>
        /// <returns>ImageStamp</returns>
        private ImageStamp CreateBarcodeStamp(BaseEncodeType barcodeType, Field barcodeFormField, string barcodeText, int captionFontSize, string captionText, Model.DTO.PrinterLabelSetting labelSettings, double verticalTrimAdjust = 0)
        {
            BarcodeGenerator barCodeGenerator;
            MemoryStream barcodeStream;
            ImageStamp barcodeStamp;

            barCodeGenerator = new BarcodeGenerator(barcodeType, barcodeText);

            barCodeGenerator.Parameters.Barcode.CodeTextParameters.Location = CodeLocation.None;

            barCodeGenerator.Parameters.Resolution = 300f;
            barCodeGenerator.Parameters.CaptionBelow.Text = captionText;
            barCodeGenerator.Parameters.CaptionBelow.Visible = true;
            barCodeGenerator.Parameters.CaptionBelow.Font.FamilyName = "Courier New";
            barCodeGenerator.Parameters.CaptionBelow.Font.Size.Point = captionFontSize;
            barCodeGenerator.Parameters.CaptionBelow.Alignment = TextAlignment.Center;


            barcodeStream = new MemoryStream();
            barCodeGenerator.Save(barcodeStream, BarCodeImageFormat.Bmp);
            barcodeStream.Position = 0;

            barcodeStamp = new ImageStamp(barcodeStream)
            {
                Height = barcodeFormField.Rect.Height,
                Width = barcodeFormField.Rect.Width,
                XIndent = barcodeFormField.Rect.LLX + (double)labelSettings.HorizontalMargin,
                YIndent = barcodeFormField.Rect.LLY - verticalTrimAdjust - (double)labelSettings.VerticalMargin
            };

            return barcodeStamp;
        }

        /// <summary>
        /// Create a Printer Request Model to send data to printers
        /// </summary>
        /// <param name="printLabelRequestId"></param>
        /// <returns></returns>
        internal PrintRequestModel CreatePrintRequestModel(int printLabelRequestId)
        {
            List<byte[]> documentsToPrint = new List<byte[]>();
            var labelPrintRequest = GetLabelPrintRequest(printLabelRequestId);
            var labelSettings = GetPrinterLabelSettingsById(labelPrintRequest.SelectedPrinterLabelSettingId,labelPrintRequest.LabelType);

            switch (labelPrintRequest.LabelType)
            {
                case (int)Labeltypes.Unit:
                    var unitLabelsToPrint = GetUnitLabelPrintData(labelPrintRequest, true);

                    foreach (var unitLabelToPrint in unitLabelsToPrint)
                    {
                        documentsToPrint.Add(CreateUnitLabelsPrintDocumentInDPL(unitLabelToPrint, labelSettings));
                    };
                    break;

                case (int)Labeltypes.Bag:
                    var bagLabelsToPrint = GetBagLabelPrintData(labelPrintRequest);
                    documentsToPrint.Add(CreateBagLabelsPrintDocument(bagLabelsToPrint));
                    break;
            }

            var selectedPrinter = GetSelectedPrinter(labelPrintRequest);

            var printRequestModel = new PrintRequestModel()
            {
                LabelTypeId = labelPrintRequest.LabelType,
                LabelIds = labelPrintRequest.LabelIds,
                Printer = selectedPrinter,
                PrintDocuments = documentsToPrint
            };

            return printRequestModel;
        }

        internal List<byte[]> GetUnitLabelPdfDocumentData(int printLabelRequestId)
        {
            List<byte[]> documentsToPrint = new List<byte[]>();
            var labelPrintRequest = GetLabelPrintRequest(printLabelRequestId);
            var labelSettings = GetPrinterLabelSettingsById(labelPrintRequest.SelectedPrinterLabelSettingId,labelPrintRequest.LabelType);

            var unitLabelsToPrint = GetUnitLabelPrintData(labelPrintRequest, false);

            documentsToPrint.Add(CreateUnitLabelsPdfDocument(unitLabelsToPrint, labelSettings));

            return documentsToPrint;
        }

        /// <summary>
        /// Gets the selected printer
        /// </summary>
        /// <param name="labelPrintRequest">A label print request message object</param>
        /// <returns>Printer</returns>
        private Model.DTO.Printer GetSelectedPrinter(PrintLabelMessageRequest labelPrintRequest)
        {
            try
            {
                if (labelPrintRequest == null)
                    throw new ArgumentNullException(nameof(labelPrintRequest));

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();

                    var printerEntity = context.Printers.FirstOrDefault(ptr => labelPrintRequest.SelectedPrinterId == ptr.PrinterId);

                    var selectedPrinter = _mapper.Map<Model.DTO.Printer>(printerEntity);
                    return selectedPrinter;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(GetSelectedPrinter)}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Sends a request to the print service api for printing
        /// </summary>
        /// <param name="printLabelRequestId">The print label request id primary key</param>
        /// <returns>Print Response Model</returns>
        public async Task<PrintResponseModel> PrintDocumentAsync(int printLabelRequestId, bool isPrintNeeded, bool isPdfNeeded = false)
        {
            var printRequestModel = new PrintRequestModel();
            var printResponseModel = new PrintResponseModel();
            printResponseModel.LabelIds = new List<int>();
            printResponseModel.SuccessCount = 0;
            printResponseModel.ErrorCount = 0;

            try
            {
                if (printLabelRequestId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(printLabelRequestId));

                printRequestModel = CreatePrintRequestModel(printLabelRequestId);
                var allPrintRequestDocuments = printRequestModel.PrintDocuments;

                if (isPrintNeeded)
                {
                    var totalDocumentsPrinted = 0;
                    var printBatchSize = _apiSettings.PrintApiBatchCount;
                    var totalDocumentsToPrint = printRequestModel.PrintDocuments;
                    var totalLabelIdsToPrint = printResponseModel.LabelIds;

                    do
                    {
                        var batchDocumentsToPrint = totalDocumentsToPrint.Skip(totalDocumentsPrinted).Take(printBatchSize).ToList();
                        var batchLabelsIds = printRequestModel.LabelIds.Skip(totalDocumentsPrinted).Take(printBatchSize).ToList();
                        printRequestModel.PrintDocuments = batchDocumentsToPrint;

                        var sendDocumentsPrintResponse = await SendDocumentsToPrinterAsync(printRequestModel);

                        printResponseModel.SuccessCount += sendDocumentsPrintResponse.SuccessCount;
                        printResponseModel.ErrorCount += sendDocumentsPrintResponse.ErrorCount;

                        totalDocumentsPrinted = printResponseModel.SuccessCount + printResponseModel.ErrorCount;

                        if (sendDocumentsPrintResponse.HasError)
                        {
                            printResponseModel.HasError = true;
                            printResponseModel.ErrorDescription = sendDocumentsPrintResponse.ErrorDescription;
                            return printResponseModel;
                        }
                        else
                        {
                            printResponseModel.LabelIds.AddRange(batchLabelsIds);
                        }
                    } while (totalDocumentsPrinted < totalDocumentsToPrint.Count);
                }

                printResponseModel.LabelTypeId = printRequestModel.LabelTypeId;

                if (printResponseModel.LabelTypeId.Equals((int)Labeltypes.Unit) && isPdfNeeded)
                {
                    printResponseModel.PrintDocuments = GetUnitLabelPdfDocumentData(printLabelRequestId);
                }
                else if (printResponseModel.LabelTypeId.Equals((int)Labeltypes.Bag))
                {
                    printResponseModel.PrintDocuments = printRequestModel.PrintDocuments;
                }

                if (!isPrintNeeded && isPdfNeeded)
                {
                    // pdf only printing

                    // Add all labels Ids to list to bill
                    printResponseModel.LabelIds = printRequestModel.LabelIds;
                    printResponseModel.SuccessCount = printRequestModel.LabelIds.Count;
                }

                return printResponseModel;
            }
            catch (HttpRequestException e)
            {
                var errorMessage = $"Service: {nameof(PrinterService)} - Method: {nameof(PrintDocumentAsync)} resulted in error!\r\nPlease verify the Printing Service API is running and a connection can be established.\r\nError details:{e.Message}.\r\nInner Exception: {e.InnerException?.Message ?? "No inner exception details"}";
                _logger.LogError(errorMessage);
                printResponseModel.HasError = true;
                printResponseModel.ErrorDescription = errorMessage;
                printResponseModel.ErrorCount = printRequestModel.LabelIds.Count - printResponseModel.SuccessCount;
            }
            catch (Exception e)
            {
                var errorMessage = $"Service: {nameof(PrinterService)} - Method: {nameof(PrintDocumentAsync)} resulted in error!\r\nError details:{e.Message}.\r\nInner Exception: {e.InnerException?.Message ?? "No inner exception details"}";
                _logger.LogError(errorMessage);
                var friendlyMessage = $"Error Details: {e.Message}\r\n Additional Information: {e.InnerException?.Message ?? "Not available"}";
                printResponseModel.HasError = true;
                printResponseModel.ErrorDescription = friendlyMessage;
                printResponseModel.ErrorCount = 1;
            }

            return printResponseModel;
        }

        private async Task<PrintResponseModel> SendDocumentsToPrinterAsync(PrintRequestModel printRequestModel)
        {
            var printResponseModel = new PrintResponseModel() { HasError = false };

            _logger.LogInformation($"Service: {nameof(PrinterService)} - Method: {nameof(SendDocumentsToPrinterAsync)} - Before invoking print service web API");

            //TODO: Add Security to the printer service web api
            //var tokenResponse = _authenticationService.GetAccessToken();
            //httpClient.SetBearerToken(tokenResponse.AccessToken);

            var uri = _apiSettings.PrintServiceUri + ApiRouteConstants.PrintDocument();
            var dataAsString = JsonConvert.SerializeObject(printRequestModel);
            var content = new StringContent(dataAsString);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await _httpClient.PostAsync(uri, content);
            _logger.LogInformation($"Service: {nameof(PrinterService)} - Method: {nameof(SendDocumentsToPrinterAsync)} - After invoking print service web API");

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                printResponseModel = JsonConvert.DeserializeObject<PrintResponseModel>(result);
                printResponseModel.SuccessCount = printResponseModel.PrintDocuments.Count;
                printResponseModel.ErrorCount = 0;
            }
            else
            {
                var errorDescription = response != null
                    ? $"A successful call to the PrinterService Web Api was made however a response error code was received: {response.StatusCode}\r\nReason: {response.ReasonPhrase}"
                    : "A successful call to the PrinterService Web Api was made however the Printing Service Api response is null";

                printResponseModel.HasError = true;
                printResponseModel.LabelTypeId = printRequestModel.LabelTypeId;
                printResponseModel.ErrorDescription = errorDescription;
                printResponseModel.SuccessCount = 0;
                printResponseModel.ErrorCount = printResponseModel.PrintDocuments.Count;
            }

            return printResponseModel;
        }

        /// <summary>
        /// Deletes the print request
        /// </summary>
        /// <param name="printLabelRequestId">Print label request primary key to delete</param>
        public void DeletePrintRequest(int printLabelRequestId)
        {
            try
            {
                if (printLabelRequestId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(printLabelRequestId));

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();
                    var printRequestToDelete = context.PrintLabelRequests.FirstOrDefault(req => req.PrintLabelRequestId == printLabelRequestId);

                    if (printRequestToDelete == null)
                        return;

                    context.PrintLabelRequests.Remove(printRequestToDelete);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error at service {nameof(PrinterService)} - method {nameof(DeletePrintRequest)}: {ex.Message}");
            }
        }

        /// <summary>
        /// Increment PrintCount for list of LabelIds
        /// </summary>
        /// <param name="labelIds"></param>
        /// <returns></returns>
        public async Task<List<DTO.Label>> IncrementLabelPrintCountsAsync(List<int> labelIds)
        {
            var response = new List<DTO.Label>();
            try
            {
                _logger.LogInformation($"Method {nameof(IncrementLabelPrintCountsAsync)} : performing increment print count process");

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetService<ILabelModel>();
                    var labelData = context.Labels.Where(a => labelIds.Contains(a.LabelId)).ToList();
                    labelData.ForEach(l =>
                    {
                        l.PrintCount = l.PrintCount + 1;
                    });

                    context.SaveChanges();
                }

                _logger.LogInformation($"Method {nameof(IncrementLabelPrintCountsAsync)} : after performing increment print count process");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Label management service: {nameof(IncrementLabelPrintCountsAsync)} error message - { ex.Message }");
                throw ex;
            }
        }
    }

    #endregion
}



