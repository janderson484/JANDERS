using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService
{
    public class InvoiceService : IInvoiceService
    {
        private readonly ILogger<InvoiceService> _logger;
        private readonly IAuthService _authenticationService;
        private readonly PMApiSettings _pmApiSettings;
        public InvoiceService(IOptions<PMApiSettings> pmApiSettings, ILogger<InvoiceService> logger, IAuthService authenticationService)
        {
            _pmApiSettings = pmApiSettings.Value;
            _logger = logger;
            _authenticationService = authenticationService;
        }

        /// <summary>
        /// Sumbit the create invoice request to pm api
        /// </summary>
        /// <param name="clientCode"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> CreateInvoiceAsync(string clientCode, string user)
        {
            try
            {
                var uri = _pmApiSettings.Uri + PMApiRouteConstants.CreateInvoiceAsync() + $"/{clientCode}/{user}";
                var token = _authenticationService.GetAccessToken();
                using (var httpClient = new HttpClient())
                {
                    _logger.LogInformation($"Method: {nameof(CreateInvoiceAsync)} - Before invoking PM web API to create the invoice");
                    httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");
                    var response = await httpClient.PostAsync(uri, null);
                    _logger.LogInformation($"Method: {nameof(CreateInvoiceAsync)} - After invoking PM web API to create the invoice");
                    return response;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Sumbit the create invoice billing request to pm api
        /// </summary>
        /// <param name="clientCode"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> CreateInvoiceBillingsAsync(List<InvoiceBilling> invoiceBillings, int invoiceId)
        {
            try
            {
                var uri = _pmApiSettings.Uri + PMApiRouteConstants.CreateInvoiceBillingsAsync() + $"/{invoiceId}";
                var token = _authenticationService.GetAccessToken();
                using (var httpClient = new HttpClient())
                {
                    _logger.LogInformation($"Method: {nameof(CreateInvoiceBillingsAsync)} - Before invoking PM web API to create the invoice billing");
                    httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");
                    var jsonObject = JsonConvert.SerializeObject(invoiceBillings);
                    var content = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                    var billingResponse = await httpClient.PostAsync(uri, content);
                    _logger.LogInformation($"Method: {nameof(CreateInvoiceBillingsAsync)} - After invoking PM web API to create the invoice billing");
                    return billingResponse;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Calls the plate management api to get invoice details for a list of invoice ids
        /// </summary>
        /// <param name="invoiceIds">The invoice ids to get invoice details for</param>
        /// <returns>List of SelectInvoiceViewModel</returns>
        public async Task<HttpResponseMessage> GetInvoiceStatusByIdsAsync(List<int> invoiceIds)
        {
            try
            {
                // Get the invoice details for labels that are associated with invoices
                // Calls plate management invoicing api - Security based token required
                var token = _authenticationService.GetAccessToken();

                using (var httpClient = new HttpClient())
                {
                    _logger.LogInformation($"Method: {nameof(GetInvoiceStatusByIdsAsync)} - Before invoking PM web API to get invoice details");

                    var fullPmUrl = _pmApiSettings.Uri + PMApiRouteConstants.GetInvoiceStatusByIds();
                    httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");
                    var invoiceIdsJson = JsonConvert.SerializeObject(invoiceIds);
                    var content = new StringContent(invoiceIdsJson, Encoding.UTF8, "application/json");

                    var response = await httpClient.PostAsync(fullPmUrl, content);
                    _logger.LogInformation($"Method: {nameof(GetInvoiceStatusByIdsAsync)} - After invoking PM web API to to get invoice details");

                    return response;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(InvoiceService)}, Method: {nameof(GetInvoiceStatusByIdsAsync)} - {ex.Message}");
                throw;
            }

        }

        /// <summary>
        /// Deletes invoice billings by line item
        /// </summary>
        /// <param name="clientCode">The client code</param>
        /// <param name="itemTypeId">The type of item to delete billings for</param>
        /// <param name="billingIds">The billings ids that will be deleted</param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> DeleteInvoiceBillingsByLineItemIdAsync(string clientCode, int itemTypeId, List<int> billingIds)
        {
            try
            {
                var token = _authenticationService.GetAccessToken();
                using (var httpClient = new HttpClient())
                {
                    _logger.LogInformation($"Method: {nameof(DeleteInvoiceBillingsByLineItemIdAsync)} - Before invoking PM web API to delete invoice billings");

                    var fullPmUrl = _pmApiSettings.Uri + PMApiRouteConstants.DeleteInvoiceBillingsByLineItemId() + $"/{clientCode}/{itemTypeId}";
                    httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");

                    var dataAsString = JsonConvert.SerializeObject(billingIds);
                    var content = new StringContent(dataAsString, Encoding.UTF8, "application/json");
                    var response = await httpClient.PostAsync(fullPmUrl, content);

                    _logger.LogInformation($"Method: {nameof(GetInvoiceStatusByIdsAsync)} - After invoking PM web API to delete invoice billings");

                    return response;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(InvoiceService)}, Method: {nameof(DeleteInvoiceBillingsByLineItemIdAsync)} - {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets the billing lookup data 
        /// </summary>
        /// <returns>HttpResponseMessage</returns>
        public async Task<HttpResponseMessage> GetBillingLookupsAsync()
        {
            try
            {
                var token = _authenticationService.GetAccessToken();
                using (var httpClient = new HttpClient())
                {
                    _logger.LogInformation($"Method: {nameof(GetBillingLookupsAsync)} - Before invoking PM web API to get the billing lookup data");

                    var fullPmUrl = _pmApiSettings.Uri + PMApiRouteConstants.GetBillingLookUps();
                    httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");
                    var response = await httpClient.GetAsync(fullPmUrl);
                    _logger.LogInformation($"Method: {nameof(GetBillingLookupsAsync)} - After invoking PM web API to get the billing lookup data");

                    return response;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(InvoiceService)}, Method: {nameof(GetBillingLookupsAsync)} - {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets the invoie data to print
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> GetInvoiceDataToPrintAsync(SearchInvoiceDataToPrintViewModel model)
        {
            try
            {
                var token = _authenticationService.GetAccessToken();
                using (var httpClient = new HttpClient())
                {
                    _logger.LogInformation($"Method: {nameof(GetInvoiceDataToPrintAsync)} - Before invoking PM web API to get the Invoice data");

                    var fullPmUrl = _pmApiSettings.Uri + PMApiRouteConstants.GetInvoiceDataToPrint();
                    httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");
                    var jsonObject = JsonConvert.SerializeObject(model);
                    var content = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                    var response = await httpClient.PostAsync(fullPmUrl, content);
                    _logger.LogInformation($"Method: {nameof(GetBillingLookupsAsync)} - After invoking PM web API to get the Invoice data");
                    return response;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: {nameof(InvoiceService)}, Method: {nameof(GetInvoiceDataToPrintAsync)} - {ex.Message}");
                throw;
            }
        }

    }
}
