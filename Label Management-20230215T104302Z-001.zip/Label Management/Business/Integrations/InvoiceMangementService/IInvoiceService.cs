using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService
{
    public interface IInvoiceService
    {
        Task<HttpResponseMessage> CreateInvoiceAsync(string clientCode, string user);
        Task<HttpResponseMessage> CreateInvoiceBillingsAsync(List<InvoiceBilling> invoiceBillings, int invoiceId);
        Task<HttpResponseMessage> GetInvoiceStatusByIdsAsync(List<int> invoiceIds);
        Task<HttpResponseMessage> DeleteInvoiceBillingsByLineItemIdAsync(string clientCode, int itemTypeId, List<int> billingIds);
        Task<HttpResponseMessage> GetBillingLookupsAsync();
        Task<HttpResponseMessage> GetInvoiceDataToPrintAsync(SearchInvoiceDataToPrintViewModel model);
    }
}
