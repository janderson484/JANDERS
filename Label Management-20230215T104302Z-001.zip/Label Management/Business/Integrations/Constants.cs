using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Business.Integrations
{
    public class ApiRouteConstants
    {
        //Print Service API Urls
        public static string PrintDocument() => "api/Printing/PrintDocument";
    }

    public static class PrinterConfigurationValidationErrors
    {
        public static string DisplayNameNotUnique = "PrinterDisplayNameNotUnique";
        public static string IPAddressPortNumberNotUnique = "PrinterIpAddressPortNumberPairNotUnique";
    }
}
