using System.Collections.Generic;
using System.Threading.Tasks;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Business
{
    public interface ILabelManagementService
    {
        Task<Dictionary<string, object>> GetLabelLookUpsAsync();
        Task<SearchLabelViewModel> GetLabelsAsync(SearchLabelViewModel searchCriteria);

        List<LabelViewModel> GetLabelsPrintData(List<int> labelIds);
        List<LabelViewModel> GetLabelsPrintData(int printLabelRequestId);

        //Task<List<Model.DTO.LabelStatusType>> GetLabelStatusesAsync();
        Task<BulkUpdateResultViewModel> UpdateLabelsAsync(UpdateLabelsModel updatedLabels);
        Task<IPaginate<Label>> GetPendingNonActiveLabelsForBulkProcessAsync(string clientCode, string processingLocationCode, int labelTypeId, int batchSize = 20);
        Task<IPaginate<Label>> GetActiveLabelsByVinsAsync(string clientCode, string processingLocationCode, List<string> labelVins, int batchSize = 20);
        Task<BulkProcessViewModel> GetBulkProcessRecordCountTaskAsync(string client, string processingLocationCode);
        Task<LabelImportViewModel> SubmitImportLabelRequestAsync(LabelImportViewModel model);
        Task<NotificationViewModel> CreateNotificationsAsync(Log log);
        Task<List<NotificationViewModel>> GetNotificationsByUserNameAsync(string userName);
        Task<LogSummaryViewModel> GetLogsAsync(LogSummaryViewModel model);
        Task<Log> GetLogAsync(int logId);
        Task<LogDetailViewModel> GetLogDetailsAsync(LogDetailViewModel model);
        Task<DTO.Log> CreateJobLogTaskAsync(DTO.Log log);
        Task<DTO.Log> UpdateLogStatusByIdAsync(int logId, string logStatus);
        Task<DTO.Log> UpdateLogStatusAsync(DTO.Log log, List<DTO.LogDetail> logDetails);

        Task<List<DTO.ImportLabelRequest>> GetImportLabelDetailsAsync(int logId, string clientCode);
        Task<IPaginate<Label>> CloseActivePrintedLabelsForBulkProcessAsync(string clientCode, string processingLocationCode, int batchSize = 20);
        //Task<List<DTO.LabelImportConfiguration>> GetLabelImportFieldMappingsAsync(int labelImportId, string clientCode);
        Task<DTO.LabelImportValidationResponse> ValidateImportLabelRequestAsync(List<DTO.ImportLabelRequest> importLabels, string clientCode);
        Task AddLabelsAsync(List<Label> entityLabels);
        Task DeleteImportLabelRequestAsync(int logId);
        Task<List<int>> GetVoidedLabelBillingsForCreditLabelsAsync(List<int> labelIds);
        Task<DTO.Log> SubmitExportAllRequestAsync(ExportLabelViewModel model);
        Task<SearchLabelViewModel> GetLabelsForExportAsync(SearchLabelViewModel searchCriteria);
        Task<DTO.Log> GetLogStatusAsync(int logid);
        Task<List<CreditLabelViewModel>> ValidateLabelsToApplyCreditsAsync(IEnumerable<int> labels);
        Task ApplyCreditsToLabelsAsync(CreditLabelRequestModel model);
        //Task<List<InvoiceStatusViewModel>> GetInvoiceStatusAsync(List<int> invoiceId);
        Task<List<int>> GetVoidedLabelBillingsAsync(List<int> labelIds);
        //Task DeleteInvoiceByBillingIdAsync(List<int> labelBillingIds, string clientCode);
        Task<BulkUpdateResultViewModel> PerformBulkUpdateAsync(BulkUpdateViewModel bulkUpdateModel);


        /// <summary>
        /// Gets list of Labels for a specified type that are not in void status
        /// </summary>
        /// <param name="clientCode"></param>
        /// <param name="batchSize"></param>
        /// <returns></returns>
        Task<IPaginate<LabelBilling>> GetInvoicePendingLabelsForBulkProcessAsync(string clientCode, int batchSize = 20);

        /// <summary>
        /// Updates existing log record counts. If remainingCount == 0, then updates to Complete status
        /// </summary>
        /// <param name="log">Existing Log to be updated</param>
        /// <param name="totalProcessedCount">Accumulative count of records processed</param>
        /// <param name="remainingCount">Count of records remaining</param>
        /// <param name="fileName"></param>
        Task<Log> UpdateLogStatusAsync(Log log, int totalProcessedCount, int remainingCount, string fileName = "");

        /// <summary>
        /// Updates Log to In Progress once records have begun processing
        /// </summary>
        /// <param name="log">Existing Log to be updated</param>
        /// <param name="remainingCount">Total count of records to be processed</param>
        Task CreateInProgressLogAsync(Log log, int remainingCount);

        /// <summary>
        /// Updates an existing Log row to Failed status
        /// </summary>
        /// <param name="log">Existing Log records to be updated</param>
        Task<Log> CreateLogFailedAsync(Log log);

        /// <summary>
        /// Create individual LogDetails for Failed labels
        /// </summary>
        /// <param name="log">LogId associated with plate update attempt</param>
        /// <param name="labelList">labels associated with label update attempt</param>
        /// <param name="errorMessage">Error message to attach to Failed records</param>
        Task CreateLogDetailsErrorsAsync(Log log, string errorMessage, IPaginate<Label> labelList = null, IPaginate<LabelBilling> labelBillingList = null);

        /// <summary>
        /// Gets the labels billings data
        /// </summary>
        /// <param name="labelIds">returns label billings</param>
        Task<List<DTO.LabelBilling>> GetLabelBillingDataAsync(List<int> labelIds);

        /// <summary>
        /// Gets the labels data
        /// </summary>
        /// <param name="labelIds">returns label data</param>
        Task<List<DTO.Label>> GetLabelDataAsync(List<int> labelIds);

        /// <summary>
        /// Service method to update label billings
        /// </summary>
        /// <param name="labelBillings">input criteria</param>
        /// <returns>returns status</returns>
        Task<bool> UpdateLabelBillingAsync(List<int> labelBillingIds, int invoiceId);

        /// <summary>
        /// Service method to perform invoice for label billings
        /// </summary>
        /// <param name="labelsToProcess">input criteria</param>
        /// <param name="clientCode">input criteria</param>
        /// <param name="user">input criteria</param>
        /// <returns>returns status</returns>
        Task<DTO.ApiResponseDto> PerformBulkInvoiceAsync(string clientCode, string user, IList<Label> labelsToProcess = null, IList<LabelBilling> labelBillingsToProcess = null);
        Task<List<int>> GetInvoiceIdsForLabelsAsync(List<int> labels);
        Task<SaveBillingsResult> SaveLabelBillingsAsync(List<LabelViewModel> labels, string userId);
        bool VoidLabelBillings(int labelId, string userId);
        Task<List<SelectInvoiceViewModel>> GetInvoiceStatusByIdsAsync(List<int> invoiceIds);
        Task<string> DeleteInvoiceBillingsByLineItemIdAsync(string clientCode, int itemTypeId, List<int> billingIds);
        Task<DTO.BillingLookup> GetBillingLookupsAsync();
        Task<DTO.ApiResponseDto> BulkInvoiceProcessAsync(List<DTO.Label> labels, string clientCode, string user);

        /// <summary>
        /// Service method to update label 
        /// </summary>
        /// <param name="labelIds">input criteria</param>
        /// <returns>returns status</returns>
        Task<bool> UpdateLabelStatusAsync(List<int> labelIds);
        Task<bool> UpdateLabelProcessingOfficeAsync(MoveLabelsViewModel model);
        Task<CopyLabelsViewModel> CopyLabelsAsync(CopyLabelsViewModel model);
        Task<bool> GetBillingReasonTypeAsync(LabelViewModel model);
    }
}


