using System.Collections.Generic;
using AutoMapper;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;

namespace VM.FleetServices.TnR.LM.Business.Mapping
{
    public class LabelManagementMappingProfile : Profile
    {
        public LabelManagementMappingProfile()
        {
            CreateMap<LabelStatusType, Model.DTO.LabelStatusType>();
            CreateMap<Model.DTO.LabelStatusType, LabelStatusType>();

            CreateMap<LabelType, Model.DTO.LabelType>();
            CreateMap<Model.DTO.LabelType, LabelType>();

            CreateMap<LabelImport, Model.ViewModel.ImportLayoutViewModel>();
            CreateMap<Model.ViewModel.ImportLayoutViewModel, LabelImport>();

            CreateMap<LabelImportField, VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>();
            CreateMap<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField, LabelImportField>();

            CreateMap<LabelImportFieldsMapping, Model.DTO.LabelImportFieldsMapping>();
            CreateMap<Model.DTO.LabelImportFieldsMapping, LabelImportFieldsMapping>();

            CreateMap<Label, Model.ViewModel.LabelViewModel>();
            CreateMap<Model.ViewModel.LabelViewModel, Label>();

            CreateMap<Log, Model.DTO.Log>();
            CreateMap<Model.DTO.Log, Log>();

            CreateMap<LogDetail, Model.DTO.LogDetail>();
            CreateMap<Model.DTO.LogDetail, LogDetail>();

            CreateMap<ImportLabelRequest, Model.DTO.ImportLabelRequest>();
            CreateMap<Model.DTO.ImportLabelRequest, ImportLabelRequest>();

            CreateMap<LabelImport, Model.DTO.LabelImport>();
            CreateMap<Model.DTO.LabelImport, LabelImport>();

            CreateMap<Label, Model.DTO.Label>();
            CreateMap<Model.DTO.Label, Label>();

            CreateMap<Printer, Model.ViewModel.UserPrintersViewModel>();
            CreateMap<Model.ViewModel.UserPrintersViewModel, Printer>();

            CreateMap<PrinterLabelSetting, Model.ViewModel.UserPrintersViewModel>();
            CreateMap<Model.ViewModel.UserPrintersViewModel, PrinterLabelSetting>();

            CreateMap<PrinterLabelSetting, Model.DTO.PrinterLabelSetting>();
            CreateMap<Model.DTO.PrinterLabelSetting, PrinterLabelSetting>();

            CreateMap<Printer, Model.DTO.Printer>();
            CreateMap<Model.DTO.Printer, Printer>();

            CreateMap<LabelBilling, Model.DTO.LabelBilling>();
            CreateMap<Model.DTO.LabelBilling, LabelBilling>();
        }
    }
}
