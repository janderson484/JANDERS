using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ServiceBus;

namespace VM.FleetServices.TnR.LM.Business.ServiceBus
{
    public class ServiceBusService : IServiceBusService
    {
        /// <summary>
        /// The _sender svc.
        /// </summary>
        private readonly ISenderServiceBus _senderSvc;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBusService"/> class.
        /// </summary>
        /// <param name="senderSvc"></param>
        public ServiceBusService(ISenderServiceBus senderSvc)
        {
            _senderSvc = senderSvc;
        }

        /// <summary>
        /// Creates JSON message and sends to Service Bus
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        public async Task SendMessageAsync(Log log)
        {
            var msg = CreateJsonMessage(log);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }

        // TODO: Add back with LM has export all
        /*
        /// <summary>
        /// Sends the message to service bus queue.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="exportRequest">The export request.</param>
        public async Task SendMessageAsync(Log log, ExportAllReportDataRequest exportRequest)
        {
            var msg = CreateJsonMessage(log, exportRequest);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }
        */

        /// <summary>
        /// Sends the message to service bus queue.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="processingLocationCode">The processing location code.</param>
        public async Task SendMessageAsync(Log log, string processingLocationCode)
        {
            var msg = CreateJsonMessage(log, processingLocationCode);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }

        /// <summary>
        /// Creates the json message.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="processingLocationCode">The processing location code.</param>
        /// <returns>Message as JSON string</returns>
        public string CreateJsonMessage(Log log, string processingLocationCode = null)
        {
            var messageDictionary = new ServiceBusMessage();

            messageDictionary.Data.Add(ServiceBusMessageProperties.ClientCode, log.ClientCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.ProcessingLocationCode, log.ProcessingLocationCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.UserName, log.CreatedUser);
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionCode, log.ProcessName);
            messageDictionary.Action.Add(ServiceBusMessageProperties.LogId, log.LogId.ToString());
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionDateTime, DateTime.Now.ToString());

            if (!string.IsNullOrEmpty(processingLocationCode))
            {
                messageDictionary.Action.Add(ServiceBusMessageProperties.ProcessingLocationCode, processingLocationCode);
            }

            var msgText = JsonConvert.SerializeObject(messageDictionary);
            return msgText;
        }

        /// <summary>
        /// Creates JSON message and sends to Service Bus
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="log"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task SendDynamicMessageAsync<T>(Log log, T model)
        {
            var msg = CreateDynamicJsonMessage(log, model);

            if (!string.IsNullOrEmpty(msg))
            {
                await _senderSvc.SendMessageAsync(msg, log);
            }
        }

        /// <summary>
        /// Creates the json message for type class.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="log"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        public string CreateDynamicJsonMessage<T>(Log log, T model)
        {
            var messageDictionary = new ServiceBusMessage();

            messageDictionary.Data.Add(ServiceBusMessageProperties.ClientCode, log.ClientCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.ProcessingLocationCode, log.ProcessingLocationCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.UserName, log.CreatedUser);
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionCode, log.ProcessName);
            messageDictionary.Action.Add(ServiceBusMessageProperties.LogId, log.LogId.ToString());
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionDateTime, DateTime.Now.ToString());

            var type = model.GetType();
            if (type.IsClass)
            {
                foreach (var propertyInfo in type.GetProperties())
                {
                    var value = propertyInfo.GetValue(model);
                    var name = propertyInfo.Name;
                    messageDictionary.Action.Add(name, Convert.ToString(value));
                }
            }
            var msgText = JsonConvert.SerializeObject(messageDictionary);
            return msgText;
        }

        // TODO: Add back when LM has export all
        /*
        /// <summary>
        /// Creates the json message.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="request">The request.</param>
        /// <returns>JSON string</returns>
        public string CreateJsonMessage(Log log, ExportAllReportDataRequest request)
        {
            var messageDictionary = new ServiceBusMessage();

            messageDictionary.Data.Add(ServiceBusMessageProperties.ClientCode, log.ClientCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.StateProvinceCode, log.StateProvinceCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.ProcessingLocationCode, log.ProcessingLocationCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.InventoryCode, log.InventoryCode);
            messageDictionary.Data.Add(ServiceBusMessageProperties.UserName, log.CreatedUser);
            messageDictionary.Data.Add(ServiceBusMessageProperties.ExportName, request?.ExportName);
            messageDictionary.Data.Add(ServiceBusMessageProperties.StartDate, request?.StartDate.ToString());
            messageDictionary.Data.Add(ServiceBusMessageProperties.EndDate, request?.EndDate.ToString());
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionCode, log.ProcessType);
            messageDictionary.Action.Add(ServiceBusMessageProperties.LogId, log.LogId.ToString());
            messageDictionary.Action.Add(ServiceBusMessageProperties.ActionDateTime, DateTime.Now.ToString(CultureInfo.InvariantCulture));

            var msgText = JsonConvert.SerializeObject(messageDictionary);
            return msgText;
        }
        */
    }

    /// <summary>
    /// The ServiceBusService interface.
    /// </summary>
    public interface IServiceBusService
    {
        /// <summary>
        /// The send message async.
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        Task SendMessageAsync(Log log);

        // TODO: Add back when LM has export all
        //Task SendMessageAsync(Log log, ExportAllReportDataRequest message);

        Task SendMessageAsync(Log log, string processingLocationCode);
        Task SendDynamicMessageAsync<T>(Log log, T model);
    }
}
