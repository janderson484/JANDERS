using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.Business.ServiceBus
{
    public class ServiceBusOptions
    {
        /// <summary>
        /// Gets or sets Connection String
        /// </summary>
        public string ConnectionString { get; set; }

        /// <summary>
        /// Gets or sets the name space.
        /// </summary>
        public string NameSpace { get; set; }

        /// <summary>
        /// Gets or sets the access key name.
        /// </summary>
        public string AccessKeyName { get; set; }

        /// <summary>
        /// Gets or sets the key.
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// Gets or sets the queue name.
        /// </summary>
        public string QueueName { get; set; }
    }
}
