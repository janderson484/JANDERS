using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Business.ServiceBus
{
    public interface ISenderServiceBus
    {
        Task SendMessageAsync(string msg, Log log);
    }
}
