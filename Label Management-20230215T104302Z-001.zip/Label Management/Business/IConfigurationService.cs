using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Business
{
    public interface IConfigurationService
    {
        Task<ImportLayoutConfigurationViewModel> GetImportLayoutsAsync(UserProfileSettingsViewModel baseRequest);

        Task<bool> UpdateImportLayoutStatusAsync(ImportLayoutViewModel model);

        Task<LabelSortOrderViewModel> GetLabelSortOrderByUserAsync(string userId, string clientCode, string processingCode);

        Task<Tuple<List<LabelImportField>, List<LabelType>>> GetMasterDataAsync();

        Task<ImportLayoutViewModel> GetImportLayoutAsync(int id);
        Task<bool> SaveLayoutConfigAsync(ImportLayoutViewModel model);

        Task<ImportLayoutConfigurationViewModel> GetImportTypesAsync(UserProfileSettingsViewModel profileSettingsViewModel);
        Task<ImportLayoutConfigurationViewModel> GetLabelTypeAsync(AddLabelsViewModel model);
        Task<LabelSortOrderConfigurationViewModel> GetLabelSortOrderAsync(UserProfileSettingsViewModel baseRequest);
        Task<LabelSortOrderViewModel> GetLabelSortOrderAsync(int id);
        Task<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>> GetLabelDataAsync();
        Task<bool> SaveLabelSortOrderAsync(LabelSortOrderViewModel model);
        Task<bool> UpdateLabelSortOrderStatusAsync(LabelSortOrderViewModel model);
        Task<bool> DeleteSortOrderAsync(int id);
        Task<List<LabelSortOrderViewModel>> GetAllLabelSortOrderAsync(string clientCode,string ProcessingCode);
        Task<PersonalSettingsViewModel> GetPersonalSettingsAsync(string userId, string clientCode, string processingCode);
        Task<bool> SetPersonalSettingsAsync(PersonalSettingsViewModel model);
    }
}
