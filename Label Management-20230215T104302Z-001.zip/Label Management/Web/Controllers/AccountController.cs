using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Mvc;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly OpenIdSettings _openIdSettings;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IApiClientService apiClientService, IOptions<ApiSettings> apiSettings, IOptions<OpenIdSettings> openIdSettings, ILogger<AccountController> logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _openIdSettings = openIdSettings.Value;
            _logger = logger;
        }

        [Authorize]
        public IActionResult SignIn()
        {
            return RedirectToAction("Index", "Home");
        }

        public IActionResult SignOut()
        {
            // clear session data, check if Abandon is available in asp.net core
            HttpContext.Session.Clear();
          
            // Remove the authentication cookie and return the user to the client application.            
            return SignOut("Cookies", "oidc");
        }

        [Authorize]
        public IActionResult Information()
        {
            var uri = new Uri(new Uri(_openIdSettings.Authority), "Account/UserProfile");
            return Redirect(uri.ToString());
        }

        #region PersonalSettings

        //[Authorize]
        //[HttpGet]
        //public async Task<IActionResult> PersonalSettings()
        //{
        //    var client = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
        //    _apiClientService.SetClientCode(client);

        //    var uri = _apiSettings.Uri + ApiRouteConstants.GetPlateLookups();

        //    // TODO: the below code has to be enabled and should be in Home controller index when we move ahead with applying caching techniques
        //    // TODO: Not sure if this is necessary for Personal Settings
        //    //if (!_cache.TryGetValue(SessionKeys.PlateManagementLookUps, out Dictionary<string, object> pmLookups))
        //    //{
        //    //    pmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
        //    //    _cache.Set(SessionKeys.PlateManagementLookUps, pmLookups);
        //    //}

        //    var pmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.PlateManagementLookUps);

        //    if (pmLookups == null)
        //    {
        //        pmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
        //        HttpContext.Session.Set(SessionKeys.PlateManagementLookUps, pmLookups);
        //    }

        //    uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings();
        //    var personalSettingsDefaults = HttpContext.Session.Get<PersonalSetting>(SessionKeys.PersonalSettingsDefaults);
        //    var personalSettingsSession = HttpContext.Session.Get<PersonalSetting>(SessionKeys.PersonalSettingsSession);

        //    if (personalSettingsSession == null || personalSettingsDefaults == null)
        //    {
        //        var personalSettings = await _apiClientService.GetResponseAsync<PersonalSetting>(uri);
        //        HttpContext.Session.Set(SessionKeys.PersonalSettingsDefaults, personalSettings);
        //        HttpContext.Session.Set(SessionKeys.PersonalSettingsSession, personalSettings);

        //        personalSettingsDefaults = HttpContext.Session.Get<PersonalSetting>(SessionKeys.PersonalSettingsDefaults);
        //    }

        //    var model = new PersonalSettingsViewModel()
        //    {
        //        ProcessingLocationCodeList = GetProcessingLocationListCodeAsync(),
        //        RowsPerPageList = GetRowsPerPageList(),
        //        ProcessingLocationCode = personalSettingsDefaults?.ProcessingLocationCode,
        //        RowsPerPage = personalSettingsDefaults?.RowsPerPage ?? default(int)
        //    };

        //    return View(model);
        //}

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //[Authorize]
        //public async Task<IActionResult> PersonalSettings(PersonalSettingsViewModel model)
        //{
        //    var uri = _apiSettings.Uri + ApiRouteConstants.SetPersonalSettings();

        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            var clientCode = HttpContext.Session.GetString(SessionKeys.SelectedClientCode);
        //            _apiClientService.SetClientCode(clientCode);

        //            var apiResponse = await _apiClientService.PostRequestAsync(uri, model);

        //            if (apiResponse.IsSuccessStatusCode)
        //            {
        //                var result = apiResponse.Content.ReadAsStringAsync().Result;
        //                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<PersonalSetting>>(result);

        //                if (serviceResponse != null && serviceResponse.ResponseCode == HttpStatusCode.Accepted)
        //                {
        //                    HttpContext.Session.Set(SessionKeys.PersonalSettingsDefaults, serviceResponse.Data);
        //                    HttpContext.Session.Set(SessionKeys.PersonalSettingsSession, serviceResponse.Data);
        //                    HttpContext.Session.Set("PersonalSettingsFormResponse", "SUCCESS");
        //                }
        //                else
        //                {
        //                    HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");
        //                }

        //            }
        //            else
        //            {
        //                HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");
        //            }                    
        //        }
        //        else
        //        {
        //            ModelState.Clear();
        //            HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");

        //            return View(model);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");
        //        _logger.LogError($"POST method: {nameof(PersonalSettings)} - Unable to save changes. Message: {ex.Message}");
        //    }

        //    return RedirectToAction("PersonalSettings");
        //}

        [AllowAnonymous]
        public IActionResult KeepAlive()
        {
            return Content("I am alive!");
        }

        #endregion

        #region Private Methods

        //private IEnumerable<SelectListItem> GetProcessingLocationListCodeAsync()
        //{
        //    var pmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.PlateManagementLookUps);

        //    return ((JArray)pmLookups?["ProcessingLocations"])?.ToObject<List<ProcessingLocation>>().Where(a => a.Active).Select(a => new SelectListItem
        //    {
        //        Text = a.DisplayName,
        //        Value = a.ProcessingLocationCode
        //    });
        //}

        private IEnumerable<SelectListItem> GetRowsPerPageList()
        {
            var rowNums = new List<int>
            {
                25,
                50,
                100,
                150
            };

            return rowNums.Select(a => new SelectListItem
            {
                Text = a.ToString(),
                Value = a.ToString()
            });
        }

        #endregion

        #region Public Methods

        public string GetPersonalSettingsFormResponse()
        {
            return HttpContext.Session.GetString("PersonalSettingsFormResponse");
        }

        public IActionResult UpdateHeaderSelectionViewComponent(string clientCode, string processingLocationCode, string inventoryCode)
        {
            return ViewComponent("HeaderSelection", new { ClientCode = clientCode, ProcessingLocationCode = processingLocationCode, InventoryCode = inventoryCode});
        }

        #endregion
    }
}
