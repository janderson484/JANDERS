using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.Models;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [Authorize]
    public class AddLabelsController : BaseController
    {
        #region PrivateMembers

        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly ILogger<AddLabelsController> _logger;
        private readonly IMemoryCache _cache;
        private readonly AppSettings _appSettings;
        private readonly PMApiSettings _pmApiSettings;

        #endregion

        #region Constructor
        public AddLabelsController(IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IApiClientService apiClientService,
            ILogger<AddLabelsController> logger, IMemoryCache cache, IOptions<AppSettings> appSettings) : base(apiSettings, pmApiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            _cache = cache;
            _appSettings = appSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
        }
        #endregion

        #region Public Methods

        [VerifyClientLocationUserPreferencesActionFilter]
        public async Task<IActionResult> IndexAsync()
        {
            if (User.IsLMExternalUser())
            {
                return AccessDenied();
            }

            if (HttpContext.Session.Get<DTO.PersonalSetting>(SessionKeys.PersonalSettingsSession) == null)
            {
                return RedirectToAction("PersonalSettings", "Configuration");
            }

            var profileSettings = GetUserProfileSettings();
            var model = await GetImportTypesAsync(profileSettings);

            return View(model);
        }

        /// <summary>
        /// Gets import types
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<ImportLayoutConfigurationViewModel> GetImportTypesAsync(UserProfileSettingsViewModel profileSettings)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetImportTypes();

            _logger.LogInformation($"Post method: {nameof(GetImportTypesAsync)} - Calling {uri}");
            var response = await _apiClientService.GetResponseAsync(uri, profileSettings);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<ServiceResponse<ImportLayoutConfigurationViewModel>>(stringResult);
            return result.Data;
        }

        /// <summary>
        /// Gets Label type based on selected Import Type Dropdown Selection
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ImportLayoutConfigurationViewModel> GetLabelTypeAsync(int id)
        {
            var model = new AddLabelsViewModel()
            {
                LabelImportId = id,
                ClientCode = GetUserProfileSettings().ClientCode,
                ProcessingLocationCode = GetUserProfileSettings().ProcessingLocationCode
            };

            var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelType();
            var processingLocationList = await GetProcessingLocationListAsync();

            _logger.LogInformation($"Post method: {nameof(GetImportTypesAsync)} - Calling {uri}: for LabelImportId: {id}");
            var response = await _apiClientService.GetResponseAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<ServiceResponse<ImportLayoutConfigurationViewModel>>(stringResult);
            if(result.Data!=null)
            {
                if (result.Data.ImportLayouts != null && result.Data.ImportLayouts.Count > 0 && result.Data.ImportLayouts[0].SelectedProcessingLocationCodeList != null)
                {
                    result.Data.ImportLayouts[0].ProcessingLocationCode = GetUserProfileSettings().ProcessingLocationCode;
                    result.Data.SelectedProcessingLocationList = processingLocationList.Where(a => result.Data.ImportLayouts[0].SelectedProcessingLocationCodeList.Contains(a.Value));
                }
            }
            

            return result.Data;
        }

        /// <summary>
        /// This method pulls data from the View & cleans the import data
        /// </summary>
        /// <param name="model"></param>
        /// <returns>If a parsing error, it returns and error. If no error, it calls the api</returns>
        [HttpPost]
        public async Task<JsonResult> ImportLabelsAsync(LabelImportViewModel model)
        {
            var userInfo = GetUserProfileSettings();
            model.ClientCode = userInfo.ClientCode;
            model.CreatedUser = User.Identity.Name;
            model.CreatedDate = DateTime.Now;
            model.ModifiedUser = User.Identity.Name;
            model.ModifiedDate = DateTime.Now;
            model.DmvStateCode = userInfo.DmvStateCode;
            model.ProcessingOffice = userInfo.ProcessingLocationCode;
            var parsedData = ParseImportLabelData(model);
            model.ImportLabelData = parsedData;

            try
            {
                if (parsedData.First().ContainsKey("Error"))
                {
                    foreach (var item in parsedData)
                    {
                        return Json(item);
                    }
                }

                var uri = _apiSettings.Uri + ApiRouteConstants.ImportLabels();
                _logger.LogInformation($"Post method: {nameof(ImportLabelsAsync)} - Calling {uri}: for LabelImportId: {model}");

                var response = await _apiClientService.PostRequestAsync(uri, model);
                if (!response.IsSuccessStatusCode)
                    throw new Exception("Http Response was not successful");

                var stringResult = response.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<ServiceResponse<ImportLayoutConfigurationViewModel>>(stringResult);
                return Json(result.Data);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Get user profile settings
        /// </summary>
        /// <returns></returns>
        private UserProfileSettingsViewModel GetUserProfileSettings()
        {
            var userPreferences = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            return new UserProfileSettingsViewModel()
            {
                ClientCode = userPreferences?.ClientCode,
                ProcessingLocationCode = userPreferences?.ProcessingLocationCode
            };
        }

        /// <summary>
        /// Separate pasted import label data, with validations
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Validated List of Dictionary Records</returns>
        private List<Dictionary<string, string>> ParseImportLabelData(LabelImportViewModel model)
        {
            var importList = new List<Dictionary<string, string>>();
            var data = model.LabelData;
            string[] rows = { };
            string[] fields = { };

            try
            {
                // check for no data input
                if (data != null)
                {
                    if (!data.Contains(Delimiters.NewLine))
                    {
                        data += Delimiters.Tab;
                        data += Delimiters.NewLine;
                    }

                    if (data.Contains(Delimiters.NewLine))
                    { rows = data.Split(Delimiters.NewLine, StringSplitOptions.RemoveEmptyEntries); }

                    // check for more rows than allowed
                    if (rows.Count() > RecordCountLimits.MaxRecordCount)
                    {
                        var importData = new Dictionary<string, string>();
                        importData.Add("Error", "Record count cannot exceed 1000");
                        importList.Add(importData);
                        return importList;
                    }
                    // check for only tab / carriage return with no actual data
                    if (rows.Count() >= RecordCountLimits.MinRecordCount)
                    {
                        foreach (var item in rows)
                        {
                            var importData = new Dictionary<string, string>();
                            var fieldData = new string[] { };
                            // Tab and comma delimited
                            if (item.Contains(Delimiters.Tab))
                            {
                                fieldData = item.Split(Delimiters.Tab, StringSplitOptions.None);

                                if ((fieldData.Length > model.ImportOrderList.Count) && string.IsNullOrEmpty(fieldData.Last()))
                                {
                                    //skips the last index if it is empty
                                    fields = fieldData.SkipLast(1).ToArray();
                                }
                                else
                                {
                                    fields = fieldData;
                                }
                            }
                            else if (item.Contains(Delimiters.Comma))
                            {
                                fieldData = item.Split(Delimiters.Comma, StringSplitOptions.None);
                                if ((fieldData.Length > model.ImportOrderList.Count) && string.IsNullOrEmpty(fieldData.Last()))
                                {
                                    //skips the last index if it is empty
                                    fields = fieldData.SkipLast(1).ToArray();
                                }
                                else
                                {
                                    fields = fieldData;
                                }
                            }
                            else if (!string.IsNullOrEmpty(item))
                            {
                                fields = new string[] { item };
                            }

                            for (var x = 0; x < fields.Count(); x++)
                            {
                                for (var i = x; i <= model.ImportOrderList.Count(); i++)
                                {
                                    if (x == i)
                                    {
                                        if (model.ImportOrderList.Count() != fields.Count())
                                        {
                                            var error = FieldParsingError("The pasted data does not match the expected layout.");
                                            return error;
                                        }
                                        var column = model.ImportOrderList.ElementAt(i).Substring(0, model.ImportOrderList.ElementAt(i).IndexOf(Delimiters.Colon));
                                        var field = fields.ElementAt(x);

                                        // checks for a null value passed with a required field
                                        if (model.ImportOrderList.ElementAt(i).Contains("true") && (field == "" || field == null))
                                        {
                                            var error = FieldParsingError($"The {column}: {field} is Required");
                                            return error;
                                        }
                                        else
                                        {
                                            // Ignore column & associated value for blank columns
                                            if (!column.Contains("BLANK"))
                                            {
                                                // checks for a duplicate column in import
                                                if (importData.ContainsKey(column))
                                                {
                                                    var error = FieldParsingError($"The {column} field is a duplicate! Please update the configuration.");
                                                    return error;
                                                }
                                                // uppercase Vin Value
                                                if (column.Equals("VIN"))
                                                {
                                                    field = field.ToUpper();
                                                    if (!Regex.IsMatch(field, "^[a-zA-Z0-9]*$"))
                                                    {
                                                        var error = FieldParsingError($"The {column}: {field} contains invalid charachers");
                                                        return error;
                                                    }
                                                    if (field.Length < RecordCountLimits.VinImportMinLength)
                                                    {
                                                        var error = FieldParsingError($"The {column}: {field} must be at least {RecordCountLimits.VinImportMinLength} character long.");
                                                        return error;
                                                    }
                                                    if (field.Length > RecordCountLimits.VinImportMaxLength)
                                                    {
                                                        var error = FieldParsingError($"The {column}: {field} can not be more than {RecordCountLimits.VinImportMaxLength} characters long.");
                                                        return error;
                                                    }
                                                    if (importList.Any(l => l.ContainsValue(field)))
                                                    {
                                                        var error = FieldParsingError($"The {column}: {field} is duplicated in the input.");
                                                        return error;
                                                    }
                                                }
                                                importData.Add(column, field);
                                            }
                                        }
                                    }
                                    else
                                    { break; }
                                }
                            }
                            importList.Add(importData);
                        }
                    }
                    else
                    {
                        var error = FieldParsingError("Must contain one record!");
                        return error;
                    }
                }
                else
                {
                    var error = FieldParsingError("Must contain one record!");
                    return error;
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Validation Parse method: {nameof(ParseImportLabelData)} - Error: {e.Message}");
                throw e;
            }

            return importList;
        }

        /// <summary>
        /// Handle parsing validation errors
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns>Error message back to the user</returns>
        private List<Dictionary<string, string>> FieldParsingError(string errorMessage)
        {
            var error = new List<Dictionary<string, string>>();
            var importData = new Dictionary<string, string>();
            importData.Add("Error", errorMessage);
            error.Add(importData);
            return error;
        }

        private async Task<IEnumerable<SelectListItem>> GetProcessingLocationListAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

            var _lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementCommonLookUps);
            if (_lmLookups == null)
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.CommonLookUps();
                _lmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
                HttpContext.Session.Set(SessionKeys.LabelManagementCommonLookUps, _lmLookups);
            }
            return ((JArray)_lmLookups?["ProcessingLocations"])?.ToObject<List<DTO.ProcessingLocation>>().Where(a => a.Active)
                .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ProcessingLocationCode });
        }

        #endregion
    }
}
