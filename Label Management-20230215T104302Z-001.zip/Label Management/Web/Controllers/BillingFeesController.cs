using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.LM.Web.Integrations.Identity;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using PersonalSetting = VM.FleetServices.TnR.LM.Model.DTO.PersonalSetting;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [Authorize]
    public class BillingFeesController : BaseController
    {
        #region PrivateMembers

        private readonly IApiClientService _apiClientService;
        private readonly ILogger<BillingFeesController> _logger;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly IMemoryCache _cache;
        private readonly IAuthService _authService;

        #endregion

        #region Constructor
        public BillingFeesController(IApiClientService apiClientService, IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IMemoryCache cache,
             ILogger<BillingFeesController> logger, IAuthService authService) : base(apiSettings, pmApiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            _pmApiSettings = pmApiSettings.Value;
            _cache = cache;
            _authService = authService;
        }
        #endregion

        [VerifyClientLocationUserPreferencesActionFilter]
        [VerifyPersonalSettingsActionFilter]
        public IActionResult Index()
        {
            var profileSettings = GetUserProfileSettings();
            var model = new BillingFeeConfigurationViewModel()
            {
                Results = new List<BillingFeeViewModel>(),
                ClientCode = profileSettings.ClientCode,
                DmvStateCode = profileSettings.DmvStateCode,
                InventoryCode = profileSettings.InventoryCode,
                ProcessingLocationCode = profileSettings.ProcessingLocationCode,
                SelectedRowsPerPage = profileSettings.SelectedRowsPerPage,
                DefaultRowsPerPage = profileSettings.DefaultRowsPerPage,
                PageNumber = 1,
                IncludeDisabled = false
            };
            return View(model);
        }

        #region BillingFeeConfig

        /// <summary>
        /// Gets the billing fees
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<JsonResult> GetBillingFeesAsync([DataSourceRequest] DataSourceRequest request, bool newRequest, bool includeDisabled)
        {
            var result = new DataSourceResult();
            var baseRequest = GetDataRequest(request.Page, request.PageSize);
            var billingFeeConfigurations = HttpContext.Session.Get<BillingFeeConfigurationViewModel>(SessionKeys.BillingFeeTypeData);
            var billingFeeData = HttpContext.Session.Get<BillingFeeConfigurationViewModel>(SessionKeys.BillingFeeData);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            // when sort order changes
            if (request.Sorts != null
                              && request.Sorts.Any()
                              && newRequest
                              && billingFeeConfigurations != null
                              && billingFeeConfigurations.Results != null
                              && billingFeeConfigurations.PageNumber == baseRequest.PageNumber
                              && billingFeeConfigurations.SelectedRowsPerPage == baseRequest.SelectedRowsPerPage)

            {
                var propertyInfo = typeof(BillingFeeViewModel).GetProperty(request.Sorts[0].Member);
                result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ?
                              billingFeeConfigurations.Results.OrderBy(p => propertyInfo?.GetValue(p, null)) :
                              billingFeeConfigurations.Results.OrderByDescending(p => propertyInfo?.GetValue(p, null));

                result.Total = billingFeeConfigurations.TotalCount;
                return Json(result);
            }

            // Prevents calling the API a second time on grid refresh
            // On grid refresh, the newRequest flag is false, but billingFeeConfigurations collection is not null
            // After grid refresh, the billingFeeConfigurations collection is cleared out.
            if (billingFeeConfigurations != null
                && !newRequest
                && billingFeeConfigurations.ClientCode.Equals(baseRequest.ClientCode)
                && billingFeeConfigurations.ProcessingLocationCode.Equals(baseRequest.ProcessingLocationCode)
                && billingFeeConfigurations.PageNumber.Equals(baseRequest.PageNumber)
                && billingFeeConfigurations.SelectedRowsPerPage.Equals(baseRequest.DefaultRowsPerPage)
                && billingFeeConfigurations.IncludeDisabled.Equals(includeDisabled))
            {
                var refreshResult = new DataSourceResult();
                refreshResult.Data = billingFeeConfigurations.Results;
                refreshResult.Total = billingFeeConfigurations.TotalCount;
                HttpContext.Session.Remove(SessionKeys.BillingFeeTypeData);
                return Json(refreshResult);
            }

            try
            {
                var token = _authService.GetAccessToken();
                // when sort order changes
                if (request.Sorts != null
                                  && request.Sorts.Any()
                                  && !newRequest
                                  && billingFeeData != null
                                  && billingFeeData.Results != null
                                  && billingFeeData.PageNumber == baseRequest.PageNumber
                                  && billingFeeData.SelectedRowsPerPage == baseRequest.SelectedRowsPerPage)

                {
                    var propertyInfo = typeof(BillingFeeViewModel).GetProperty(request.Sorts[0].Member);
                    result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ?
                                  billingFeeData.Results.OrderBy(p => propertyInfo?.GetValue(p, null)) :
                                  billingFeeData.Results.OrderByDescending(p => propertyInfo?.GetValue(p, null));

                    result.Total = billingFeeData.TotalCount;
                }
                else
                {
                    // Adds the flag to get disabled configurations as well as active ones
                    if (includeDisabled)
                    {
                        baseRequest.IncludeDisabled = true;
                    }

                    if (request.Sorts != null)
                    {
                        request.Sorts.Clear();
                    }

                    _apiClientService.SetClientCode(baseRequest.ClientCode);
                    var uri = _pmApiSettings.Uri + ApiRouteConstants.GetBillingFeesAsync();

                    _logger.LogInformation($"POST method: {nameof(GetBillingFeesAsync)} - Calling {uri}");

                    var response = await _apiClientService.PostRequestAsync(uri, baseRequest, token.AccessToken);
                    if (!response.IsSuccessStatusCode)
                        throw new Exception("Http Response was not successful");

                    var stringResult = response.Content.ReadAsStringAsync().Result;
                    var billingFeeConfigResult = JsonConvert.DeserializeObject<BillingFeeConfigurationViewModel>(stringResult);

                    billingFeeConfigResult.ClientCode = baseRequest.ClientCode;
                    billingFeeConfigResult.DmvStateCode = baseRequest.DmvStateCode;
                    billingFeeConfigResult.ProcessingLocationCode = baseRequest.ProcessingLocationCode;
                    billingFeeConfigResult.InventoryCode = baseRequest.InventoryCode;
                    billingFeeConfigResult.IncludeDisabled = includeDisabled;
                    billingFeeConfigResult.SelectedRowsPerPage = baseRequest.SelectedRowsPerPage;
                    billingFeeConfigResult.PageNumber = baseRequest.PageNumber;


                    HttpContext.Session.Set(SessionKeys.BillingFeeTypeData, billingFeeConfigResult);
                    HttpContext.Session.Set(SessionKeys.BillingFeeData, billingFeeConfigResult);
                    result.Data = billingFeeConfigResult.Results;
                    result.Total = billingFeeConfigResult.TotalCount;
                    _logger.LogInformation($"POST method: {nameof(GetBillingFeesAsync)} - Returned from Web Api call successfully");
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetBillingFeesAsync)} - A critical error occurred getting type of Billing Fees.\r\n Message: {e.Message} ");
            }
            return Json(result);
        }

        /// <summary>
        /// Builds up the data for both the add and edit modals
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> AddEditBillingFees(BillingFeeViewModel model, string entity)
        {
            var profileSettings = GetUserProfileSettings();
            try
            {
                var billingLookups = await GetBillingLookUpsAsync();

                var plateConditionTypes = billingLookups != null ? ((JArray)billingLookups["plateConditionTypes"]).ToObject<List<Model.DTO.PlateConditionType>>().Where(a => a.Active == true).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.PlateConditionTypeId.ToString() }).ToList() : null;
                if (plateConditionTypes != null)
                {
                    model.PlateConditionTypes = plateConditionTypes;
                    model.PlateConditionType = plateConditionTypes.Where(x => x.Value == model.ConditionTypeId).Select(y => y.Text).FirstOrDefault();
                }

                if (model.BillingFeeId == 0)
                {
                    var data = HttpContext.Session.Get<BillingFeeConfigurationViewModel>(SessionKeys.BillingFeeData);
                    var billing = (billingLookups["billingFees"] == null) ? null : ((JArray)billingLookups["billingFees"]).ToObject<List<BillingFee>>();

                    if (data != null)
                    {
                        model.ClientCode = data.ClientCode;
                        model.ProcessingLocationCode = data.ProcessingLocationCode;

                        if (entity != null)
                        {
                            var billingEntity = Convert.ToInt32(entity);
                            // Bring back full list, but set the selected Billing Entity
                            model.BillingItemTypes = ((JArray)billingLookups["billingItemTypes"]).ToObject<List<BillingItemType>>().Where(a => a.Active == true).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.BillingItemTypeId.ToString(), Selected = a.BillingItemTypeId.Equals(billingEntity) }).ToList();
                            model.BillingTypes = ((JArray)billingLookups["billingTypes"]).ToObject<List<BillingType>>().Where(a => a.Active == true && a.BillingItemTypeId.Equals(billingEntity)).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.BillingTypeId.ToString() }).ToList();
                            model.BillingReasonTypes = ((JArray)billingLookups["billingReasonTypes"]).ToObject<List<BillingReasonType>>().Where(a => a.Active == true && a.BillingItemTypeId.Equals(billingEntity)).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.BillingReasonTypeId.ToString() }).ToList();
                        }
                        else
                        {
                            // On initial load, bring back full lists
                            model.BillingItemTypes = ((JArray)billingLookups["billingItemTypes"]).ToObject<List<BillingItemType>>().Where(a => a.Active == true).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.BillingItemTypeId.ToString() }).ToList();
                            model.BillingTypes = ((JArray)billingLookups["billingTypes"]).ToObject<List<BillingType>>().Where(a => a.Active == true).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.BillingTypeId.ToString() }).ToList();
                            model.BillingReasonTypes = ((JArray)billingLookups["billingReasonTypes"]).ToObject<List<BillingReasonType>>().Where(a => a.Active == true).Select(a => new SelectListItem { Text = a.DisplayName, Value = a.BillingReasonTypeId.ToString() }).ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Populating Add Billing Fees Modal failed: {nameof(AddEditBillingFees)}");
                throw ex.InnerException;
            }
            return PartialView(model);
        }

        /// <summary>
        /// This method will make the billing fee active or inactive based on toggle in grid
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task UpdateBillingFeeStatusAsync(int billingFeeId, bool feeActive)
        {
            var baseRequest = GetDataRequest();
            var request = new BillingFeeStatusUpdateViewModel()
            {
                BillingFeeId = billingFeeId,
                Active = feeActive
            };

            var result = new DataSourceResult();

            try
            {
                _apiClientService.SetClientCode(baseRequest.ClientCode);
                var token = _authService.GetAccessToken();
                var uri = _pmApiSettings.Uri + ApiRouteConstants.UpdateBillingFeeActiveStatusAsync();

                _logger.LogInformation($"POST method: {nameof(UpdateBillingFeeStatusAsync)} - Calling {uri}");

                var response = await _apiClientService.PostRequestAsync(uri, request, token.AccessToken);
                if (!response.IsSuccessStatusCode)
                    throw new Exception("Http Response was not successful");

                _logger.LogInformation($"POST method: {nameof(UpdateBillingFeeStatusAsync)} - Returned from Web Api call successfully");
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(UpdateBillingFeeStatusAsync)} - A critical error occurred updating the Billing Fee Active Status.\r\n Message: {e.Message} ");
            }
        }

        /// <summary>
        /// This method adds a new billing record, or updates an existing record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task AddUpdateBillingFeeAsync(AddUpdateBillingFeeViewModel model)
        {
            var baseRequest = GetDataRequest();
            var result = new DataSourceResult();

            var request = new AddUpdateBillingFeeViewModel();
            request.BillingItemTypeId = model.BillingItemTypeId;
            request.BillingReasonTypeId = model.BillingReasonTypeId;
            request.ConditionTypeId = model.ConditionTypeId;
            request.BillingTypeId = model.BillingTypeId;
            request.DisplayName = model.DisplayName;
            request.DefaultAmount = model.DefaultAmount;
            request.ClientCode = model.ClientCode;
            request.ProcessingLocationCode = model.ProcessingLocationCode;
            request.BillingFeeId = model.BillingFeeId;

            // New billing fee
            if (model.BillingFeeId == 0)
            {
                request.CreatedUser = User.GetUserId();
                request.CreatedDate = DateTime.Now;
            }
            else // Update existing billing fee
            {
                request.CreatedUser = model.CreatedUser;
                request.CreatedDate = model.CreatedDate;
            }

            try
            {
                _apiClientService.SetClientCode(baseRequest.ClientCode);
                var token = _authService.GetAccessToken();
                var uri = _pmApiSettings.Uri + ApiRouteConstants.AddUpdateBillingFeeAsync();

                _logger.LogInformation($"POST method: {nameof(AddUpdateBillingFeeAsync)} - Calling {uri}");

                var response = await _apiClientService.PostRequestAsync(uri, request, token.AccessToken);
                if (!response.IsSuccessStatusCode)
                    throw new Exception();

                _logger.LogInformation($"POST method: {nameof(AddUpdateBillingFeeAsync)} - Returned from Web Api call successfully");
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(AddUpdateBillingFeeAsync)} - A critical error occurred updating the Billing Fee Active Status.\r\n Message: {e.Message} ");
                throw e;
            }
        }

        /// <summary>
        /// Gets the billing lookups
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<Dictionary<string, object>> GetBillingLookUpsAsync()
        {
            if (!_cache.TryGetValue("BillingLookUps", out Dictionary<string, object> billingLookUps))
            {
                _logger.LogInformation("Getting Billing Lookups");
                var userProfile = GetUserProfileSettings();
                try
                {
                    _apiClientService.SetClientCode(userProfile.ClientCode);
                    var uri = _apiSettings.Uri + ApiRouteConstants.GetBillingLookUps();
                    var response = await _apiClientService.GetResponseAsync<ServiceResponse<Dictionary<string, object>>>(uri);

                    if (response.ResponseCode == HttpStatusCode.Accepted)
                    {
                        billingLookUps = response.Data;
                    }
                    else
                    {
                        _logger.LogError($"GET method: {nameof(GetBillingLookUpsAsync)} - Unable to process. Message: {response.ErrorMessage}");
                    }
                }
                catch (Exception e)
                {
                    _logger.LogError($"Method: {nameof(GetBillingLookUpsAsync)} - Error getting data from Web API", e.Message);
                }
                _logger.LogInformation("Adding Billing Lookups to cache");
                var options = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15), //cache will expire in 15 mins
                    SlidingExpiration = TimeSpan.FromMinutes(5) // cache will expire if inactive for 5 mins
                };

                if (billingLookUps != null)
                {
                    _cache.Set("BillingLookUps", billingLookUps, options);
                }
            }
            return billingLookUps;
        }

        /// <summary>
        /// Verifying the billing reason type
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> GetBillingReasonTypeAsync(LabelViewModel model)
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            model.ClientCode = clientLocationPreference?.ClientCode;
            model.ProcessingLocationCode = clientLocationPreference?.ProcessingLocationCode;
            var baseRequest = GetDataRequest();
            try
            {
                _apiClientService.SetClientCode(baseRequest.ClientCode);

                var uri = _apiSettings.Uri + ApiRouteConstants.GetBillingReasonTypeAsync();

                _logger.LogInformation($"POST method: {nameof(GetBillingReasonTypeAsync)} - Calling {uri}");
                var response = await _apiClientService.PostRequestAsync(uri, model);
                _logger.LogInformation($"POST method: {nameof(GetBillingReasonTypeAsync)} - Returned from Web Api call successfully");

                if (!response.IsSuccessStatusCode)
                    return Json(new { Status = false, ResponseText = "HttpError" });

                var responseResult = response.Content.ReadAsStringAsync().Result;
                var result = JsonConvert.DeserializeObject<bool>(responseResult);
                return Json(new { Status = result });
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetBillingReasonTypeAsync)} - A critical error occurred getting reason type of Billing Fees.\r\n Message: {e.Message} ");
                throw e;
            }

        }

        #endregion


        #region Private Methods

        /// <summary>
        /// Gets the user profile settings
        /// </summary>
        /// <returns></returns>
        private UserProfileSettingsViewModel GetUserProfileSettings()
        {
            var userPreferences = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();
            return new UserProfileSettingsViewModel()
            {
                ClientCode = userPreferences?.ClientCode,
                ProcessingLocationCode = userPreferences?.ProcessingLocationCode,
                DefaultRowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage
        };
        }

        /// <summary>
        /// Gets the label management lookups from the database by making an api call 
        /// </summary>
        /// <returns>Dictionary</returns>
        private async Task<Dictionary<string, object>> GetLookupsAsync()
        {
            Dictionary<string, object> lmLookups = null;
            try
            {
                // Label management lookups to render the filters namely label status types
                lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementLookUps);
                if (lmLookups == null)
                {
                    var uri = _apiSettings.Uri + ApiRouteConstants.LabelManagementLookUps();
                    lmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
                    HttpContext.Session.Set(SessionKeys.LabelManagementLookUps, lmLookups);
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetLookupsAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetLookupsAsync)}: Error occurred : Error message: {e.Message}");
            }

            return lmLookups;
        }

        /// <summary>
        /// Base Request data
        /// </summary>
        /// <param name="selectedPageNumber"></param>
        /// <param name="selectedRowsPerPage"></param>
        /// <returns></returns>
        private UserProfileSettingsViewModel GetDataRequest(int selectedPageNumber = 1, int? selectedRowsPerPage = null, bool includeDisabled = false)
        {
            var userPreferences = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var request = new UserProfileSettingsViewModel()
            {
                ClientCode = userPreferences.ClientCode,
                ProcessingLocationCode = userPreferences.ProcessingLocationCode,
                DefaultRowsPerPage = 25,
                SelectedRowsPerPage = 25,
                PageNumber = selectedPageNumber,
                IncludeDisabled = includeDisabled
            };

            return request;
        }

        /// <summary>
        /// private method to get personal settings data 
        /// </summary>
        /// <returns>returns data</returns>
        private async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync()
        {
            var user = User.GetUserId();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
            var response = await _apiClientService.GetResponseAsync(uri);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(responseResult);
            return result;
        }

        #endregion
    }
}
