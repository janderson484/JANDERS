using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.LM.Web.Models;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [ValidateSessionActionFilter]
    public class ReportsController : Controller
    {
        [VerifyClientLocationUserPreferencesActionFilter]
        [VerifyPersonalSettingsActionFilter]
        public IActionResult Reports()
        {
            return View();
        }

        public IActionResult ValidUserToDownload(string userName, string processType)
        {
            var displayForOtherUsers = false;
            var user = User.GetUserId();

            if (processType.Equals(ProcessTypes.Import))
            {
                if (User.IsTnrAdminUser() || User.IsLMInternalUser())
                {
                    displayForOtherUsers = true;
                }

            }


            if (user.Equals(userName) || displayForOtherUsers)
            {
                return Json(new { isValid = true });
            }
            else
            {
                return Json(new { isValid = false });
            }
        }
    }
}
