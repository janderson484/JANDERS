using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.LM.Web.Integrations.Identity;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using System.Reflection;
using Aspose.Pdf;
using Aspose.Pdf.Forms;
using Aspose.Pdf.Text;
using Aspose.Pdf.Drawing;
using System.IO;
using VM.FleetServices.TnR.Core.Common.Identity;
using Microsoft.AspNetCore.Authorization;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [Authorize]
    public class InvoiceController : BaseController
    {
        private readonly IApiClientService _apiClientService;
        private readonly ILogger<LabelController> _logger;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly IMemoryCache _cache;
        private readonly IAuthService _authService;


        public InvoiceController(IApiClientService apiClientService, IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IMemoryCache cache,
             ILogger<LabelController> logger, IAuthService authService) : base(apiSettings, pmApiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            _pmApiSettings = pmApiSettings.Value;
            _cache = cache;
            _authService = authService;
        }

        [VerifyClientLocationUserPreferencesActionFilter]
        [VerifyPersonalSettingsActionFilter]
        public async Task<IActionResult> Index()
        {
            ClearInvoiceSearch();
            await GetBillingLookUpsAsync();

            ViewBag.PageSize = GetUserProfileSettings().DefaultRowsPerPage;
            return View(await GetInvoiceLookUpsAsync());
        }

        #region Invoice

        /// <summary>
        /// Gets the invoices for invoice drop down
        /// </summary>
        /// <param name="invoiceStatusTypes"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<JsonResult> GetInvoicesAsync(string invoiceStatusTypes)
        {
            var invoices = new List<SelectInvoiceViewModel>();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            try
            {
                var invoiceUserPreferences = await UpdateInvoiceUserPreferencesToSessionAsync(invoiceStatusTypes);
                var token = _authService.GetAccessToken();
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);
                var uri = _pmApiSettings.Uri + ApiRouteConstants.GetInvoices() + $"/{invoiceStatusTypes}/{clientLocationPreference.ClientCode}";
                var response = await _apiClientService.GetResponseAsync<ServiceResponse<List<SelectInvoiceViewModel>>>(uri, token.AccessToken);

                if (response != null && response.ResponseCode == HttpStatusCode.Accepted)
                {
                    invoices = response.Data.OrderByDescending(i => i.InvoiceId).ToList();
                }
                else
                {
                    _logger.LogError($"GET method: {nameof(GetInvoicesAsync)} - Unable to process. Message: {response.ErrorMessage}");
                }
                await SaveUserPreferenceAsync(new UserPreferenceViewModel() { ActionCode = VM.FleetServices.TnR.LM.Model.Enums.UserActions.Invoice.GetDescription(), ClientCode = clientLocationPreference.ClientCode, UserPreference = JsonConvert.SerializeObject(invoiceUserPreferences), UserName = User.GetUserId() });
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetInvoicesAsync)} - Error getting data from Web API", e.Message);
            }
            return Json(invoices);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<List<InvoiceStatusTypesViewModel>> GetInvoiceLookUpsAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var invoiceUserPreferences = await GetUserPreferencesByKey<InvoiceUserPreferencesViewModel>(SessionKeys.InvoiceUserPreferences);

            try
            {
                var token = _authService.GetAccessToken();
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);
                var uri = _pmApiSettings.Uri + ApiRouteConstants.GetInvoiceLookUps() + $"/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
                var response = await _apiClientService.GetResponseAsync<ServiceResponse<Dictionary<string, object>>>(uri, token.AccessToken);

                if (response.ResponseCode == HttpStatusCode.Accepted)
                {
                    var invoiceLookUps = response.Data;
                    var statusTypes = ((JArray)invoiceLookUps["invoiceStatusTypes"]).ToObject<List<InvoiceStatusTypesViewModel>>();
                    statusTypes?.ForEach(x => x.Selected = false);
                    invoiceLookUps["invoiceStatusTypes"] = statusTypes;
                    return UpdateLookupsWithUserPreferences(invoiceLookUps, invoiceUserPreferences);
                }

                _logger.LogError($"GET method: {nameof(GetInvoiceLookUpsAsync)} - Unable to process. Message: {response.ErrorMessage}");
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetInvoiceLookUpsAsync)} - Error getting data from Web API", e.Message);
            }
            return new List<InvoiceStatusTypesViewModel>();
        }


        /// <summary>
        /// Get the invoice details
        /// </summary>
        /// <param name="request"></param>
        /// <param name="refreshGrid"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<JsonResult> GetInvoiceDetailsAsync([DataSourceRequest] DataSourceRequest request, bool refreshGrid = false)
        {
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var invoiceDetails = new InvoiceViewModel()
            {
                Results = new List<InvoiceDetailsViewModel>(),
                SearchCriteria = new SearchInvoiceViewModel() { PageNumber = request.Page, UserProfileSettings = GetUserProfileSettings() }
            };
            invoiceDetails.SearchCriteria.UserProfileSettings.SelectedRowsPerPage = request.PageSize;
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            var searchCriteriaFromCache = GetSearchCriteriaFromSession(invoiceDetails.SearchCriteria);
            try
            {
                if (searchCriteriaFromCache.Search || invoiceDetails.SearchCriteria.PageNumber != searchCriteriaFromCache.PageNumber
                    || invoiceDetails.SearchCriteria.UserProfileSettings.SelectedRowsPerPage != searchCriteriaFromCache.UserProfileSettings.SelectedRowsPerPage || refreshGrid)
                {
                    var token = _authService.GetAccessToken();
                    invoiceDetails.SearchCriteria.Search = false;
                    invoiceDetails.SearchCriteria.InvoiceId = searchCriteriaFromCache.InvoiceId;
                    SetSearchCriteriaToSession(invoiceDetails.SearchCriteria);

                    var clientCode = User.GetSelectedClient(HttpContext.Session.Get<string>(SessionKeys.SelectedClientCode));
                    var uri = $"{_pmApiSettings.Uri}{ApiRouteConstants.GetInvoiceDetails()}";
                    _apiClientService.SetClientCode(clientCode);

                    var response = await _apiClientService.PostRequestAsync(uri, invoiceDetails, token.AccessToken);
                    //Checking the response is successful or not which is sent using HttpClient  
                    if (response.IsSuccessStatusCode)
                    {
                        var result = response.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the invoice list  
                        invoiceDetails = JsonConvert.DeserializeObject<InvoiceViewModel>(result);
                        //Map the billing data from billing lookups
                        await MapBillingDetailsAsync(invoiceDetails.Results.ToList());
                        _cache.Set("InvoiceDetailsResponse", invoiceDetails.Results);
                    }
                }

                _cache.TryGetValue("InvoiceDetailsResponse", out List<InvoiceDetailsViewModel> resultFromCache);
                invoiceDetails.Results = resultFromCache;

                //To sort the data based on the order
                if (request.Sorts.Any() && resultFromCache != null)
                {
                    if (request.Sorts[0].SortDirection == ListSortDirection.Ascending)
                    {
                        var orderByExpression = GetOrderByExpression<InvoiceDetailsViewModel>(request.Sorts[0].Member);
                        invoiceDetails.Results = OrderByDirection(resultFromCache, "ASC", orderByExpression);
                    }
                    else
                    {
                        var orderByExpression = GetOrderByExpression<InvoiceDetailsViewModel>(request.Sorts[0].Member);
                        invoiceDetails.Results = OrderByDirection(resultFromCache, "DESC", orderByExpression);
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetInvoiceDetailsAsync)} - Error getting data from Web API", e.Message);
            }

            return Json(new DataSourceResult()
            {
                Data = invoiceDetails.Results,
                Total = invoiceDetails.Results.Count > 0 ? invoiceDetails.Results.First().TotalRowCount : 0
            });
        }

        /// <summary>
        /// Method that updates the Invoice Name and or Note
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Message</returns>
        [HttpPost]
        public async Task<IActionResult> UpdateInvoiceNameNoteAsync(UpdateInvoiceViewModel model)
        {
            var userProfile = GetUserProfileSettings();
            model.UpdateUser = User.GetUserId();
            model.UpdateDate = DateTime.Now;
            model.InvoiceId = Convert.ToInt32(model.InvoiceId);
            model.InvoiceStatusTypeId = (int)VM.FleetServices.TnR.LM.Model.Enums.InvoiceStatusTypes.Open;

            try
            {
                _apiClientService.SetClientCode(userProfile.ClientCode);
                var token = _authService.GetAccessToken();
                var uri = _pmApiSettings.Uri + ApiRouteConstants.UpdateInvoiceAsync() + $"/{userProfile.ClientCode}";
                var res = await _apiClientService.PostRequestAsync(uri, model, token.AccessToken);

                if (!res.IsSuccessStatusCode)
                {
                    throw new Exception("Http Response was not successful");
                }

                var result = res.Content.ReadAsStringAsync().Result;
                var response = JsonConvert.DeserializeObject<ServiceResponse<UpdateInvoiceViewModel>>(result);

                return Json(response.Data.UpdateResultMessage != null ?
                    new { isSuccess = false, Message = response.Data.UpdateResultMessage } :
                    new { isSuccess = true, Message = "Successfully Updated Invoice" });
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(UpdateInvoiceNameNoteAsync)} - Error updating the invoice", e.Message);
                return Json(new { isSuccess = false, Message = "Updating Invoice Failed!" });
            }
        }

        /// <summary>
        /// Close and Open Invoice
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> CloseOpenInvoiceAsync(UpdateInvoiceViewModel model)
        {
            var userProfile = GetUserProfileSettings();
            model.InvoiceId = Convert.ToInt32(model.InvoiceId);
            model.InvoiceStatusTypeId = (int)VM.FleetServices.TnR.LM.Model.Enums.InvoiceStatusTypes.Closed;
            model.UpdateUser = User.GetUserId();
            model.UpdateDate = DateTime.Now;

            try
            {
                _apiClientService.SetClientCode(userProfile.ClientCode);
                var token = _authService.GetAccessToken();
                var uri = _pmApiSettings.Uri + ApiRouteConstants.UpdateInvoiceAsync() + $"/{userProfile.ClientCode}";
                var res = await _apiClientService.PostRequestAsync(uri, model, token.AccessToken);

                if (!res.IsSuccessStatusCode)
                {
                    throw new Exception("Http Response was not successful");
                }

                var result = res.Content.ReadAsStringAsync().Result;
                var response = JsonConvert.DeserializeObject<ServiceResponse<UpdateInvoiceViewModel>>(result);

                return Json(response.Data.UpdateResultMessage != null ?
                    new { isSuccess = false, Message = response.Data.UpdateResultMessage } :
                    new { isSuccess = true, Message = "Successfully Closed Invoice" });
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(CloseOpenInvoiceAsync)} - Error closing the invoice", e.Message);
                return Json(new { isSuccess = false, Message = "Closing Invoice Failed!" });
            }
        }

        /// <summary>
        /// Sets the Invoice search criteria to cache
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SearchInvoiceDetails(SearchInvoiceViewModel model)
        {
            return Json(SetSearchCriteriaToSession(model));
        }

        /// <summary>
        /// Gets the Invoice, Address, and Invoice Details data to Print Invoice PDF
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<SearchInvoiceDataToPrintViewModel> GetInvoiceDataToPrintAsync(SearchInvoiceDataToPrintViewModel model)
        {
            var lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementLookUps);
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

            var clientCode = clientLocationPreference.ClientCode;
            _apiClientService.SetClientCode(clientCode);

            var selectedClientCode = clientCode;
            var selectedProcessingLocationCode = clientLocationPreference.ProcessingLocationCode;

            // model.ClientId = (lmLookups != null && !string.IsNullOrEmpty(selectedClientCode)) ? ((JArray)lmLookups["Clients"]).ToObject<List<VM.FleetServices.TnR.Data.TnrModel.Entities.Client>>().First(a => a.ClientCode == selectedClientCode).ClientId : 0;
            model.ClientId = 1;
            model.ProcessingLocationId = lmLookups != null ? ((JArray)lmLookups["ProcessingLocations"]).ToObject<List<ProcessingLocation>>().First(a => a.ProcessingLocationCode == selectedProcessingLocationCode).ProcessingLocationId : 1;
            model.ClientCode = clientCode;

            var uri = _pmApiSettings.Uri + ApiRouteConstants.GetInvoiceDataToPrint();
            var token = _authService.GetAccessToken();
            var response = await _apiClientService.PostRequestAsync(uri, model, token.AccessToken);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Http Response was not successful");
            }

            var result = response.Content.ReadAsStringAsync().Result;
            var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<SearchInvoiceDataToPrintViewModel>>(result);

            serviceResponse.Data.InvoiceDetails = await MapBillingDetailsAsync(serviceResponse.Data.InvoiceDetails);

            return serviceResponse.Data;
        }


        /// <summary>
        /// Submits service bus request for Prints invoice 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<JsonResult> PrintInvoiceAsync(SearchInvoiceDataToPrintViewModel model)
        {
            var jsonObject = new JObject();
            try
            {
                if (model == null || model.InvoiceId < 0)
                {
                    throw new Exception("Invoice id not found");
                }
                var lmLookups = await GetLookupsAsync();
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

                var clientCode = clientLocationPreference.ClientCode;
                _apiClientService.SetClientCode(clientCode);

                var selectedClientCode = clientCode;
                var selectedProcessingLocationCode = clientLocationPreference.ProcessingLocationCode;

                model.ClientId = (lmLookups != null && !string.IsNullOrEmpty(selectedClientCode) && lmLookups.ContainsKey("Clients")) ? ((JArray)lmLookups["Clients"]).ToObject<List<Model.DTO.Client>>().First(a => a.ClientCode == selectedClientCode).ClientId : 1;
                model.ProcessingLocationId = lmLookups != null && lmLookups.ContainsKey("ProcessingLocations") ? ((JArray)lmLookups["ProcessingLocations"]).ToObject<List<ProcessingLocation>>().First(a => a.ProcessingLocationCode == selectedProcessingLocationCode).ProcessingLocationId : 1;
                model.UserId = User.GetUserId();
                model.ClientCode = GetUserProfileSettings().ClientCode;
                model.ProcessingLocationCode = GetUserProfileSettings().ProcessingLocationCode;

                var uri = _apiSettings.Uri + ApiRouteConstants.PrintInvoice();
                var response = await _apiClientService.PostRequestAsync(uri, model);
                if (response.IsSuccessStatusCode)
                {
                    jsonObject.Add("Message", "Request to print invoice created successfully!");
                    jsonObject.Add("ExportStatus", true);
                }
                else
                {
                    jsonObject.Add("Message", "Print invoice request failed.");
                    jsonObject.Add("ExportStatus", false);
                }
            }
            catch (Exception ex)
            {
                jsonObject.Add("Message", "Print invoice request failed. " + ex.Message);
                jsonObject.Add("ExportStatus", false);
            }

            return Json(jsonObject);
        }

        #endregion

        #region Billing

        /// <summary>
        /// Gets the billing lookups
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<Dictionary<string, object>> GetBillingLookUpsAsync()
        {
            if (!_cache.TryGetValue("BillingLookUps", out Dictionary<string, object> billingLookUps))
            {
                _logger.LogInformation("Getting Billing Lookups");

                try
                {
                    _apiClientService.SetClientCode(User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
                    var uri = _apiSettings.Uri + ApiRouteConstants.GetBillingLookUps();
                    var response = await _apiClientService.GetResponseAsync<ServiceResponse<Dictionary<string, object>>>(uri);

                    if (response.ResponseCode == HttpStatusCode.Accepted)
                    {
                        billingLookUps = response.Data;
                    }
                    else
                    {
                        _logger.LogError($"GET method: {nameof(GetBillingLookUpsAsync)} - Unable to process. Message: {response.ErrorMessage}");
                    }
                }
                catch (Exception e)
                {
                    _logger.LogError($"Method: {nameof(GetBillingLookUpsAsync)} - Error getting data from Web API", e.Message);
                }
                _logger.LogInformation("Adding Billing Lookups to cache");
                var options = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15), //cache will expire in 15 mins
                    SlidingExpiration = TimeSpan.FromMinutes(5) // cache will expire if inactive for 5 mins
                };

                if (billingLookUps != null)
                {
                    _cache.Set("BillingLookUps", billingLookUps, options);
                }
            }
            return billingLookUps;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Gets the user profile settings
        /// </summary>
        /// <returns></returns>
        private UserProfileSettingsViewModel GetUserProfileSettings()
        { 
            var userPreferences = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            return new UserProfileSettingsViewModel()
            {
                ClientCode = userPreferences?.ClientCode,
                ProcessingLocationCode = userPreferences?.ProcessingLocationCode,
                DefaultRowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage
            };
        }

        /// <summary>
        /// Gets the label management lookups from the database by making an api call 
        /// </summary>
        /// <returns>Dictionary</returns>
        private async Task<Dictionary<string, object>> GetLookupsAsync()
        {
            Dictionary<string, object> lmLookups = null;
            try
            {
                // Label management lookups to render the filters namely label status types
                lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementLookUps);
                if (lmLookups == null)
                {
                    var uri = _apiSettings.Uri + ApiRouteConstants.LabelManagementLookUps();
                    lmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
                    HttpContext.Session.Set(SessionKeys.LabelManagementLookUps, lmLookups);
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetLookupsAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetLookupsAsync)}: Error occurred : Error message: {e.Message}");
            }

            return lmLookups;
        }


        /// <summary>
        /// Maps the billing data with the billing lookups
        /// </summary>
        /// <param name="invoiceDetails"></param>
        /// <returns></returns>
        private async Task<List<InvoiceDetailsViewModel>> MapBillingDetailsAsync(List<InvoiceDetailsViewModel> invoiceDetails)
        {
            var billingLookups = await GetBillingLookUpsAsync();
            invoiceDetails.ForEach(i =>
            {
                var billing = (billingLookups["billingFees"] == null) ? null : ((JArray)billingLookups["billingFees"]).ToObject<List<VM.FleetServices.TnR.LM.Model.DTO.BillingFee>>().Where(x => x.BillingFeeId == i.BillingFeeId).FirstOrDefault();
                //var billing = (billingLookups["billingFees"] == null) ? null : ((JArray)billingLookups["billingFees"]).ToObject<List<BillingFee>>().Where(x => x.BillingFeeId == i.BillingFeeId).FirstOrDefault();
                if (billing != null)
                {
                    i.BillingFee = billing.DisplayName;
                    i.BillingReason = (billingLookups["billingReasonTypes"] == null) ? string.Empty : ((JArray)billingLookups["billingReasonTypes"]).ToObject<List<BillingReasonType>>().Where(x => x.BillingReasonTypeId == billing.BillingReasonTypeId).Select(x => x.DisplayName).FirstOrDefault();
                    i.BillingItemType = (billingLookups["billingItemTypes"] == null) ? string.Empty : ((JArray)billingLookups["billingItemTypes"]).ToObject<List<BillingItemType>>().Where(x => x.BillingItemTypeId == billing.BillingItemTypeId).Select(x => x.DisplayName).FirstOrDefault();
                }
            });
            return invoiceDetails;
        }

        /// <summary>
        /// Updates the invoice user preferences to session.
        /// </summary>
        /// <param name="invoiceStatusTypes">Selected invoice status types.</param>
        /// <returns>InvoiceUserPreferencesViewModel</returns>
        private async Task<InvoiceUserPreferencesViewModel> UpdateInvoiceUserPreferencesToSessionAsync(string invoiceStatusTypes)
        {
            var selectedStatusTypes = new List<int>();
            if (invoiceStatusTypes.Length > 0)
            {
                selectedStatusTypes = invoiceStatusTypes.Split(',')?.Select(int.Parse).ToList();
            }

            var invoicePreferences = new InvoiceUserPreferencesViewModel() { SelectedInvoiceStatuses = selectedStatusTypes };
            await UpdateUserPreferencesToSession(SessionKeys.InvoiceUserPreferences, invoicePreferences);
            return invoicePreferences;
        }

        /// <summary>
        /// Sets the Invoice search criteria into cache
        /// </summary>
        /// <param name="searchCriteria"></param>
        private bool SetSearchCriteriaToSession(SearchInvoiceViewModel searchCriteria)
        {
            var options = new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15), //cache will expire in 15 mins
                SlidingExpiration = TimeSpan.FromMinutes(5) // cache will expire if inactive for 5 mins
            };

            _cache.Set("InvoiceSearchCriteria", searchCriteria);
            return true;
        }

        /// <summary>
        /// Gets the Invoice search criteria from cache
        /// </summary>
        /// <returns></returns>
        private SearchInvoiceViewModel GetSearchCriteriaFromSession(SearchInvoiceViewModel searchCriteria = null)
        {
            if (searchCriteria != null)
            {
                if (!_cache.TryGetValue("InvoiceSearchCriteria", out SearchInvoiceViewModel searchCriteriaFromCache))
                {

                    _logger.LogInformation("Adding SearchCriteria to cache");
                    var options = new MemoryCacheEntryOptions
                    {
                        AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15), //cache will expire in 15 mins
                        SlidingExpiration = TimeSpan.FromMinutes(5) // cache will expire if inactive for 5 mins
                    };

                    if (searchCriteria != null)
                    {
                        _cache.Set("InvoiceSearchCriteria", searchCriteria, options);
                    }

                    searchCriteriaFromCache = searchCriteria;
                    searchCriteriaFromCache.Search = true;
                }
                return searchCriteriaFromCache;
            }
            else
            {
                SearchInvoiceViewModel searchCriteriafromCache;
                _cache.TryGetValue("InvoiceSearchCriteria", out searchCriteriafromCache);
                return searchCriteriafromCache;
            }
        }

        /// <summary>
        /// To clear the search criteria from memroy cache on page init.
        /// </summary>
        private void ClearInvoiceSearch()
        {
            var searchCriteria = GetSearchCriteriaFromSession();
            if (searchCriteria != null)
            {
                SetSearchCriteriaToSession(null);
            }
        }

        /// <summary>
        /// Order by expression for sorting the data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sortColumn"></param>
        /// <returns></returns>
        private Func<T, object> GetOrderByExpression<T>(string sortColumn)
        {
            Func<T, object> orderByExpr = null;
            if (!string.IsNullOrEmpty(sortColumn))
            {
                var sponsorResultType = typeof(T);

                if (sponsorResultType.GetProperties().Any(prop => prop.Name == sortColumn))
                {
                    var propertyInfo = sponsorResultType.GetProperty(sortColumn);
                    orderByExpr = (data => propertyInfo.GetValue(data, null));
                }
            }

            return orderByExpr;
        }

        /// <summary>
        /// Order by direction for sorting the data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="direction"></param>
        /// <param name="OrderByColumn"></param>
        /// <returns></returns>
        private List<T> OrderByDirection<T>(IEnumerable<T> source, string direction, Func<T, object> OrderByColumn)
        {
            return direction.ToUpper() == "ASC" ? source.OrderBy(OrderByColumn).ToList() : source.OrderByDescending(OrderByColumn).ToList();
        }

        /// <summary>
        /// Updates the InvoiceStatusTypes lookups with user preferences.
        /// </summary>
        /// <param name="lookups">The lookups.</param>
        /// <param name="userPreferences">The user preferences.</param>
        /// <returns>List of InvoiceStatusTypesViewModel</returns>
        private List<InvoiceStatusTypesViewModel> UpdateLookupsWithUserPreferences(Dictionary<string, object> lookups, InvoiceUserPreferencesViewModel userPreferences)
        {
            var invoiceStatusTypes = (List<InvoiceStatusTypesViewModel>)lookups["invoiceStatusTypes"];

            var selectedInvoiceStatusTypes = userPreferences.SelectedInvoiceStatuses != null ? invoiceStatusTypes.Where(i => userPreferences.SelectedInvoiceStatuses.Contains(i.InvoiceStatusTypeId)).ToList() : new List<InvoiceStatusTypesViewModel>();
            foreach (var item in selectedInvoiceStatusTypes)
            {
                item.Selected = true;
            }

            return invoiceStatusTypes;
        }

        /// <summary>
        /// private method to get personal settings data 
        /// </summary>
        /// <returns>returns data</returns>
        private async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync()
        {
            var user = User.GetUserId();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
            var response = await _apiClientService.GetResponseAsync(uri);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(responseResult);
            return result;
        }

        #endregion
    }
}
