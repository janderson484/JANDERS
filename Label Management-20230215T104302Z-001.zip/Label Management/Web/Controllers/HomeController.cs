using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Models;
using VM.FleetServices.TnR.LM.Model.DTO;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using System;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.Core.Common.Identity;
using System.Threading.Tasks;
using VM.FleetServices.TnR.Model.ViewModel;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using System.Linq;
using VM.FleetServices.TnR.LM.Web.Integrations.Identity;
using System.Net.Http;
using VM.FleetServices.TnR.Core.Common.SignalR;
using Microsoft.AspNetCore.SignalR;
using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Web.Helpers;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [ValidateSessionActionFilter]
    [ViewBagInitializerActionFilter]
    public class HomeController : Controller
    {
        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly ILogger _logger;
        private readonly PMApiSettings _pmApiSettings;
        private readonly IHttpContextAccessor _httpContext;
        private readonly IAuthService _authenticationService;
        private readonly IHubContext<NotificationHub> _hubContext;


        public HomeController(IApiClientService apiClientService, IOptions<ApiSettings> apiSettings,
            ILogger<HomeController> logger, IOptions<PMApiSettings> pmApiSettings, IHttpContextAccessor httpContext,
            IAuthService authenticationService, IHubContext<NotificationHub> hubContext)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            _pmApiSettings = pmApiSettings.Value;
            _httpContext = httpContext;
            _authenticationService = authenticationService;
            _hubContext = hubContext;
        }

        [HttpGet]
        [SkipViewBagInitializerActionFilterAttribute]
        public async Task<IActionResult> Index()
        {
            try
            {
                ViewBag.UserPreferenceExists = true;

                var userPreferencesResult = await GetUserPreferencesAsync();
                if (userPreferencesResult == false)
                {
                    // Would return index view and display the customer list popup
                    ViewBag.UserPreferenceExists = false;
                    return View();
                }

                var personalSettingsResult = await GetPersonalSettingsAsync();
                if (personalSettingsResult == false)
                {
                    // Would redirect to the personal setting page if user hasn't established selected personal settings yet 
                    return RedirectToAction("PersonalSettings", "Configuration");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(Index)} - {ex.Message}");
                //TODO Ensure user is informed of an issue here and return correct response
            }

            return View();

        }

        private async Task<bool> GetUserPreferencesAsync()
        {
            try
            {
               var userPreferences = HttpContext.Session.Get<UserPreferenceViewModel>(SessionKeys.UserPreferences);

                if (userPreferences == null)
                {
                    _logger.LogInformation($"Method: {nameof(Index)} - Before processing Get userPreference");

                    ViewBag.UserPreferenceExists = false;
                    var uri = _pmApiSettings.Uri + ApiRouteConstants.GetUserPreference() + $"/{User.GetUserId()}/{UserPreferenceActionCodes.HeaderSelection.GetDescription()}";
                    var token = _authenticationService.GetAccessToken();

                    using (var httpClient = new HttpClient())
                    {
                        _logger.LogInformation($"Service: - Method: {nameof(Index)} - Before invoking PM web API");
                        httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");

                        // Try get the user preferences by calling the shared plate management api
                        var response = await httpClient.GetAsync(uri);
                        _logger.LogInformation($"Method: {nameof(Index)} - After processing Get userPreference");

                        if (!response.IsSuccessStatusCode)
                            throw new Exception($"Method: {nameof(Index)} - No valid response from API");

                        var result = response.Content.ReadAsStringAsync().Result;
                        var userPreference = JsonConvert.DeserializeObject<ServiceResponse<UserPreference>>(result);
                        if (userPreference != null && userPreference.Data.ActionPreference != null)
                        {
                            // We have user preferences so store them in session
                            ViewBag.UserPreferenceExists = true;
                            var clientLocationDetails = string.IsNullOrEmpty(userPreference.Data.ActionPreference) ? null : JsonConvert.DeserializeObject<ClientLocationUserPreferencesViewModel>(userPreference.Data.ActionPreference);
                            HttpContext.Session.Set(SessionKeys.ClientLocationUserPreferences, clientLocationDetails);
                            HttpContext.Session.Set(SessionKeys.UserPreferences, new UserPreferenceViewModel()
                            {
                                ActionCode = UserPreferenceActionCodes.HeaderSelection.GetDescription(),
                                ClientCode = clientLocationDetails?.ClientCode,
                                UserPreference = JsonConvert.SerializeObject(clientLocationDetails),
                                UserName = User.Identity!.Name
                            });

                            // User preferences exist
                            return true;
                        }
                    }
                }
                else
                {
                    // User preferences exist
                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(Index)} - {ex.Message}");
                throw;
            }

            // No user preferences exist
            return false;
        }

        private async Task<bool> GetPersonalSettingsAsync()
        {
            try
            {
                var personalSettings = HttpContext.Session.Get<PersonalSettingsViewModel>(SessionKeys.PersonalSettingsSession);
                if (personalSettings == null)
                {
                    var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                    _apiClientService.SetClientCode(clientLocationPreference.ClientCode);
                    var user = User.GetUserId();

                    var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
                    var response = await _apiClientService.GetResponseAsync(uri);

                    if (!response.IsSuccessStatusCode)
                        throw new Exception($"Method: {nameof(Index)} - No valid response from API");

                    var stringResult = response.Content.ReadAsStringAsync().Result;
                    var personalSettingsResult = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(stringResult);

                    if (personalSettingsResult != null && (personalSettingsResult.DaysofHistory == 0 ||
                                                           personalSettingsResult.LabelSortOrderId == 0 ||
                                                           personalSettingsResult.RowsPerPage == 0))
                    {
                        return false;
                    }

                    if (personalSettingsResult != null)
                    {
                        // We have personal settings for the user
                        HttpContext.Session.Set(SessionKeys.PersonalSettingsDefaults, personalSettingsResult);
                        HttpContext.Session.Set(SessionKeys.PersonalSettingsSession, personalSettingsResult);

                        return true;
                    }
                }
                else
                {
                    // Personal settings exist
                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(Index)} - {ex.Message}");
                throw;
            }

            // No personal settings exist
            return false;

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public IActionResult GetConfigurationValue()
        {
            var result = new { configurationValue = _apiSettings.Uri, userId = HttpContext.User.Identity.Name };
            return Json(result);
        }

        [HttpPost]
        public async Task SetCustomerListSession(CustomerListViewModel customerList)
        {
            try
            {
                await UpdateClientLocationDetailsAsync(customerList.ClientCode, customerList.ProcessingLocation);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(SetCustomerListSession)} - " + ex.Message);
            }
        }

        /// <summary>
        /// Updates the client location details to session and also updates User preferences.
        /// </summary>
        /// <param name="clientCode">The client code.</param>
        /// <param name="processingLocation">The processing location.</param>
        private async Task UpdateClientLocationDetailsAsync(string clientCode, string processingLocation)
        {
            var clientLocationUserPreferences = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences) == null ? new ClientLocationUserPreferencesViewModel() : HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            if (clientLocationUserPreferences == null || (clientLocationUserPreferences?.ClientCode != clientCode || clientLocationUserPreferences?.ProcessingLocationCode != processingLocation))
            {
                clientLocationUserPreferences.ClientCode = clientCode;
                clientLocationUserPreferences.UserName = User.GetUserId();
                clientLocationUserPreferences.ProcessingLocationCode = processingLocation;
            }
            HttpContext.Session.Set(SessionKeys.ClientLocationUserPreferences, clientLocationUserPreferences);
            await SaveUserPreferenceAsync(new UserPreferenceViewModel() { ActionCode = UserPreferenceActionCodes.HeaderSelection.GetDescription(), ClientCode = clientCode, UserPreference = JsonConvert.SerializeObject(clientLocationUserPreferences), UserName = User.Identity.Name });
        }

        /// <summary>
        /// Updates the client location details to session and also updates User preferences.
        /// </summary>
        /// <param name="clientCode">The client code.</param>
        /// <param name="processingLocation">The processing location.</param>
        public async Task<IActionResult> UpdateHeaderSessionValuesAsync(string clientCode, string processingLocationCode)
        {
            var clientLocationUserPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences) == null ? new ClientLocationUserPreferencesViewModel() : HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            clientLocationUserPreference.ClientCode = clientCode;
            clientLocationUserPreference.ProcessingLocationCode = processingLocationCode;
            await SaveUserPreferenceAsync(new UserPreferenceViewModel() { ActionCode = UserPreferenceActionCodes.HeaderSelection.GetDescription(), ClientCode = clientCode, UserPreference = JsonConvert.SerializeObject(clientLocationUserPreference), UserName = User.Identity.Name });
            HttpContext.Session.Set(SessionKeys.ClientLocationUserPreferences, clientLocationUserPreference);
            return ViewComponent("HeaderSelection", new { ClientCode = clientCode, ProcessingLocationCode = processingLocationCode });
        }

        /// <summary>
        /// Calls the PM Api and updates User preferences.
        /// </summary>
        /// <param name="userPreference">The userPreference view model.</param>
        private async Task SaveUserPreferenceAsync(UserPreferenceViewModel userPreference)
        {
            var uri = _pmApiSettings.Uri + ApiRouteConstants.SaveUserPreference();
            _logger.LogInformation($"Method: {nameof(Index)} - Before processing Save userPrereference");

            await _apiClientService.PostRequestAsync(uri, userPreference);
            HttpContext.Session.Set(SessionKeys.UserPreferences, userPreference);
            _logger.LogInformation($"Method: {nameof(Index)} - After processing Save userPrereference");
        }

        [HttpGet]
        public IActionResult KeepAlive()
        {
            return Content("I am alive!");
        }

        #region Notification

        [HttpGet]
        public async Task<IActionResult> GetNotificationViewComponentAsync()
        {
            var notifications = new List<NotificationViewModel>();

            try
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.GetNotifications() + $"/{User.Identity.Name}";
                _apiClientService.SetClientCode(User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));
                var response = await _apiClientService.GetResponseAsync(uri);
                var result = response.Content.ReadAsStringAsync().Result;
                notifications = JsonConvert.DeserializeObject<ServiceResponse<List<NotificationViewModel>>>(result).Data;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetNotificationViewComponentAsync)} - {ex.Message}");
            }
            return ViewComponent("Notifications", notifications);
        }
        #endregion
    }
}
