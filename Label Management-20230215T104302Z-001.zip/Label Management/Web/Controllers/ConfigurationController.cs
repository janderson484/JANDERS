using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper.Configuration;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Configuration;
using VM.FleetServices.TnR.LM.Web.Helpers;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json.Linq;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [Authorize]
    [ValidateSessionActionFilter]
    public class ConfigurationController : BaseController
    {
        #region PrivateMembers

        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly ILogger<ConfigurationController> _logger;
        private readonly IMemoryCache _cache;
        private readonly AppSettings _appSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly Settings _settings;

        #endregion

        #region Constructor
        public ConfigurationController(IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IApiClientService apiClientService,
            ILogger<ConfigurationController> logger, IMemoryCache cache, IOptions<AppSettings> appSettings, IOptions<Settings> settings) : base(apiSettings, pmApiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            _cache = cache;
            _appSettings = appSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
            _settings = settings.Value;
        }
        #endregion
        #region Public Methods

        public IActionResult Index()
        {
            if (User.IsLMExternalUser())
            {
                return AccessDenied();
            }
            var profileSettings = GetUserProfileSettings();
            var model = new ImportLayoutConfigurationViewModel()
            {
                ImportLayouts = new List<ImportLayoutViewModel>(),
                ClientCode = profileSettings.ClientCode,
                DefaultRowsPerPage = profileSettings.DefaultRowsPerPage,
                PageNumber = 1
            };
            return View(model);
        }

        /// <summary>
        /// Gets the import layouts
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<JsonResult> GetImportLayoutsAsync([DataSourceRequest] DataSourceRequest request, bool newRequest, bool includeDisabledConfigs)
        {
            var baseRequest = GetDataRequest(request.Page, request.PageSize);
            baseRequest.IncludeDisabled = includeDisabledConfigs;
            var result = new DataSourceResult();
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            try
            {
                var importLayoutConfigs = HttpContext.Session.Get<ImportLayoutConfigurationViewModel>(SessionKeys.ImportLayouts);

                // when sorting order changes
                if (request.Sorts != null && request.Sorts.Any() && !newRequest && importLayoutConfigs != null && importLayoutConfigs.ImportLayouts != null && importLayoutConfigs.PageNumber == baseRequest.PageNumber
                                                                        && importLayoutConfigs.SelectedRowsPerPage != null && importLayoutConfigs.SelectedRowsPerPage == baseRequest.SelectedRowsPerPage)

                {
                    var propertyInfo = typeof(ImportLayoutViewModel).GetProperty(request.Sorts[0].Member);
                    result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? importLayoutConfigs.ImportLayouts.OrderBy(p => propertyInfo?.GetValue(p, null))
                                                                                                : importLayoutConfigs.ImportLayouts.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                    result.Total = importLayoutConfigs.TotalCount;
                }
                else
                {
                    _apiClientService.SetClientCode(baseRequest.ClientCode);
                    var uri = _apiSettings.Uri + ApiRouteConstants.GetImportLayouts();

                    _logger.LogInformation($"POST method: {nameof(GetImportLayoutAsync)} - Calling {uri}");

                    var response = await _apiClientService.PostRequestAsync(uri, baseRequest);
                    if (!response.IsSuccessStatusCode)
                        throw new Exception("Http Response was not successful");

                    var stringResult = response.Content.ReadAsStringAsync().Result;
                    var importLayoutConfigFResult = JsonConvert.DeserializeObject<ImportLayoutConfigurationViewModel>(stringResult);
                    importLayoutConfigFResult.ClientCode = baseRequest.ClientCode;
                    importLayoutConfigFResult.DmvStateCode = baseRequest.DmvStateCode;
                    importLayoutConfigFResult.SelectedRowsPerPage = baseRequest.SelectedRowsPerPage;
                    importLayoutConfigFResult.PageNumber = baseRequest.PageNumber;

                    if (request.Sorts == null || !request.Sorts.Any())
                    {
                        var clientCodeList = await GetClientListAsync();
                        var processingLocationCodeList = await GetProcessingLocationListAsync();
                        foreach (var layout in importLayoutConfigFResult.ImportLayouts.ToList())
                        {
                            layout.ClientCode = (clientCodeList.Count() == layout.SelectedClientCodeList.Count()) ? "All" : string.Join(", ", clientCodeList.Where(a => layout.SelectedClientCodeList.Contains(a.Value)).Select(x => x.Text).ToArray());
                            layout.ProcessingLocationCode = (processingLocationCodeList.Count() == layout.SelectedProcessingLocationCodeList.Count()) ? "All" : string.Join(", ", processingLocationCodeList.Where(a => layout.SelectedProcessingLocationCodeList.Contains(a.Value)).Select(x => x.Text).ToArray());
                        }


                        result.Data = importLayoutConfigFResult.ImportLayouts;
                    }
                    else
                    {
                        var propertyInfo = typeof(ImportLayoutViewModel).GetProperty(request.Sorts[0].Member);
                        result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? importLayoutConfigFResult.ImportLayouts.OrderBy(p => propertyInfo?.GetValue(p, null)) : importLayoutConfigFResult.ImportLayouts.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                    }
                    result.Total = importLayoutConfigFResult.TotalCount;
                    HttpContext.Session.Set(SessionKeys.ImportLayouts, importLayoutConfigFResult);
                    _logger.LogInformation($"POST method: {nameof(GetImportLayoutAsync)} - Returned from Web Api call successfully");
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetImportLayoutAsync)} - A critical error occurred getting import layout.\r\n Message: {e.Message} ");
            }

            return Json(result);
        }

        /// <summary>
        /// Updates the import layouts status
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> UpdateImportLayoutConfigStatusAsync(int Id, bool Active)
        {
            if (User.IsLMExternalUser() || User.IsTnrSupervisorUser() || User.IsLMInternalUser())
            {
                return AccessDenied();
            }
            var model = new ImportLayoutViewModel
            {
                LabelImportId = Id,
                Active = Active,
                UserId = User.GetUserId(),
            };
            var uri = _apiSettings.Uri + ApiRouteConstants.UpdateImportLayoutStatus();

            _logger.LogInformation($"Post method: {nameof(UpdateImportLayoutConfigStatusAsync)} - Calling {uri}");

            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<bool>(stringResult);
            return Json(new { Status = result, ResponseText = "Import layout configuration status has been updated" });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> AddEditImportLayoutGetAsync(int id)
        {
            var profileSettings = GetUserProfileSettings();
            var masterDatas = await GetMasterDatasAsync();
            var model = new ImportLayoutViewModel();
            if (id != 0)
            {
                model.StateProvinceCode = profileSettings.DmvStateCode;
                var data = await GetImportLayoutAsync(id);
                if (data == null)
                {
                    return PartialView(model);
                }
                model = data;
            }
            model.Labelimportfields = masterDatas != null ? masterDatas.Item1 : new List<DTO.LabelImportField>();
            model.LabelTypes = masterDatas != null ? masterDatas.Item2 : new List<DTO.LabelType>();
            model.ClientCodeList = await GetClientListAsync();
            model.ProcessingLocationCodeList = await GetProcessingLocationListAsync();
            return PartialView("_AddEditImportConfig", model);
        }

        /// <summary>
        /// Add/Update the Layout configuration
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<ActionResult> AddEditImportLayoutSaveAsync(ImportLayoutViewModel model)
        {
            if (model == null)
            {
                return Json(new { Status = false, ResponseText = "Model is empty" });
            }
            var profileSettings = GetUserProfileSettings();
            model.UserId = User.GetUserId();
            model.StateProvinceCode = profileSettings.DmvStateCode;
            var uri = _apiSettings.Uri + ApiRouteConstants.SaveLayoutConfig();
            _logger.LogInformation($"Post method: {nameof(AddEditImportLayoutSaveAsync)} - Calling {uri}");
            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<(bool, string)>(stringResult);
            HttpContext.Session.Remove(SessionKeys.ImportLayouts);
            return Json(new { Status = result.Item1, ResponseText = result.Item2 });
        }

        #region Print Sort Order

        public IActionResult CreateSortOrder()
        {
            if (!User.IsTnrAdminUser())
            {
                return AccessDenied();
            }
            var profileSettings = GetUserProfileSettings();
            var model = new LabelSortOrderConfigurationViewModel()
            {
                LabelSortOrders = new List<LabelSortOrderViewModel>(),
                ClientCode = profileSettings.ClientCode,
                DefaultRowsPerPage = profileSettings.DefaultRowsPerPage,
                PageNumber = 1
            };
            return View("ViewSortOrder",model);
        }

        /// <summary>
        /// Gets the label sort order
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<JsonResult> GetPrintSortOrderAsync([DataSourceRequest] DataSourceRequest request, bool newRequest, bool includeDisabledConfigs)
        {
            var baseRequest = GetDataRequest(request.Page, request.PageSize);
            baseRequest.IncludeDisabled = includeDisabledConfigs;
            var result = new DataSourceResult();
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            try
            {
                var importSortOrderConfigs = HttpContext.Session.Get<LabelSortOrderConfigurationViewModel>(SessionKeys.LabelSortOrder);

                // when sorting order changes
                if (request.Sorts != null && request.Sorts.Any() && !newRequest && importSortOrderConfigs != null && importSortOrderConfigs.LabelSortOrders != null && importSortOrderConfigs.PageNumber == baseRequest.PageNumber
                                                                        && importSortOrderConfigs.SelectedRowsPerPage != null && importSortOrderConfigs.SelectedRowsPerPage == baseRequest.SelectedRowsPerPage)

                {
                    var propertyInfo = typeof(LabelSortOrderViewModel).GetProperty(request.Sorts[0].Member);
                    result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? importSortOrderConfigs.LabelSortOrders.OrderBy(p => propertyInfo?.GetValue(p, null))
                                                                                                : importSortOrderConfigs.LabelSortOrders.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                    result.Total = importSortOrderConfigs.TotalCount;
                }
                else
                {
                    _apiClientService.SetClientCode(baseRequest.ClientCode);
                    var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelSortOrder();

                    _logger.LogInformation($"POST method: {nameof(GetPrintSortOrderAsync)} - Calling {uri}");

                    var response = await _apiClientService.PostRequestAsync(uri, baseRequest);
                    if (!response.IsSuccessStatusCode)
                        throw new Exception("Http Response was not successful");

                    var stringResult = response.Content.ReadAsStringAsync().Result;
                    var labelSortOrdertConfigFResult = JsonConvert.DeserializeObject<LabelSortOrderConfigurationViewModel>(stringResult);
                    labelSortOrdertConfigFResult.ClientCode = baseRequest.ClientCode;
                    labelSortOrdertConfigFResult.SelectedRowsPerPage = baseRequest.SelectedRowsPerPage;
                    labelSortOrdertConfigFResult.PageNumber = baseRequest.PageNumber;

                    if (request.Sorts == null || !request.Sorts.Any())
                    {
                        var clientCodeList = await GetClientListAsync();
                        var processingLocationCodeList = await GetProcessingLocationListAsync();
                        foreach (var sortOrder in labelSortOrdertConfigFResult.LabelSortOrders.ToList())
                        {
                            sortOrder.ClientCode = (clientCodeList.Count() == sortOrder.SelectedClientCodeList.Count()) ? "All" : string.Join(", ", clientCodeList.Where(a => sortOrder.SelectedClientCodeList.Contains(a.Value)).Select(x => x.Text).ToArray());
                            sortOrder.ProcessingLocationCode = (processingLocationCodeList.Count() == sortOrder.SelectedProcessingLocationCodeList.Count()) ? "All" : string.Join(", ", processingLocationCodeList.Where(a => sortOrder.SelectedProcessingLocationCodeList.Contains(a.Value)).Select(x => x.Text).ToArray());
                        }
                        result.Data = labelSortOrdertConfigFResult.LabelSortOrders;
                    }
                    else
                    {
                        var propertyInfo = typeof(LabelSortOrderViewModel).GetProperty(request.Sorts[0].Member);
                        result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? labelSortOrdertConfigFResult.LabelSortOrders.OrderBy(p => propertyInfo?.GetValue(p, null)) : labelSortOrdertConfigFResult.LabelSortOrders.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                    }
                    result.Total = labelSortOrdertConfigFResult.TotalCount;
                    HttpContext.Session.Set(SessionKeys.LabelSortOrder, labelSortOrdertConfigFResult);
                    _logger.LogInformation($"POST method: {nameof(GetPrintSortOrderAsync)} - Returned from Web Api call successfully");
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetPrintSortOrderAsync)} - A critical error occurred getting label sort orders.\r\n Message: {e.Message} ");
            }

            return Json(result);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> AddEditSortOrderGetAsync(int id)
        {
            var fieldData = await GetLabelsDataAsync();
            var model = new LabelSortOrderViewModel();
            model.ClientCodeList = await GetClientListAsync();
            model.ProcessingLocationCodeList = await GetProcessingLocationListAsync();
            if (id != 0)
            {
                var data = await GetSortOrderAsync(id);
                if (data == null)
                {
                    return PartialView(model);
                }
                else
                {
                    data.Labelimportfields = fieldData != null ? fieldData.Item1 : new List<DTO.LabelImportField>();
                    data.ClientCodeList = model.ClientCodeList;
                    data.ProcessingLocationCodeList = model.ProcessingLocationCodeList;
                    return PartialView("_AddEditSortOrder", data);
                }
            }
            model.Labelimportfields = fieldData != null ? fieldData.Item1 : new List<DTO.LabelImportField>();
            return PartialView("_AddEditSortOrder", model);
        }

        /// <summary>
        /// Add/Update the label sort order
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<ActionResult> AddEditSortOrderSaveAsync(LabelSortOrderViewModel model)
        {
            if (model == null)
            {
                return Json(new { Status = false, ResponseText = "Model is empty" });
            }
            model.UserId = User.GetUserId();
            var uri = _apiSettings.Uri + ApiRouteConstants.SaveLabelSortOrder();
            _logger.LogInformation($"Post method: {nameof(AddEditSortOrderSaveAsync)} - Calling {uri}");
            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<(bool, string)>(stringResult);
            HttpContext.Session.Remove(SessionKeys.LabelSortOrder);
            return Json(new { Status = result.Item1, ResponseText = result.Item2 });
        }

        /// <summary>
        /// Deletes the label sort order
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<ActionResult> DeleteSortOrderAsync(int id)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.DeleteLabelSortOrder() + $"/{id}";

            _logger.LogInformation($"Post method: {nameof(UpdateLabelSortOrderStatusAsync)} - Calling {uri}");

            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<bool>(stringResult);
            return Json(new { Status = result, ResponseText = "Label sort order status has been updated" });
        }

        /// <summary>
        /// Updates the label sort order
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> UpdateLabelSortOrderStatusAsync(int Id, bool Active)
        {
            if (User.IsLMExternalUser() || User.IsTnrSupervisorUser() || User.IsLMInternalUser())
            {
                return AccessDenied();
            }
            var model = new LabelSortOrderViewModel
            {
                LabelSortOrderId = Id,
                Active = Active
            };
            var uri = _apiSettings.Uri + ApiRouteConstants.UpdateSortOrderStatus();

            _logger.LogInformation($"Post method: {nameof(UpdateLabelSortOrderStatusAsync)} - Calling {uri}");

            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<bool>(stringResult);
            return Json(new { Status = result, ResponseText = "Label sort order status has been updated" });
        }

        #endregion

        #region PersonalSettings
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> PersonalSettings()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            _apiClientService.SetClientCode(clientLocationPreference.ClientCode);
            var user = User.GetUserId();
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                return View();

            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(stringResult);
            var model = new PersonalSettingsViewModel()
            {
                LabelSortOrders = await GetLabelSortOrdersAsync(clientLocationPreference.ClientCode, clientLocationPreference.ProcessingLocationCode),
                LabelSortOrderId = result.LabelSortOrderId,
                DaysofHistory = result.DaysofHistory,
                LabelsToPDF = result.LabelsToPDF,
                LabelsToPrinter = result.LabelsToPrinter,
                IsPrintEnabled = _settings.IsPrintLabelsToEnabled,
                RowsPerPage = result.RowsPerPage,
                RowsPerPageList = result.RowsPerPageList
            };

            return View(model);
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PersonalSettings(PersonalSettingsViewModel model)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.SetPersonalSettings();

            try
            {
                if (ModelState.IsValid)
                {
                    var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                    _apiClientService.SetClientCode(clientLocationPreference.ClientCode);
                    model.UserId = User.GetUserId();
                    model.ClientCode = clientLocationPreference.ClientCode;
                    model.ProcessingLocationCode = clientLocationPreference.ProcessingLocationCode;
                    var apiResponse = await _apiClientService.PostRequestAsync(uri, model);

                    if (apiResponse.IsSuccessStatusCode)
                    {
                        var result = apiResponse.Content.ReadAsStringAsync().Result;
                        var serviceResponse = JsonConvert.DeserializeObject<bool>(result);
                        if (serviceResponse == true)
                        {
                            HttpContext.Session.Set(SessionKeys.PersonalSettingsDefaults, model);
                            HttpContext.Session.Set(SessionKeys.PersonalSettingsSession, model);

                            return Json(new { data = "SUCCESS" });
                        }
                    }
                    else
                    {
                        //HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");
                        return Json(new { data = "FAIL" });
                    }
                }
                else
                {
                    ModelState.Clear();
                    //HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");

                    return Json(new { data = "FAIL" });
                }
            }
            catch (Exception ex)
            {
                //HttpContext.Session.Set("PersonalSettingsFormResponse", "FAIL");
                _logger.LogError($"POST method: {nameof(PersonalSettings)} - Unable to save changes. Message: {ex.Message}");
            }

            return Json(new { data = "FAIL" });
        }

        public async Task<List<LabelSortOrderViewModel>> GetLabelSortOrdersAsync(string client, string processing)
        {
            _apiClientService.SetClientCode(client);
            var uri = _apiSettings.Uri + ApiRouteConstants.GetAllLabelSortOrders() + $"/{client}/{processing}";
            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                return new List<LabelSortOrderViewModel>();
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<List<LabelSortOrderViewModel>>(stringResult);
            return result;
        }
        #endregion

        #region Printer Configuration

        public IActionResult ViewPrinterAssignment()
        {
            var profileSettings = GetUserProfileSettings();
            var model = new ViewLabelPrintersConfigurationViewModel()
            {
                Printers = new List<PrinterAssignmentResponseModel>(),
                ClientCode = profileSettings.ClientCode,
                DefaultRowsPerPage = profileSettings.DefaultRowsPerPage,
                PageNumber = 1
            };
            return View("ViewPrinterAssignment", model);
        }

        /// <summary>
        /// Gets the printer assignment
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<JsonResult> GetLabelPrinterAssignmentsAsync([DataSourceRequest] DataSourceRequest request, bool newRequest = false, bool includeDisabled = false)
        {
            var baseRequest = GetDataRequest(request.Page, request.PageSize);
            baseRequest.IncludeDisabled = includeDisabled;
            var result = new DataSourceResult();
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            try
            {
                _apiClientService.SetClientCode(baseRequest.ClientCode);
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelPrinterAssignments();

                _logger.LogInformation($"POST method: {nameof(GetLabelPrinterAssignmentsAsync)} - Calling {uri}");

                var response = await _apiClientService.PostRequestAsync(uri, baseRequest);
                if (!response.IsSuccessStatusCode)
                    throw new Exception("Http Response was not successful");

                var responseResult = response.Content.ReadAsStringAsync().Result;
                var labePrintersConfigFResult = JsonConvert.DeserializeObject<ViewLabelPrintersConfigurationViewModel>(responseResult);
                labePrintersConfigFResult.ClientCode = baseRequest.ClientCode;
                labePrintersConfigFResult.SelectedRowsPerPage = baseRequest.SelectedRowsPerPage;
                labePrintersConfigFResult.PageNumber = baseRequest.PageNumber;

                result.Data = labePrintersConfigFResult.Printers;

                if (!request.Sorts.Any())
                {
                    var clientCodeList = await GetClientListAsync();
                    var processingLocationCodeList = await GetProcessingLocationListAsync();

                    foreach (var printer in labePrintersConfigFResult.Printers)
                    {
                        printer.ClientCode = printer.SelectedClientCodeList.Count() == clientCodeList.Count() ? "All" : printer.ClientCode;
                        printer.ProcessingLocationCode = printer.SelectedProcessingLocationCodeList.Count() == processingLocationCodeList.Count() ? "All" : printer.ProcessingLocationCode;
                    }


                    result.Data = labePrintersConfigFResult.Printers;
                }
                else
                {
                    var propertyInfo = typeof(PrinterAssignmentResponseModel).GetProperty(request.Sorts[0].Member);
                    result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? labePrintersConfigFResult.Printers.OrderBy(p => propertyInfo?.GetValue(p, null)) : labePrintersConfigFResult.Printers.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                }

                result.Total = labePrintersConfigFResult.TotalCount;
                _logger.LogInformation($"POST method: {nameof(GetLabelPrinterAssignmentsAsync)} - Returned from Web Api call successfully");
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetLabelPrinterAssignmentsAsync)} - A critical error occurred getting label sort orders.\r\n Message: {e.Message} ");
            }

            return Json(result);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> AssignPrinterGetAsync(int id)
        {
            var profileSettings = GetUserProfileSettings();
            var currentUser = User.Identity.Name;
            var model = new PrinterAssignViewModel();
            model.UserId = currentUser;
            model.PrinterUserId = id;
            var data = await GetPrinterAssignmentDetailsAsync(model);
            if (id != 0)
            {
                model.DisplayName = data.DisplayName;
            }
            // model.ClientCode = profileSettings.ClientCode;
            model.ClientCodeList = await GetClientListAsync();
            model.ProcessingLocationCodeList = await GetProcessingLocationListAsync();
            model.Printers = data.Printers;
            model.PrinterId = data.PrinterId;
            model.PrinterUserId = data.PrinterUserId;
            model.UserId = data.UserId;
            model.Active = data.Active;
            model.SelectedClientCodeList = data.SelectedClientCodeList;
            model.SelectedProcessingLocationCodeList = data.SelectedProcessingLocationCodeList;
            if (model.PrinterUserId == 0)
            {
                model.Active = true;
                model.UserId = "";
            }

            return PartialView("_AssignPrinter", model);
        }

        /// <summary>
        /// Add/Update the printer assignment
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<ActionResult> AddUpdatePrinterAssignmentSaveAsync(PrinterAssignViewModel model)
        {
            if (model == null)
            {
                return Json(new { Status = false, ResponseText = "Model is empty" });
            }
            var profileSettings = GetUserProfileSettings();
            var currentUser = User.Identity.Name;
            model.UserName = currentUser;
            model.ProcessingLocationCode = profileSettings.ProcessingLocationCode;
            model.SelectedClientCodeList = (model.SelectedClientCodeList != null && model.SelectedClientCodeList.Count > 0) ? model.SelectedClientCodeList[0].Split(',').ToList() : model.SelectedClientCodeList;
            model.SelectedProcessingLocationCodeList = (model.SelectedProcessingLocationCodeList != null && model.SelectedProcessingLocationCodeList.Count > 0) ? model.SelectedProcessingLocationCodeList[0].Split(',').ToList() : model.SelectedProcessingLocationCodeList;
            var uri = _apiSettings.Uri + ApiRouteConstants.AddUpdatePrinterAssignmentSaveAsync();
            _logger.LogInformation($"Post method: {nameof(AddUpdatePrinterAssignmentSaveAsync)} - Calling {uri}");
            var response = await _apiClientService.PostRequestAsync(uri, model);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<(bool, string)>(responseResult);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            if (result.Item1 != true)
            {
                return Json(new { Status = result.Item1, ResponseText = result.Item2 });
            }

            return Json(new { Status = true, ResponseText = "Success" });
        }

        /// <summary>
        /// Update the printer assignment status
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> UpdatePrinterAssignmentStatusAsync(int Id, bool Active)
        {
            var model = new PrinterAssignViewModel
            {
                PrinterUserId = Id,
                Active = Active
            };
            var uri = _apiSettings.Uri + ApiRouteConstants.UpdatePrinterAssignmentStatusAsync();

            _logger.LogInformation($"Post method: {nameof(UpdatePrinterAssignmentStatusAsync)} - Calling {uri}");

            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<bool>(responseResult);
            return Json(new { Status = result, ResponseText = "Printer assignment status has been updated" });
        }

        public IActionResult ViewLabelPrinters()
        {
            var profileSettings = GetUserProfileSettings();
            var model = new ViewLabelPrintersConfigurationViewModel()
            {
                Printers = new List<PrinterAssignmentResponseModel>(),
                ClientCode = profileSettings.ClientCode,
                DefaultRowsPerPage = profileSettings.DefaultRowsPerPage,
                PageNumber = 1
            };
            return View("ViewLabelPrinters", model);
        }

        /// <summary>
        /// Gets the label printers
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<JsonResult> GetLabelPrintersAsync([DataSourceRequest] DataSourceRequest request, bool newRequest = false, bool includeDisabled = false)
        {
            var baseRequest = GetDataRequest(request.Page, request.PageSize);
            baseRequest.IncludeDisabled = includeDisabled;
            var result = new DataSourceResult();
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            try
            {
                _apiClientService.SetClientCode(baseRequest.ClientCode);
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelPrintersAsync();

                _logger.LogInformation($"POST method: {nameof(GetLabelPrinterAssignmentsAsync)} - Calling {uri}");

                var response = await _apiClientService.PostRequestAsync(uri, baseRequest);
                if (!response.IsSuccessStatusCode)
                    throw new Exception("Http Response was not successful");

                var responseResult = response.Content.ReadAsStringAsync().Result;
                var labePrintersConfigFResult = JsonConvert.DeserializeObject<ViewLabelPrintersConfigurationViewModel>(responseResult);
                labePrintersConfigFResult.ClientCode = baseRequest.ClientCode;
                labePrintersConfigFResult.SelectedRowsPerPage = baseRequest.SelectedRowsPerPage;
                labePrintersConfigFResult.PageNumber = baseRequest.PageNumber;

                result.Data = labePrintersConfigFResult.Printers;

                if (!request.Sorts.Any())
                {
                    result.Data = labePrintersConfigFResult.Printers;
                }
                else
                {
                    var propertyInfo = typeof(PrinterAssignmentResponseModel).GetProperty(request.Sorts[0].Member);
                    result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? labePrintersConfigFResult.Printers.OrderBy(p => propertyInfo?.GetValue(p, null)) : labePrintersConfigFResult.Printers.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                }

                result.Total = labePrintersConfigFResult.TotalCount;
                _logger.LogInformation($"POST method: {nameof(GetLabelPrintersAsync)} - Returned from Web Api call successfully");
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GetLabelPrintersAsync)} - A critical error occurred getting label sort orders.\r\n Message: {e.Message} ");
            }

            return Json(result);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> PrintersGetAsync(int id)
        {
            var profileSettings = GetUserProfileSettings();
            var currentUser = User.Identity.Name;
            var model = new PrinterAssignViewModel();
            model.PrinterId = id;
            var data = await GetPrinterDetailsAsync(model);
            if (model.PrinterId == 0)
            {
                model.Active = true;
                model.LabelTypeData = data.LabelTypeData;
                model.SelectedLabeltypes = data.SelectedLabeltypes;
            }
            else
            {
                model.DisplayName = data.DisplayName;
                model.IPAddress = data.IPAddress;
                model.PortNumber = data.PortNumber;
                model.Active = data.Active;
                model.LabelTypeData = data.LabelTypeData;
                model.SelectedLabeltypes = data.SelectedLabeltypes;
            }

            return PartialView("_AddEditPrinter", model);
        }

        /// <summary>
        /// Add/Update the label printer 
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<ActionResult> AddUpdatePrinterSaveAsync(PrinterAssignViewModel model)
        {
            if (model == null)
            {
                return Json(new { Status = false, ResponseText = "Model is empty" });
            }
            var profileSettings = GetUserProfileSettings();
            var currentUser = User.Identity.Name;
            model.UserName = currentUser;
            var uri = _apiSettings.Uri + ApiRouteConstants.AddUpdatePrinterSaveAsync();
            _logger.LogInformation($"Post method: {nameof(AddUpdatePrinterSaveAsync)} - Calling {uri}");
            var response = await _apiClientService.PostRequestAsync(uri, model);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<(bool, string)>(responseResult);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            if (result.Item1 != true)
            {
                return Json(new { Status = result.Item1, ResponseText = result.Item2 });
            }

            return Json(new { Status = true, ResponseText = "Success" });
        }

        /// <summary>
        /// Update the label printer status
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> UpdatePrinterStatusAsync(int Id, bool Active)
        {
            var model = new PrinterAssignViewModel
            {
                PrinterId = Id,
                Active = Active
            };
            var uri = _apiSettings.Uri + ApiRouteConstants.UpdatePrinterStatusAsync();

            _logger.LogInformation($"Post method: {nameof(UpdatePrinterStatusAsync)} - Calling {uri}");

            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<bool>(responseResult);
            return Json(new { Status = result, ResponseText = "Printer status has been updated" });
        }
        #endregion

        #endregion

        #region Private Methods

        /// <summary>
        /// Base Request data
        /// </summary>
        /// <param name="selectedPageNumber"></param>
        /// <param name="selectedRowsPerPage"></param>
        /// <returns></returns>
        private UserProfileSettingsViewModel GetDataRequest(int selectedPageNumber = 1, int? selectedRowsPerPage = null)
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var request = new UserProfileSettingsViewModel()
            {
                ClientCode = clientLocationPreference?.ClientCode,
                DefaultRowsPerPage = 10,//HttpContext.Session.Get<PersonalSetting>(SessionKeys.PersonalSettingsSession).RowsPerPage,
                SelectedRowsPerPage = selectedRowsPerPage ?? 10,
                //HttpContext.Session.Get<PersonalSetting>(SessionKeys.PersonalSettingsSession).RowsPerPage,
                ProcessingLocationCode = clientLocationPreference?.ProcessingLocationCode,
                DmvStateCode = "FL",
                PageNumber = selectedPageNumber
            };

            return request;
        }

        /// <summary>
        /// Get user profile settings
        /// </summary>
        /// <returns></returns>
        private UserProfileSettingsViewModel GetUserProfileSettings()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            return new UserProfileSettingsViewModel()
            {
                ClientCode = clientLocationPreference?.ClientCode,
                DmvStateCode = "FL",
                ProcessingLocationCode = clientLocationPreference?.ProcessingLocationCode,
                DefaultRowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage
        };
        }

        /// <summary>
        /// Get master data
        /// </summary>
        /// <returns></returns>
        private async Task<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>> GetMasterDatasAsync()
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetMasterData();

            _logger.LogInformation($"Get method: {nameof(GetMasterDatasAsync)} - Calling {uri}");

            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<(List<DTO.LabelImportField>, List<DTO.LabelType>)>(stringResult);
            return new Tuple<List<DTO.LabelImportField>, List<DTO.LabelType>>(result.Item1, result.Item2);
        }

        /// <summary>
        /// Getimport layout data
        /// </summary>
        /// <returns></returns>
        private async Task<ImportLayoutViewModel> GetImportLayoutAsync(int id)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetImportLayout() + $"/{id}";

            _logger.LogInformation($"Get method: {nameof(GetImportLayoutAsync)} - Calling {uri}");
            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<ServiceResponse<ImportLayoutViewModel>>(stringResult);
            if (result.ResponseCode == HttpStatusCode.OK)
            {
                return result.Data;
            }
            return null;
        }

        /// <summary>
        /// Get Labels
        /// </summary>
        /// <returns></returns>
        private async Task<Tuple<List<Model.DTO.LabelImportField>, List<Model.DTO.LabelType>>> GetLabelsDataAsync()
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelData();

            _logger.LogInformation($"Get method: {nameof(GetMasterDatasAsync)} - Calling {uri}");

            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<(List<DTO.LabelImportField>, List<DTO.LabelType>)>(stringResult);
            return new Tuple<List<DTO.LabelImportField>, List<DTO.LabelType>>(result.Item1, result.Item2);
        }

        /// <summary>
        /// Get label sort order data
        /// </summary>
        /// <returns></returns>
        /// 
        private async Task<LabelSortOrderViewModel> GetSortOrderAsync(int id)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetSortOrder() + $"/{id}";

            _logger.LogInformation($"Get method: {nameof(GetSortOrderAsync)} - Calling {uri}");
            var response = await _apiClientService.GetResponseAsync(uri);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");

            var stringResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<ServiceResponse<LabelSortOrderViewModel>>(stringResult);
            if (result.ResponseCode == HttpStatusCode.OK)
            {
                return result.Data;
            }
            return null;
        }

        /// <summary>
        /// Get Printer Assignment Details
        /// </summary>
        /// <returns></returns>
        private async Task<PrinterAssignViewModel> GetPrinterAssignmentDetailsAsync(PrinterAssignViewModel model)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPrinterAssignmentDetailsAsync();

            _logger.LogInformation($"Get method: {nameof(GetPrinterAssignmentDetailsAsync)} - Calling {uri}");

            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PrinterAssignViewModel>(responseResult);

            return result;
        }

        /// <summary>
        /// Get Printer Details
        /// </summary>
        /// <returns></returns>
        private async Task<PrinterAssignViewModel> GetPrinterDetailsAsync(PrinterAssignViewModel model)
        {
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPrinterDetailsAsync();

            _logger.LogInformation($"Get method: {nameof(GetPrinterDetailsAsync)} - Calling {uri}");

            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                throw new Exception("Http Response was not successful");
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PrinterAssignViewModel>(responseResult);

            return result;
        }

        public async Task<IEnumerable<SelectListItem>> GetClientListAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

            var _lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementCommonLookUps);
            if (_lmLookups == null)
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.CommonLookUps();
                _lmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
                HttpContext.Session.Set(SessionKeys.LabelManagementCommonLookUps, _lmLookups);
            }
            return ((JArray)_lmLookups?["Clients"])?.ToObject<List<DTO.Client>>().Where(a => a.Active)
                .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ClientCode });
        }

        private async Task<IEnumerable<SelectListItem>> GetProcessingLocationListAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

            var _lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementCommonLookUps);
            if (_lmLookups == null)
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.CommonLookUps();
                _lmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
                HttpContext.Session.Set(SessionKeys.LabelManagementCommonLookUps, _lmLookups);
            }
            return ((JArray)_lmLookups?["ProcessingLocations"])?.ToObject<List<DTO.ProcessingLocation>>().Where(a => a.Active)
                .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ProcessingLocationCode });
        }

        /// <summary>
        /// private method to get personal settings data 
        /// </summary>
        /// <returns>returns data</returns>
        private async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync()
        {
            var user = User.GetUserId();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
            var response = await _apiClientService.GetResponseAsync(uri);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(responseResult);
            return result;
        }

        #endregion
    }
}
