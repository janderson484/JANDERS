using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Models;
using VM.FleetServices.TnR.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    //[Authorize]    
    [ViewBagInitializerActionFilter]
    public class BaseController : Controller
    {
        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly ILogger _logger;


        #region Constructor
        public BaseController(IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings,IApiClientService apiClientService, ILogger logger)  
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
            _logger = logger;
            ViewBag.UserPreferenceExists = false;
        }
        #endregion

        #region UserPreferences

        [Authorize]
        [HttpPost]
        public async Task SaveUserPreferenceAsync(UserPreferenceViewModel userPreferenceToSave)
        {
            _apiClientService.SetClientCode(userPreferenceToSave.ClientCode);
            var uri = _pmApiSettings.Uri + Constant.ApiRouteConstants.SaveUserPreference();

            try
            {
                _logger.LogInformation($"Calling Api method { nameof(SaveUserPreferenceAsync)} to save user preferences for ActionCode - {userPreferenceToSave.ActionCode}");
                await _apiClientService.PostRequestAsync(uri, userPreferenceToSave);

            }
            catch (Exception e)
            {
                _logger.LogError($"Execution of Api method { nameof(SaveUserPreferenceAsync)} to save user preferences for ActionCode - {userPreferenceToSave.ActionCode} failed.\r\nError message: {e.Message}. ");
            }
        }
        #endregion

        /// <summary>
        /// Updates the user preferences to session.
        /// </summary>
        /// <typeparam name="T">User preference type</typeparam>
        /// <param name="key">The session key.</param>
        /// <param name="userPreferences">The user preference to update.</param>
        /// <returns>User preference object</returns>
        public async Task<T> UpdateUserPreferencesToSession<T>(string key, T userPreferences)
        {
            //Todo: use object comparer to check if current session object is same as incoming object and skip database save call if they are same
            _logger.LogInformation($"Updating session value for {key}", userPreferences);
            HttpContext.Session.Set(key, userPreferences);
            await Task.Yield();
            return userPreferences;
        }

        
        /// <summary>
        /// Gets the user preferences by key.
        /// </summary>
        /// <typeparam name="T">UserPreference type</typeparam>
        /// <param name="key">The session key.</param>
        /// <returns>User Preference</returns>
        public async Task<T> GetUserPreferencesByKey<T>(string key)
        {

            _logger.LogInformation($"Getting user preferences for {key}");
            var userPreferencesFromSession = HttpContext.Session.Get<T>(key);
            if (userPreferencesFromSession != null)
                return userPreferencesFromSession;

            var userPreferences = HttpContext.Session.Get<Model.DTO.UserPreference>(Constant.SessionKeys.UserPreferences);
            //TODO: Have to do a search matching on key if we are dealing with more than one user preference in the future
            //var jsonString = userPreferences.FirstOrDefault(p => p.ActionCode.Equals(GetActionCodeBySessionKey(key)))?.ActionPreference;
            var actionCode = GetActionCodeBySessionKey(key);
            var jsonString = userPreferences.ActionPreference;
            var userPreference = string.IsNullOrEmpty(jsonString) ? Activator.CreateInstance<T>() : JsonConvert.DeserializeObject<T>(jsonString);
            HttpContext.Session.Set(key, userPreference);
            await Task.Yield();
            return userPreference;
        }

        /*
        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <returns></returns>
        public DataSourceResult HandleError(HttpResponseMessage message, string methodName)
        {
            var result = JsonConvert.DeserializeObject<ServiceResponse<object>>(message.Content.ReadAsStringAsync().Result);
            _logger.LogError($"{((int)message.StatusCode).ToString()} - {message.ReasonPhrase}", methodName, message);
            return new DataSourceResult()
            {
                Data = null,
                Total = 0,
                Errors = new List<string> { $"{result.ErrorMessage}" }
            };
        }
        */
        /// <summary>
        /// Gets the action code by session key.
        /// </summary>
        /// <param name="key">The session key.</param>
        /// <returns>Action Code</returns>
        protected static string GetActionCodeBySessionKey(string key)
        {
            switch (key)
            {
                case Constant.SessionKeys.ClientLocationUserPreferences:
                    return Model.Enums.UserActions.ClientSelection.GetDescription();
                case Constant.SessionKeys.ViewLabelsUserPreferences:
                    return Model.Enums.UserActions.ViewLabels.GetDescription();
                case Constant.SessionKeys.ViewLabelsBagUserPreferences:
                    return Model.Enums.UserActions.ViewBagLabels.GetDescription();
                case Constant.SessionKeys.ViewLabelsUnitUserPreferences:
                    return Model.Enums.UserActions.ViewUnitLabels.GetDescription();
                default:
                    return string.Empty;
            }
        }

        #region Access Denied

        [Authorize]
        public IActionResult AccessDenied()
        {
            return View("~/Views/Account/AccessDenied.cshtml");
        }

        #endregion
    }
}
