using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.Infrastructure.Implementation;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.LM.Web.Integrations.Identity;
using VM.FleetServices.TnR.LM.Web.Models;
using VM.FleetServices.TnR.Model.ViewModel;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using SelectListItem = Microsoft.AspNetCore.Mvc.Rendering.SelectListItem;
using System.IO;
using Microsoft.Net.Http.Headers;
using VM.FleetServices.TnR.LM.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;
using Microsoft.WindowsAzure.Storage.Blob;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using Microsoft.AspNetCore.Authorization;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [Authorize]
    [ValidateSessionActionFilter]
    public class LabelController : BaseController
    {
        private readonly IApiClientService _apiClientService;
        private readonly ILogger<LabelController> _logger;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly IMemoryCache _cache;
        private readonly IAuthService _authService;
        private readonly IBlobStorage _blobStorage;
        private readonly StorageOptions _storageOptions;
        private readonly IApiClientService _apiClient;

        public LabelController(IApiClientService apiClientService, IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IMemoryCache cache,
             ILogger<LabelController> logger, IBlobStorage blobStorage, IOptions<StorageOptions> storageOptions, IAuthService authService, IApiClientService apiClient) : base(apiSettings, pmApiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _logger = logger;
            _blobStorage = new CloudBlobStorage(storageOptions.Value.StorageConnection, storageOptions.Value.BlobContainer);
            _storageOptions = storageOptions.Value;
            _pmApiSettings = pmApiSettings.Value;
            _cache = cache;
            _authService = authService;
            _apiClient = apiClient;
        }

        #region View Labels

        #region View Labels Get/Post Methods
        /// <summary>
        /// View bag labels index page
        /// </summary>
        /// <returns>returns bag labels to view</returns>
        [VerifyClientLocationUserPreferencesActionFilter]
        [VerifyPersonalSettingsActionFilter]
        public async Task<IActionResult> ViewBagLabels(string errorMessage = "")
        {
            SearchLabelViewModel searchCriteria = null;

            _logger.LogInformation($"{nameof(LabelController)} - {nameof(ViewBagLabels)}: Method invoked at {DateTime.Now}");

            try
            {
                HttpContext.Session.Set(SessionKeys.BagLabelSearch, searchCriteria);
                searchCriteria = await GetSearchCriteriaAsync((int)Labeltypes.Bag);
                ViewBag.ErrorMessage = errorMessage;
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(ViewBagLabels)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(ViewBagLabels)}: Error occurred : Error message: {e.Message}");
            }

            return View(searchCriteria);
        }

        /// <summary>
        /// View unit labels index page
        /// </summary>
        /// <returns>returns unit labels to view</returns>
        [VerifyClientLocationUserPreferencesActionFilter]
        [VerifyPersonalSettingsActionFilter]
        public async Task<IActionResult> ViewUnitLabels(string errorMessage = "")
        {
           SearchLabelViewModel searchCriteria = null;

            _logger.LogInformation($"{nameof(LabelController)} - {nameof(ViewUnitLabels)}: Method invoked at {DateTime.Now}");

            try
            {
                HttpContext.Session.Set(SessionKeys.UnitLabelSearch, searchCriteria);
                searchCriteria = await GetSearchCriteriaAsync((int)Labeltypes.Unit);
                ViewBag.ErrorMessage = errorMessage;
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(ViewUnitLabels)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(ViewUnitLabels)}: Error occurred : Error message: {e.Message}");
            }

            return View(searchCriteria);
        }

        /// <summary>
        /// This method is called when the view labels data grid needs to refresh its data
        /// </summary>
        /// <param name="request">The kendo grids request object containing search data parameters</param>
        /// <param name="submittedCriteria">The latest search criteria submitted for this search</param>
        /// <returns>DataSourceResult</returns>
        public async Task<IActionResult> GetLabelsAsync([DataSourceRequest] DataSourceRequest request, SearchLabelViewModel submittedCriteria)
        {

            var result = new DataSourceResult();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            try
            {
                
                if (submittedCriteria.LabelTypeId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(submittedCriteria.LabelTypeId));

                var searchCriteriaFromSession = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.LabelSearch)
                                     ?? await GetSearchCriteriaAsync(submittedCriteria.LabelTypeId);

                var personalSettings = GetPersonalSettingsAsync();

                if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
                {
                    var selectedPageRows = new UserProfileSettingsViewModel()
                    {
                        SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                        DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                    };
                    HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
                }

                // When sorting order changes
                if (submittedCriteria.Search == false && request.Page == searchCriteriaFromSession.PageNumber && request.PageSize == searchCriteriaFromSession.DefaultRowsPerPage /*&& searchCriteriaFromSession.Printed == submittedCriteria.Printed*/ && searchCriteriaFromSession.Results != null && request.Sorts.Any())
                {
                    var propertyInfo = typeof(LabelViewModel).GetProperty(request.Sorts[0].Member);
                    if (searchCriteriaFromSession.Results.Any())
                    {
                        foreach (var data in searchCriteriaFromSession.Results)
                        {
                            data.LabelStatusData = new LabelStatusType { LabelStatusTypeId = data.LabelStatusTypeId, DisplayName = data.LabelStatus };
                        }
                    }
                    result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? searchCriteriaFromSession.Results.OrderBy(p => propertyInfo?.GetValue(p, null))
                                                                                                : searchCriteriaFromSession.Results.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                    result.Total = searchCriteriaFromSession.TotalCount;
                }
                else
                {
                    // Save the updated search criteria to session
                    submittedCriteria.PageNumber = request.Page;
                    submittedCriteria.DefaultRowsPerPage = request.PageSize;
                    submittedCriteria.SelectedLabelStatusTypes = submittedCriteria.GetSelectedLabelStatusTypes();
                    submittedCriteria.ClientCode = clientLocationPreference?.ClientCode;
                    submittedCriteria.ProcessingLocationCode = clientLocationPreference.ProcessingLocationCode;

                    if (submittedCriteria.LabelTypeId == (int)Labeltypes.Bag)
                    {
                        HttpContext.Session.Set(SessionKeys.BagLabelSearch, submittedCriteria);
                    }
                    else
                    {
                        HttpContext.Session.Set(SessionKeys.UnitLabelSearch, submittedCriteria);
                    }
                    // HttpContext.Session.Set(SessionKeys.LabelSearch, submittedCriteria);

                    // Save the user preferences to the session and database
                    await UpdateUserPreferenceAsync(submittedCriteria);

                    // Make the api call to get label data
                    var labelData = await GetLabelDataAsync(submittedCriteria);
                    if (labelData.Results.Any())
                    {
                        foreach (var data in labelData.Results)
                        {
                            data.LabelStatusData = new LabelStatusType { LabelStatusTypeId = data.LabelStatusTypeId, DisplayName = data.LabelStatus };
                        }
                    }

                    result.Data = labelData != null ? labelData.Results : new List<LabelViewModel>();
                    result.Total = labelData?.TotalCount ?? 0;

                    if (!request.Sorts.Any())
                    {
                        result.Data = labelData?.Results;
                    }
                    else
                    {
                        var propertyInfo = typeof(LabelViewModel).GetProperty(request.Sorts[0].Member);
                        result.Data = request.Sorts[0].SortDirection == ListSortDirection.Ascending ? labelData.Results.OrderBy(p => propertyInfo?.GetValue(p, null)) : labelData.Results.OrderByDescending(p => propertyInfo?.GetValue(p, null));
                    }
                    _logger.LogInformation($"POST method: {nameof(GetLabelsAsync)} - Returned from Web Api call successfully");
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetLabelsAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetLabelsAsync)}: Error occurred : Error message: {e.Message}");
            }

            return Json(result);
        }

        #endregion

        #region View Labels Private Methods

        /// <summary>
        /// Updates user preferences to session and the database if necessary
        /// </summary>
        /// <param name="submittedSearchCriteria">The latest search criteria submitted</param>
        /// <returns></returns>
        private async Task UpdateUserPreferenceAsync(SearchLabelViewModel submittedSearchCriteria)
        {
            try
            {
                var saveUserPreference = false;
                string sessionKey = null;

                if (submittedSearchCriteria.LabelTypeId == (int)Labeltypes.Bag)
                {
                    sessionKey = SessionKeys.ViewLabelsBagUserPreferences;
                }
                else
                {
                    sessionKey = SessionKeys.ViewLabelsUnitUserPreferences;
                }

                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

                // Get the last user preference from session and compare to the submitted preference data
                // If the preference data is the same then a database call is not needed
                var submittedLabelStatuses = new List<int>();

                var labelUserPreference = await GetUserPreferencesByKey<ViewLabelsUserPreferencesViewModel>(sessionKey);

                if (labelUserPreference != null)
                {
                    if (submittedSearchCriteria.SelectedLabelStatusTypes != string.Empty)
                    {
                        submittedLabelStatuses = submittedSearchCriteria.SelectedLabelStatusTypes.Split(',').Select(int.Parse).ToList();
                    }
                    if (labelUserPreference.SelectedLabelStatuses == null)
                    {
                        labelUserPreference.SelectedLabelStatuses = new List<int>();
                    }

                    var isEqual = Enumerable.SequenceEqual(labelUserPreference.SelectedLabelStatuses, submittedLabelStatuses);
                    switch (isEqual)
                    {
                        case false:
                            saveUserPreference = true;
                            break;
                    }
                }
                else
                {
                    saveUserPreference = true;
                }

                var viewLabelsUserPreferences = await UpdateUserPreferencesToSession(sessionKey,
                    new ViewLabelsUserPreferencesViewModel()
                    {
                        // Set the last selected label status types to session 
                        SelectedLabelStatuses = submittedSearchCriteria.LabelStatusTypes.Where(i => i.Selected).Select(i => int.Parse(i.Value)).ToList(),
                        // Set the last printed checkbox selection to session
                        IsPrintedSelected = submittedSearchCriteria.Printed,
                        MaintainSearchOrder = submittedSearchCriteria.MaintainSearchOrder
                    });

                if (submittedSearchCriteria.Printed != labelUserPreference.IsPrintedSelected || submittedSearchCriteria.MaintainSearchOrder != labelUserPreference.MaintainSearchOrder)
                {
                    saveUserPreference = true;
                }

                if (saveUserPreference)
                {
                    // Save the preferences to the database when selected label statuses differ

                    if (submittedSearchCriteria.LabelTypeId == (int)Labeltypes.Bag)
                    {
                        await SaveUserPreferenceAsync(new UserPreferenceViewModel()
                        {
                            ActionCode = UserActions.ViewBagLabels.GetDescription(),
                            ClientCode = clientLocationPreference.ClientCode,
                            UserName = User.GetUserId(),
                            UserPreference = JsonConvert.SerializeObject(viewLabelsUserPreferences)
                        });
                    }
                    else
                    {
                        await SaveUserPreferenceAsync(new UserPreferenceViewModel()
                        {
                            ActionCode = UserActions.ViewUnitLabels.GetDescription(),
                            ClientCode = clientLocationPreference.ClientCode,
                            UserName = User.GetUserId(),
                            UserPreference = JsonConvert.SerializeObject(viewLabelsUserPreferences)
                        });
                    }

                }

            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(UpdateUserPreferenceAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(UpdateUserPreferenceAsync)}: Error occurred : Error message: {e.Message}");

                throw;
            }

        }

        /// <summary>
        /// private method to get default search criteria
        /// </summary>
        /// <returns>return search criteria model</returns>
        private async Task<SearchLabelViewModel> GetSearchCriteriaAsync(int labelTypeId)
        {
            SearchLabelViewModel searchCriteria = null;
            var user = User.GetUserId();
            try
            {
                if (labelTypeId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(labelTypeId));

                // Get user preferences
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                var userPreferences = await GetLabelsUserPreferenceAsync(labelTypeId);

                // Get search criteria if any exists in session
                if (labelTypeId == (int)Labeltypes.Bag)
                {
                    searchCriteria = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.BagLabelSearch);
                }
                else
                {
                    searchCriteria = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.UnitLabelSearch);
                }

                if (searchCriteria == null)
                {
                    var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
                    var response = await _apiClientService.GetResponseAsync(uri);
                    var responseResult = response.Content.ReadAsStringAsync().Result;
                    var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(responseResult);
                    var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);

                    if (result.DaysofHistory == 0)
                    {
                        result.DaysofHistory = 90;
                    }

                    // Create a default search criteria model if one was not found in session
                    searchCriteria = new SearchLabelViewModel()
                    {
                        ClientCode = clientLocationPreference?.ClientCode,
                        DefaultRowsPerPage = result.RowsPerPage,
                        ProcessingLocationCode = clientLocationPreference?.ProcessingLocationCode,
                        PageNumber = 1,
                        LabelStatusTypes = new List<SelectListItem>(),
                        StartDate = DateTime.Today.AddDays(-result.DaysofHistory),
                        Printed = (bool)(userPreferences?.IsPrintedSelected),
                        MaintainSearchOrder = (bool)(userPreferences?.MaintainSearchOrder)
                    };

                    if (selectedRows != null)
                    {
                        searchCriteria.DefaultRowsPerPage = selectedRows.DefaultRowsPerPage != result.RowsPerPage ? result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage;
                    }

                    // Label management lookups to render the filters namely label status types
                    var lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementLookUps) ?? await GetLookupsAsync();
                    var labelStatusTypes = ((JArray)lmLookups["LabelStatusTypes"]).ToObject<List<LabelStatusType>>();
                    foreach (var item in labelStatusTypes ?? new List<LabelStatusType>())
                    {
                        //Load the label status types and determine what was selected previously
                        searchCriteria.LabelStatusTypes.Add(new SelectListItem()
                        {
                            Text = item.DisplayName,
                            Value = item.LabelStatusTypeId.ToString(),
                            Selected = userPreferences?.SelectedLabelStatuses?.Contains(item.LabelStatusTypeId) ?? true
                        });
                    }
                }
                else
                {
                    searchCriteria.ClientCode = clientLocationPreference?.ClientCode;
                    searchCriteria.ProcessingLocationCode = clientLocationPreference?.ProcessingLocationCode;

                }

                searchCriteria.LabelTypeId = labelTypeId;

                if (labelTypeId == (int)Labeltypes.Bag)
                {
                    HttpContext.Session.Set(SessionKeys.BagLabelSearch, searchCriteria);
                }
                else
                {
                    HttpContext.Session.Set(SessionKeys.UnitLabelSearch, searchCriteria);
                }

            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetSearchCriteriaAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetSearchCriteriaAsync)}: Error occurred : Error message: {e.Message}");
            }

            return searchCriteria;
        }

        /// <summary>
        /// private method to get labels
        /// </summary>
        /// <param name="searchCriteria">input request</param>
        /// <returns>search criteria model with results</returns>
        private async Task<SearchLabelViewModel> GetLabelDataAsync(SearchLabelViewModel searchCriteria)
        {
            try
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLabels();
                searchCriteria.UserId = User.GetUserId();
                _logger.LogInformation($"Method: {nameof(GetLabelDataAsync)} - Before processing bag labels web API");
                _apiClientService.SetClientCode(searchCriteria.ClientCode);

                searchCriteria.Results = null;
                var response = await _apiClientService.PostRequestAsync(uri, searchCriteria);
                _logger.LogInformation($"Method: {nameof(GetLabelDataAsync)} - After processing bag labels web API");

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var labels = JsonConvert.DeserializeObject<ServiceResponse<SearchLabelViewModel>>(result);
                    labels.Data.Search = false;

                    HttpContext.Session.Set(SessionKeys.LabelSearch, labels.Data);

                    return labels.Data;
                }

                _logger.LogError($"Method: {nameof(GetLabelDataAsync)} - No valid response from API");

            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetLabelDataAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetLabelDataAsync)}: Error occurred : Error message: {e.Message}");
            }

            return null;
        }

        /// <summary>
        /// Gets the user preferences from the database by making an api call if necessary
        /// </summary>
        /// <returns>ViewLabelsUserPreferencesViewModel</returns>
        private async Task<ViewLabelsUserPreferencesViewModel> GetLabelsUserPreferenceAsync(int labelTypeId)
        {
            ViewLabelsUserPreferencesViewModel labelUserPreference = null;
            string actionCode = null;

            try
            {
                if (labelTypeId == (int)Labeltypes.Bag)
                {
                    labelUserPreference = await GetUserPreferencesByKey<ViewLabelsUserPreferencesViewModel>(SessionKeys.ViewLabelsBagUserPreferences);
                    actionCode = GetActionCodeBySessionKey(SessionKeys.ViewLabelsBagUserPreferences);
                }
                else
                {
                    labelUserPreference = await GetUserPreferencesByKey<ViewLabelsUserPreferencesViewModel>(SessionKeys.ViewLabelsUnitUserPreferences);
                    actionCode = GetActionCodeBySessionKey(SessionKeys.ViewLabelsUnitUserPreferences);
                }

                if (labelUserPreference != null && labelUserPreference.SelectedLabelStatuses == null)
                {
                    var uri = _pmApiSettings.Uri + ApiRouteConstants.GetUserPreference() + $"/{User.GetUserId()}/{actionCode}";

                    var token = _authService.GetAccessToken();
                    using (var httpClient = new HttpClient())
                    {
                        _logger.LogInformation($"Method: {nameof(GetLabelsUserPreferenceAsync)} - Before invoking PM web API to get view labels user preference");

                        httpClient.DefaultRequestHeaders.Add("authorization", $"{token.TokenType} {token.AccessToken}");
                        var response = await httpClient.GetAsync(uri);

                        _logger.LogInformation($"Method: {nameof(GetLabelsUserPreferenceAsync)} - After invoking PM web API to get view labels user preference");

                        if (response != null && response.IsSuccessStatusCode)
                        {
                            var result = response.Content.ReadAsStringAsync().Result;
                            var userPreference = JsonConvert.DeserializeObject<ServiceResponse<UserPreference>>(result);
                            if (userPreference?.Data.ActionPreference != null)
                            {
                                if (labelTypeId == (int)Labeltypes.Bag)
                                {
                                    var preference = string.IsNullOrEmpty(userPreference.Data.ActionPreference)
                                   ? null : JsonConvert.DeserializeObject<ViewLabelsUserPreferencesViewModel>(userPreference.Data.ActionPreference);
                                    HttpContext.Session.Set(SessionKeys.ViewLabelsBagUserPreferences, preference);
                                    labelUserPreference = preference;
                                }
                                else
                                {
                                    var preference = string.IsNullOrEmpty(userPreference.Data.ActionPreference)
                                  ? null : JsonConvert.DeserializeObject<ViewLabelsUserPreferencesViewModel>(userPreference.Data.ActionPreference);
                                    HttpContext.Session.Set(SessionKeys.ViewLabelsUnitUserPreferences, preference);
                                    labelUserPreference = preference;
                                }

                            }
                        }
                    };
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetLabelsUserPreferenceAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetLabelsUserPreferenceAsync)}: Error occurred : Error message: {e.Message}");
            }

            return labelUserPreference;
        }

        /// <summary>
        /// Gets the label management lookups from the database by making an api call 
        /// </summary>
        /// <returns>Dictionary</returns>
        private async Task<Dictionary<string, object>> GetLookupsAsync()
        {
            Dictionary<string, object> lmLookups = null;
            try
            {
                // Label management lookups to render the filters namely label status types
                lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementLookUps);
                if (lmLookups == null)
                {
                    var uri = _apiSettings.Uri + ApiRouteConstants.LabelManagementLookUps();
                    lmLookups = await _apiClientService.GetResponseAsync<Dictionary<string, object>>(uri);
                    HttpContext.Session.Set(SessionKeys.LabelManagementLookUps, lmLookups);
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.InnerException != null
                    ? $"{nameof(LabelController)} - {nameof(GetLookupsAsync)}: Error occurred : Error message: {e.Message}\r\n Inner Exception: {e.InnerException.Message} "
                    : $"{nameof(LabelController)} - {nameof(GetLookupsAsync)}: Error occurred : Error message: {e.Message}");
            }

            return lmLookups;
        }

        #endregion

        #endregion

        public async Task<IActionResult> GetSelectedLabelsDataAsync(int labelId)
        {
            var result = new DataSourceResult();

            return Json(result);
        }

        #region Logs
        /// <summary>
        /// private method to get default log summary model
        /// </summary>
        /// <returns>returns model</returns>
        private LogSummaryViewModel GetDefaultLogSummaryViewModel()
        {
            var model = new LogSummaryViewModel { ClientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)), UserId = User.GetUserId(), IsAtLeastSupervisor = User.IsTnrInvoiceUser() };
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            model.ClientCode = clientLocationPreference?.ClientCode;
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();
            model.RowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage;
            return model;
        }

        /// <summary>
        /// private method to get log summary data based on serach criteria
        /// </summary>
        /// <param name="searchCriteria">input request</param>
        /// <returns>returns data</returns>
        private async Task<LogSummaryViewModel> GetLogSummaryDataAsync(LogSummaryViewModel searchCriteria)
        {
            try
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelsLogSummary();
                _logger.LogInformation($"Method: {nameof(GetLogSummaryDataAsync)} - Before processing log summary web API");
                _apiClientService.SetClientCode(searchCriteria.ClientCode);

                searchCriteria.Results = null;

                var response = await _apiClientService.PostRequestAsync(uri, searchCriteria);
                _logger.LogInformation($"Method: {nameof(GetLogSummaryDataAsync)} - After processing log summary web API");

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;

                    var logs = JsonConvert.DeserializeObject<ServiceResponse<LogSummaryViewModel>>(result);
                    if (logs != null)
                    {
                        logs.Data ??= new LogSummaryViewModel();
                        logs.Data.LogSearchCriteria = new SearchLogSummaryViewModel();
                        HttpContext.Session.Set(SessionKeys.LabelsLogSummarySearch, logs.Data);
                        return logs.Data;
                    }
                }

                _logger.LogError($"Method: {nameof(GetLogSummaryDataAsync)} - No valid response from API");

                return new LogSummaryViewModel();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogSummaryDataAsync)} - {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// private method to get default log detail model
        /// </summary>
        /// <returns>returns model</returns>
        private LogDetailViewModel GetDefaultLogDetailViewModel(int logId)
        {
            var logs = HttpContext.Session.Get<LogSummaryViewModel>(SessionKeys.LabelsLogSummarySearch);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);

            var model = new LogDetailViewModel() { LogId = logId, LogData = logs?.Results?.Where(a => a.LogId == logId).FirstOrDefault() };


            var personalSettings = GetPersonalSettingsAsync();

            model.RowsPerPage = selectedRows != null ? selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : (int)selectedRows.SelectedRowsPerPage : personalSettings.Result.RowsPerPage;
        
            return model;
        }

        /// <summary>
        /// private method to get log and log details data based on serach criteria
        /// </summary>
        /// <param name="searchCriteria">input request</param>
        /// <returns>returns data</returns>
        private async Task<LogDetailViewModel> GetLogDetailsByLogAsync(LogDetailViewModel searchCriteria)
        {
            try
            {
                var uri = _apiSettings.Uri + ApiRouteConstants.GetLabelsLogDetails();
                _logger.LogInformation($"Method: {nameof(GetLogDetailsByLogAsync)} - Before processing log summary web API");
                _apiClientService.SetClientCode(User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode)));

                searchCriteria.Results = null;

                var response = await _apiClientService.PostRequestAsync(uri, searchCriteria);
                _logger.LogInformation($"Method: {nameof(GetLogDetailsByLogAsync)} - After processing log summary web API");

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var logDetails = JsonConvert.DeserializeObject<ServiceResponse<LogDetailViewModel>>(result);
                    HttpContext.Session.Set(SessionKeys.LabelsLogDetailsSearch, logDetails.Data);
                    return logDetails.Data;
                }
                else
                {
                    _logger.LogError($"Method: {nameof(GetLogDetailsByLogAsync)} - No valid response from API");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogDetailsByLogAsync)} - {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// This method will return user to Logs page where user can view logs based on his rights
        /// </summary>
        /// <returns>returns view with logs data</returns>
        [HttpGet]
        public async Task<IActionResult> Logs()
        {
            if (User.IsLMExternalUser())
            {
                return AccessDenied();
            }
            var searchCriteria = GetDefaultLogSummaryViewModel();
            return View(searchCriteria);
        }

        /// <summary>
        /// This method will return user to Logs summary page where user can view logs based on his rights
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> GetLogSummaryAsync([DataSourceRequest] DataSourceRequest request)
        {
            var result = new DataSourceResult();

            var searchCriteria = HttpContext.Session.Get<LogSummaryViewModel>(SessionKeys.LabelsLogSummarySearch);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            if (searchCriteria == null)
            {
                searchCriteria = GetDefaultLogSummaryViewModel();
            }

            // determines if this is a new search or any change in parameters - if the below three statements are true, the there is no change in search criteria, returns the data from the session, else performs a new search.
            // request page number = search criteria page number
            // request page size = search criteria page size
            // search criteria results contains data.
            if (request.Page == searchCriteria.PageNumber && request.PageSize == searchCriteria.RowsPerPage && searchCriteria.Results != null && request.Sorts.Any())
            {
                var sortColumnName = request.Sorts[0].Member;
                var sortColumnOrderAscending = request.Sorts[0].SortDirection == Kendo.Mvc.ListSortDirection.Ascending ? true : false;

                // if the sort column is not available, returns the data.
                if (sortColumnName.IsNullOrEmpty())
                {
                    result.Data = searchCriteria.Results;
                }
                else
                {
                    // else gets the property name and sorts according to the flag set earlier
                    var propertyInfo = typeof(Log).GetProperty(sortColumnName);
                    result.Data = sortColumnOrderAscending ? searchCriteria.Results.OrderBy(a => propertyInfo.GetValue(a, null)) : searchCriteria.Results.OrderByDescending(a => propertyInfo.GetValue(a, null));
                }

                result.Total = searchCriteria.TotalCount;

                return Json(result);
            }

            try
            {
                foreach (var filter in request.Filters.SelectMemberDescriptors())
                {
                    switch (filter.Member)
                    {
                        case LogSearchFilters.ProcessStartDate:
                            searchCriteria.LogSearchCriteria.ProcessStartDate = Convert.ToDateTime(filter.Value);
                            break;
                        case LogSearchFilters.ProcessEndDate:
                            searchCriteria.LogSearchCriteria.ProcessEndDate = Convert.ToDateTime(filter.Value);
                            break;
                        case LogSearchFilters.FileName:
                            searchCriteria.LogSearchCriteria.FileName = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.LogStatus:
                            searchCriteria.LogSearchCriteria.LogStatus = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.ProcessType:
                            searchCriteria.LogSearchCriteria.ProcessType = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.ProcessName:
                            searchCriteria.LogSearchCriteria.ProcessName = Convert.ToString(filter.Value);
                            break;
                        case LogSearchFilters.ShowErrors:
                            searchCriteria.LogSearchCriteria.ShowErrors = Convert.ToBoolean(filter.Value);
                            break;
                        case LogSearchFilters.ShowWarnings:
                            searchCriteria.LogSearchCriteria.ShowWarnings = Convert.ToBoolean(filter.Value);
                            break;
                        default:
                            break;
                    }
                }

                searchCriteria.PageNumber = request.Page;
                searchCriteria.RowsPerPage = request.PageSize;

                var userPreferences = HttpContext.Session.Get<UserPreferenceViewModel>(SessionKeys.UserPreferences);
                searchCriteria.ClientCode = userPreferences.ClientCode;

                var logSummaryData = await GetLogSummaryDataAsync(searchCriteria);
                if (logSummaryData != null)
                {
                    result.Data = logSummaryData.Results;
                    result.Total = logSummaryData.TotalCount;
                }
                else
                {
                    result = new DataSourceResult();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogSummaryAsync)} - {ex.Message}");
            }

            return Json(result);
        }

        /// <summary>
        /// action method to get log details based on log id
        /// </summary>
        /// <param name="id">log id</param>
        /// <returns>returns view with log and log details</returns>
        [HttpGet]
        public async Task<IActionResult> LogDetails(int id)
        {
            if (User.IsLMExternalUser())
            {
                return AccessDenied();
            }
            var searchCriteria = GetDefaultLogDetailViewModel(id);

            searchCriteria = await GetLogDetailsByLogAsync(searchCriteria);

            return View(searchCriteria);
        }

        /// <summary>
        /// action method to get log details
        /// </summary>
        /// <param name="request">input request</param>
        /// <returns>returns log and log details</returns>
        [HttpPost]
        public async Task<IActionResult> GetLogDetails([DataSourceRequest] DataSourceRequest request)
        {
            var result = new DataSourceResult();

            var searchCriteria = HttpContext.Session.Get<LogDetailViewModel>(SessionKeys.LabelsLogDetailsSearch);
            var selectedRows = HttpContext.Session.Get<UserProfileSettingsViewModel>(SessionKeys.SelectedRowsPerPage);
            var personalSettings = GetPersonalSettingsAsync();

            if ((selectedRows == null) || (selectedRows != null && selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage) || (selectedRows != null && selectedRows.SelectedRowsPerPage != request.PageSize))
            {
                var selectedPageRows = new UserProfileSettingsViewModel()
                {
                    SelectedRowsPerPage = selectedRows == null ? request.PageSize : selectedRows.DefaultRowsPerPage != personalSettings.Result.RowsPerPage ? personalSettings.Result.RowsPerPage : request.PageSize,
                    DefaultRowsPerPage = personalSettings.Result.RowsPerPage
                };
                HttpContext.Session.Set(SessionKeys.SelectedRowsPerPage, selectedPageRows);
            }

            if (searchCriteria == null)
            {
                searchCriteria = GetDefaultLogDetailViewModel(searchCriteria.LogData.LogId);
            }

            // determines if this is a new search or any change in parameters - if the below three statements are true, the there is no change in search criteria, returns the data from the session, else performs a new search.
            // request page number = search criteria page number
            // request page size = search criteria page size
            // search criteria results contains data.
            if (request.Page == searchCriteria.PageNumber && request.PageSize == searchCriteria.RowsPerPage && searchCriteria.Results != null && request.Sorts.Any())
            {
                var sortColumnName = request.Sorts[0].Member;
                var sortColumnOrderAscending = request.Sorts[0].SortDirection == Kendo.Mvc.ListSortDirection.Ascending ? true : false;

                // if the sort column is not available, returns the data.
                if (sortColumnName.IsNullOrEmpty())
                {
                    result.Data = searchCriteria.Results;
                }
                else
                {
                    // else gets the property name and sorts according to the flag set earlier
                    var propertyInfo = typeof(LogDetail).GetProperty(sortColumnName);
                    result.Data = sortColumnOrderAscending ? searchCriteria.Results.OrderBy(a => propertyInfo.GetValue(a, null)) : searchCriteria.Results.OrderByDescending(a => propertyInfo.GetValue(a, null));
                }

                result.Total = searchCriteria.TotalCount;

                return Json(result);
            }

            try
            {
                searchCriteria.PageNumber = request.Page;
                searchCriteria.RowsPerPage = request.PageSize;

                var logDetailsData = await GetLogDetailsByLogAsync(searchCriteria);

                result.Data = logDetailsData.Results;
                result.Total = logDetailsData.TotalCount;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetLogDetails)} - {ex.Message}");
            }

            return Json(result);
        }

        [HttpPost]        
        public async Task<IActionResult> UpdateLogStatusAsync(int logId, string status)
        {
            try
            {
                var log = new Log
                {
                    LogId = logId,
                    Status = status
                };

                var uri = _apiSettings.Uri + ApiRouteConstants.UpdateLogStatusByIdAsync();
                var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
                _apiClientService.SetClientCode(clientCode);

                var response = await _apiClientService.PostRequestAsync(uri, log);

                if (response != null && response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var apiResponse = JsonConvert.DeserializeObject<ServiceResponse<Log>>(result);

                    if (apiResponse.Data != null)
                    {
                        var logViewModel = apiResponse.Data;

                        return Json(new { isSuccess = true, data = logViewModel });
                    }
                    else
                    {
                        return Json(new { isSuccess = false, Message = apiResponse.ErrorMessage });
                    }

                }
                else
                {
                    _logger.LogError($"Method: {nameof(UpdateLogStatusAsync)} - No valid response from API");
                    return Json(new { isSuccess = false, Message = "No valid response from API" });
                }
            }
            catch (Exception ex)
            {
                return Json(new { isSuccess = false, Message = ex.Message });
            }
        }

        /// <summary>
        /// private method to get personal settings data 
        /// </summary>
        /// <returns>returns data</returns>
        private async Task<PersonalSettingsViewModel> GetPersonalSettingsAsync()
        {
            var user = User.GetUserId();
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var uri = _apiSettings.Uri + ApiRouteConstants.GetPersonalSettings() + $"/{user}/{clientLocationPreference.ClientCode}/{clientLocationPreference.ProcessingLocationCode}";
            var response = await _apiClientService.GetResponseAsync(uri);
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<PersonalSettingsViewModel>(responseResult);
            return result;
        }

        #endregion

        #region Export Labels

        /// Exports reports common method
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ExportLabelsAsync(ExportLabelViewModel model)
        {
            var jsonObject = new JObject();
            try
            {
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                var clientCode = clientLocationPreference?.ClientCode;
                _apiClientService.SetClientCode(clientCode);
                var searchCriteria = GetSearchCriteria(model.ReportType);
                model.ProcessingLocationCode = clientLocationPreference?.ProcessingLocationCode;
                if (!string.IsNullOrEmpty(clientCode))
                {
                    model.SearchCriteria = searchCriteria;
                    model.ClientCode = clientCode;
                    model.UserId = User.GetUserId();

                    var uri = _apiSettings.Uri + ApiRouteConstants.SubmitExportAllRequest();
                    _logger.LogInformation($"Method: {nameof(ExportLabelsAsync)} - Before processing Export All web API");
                    var response = await _apiClientService.PostRequestAsync(uri, model);
                    _logger.LogInformation($"Method: {nameof(ExportLabelsAsync)} - After processing Export All web API");
                    jsonObject.Add("Message", "Request to export report submitted");
                    jsonObject.Add("ExportStatus", true);
                }
                else
                {
                    jsonObject.Add("Message", "Failed to export report");
                    jsonObject.Add("ExportStatus", false);
                }
            }
            catch (Exception)
            {
                _logger.LogError($"Method: {nameof(ExportLabelsAsync)} - Error in submitting service bus request");
                jsonObject.Add("Message", "Critical Error, failure in exporting report!");
                jsonObject.Add("ExportStatus", false);
            }
            return Json(jsonObject);
        }

        /// <summary>
        /// Downloads the CSV document from BLOB
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> ExportCSVReportDocumentAsync(string link)
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var clientCode = clientLocationPreference?.ClientCode;
            try
            {
                if (string.IsNullOrWhiteSpace(link))
                    throw new Exception("Invalid document or document does not exist");

                link = link.Split('/').Last();
                if (link.Contains("\\"))
                {
                    link = link.Split("\\").Last();
                }

                var streamResult = await Task.Run(async () =>
                {
                    var stream = new MemoryStream();
                    var blobStream = await _blobStorage.DownloadBlobAsync(_storageOptions.BlobContainer, clientCode, link, stream, BlobType.AppendBlob);
                    blobStream.Seek(0, SeekOrigin.Begin);
                    return blobStream;
                });

                return new FileStreamResult((MemoryStream)streamResult, "text/csv") { FileDownloadName = link.IndexOf('\\') > 0 ? link.Split('\\').Last() : link };
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(ExportCSVReportDocumentAsync)} - {ex.Message}");
                return View("~/Views/Shared/Error.cshtml");
            }
        }

        [HttpGet]
        public async Task<IActionResult> ExportDocumentAsync(string link)
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var clientCode = clientLocationPreference?.ClientCode;
            try
            {
                if (string.IsNullOrWhiteSpace(link))
                    throw new Exception("Invalid document or document does not exist");

                link = link.Split('/').Last();
                if (link.Contains("\\"))
                {
                    link = link.Split("\\").Last();
                }

                var streamResult = await Task.Run(() =>
                {
                    var stream = new MemoryStream();
                    var blobStream = _blobStorage.DownloadBlobAsync(_storageOptions.LabelBlobContainer, clientCode, link, stream).Result;
                    blobStream.Seek(0, SeekOrigin.Begin);
                    return blobStream;
                });

                return new FileStreamResult((MemoryStream)streamResult, "application/pdf") { FileDownloadName = link.IndexOf('\\') > 0 ? link.Split('\\').Last() : link };
            }

            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(ExportDocumentAsync)} - {ex.Message}");
                return View("~/Views/Shared/Error.cshtml");
            }
        }

        #endregion

        #region Export Labels Private Methods

        /// <summary>
        /// Private method to get the search criteria
        /// </summary>
        /// <param name="reportType"></param>
        /// <returns></returns>
        private string GetSearchCriteria(string reportType)
        {
            var searchCriteria = string.Empty;
            switch (reportType)
            {
                case Reports.ViewBagLabels:
                    var viewBagLabelSearchModel = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.BagLabelSearch);
                    if (viewBagLabelSearchModel != null)
                    {
                        viewBagLabelSearchModel.Results = null;
                        searchCriteria = JsonConvert.SerializeObject(viewBagLabelSearchModel);
                    }
                    break;
                case Reports.ViewUnitLabels:
                    var VieUnitLabelSearchModel = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.UnitLabelSearch);
                    if (VieUnitLabelSearchModel != null)
                    {
                        VieUnitLabelSearchModel.Results = null;
                        searchCriteria = JsonConvert.SerializeObject(VieUnitLabelSearchModel);
                    }
                    break;
                default:
                    searchCriteria = string.Empty;
                    break;
            }
            return searchCriteria;
        }

        #endregion

        #region Update Labels

        public async Task<List<LabelStatusType>> GetLabelStatusTypesAsync()
        {
            var lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementLookUps) ?? await GetLookupsAsync();
            var labelStatusTypes = lmLookups != null ? ((JArray)lmLookups["LabelStatusTypes"]).ToObject<List<LabelStatusType>>() : new List<LabelStatusType>();
            return labelStatusTypes;
        }

        private JsonResult BuildUpdateLabelsErrorModel(int labelCount, string detailedErrorDescription, string friendlyErrorMessage)
        {
            // Will need the report when the editor is displayed! Set it in session
            // Just log the DETAILED error in the report
            HttpContext.Session.Set(SessionKeys.BulkUpdateReport, detailedErrorDescription);

            return Json(new
            {
                // Return failed result
                success = false,
                responseText = friendlyErrorMessage,
                labels = new int[0],
                data = new BulkUpdateViewModel()
                {
                    TotalLabels = labelCount,
                    Labels = new List<int>(),
                    TotalFailed = labelCount,
                    TotalPassed = 0,
                    LogReport = detailedErrorDescription
                }
            });


        }

        /// <summary>
        /// This method will update a list of label Requests
        /// </summary>
        /// <param name="request"></param>
        /// <param name="updatedLabels"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> UpdateLabelsAsync([DataSourceRequest] DataSourceRequest request, [Bind(Prefix = "models")] List<LabelViewModel> updatedLabels)
        {

            if (updatedLabels == null)
                throw new ArgumentNullException(nameof(updatedLabels));

            if (!updatedLabels.Any())
                throw new ArgumentOutOfRangeException($"{nameof(updatedLabels)} cannot contain a 0 count", nameof(updatedLabels));

            try
            {
                // Set client code
                HttpContext.Session.Remove(SessionKeys.BulkUpdateReport);
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);

                var labelsToUpdate = updatedLabels.ToList();

                // Get associated invoice details for the labels
                var labelIds = labelsToUpdate.Select(lbl => lbl.LabelId).ToList();
                var invoiceDetailsResult = await GetInvoiceDetailsForLabelsAsync(labelIds);

                const string friendlyMessage = "The update failed! Please view the log for more details.";

                if (invoiceDetailsResult.HasError)
                {
                    // Return if error getting invoice details 
                    var errorDescription = $"The update failed because of an error getting invoice details for the labels!\r\nError message: {invoiceDetailsResult.ErrorDescription}";
                    var jsonResult = BuildUpdateLabelsErrorModel(labelsToUpdate.Count, errorDescription, friendlyMessage);

                    return jsonResult;
                }

                // Submit request to update the labels
                var updateLabelsModel = new UpdateLabelsModel()
                {
                    LabelsList = labelsToUpdate,
                    Userid = User.GetUserId(),
                    InvoiceList = invoiceDetailsResult.InvoiceDetails
                };

                var uri = _apiSettings.Uri + ApiRouteConstants.UpdateLabels();
                var apiResponse = await _apiClientService.GetResponseAsync(uri, updateLabelsModel);

                // Check for success
                if (!apiResponse.IsSuccessStatusCode)
                {
                    // Failed response from call to update labels
                    var errorDescription = $"Method: {nameof(UpdateLabelsAsync)} - Error response received from {uri}\r\nError details: Status Code: {apiResponse.StatusCode}, Reason:{apiResponse.ReasonPhrase}";
                    _logger.LogError(errorDescription);

                    var jsonResult = BuildUpdateLabelsErrorModel(labelsToUpdate.Count, errorDescription, friendlyMessage);

                    return jsonResult;

                }

                // Deserialize the response
                var stringResult = apiResponse.Content.ReadAsStringAsync().Result;
                var bulkUpdateResult = JsonConvert.DeserializeObject<BulkUpdateResultViewModel>(stringResult);
                _logger.LogInformation($"POST method: {nameof(UpdateLabelsAsync)} - Returned from Web Api call to perform update successfully with a good result");

                // Setup the results to store in session and return to the window
                var report = new StringBuilder(bulkUpdateResult.LogReport);
                var bulkUpdateViewModel = new BulkUpdateViewModel
                {
                    TotalLabels = labelsToUpdate.Count(),
                    Labels = bulkUpdateResult.FailedOrders,
                    TotalFailed = bulkUpdateResult.TotalFailed,
                    TotalPassed = bulkUpdateResult.TotalPassed,
                    LogReport = report.ToString()
                };

                // Will need the report when the editor is displayed! Set it in session
                HttpContext.Session.Set(SessionKeys.BulkUpdateReport, bulkUpdateViewModel.LogReport);
                var savedLabelSearch = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.LabelSearch);
                savedLabelSearch.Results = null;
                HttpContext.Session.Set(SessionKeys.LabelSearch, savedLabelSearch);

                var responseMessage = "Update completed successfully ";
                var successResult = true;
                if (bulkUpdateResult.VoidedLabelBillingIds.Count > 0)
                {
                    // Delete label billings from invoices if we have any
                    var deleteInvoiceBillingsResult = await DeleteInvoiceBillingsAsync((int)InvoiceItemTypes.LabelInvoice, bulkUpdateResult.VoidedLabelBillingIds);

                    if (deleteInvoiceBillingsResult.HasError)
                    {
                        successResult = false;
                        responseMessage = $"{responseMessage}however deleting the voided charges from the invoice failed!\r\nSee log report for more details";

                        //Append error to the log report
                        bulkUpdateViewModel.LogReport = $"{bulkUpdateViewModel.LogReport}\r\n{deleteInvoiceBillingsResult.ErrorDescription}";
                        HttpContext.Session.Set(SessionKeys.BulkUpdateReport, bulkUpdateViewModel.LogReport);
                    }
                }

                return Json(new
                {
                    // Success Response
                    success = successResult,
                    responseText = responseMessage,
                    labels = bulkUpdateResult.FailedOrders.ToArray<int>(),
                    data = bulkUpdateViewModel
                });

            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(UpdateLabelsAsync)} - Error updating labels");
                _logger.LogError($"POST method: {nameof(UpdateLabelsAsync)} - Unable to save changes. Message: {ex.Message}");
                ModelState.AddModelError("UpdateLabelsUnexpectedError", "Unexpected error occurred while updating labels!");
                return Json(ModelState.ToDataSourceResult());
            }
        }


        private async Task<DeleteInvoiceBillingsResult> DeleteInvoiceBillingsAsync(int invoiceItemTypeId, List<int> voidedLabelBillingIds)
        {
            var deleteInvoiceBillingsResult = new DeleteInvoiceBillingsResult()
            {
                ErrorDescription = string.Empty,
                HasError = false,
                VoidedLabelBillingIds = voidedLabelBillingIds
            };

            try
            {
                if (invoiceItemTypeId <= 0)
                    throw new ArgumentOutOfRangeException(nameof(invoiceItemTypeId));

                // Delete the voided charges from invoices
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);

                var fullLmUrl = $"{_apiSettings.Uri}{ApiRouteConstants.DeleteInvoiceBillingsByLineItemId()}/{clientLocationPreference.ClientCode}/{invoiceItemTypeId}";

                var deleteInvoiceDetailsResponse = await _apiClientService.PostRequestAsync(fullLmUrl, voidedLabelBillingIds);
                if (!deleteInvoiceDetailsResponse.IsSuccessStatusCode)
                {
                    var errorDescription = $"Method: {nameof(DeleteInvoiceBillingsAsync)} - There was an error deleting voided charges from the invoices for the updated labels!\r\nPlease verify the invoice charges for the updated labels.\r\nError response received from {fullLmUrl}\r\nError details: Status Code: {deleteInvoiceDetailsResponse.StatusCode}, Reason:{deleteInvoiceDetailsResponse.ReasonPhrase}";
                    _logger.LogError(errorDescription);
                    deleteInvoiceBillingsResult.HasError = true;
                    deleteInvoiceBillingsResult.ErrorDescription = errorDescription;
                    deleteInvoiceBillingsResult.VoidedLabelBillingIds = voidedLabelBillingIds;
                }
            }
            catch (Exception ex)
            {
                var errorDescription = $"Method: {nameof(GetInvoiceDetailsForLabelsAsync)} - Critical error occurred when deleting voided charges from invoices for labels.\r\nPlease verify the invoice charges for the updated labels.\r\nError message: {ex.Message}";
                _logger.LogError(errorDescription);
                deleteInvoiceBillingsResult.HasError = true;
                deleteInvoiceBillingsResult.ErrorDescription = errorDescription;
            }

            return deleteInvoiceBillingsResult;
        }

        /// <summary>
        /// Gets invoice details associated with labels
        /// </summary>
        /// <param name = "labelIds" >Collection of label ids</param>
        /// <returns></returns>
        private async Task<InvoiceDetailsResult> GetInvoiceDetailsForLabelsAsync(List<int> labelIds)
        {
            var invoiceDetailsResult = new InvoiceDetailsResult()
            {
                ErrorDescription = string.Empty,
                HasError = false,
                InvoiceDetails = new List<SelectInvoiceViewModel>()
            };

            try
            {
                if (labelIds == null)
                    throw new ArgumentNullException(nameof(labelIds));

                if (labelIds.Count == 0)
                    throw new ArgumentException("Value cannot be an empty collection.", nameof(labelIds));

                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);

                // Determine what labels are associated with an invoice
                // Calls label management api
                var fullLmUrlGetInvoiceIds = _apiSettings.Uri + ApiRouteConstants.GetInvoiceIdsForLabels();
                var lmGetInvoiceIdsResponse = await _apiClientService.PostRequestAsync(fullLmUrlGetInvoiceIds, labelIds);

                if (!lmGetInvoiceIdsResponse.IsSuccessStatusCode)
                {
                    var errorDescription = $"Method: {nameof(GetInvoiceDetailsForLabelsAsync)} - Error response received from {fullLmUrlGetInvoiceIds}\r\nError details: Status Code: {lmGetInvoiceIdsResponse.StatusCode}, Reason:{lmGetInvoiceIdsResponse.ReasonPhrase}";
                    _logger.LogError(errorDescription);
                    invoiceDetailsResult.HasError = true;
                    invoiceDetailsResult.ErrorDescription = errorDescription;

                    return invoiceDetailsResult;
                }

                var invIdListResponse = JsonConvert.DeserializeObject<ServiceResponse<List<int>>>(lmGetInvoiceIdsResponse.Content.ReadAsStringAsync().Result);
                if (invIdListResponse.Data.Count != 0)
                {
                    // Get the invoice details for labels that are associated with invoices
                    // Calls plate management invoicing api from the invoice service in the backend

                    var fullLmUrlGetInvoiceStatus = _apiSettings.Uri + ApiRouteConstants.GetInvoiceStatusByIds();
                    var lmGetInvoiceStatusResponse = await _apiClientService.PostRequestAsync(fullLmUrlGetInvoiceStatus, invIdListResponse.Data);

                    if (!lmGetInvoiceStatusResponse.IsSuccessStatusCode)
                    {
                        var errorDescription = $"Method: {nameof(GetInvoiceDetailsForLabelsAsync)} - Error response received from {fullLmUrlGetInvoiceStatus}\r\nError details: Status Code: {lmGetInvoiceStatusResponse.StatusCode}, Reason:{lmGetInvoiceStatusResponse.ReasonPhrase}";
                        _logger.LogError(errorDescription);
                        invoiceDetailsResult.HasError = true;
                        invoiceDetailsResult.ErrorDescription = errorDescription;

                        return invoiceDetailsResult;
                    }
                    var stringResult = lmGetInvoiceStatusResponse.Content.ReadAsStringAsync().Result;
                    var invoiceDetails = JsonConvert.DeserializeObject<ServiceResponse<List<SelectInvoiceViewModel>>>(stringResult);
                    invoiceDetailsResult.InvoiceDetails = invoiceDetails.Data;

                }
            }
            catch (Exception ex)
            {
                var errorDescription = $"Method: {nameof(GetInvoiceDetailsForLabelsAsync)} - Critical error occurred when getting invoice details for labels.\r\nError message: {ex.Message}";
                _logger.LogError(errorDescription);
                invoiceDetailsResult.HasError = true;
                invoiceDetailsResult.ErrorDescription = errorDescription;
            }

            return invoiceDetailsResult;
        }

        /// <summary>
        /// Builds and returns data that the bulk update window requires on initial loading
        /// </summary>
        /// <param name="labels">A collection of selected label ids</param>
        /// <param name="labelTypeId">The type of label being updated</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult BulkUpdateWindow(List<int> labels, int labelTypeId)
        {
            if (labels.Count == 0)
                throw new ArgumentException("Value cannot be an empty collection.", nameof(labels));

            if (labelTypeId <= 0)
                throw new ArgumentOutOfRangeException(nameof(labelTypeId));

            var model = new BulkUpdateViewModel() { LabelTypeId = labelTypeId };

            try
            {

                // Will need the selected labels when the update is performed, so store them here!
                HttpContext.Session.Set(SessionKeys.SelectedBulkLabels, labels);
                model.TotalLabels = labels.Count();
            }
            catch (ArgumentException)
            {
                _logger.LogError($"Method: {nameof(BulkUpdateWindow)} - No labels received to bulk update. " +
                                 $"Message:  Parameter {nameof(labels)} contains no label ids.");
            }

            return PartialView(model);
        }

        /// <summary>
        /// Performs a bulk update operation on selected labels
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> PerformBulkUpdateAsync(BulkUpdateViewModel bulkUpdateViewModel)
        {
            try
            {
                // Ensure we have selected labels!
                HttpContext.Session.Remove(SessionKeys.BulkUpdateReport);
                var bulkLabelIds = HttpContext.Session.Get<int[]>(SessionKeys.SelectedBulkLabels);

                if (bulkLabelIds.Length == 0)
                {
                    // No labels were selected!
                    return Json(
                        new
                        {
                            success = false,
                            responseText = "No selected labels to perform bulk update operation on.\r\nClose the bulk updates dialog and try again",
                            data = bulkUpdateViewModel
                        });
                }

                // Perform the bulk update operation on selected labels
                // Set the correct client
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);

                // Get associated invoice details for the labels
                bulkUpdateViewModel.Labels = bulkLabelIds.ToList();
                var invoiceDetailsResult = await GetInvoiceDetailsForLabelsAsync(bulkUpdateViewModel.Labels);
                const string friendlyMessage = "The bulk update failed! Please view the log for more details.";

                if (invoiceDetailsResult.HasError)
                {
                    // Return if error getting invoice details 
                    var errorDescription = $"The bulk update failed because of an error getting invoice details for the labels!\r\nError message: {invoiceDetailsResult.ErrorDescription}";
                    var jsonResult = BuildUpdateLabelsErrorModel(bulkLabelIds.Length, errorDescription, friendlyMessage);

                    return jsonResult;
                }

                // Send a request to the web api to perform the bulk update
                var uri = _apiSettings.Uri + ApiRouteConstants.PerformBulkUpdate();
                _logger.LogInformation($"GET method: {nameof(PerformBulkUpdateAsync)} - Calling {uri} , performing bulk update for {bulkLabelIds.Length} labels");

                bulkUpdateViewModel.InvoiceList = invoiceDetailsResult.InvoiceDetails;

                var apiResponse = await _apiClientService.PostRequestAsync(uri, bulkUpdateViewModel);

                // Check for success
                if (!apiResponse.IsSuccessStatusCode)
                {
                    var errorDescription = $"Method: {nameof(PerformBulkUpdateAsync)} - An error occurred when performing a bulk update operation!\r\nError response received from {uri}\r\nError details: Status Code: {apiResponse.StatusCode}, Reason:{apiResponse.ReasonPhrase}";
                    _logger.LogError(errorDescription);
                    var jsonResult = BuildUpdateLabelsErrorModel(bulkLabelIds.Length, errorDescription, friendlyMessage);

                    return jsonResult;
                }

                // Deserialize the response
                var stringResult = apiResponse.Content.ReadAsStringAsync().Result;
                var bulkUpdateResult = JsonConvert.DeserializeObject<BulkUpdateResultViewModel>(stringResult);
                _logger.LogInformation($"POST method: {nameof(PerformBulkUpdateAsync)} - Returned from Web Api call to perform bulk update successfully with a good result");

                var responseMessage = "Bulk update completed successfully.";
                var successResult = true;

                if (bulkUpdateResult.VoidedLabelBillingIds.Count > 0)
                {
                    // Delete label billings from invoices if we have any
                    var labelTypeId = bulkUpdateViewModel.LabelTypeId;
                    var deleteInvoiceBillingsResult = await DeleteInvoiceBillingsAsync((int)InvoiceItemTypes.LabelInvoice, bulkUpdateResult.VoidedLabelBillingIds);
                    if (deleteInvoiceBillingsResult.HasError)
                    {
                        responseMessage = $"{responseMessage}\r\nDeleting the voided charges from the invoice failed!\r\nSee log report for more details";
                        //Append error to the log report
                        bulkUpdateResult.LogReport = $"{bulkUpdateResult.LogReport}\r\n{deleteInvoiceBillingsResult.ErrorDescription}";
                        //Want this to be red to inform the user of this failure
                        successResult = false;
                    }
                }

                // Setup the results to store in session and return to the window
                var report = new StringBuilder(bulkUpdateResult.LogReport);
                report.AppendLine($"Submit Date:{bulkUpdateViewModel.SubmittedLocalDateTime}");

                bulkUpdateViewModel.Labels = bulkUpdateResult.FailedOrders;
                bulkUpdateViewModel.TotalFailed = bulkUpdateResult.TotalFailed;
                bulkUpdateViewModel.TotalPassed = bulkUpdateResult.TotalPassed;
                bulkUpdateViewModel.LogReport = report.ToString();

                // Will need the report when the editor is displayed! Set it in session
                HttpContext.Session.Set(SessionKeys.BulkUpdateReport, bulkUpdateViewModel.LogReport);
                // Will need to update the session
                if (bulkUpdateViewModel.LabelTypeId == (int)Labeltypes.Bag)
                {
                    var savedLabelSearch = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.BagLabelSearch);
                    savedLabelSearch.Results = null;
                    HttpContext.Session.Set(SessionKeys.BagLabelSearch, savedLabelSearch);
                }
                else
                {
                    var savedLabelSearch = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.UnitLabelSearch);
                    savedLabelSearch.Results = null;
                    HttpContext.Session.Set(SessionKeys.UnitLabelSearch, savedLabelSearch);
                }
                return Json(new
                {
                    // Success Response
                    success = successResult,
                    responseText = responseMessage,
                    labels = bulkUpdateResult.FailedOrders.ToArray<int>(),
                    data = bulkUpdateViewModel
                });
            }
            catch (Exception e)
            {
                // Critical Error Response
                _logger.LogError($"Method: {nameof(PerformBulkUpdateAsync)} - A critical error occurred performing a bulk update on labels.\r\n message: {e.Message} ");
                return StatusCode(500, "A Critical error occurred performing the bulk update!\r\nPlease try again.");
            }
        }

        /// <summary>
        /// Returns the internal log editor window content for the log editor window
        /// </summary>
        /// <returns>IActionResult</returns>
        [HttpGet]
        public IActionResult LogEditorWindowContent()
        {
            var reportContent = HttpContext.Session.Get<string>(SessionKeys.BulkUpdateReport);
            var reportEditorModel = new ReportEditorModel() { ReportLog = reportContent };

            return PartialView(reportEditorModel);
        }

        /// <summary>
        /// Returns the update label
        /// </summary>
        /// <returns>IActionResult</returns>
        [HttpPost]
        public IActionResult UpdateLabelResponseWindowContentAsync(BulkUpdateViewModel bulkUpdateViewModel)
        {
            return PartialView(bulkUpdateViewModel);
        }

        /// <summary>
        /// Returns an exported pdf file that contains results of the bulk update
        /// </summary>
        /// <param name="contentType"></param>
        /// <param name="base64"></param>
        /// <param name="fileName"></param>
        /// <returns>An exported PDF file</returns>
        [HttpPost]
        public IActionResult Pdf_Export_Save(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            return File(fileContents, contentType, fileName);
        }

        #endregion

        #region Print Labels

        /// <summary>
        /// View labels print preview page
        /// </summary>
        /// <returns>returns bag labels to view</returns>
        [HttpPost]
        public async Task<IActionResult> PrintPreview(int labelTypeId, List<int> labelIds)
        {
            _logger.LogInformation($"{nameof(LabelController)} - {nameof(PrintPreview)}: Method invoked at {DateTime.Now}");

            if (labelIds == null)
                throw new ArgumentNullException(nameof(labelIds));

            if (labelIds.Count == 0)
                throw new ArgumentException("Value cannot be an empty collection.", nameof(labelIds));

            if (labelTypeId <= 0)
                throw new ArgumentOutOfRangeException(nameof(labelTypeId));

            var model = new PrintPreviewViewModel();

            try
            {
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);

                model.UserName = User.GetUserId();
                model.LabelTypeId = labelTypeId;
                model.LabelIds = labelIds;
                model.ClientCode = clientLocationPreference.ClientCode;
                model.ProcessingLocation = clientLocationPreference.ProcessingLocationCode;

                var response = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.GetLabelPrintData(), model);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Http response was not successful");
                }
                var result = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<PrintPreviewViewModel>>(result);

                if (serviceResponse.ResponseCode == HttpStatusCode.InternalServerError || serviceResponse.ResponseCode == HttpStatusCode.BadRequest)
                {
                    throw new Exception("An unexpected error has occurred.");
                }

                if (serviceResponse.Data.Result.Printers.Count == 0 || serviceResponse.Data.Result.PrinterLabelSettings.Count == 0)
                {
                    throw new Exception("This user does not have a configured printer for this label type.");
                }

                model = serviceResponse.Data;
                ViewBag.Labels = serviceResponse.Data.Labels;
                ViewBag.LabelSettings = serviceResponse.Data.Result.PrinterLabelSettings;
                ViewBag.Printers = serviceResponse.Data.Result.Printers;
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(PrintPreview)} - Failed calling the Printer API. Message: {ex.Message}");

                var labelViewPage = model.LabelTypeId == 1 ? "ViewUnitLabels" : "ViewBagLabels";
                return RedirectToAction(labelViewPage, new { errorMessage = ex.Message });
            }

            return View(model);
        }

        /// <summary>
        /// Update a given printer's Label Settings
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<PrinterLabelSetting> UpdatePrinterLabelSettingsAsync(PrinterLabelSetting model)
        {
            _logger.LogInformation($"{nameof(LabelController)} - {nameof(UpdatePrinterLabelSettingsAsync)}: Method invoked at {DateTime.Now}");
            var serviceResponse = new PrinterLabelSetting();

            try
            {
                var clientCode = User.GetSelectedClient(HttpContext.Session.Get<string>(SessionKeys.SelectedClientCode));
                _apiClientService.SetClientCode(clientCode);

                var response = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.UpdatePrinterLabelSettings(), model);
                var stringResult = response.Content.ReadAsStringAsync().Result;
                serviceResponse = JsonConvert.DeserializeObject<PrinterLabelSetting>(stringResult);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Http response was not successful");
                }

                _logger.LogInformation($"POST method: {nameof(UpdatePrinterLabelSettingsAsync)} - Returned from Printer API call successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(UpdatePrinterLabelSettingsAsync)} - Failed calling the Printer API. Message: {ex.Message}");
                throw new Exception("Update Printer Label Settings was not successful");
            }

            return serviceResponse;
        }

        //[HttpPost]
        //public async Task<IActionResult> PrintLabelsAsync(PrintLabelsViewModel model)
        //{
        //    _logger.LogInformation($"{nameof(LabelController)} - {nameof(PrintLabelsAsync)}: Method invoked at {DateTime.Now}");

        //    try
        //    {
        //        _logger.LogInformation($"POST method: {nameof(PrintLabelsAsync)} - Returned from Printer API call successfully");

        //        var clientCode = User.GetSelectedClient(HttpContext.Session.Get<string>(SessionKeys.SelectedClientCode));
        //        _apiClientService.SetClientCode(clientCode);

        //        var response = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.PrintLabels(), model);

        //        if (!response.IsSuccessStatusCode)
        //        {
        //            return Json(new
        //            {
        //                success = false,
        //                responseText = response.RequestMessage
        //            })
        //            ;
        //        }

        //        var result = response.Content.ReadAsStringAsync().Result;
        //        var apiResponse = JsonConvert.DeserializeObject<ServiceResponse<PrintLabelsViewModel>>(result);

        //        // TODO: Call add charge method
        //        var saveLabelBillingsModel = new SaveLabelBillingsViewModel();
        //        var billingLookupsResult = await GetBillingLookUpsAsync();

        //        saveLabelBillingsModel.Labels = model.Labels.ToList();
        //        saveLabelBillingsModel.BillingLookUps = billingLookupsResult.BillingLookUps;
        //        saveLabelBillingsModel.UserId = User.GetUserId();

        //        var saveBillingsResponse = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.SaveLabelBillings(), saveLabelBillingsModel);

        //        if (apiResponse.ResponseCode != HttpStatusCode.OK)
        //        {
        //            return Json(new
        //            {
        //                success = false,
        //                responseText = apiResponse.ErrorMessage
        //            });
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"POST method: {nameof(PrintLabelsAsync)} - Failed calling the Printer API. Message: {ex.Message}");
        //        return Json(new
        //        {
        //            success = false,
        //            responseText = "Unexpected Error has occurred."
        //        });
        //    }

        //    return Json(new
        //    {
        //        success = true
        //    });
        //}

        [HttpPost]
        [RequestFormLimits(ValueCountLimit = Int32.MaxValue)]
        public async Task<IActionResult> PrintLabelsRequestAsync(PrintLabelsViewModel model)
        {
            try
            {
                _logger.LogInformation($"POST method: {nameof(PrintLabelsRequestAsync)} - starting the call");

                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                _apiClientService.SetClientCode(clientLocationPreference.ClientCode);
                model.ClientCode = clientLocationPreference.ClientCode;
                model.ProcessingLocationCode = clientLocationPreference.ProcessingLocationCode;
                model.UserId = User.GetUserId();
                var response = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.PrintLabels(), model);

                if (!response.IsSuccessStatusCode)
                {
                    return Json(new
                    {
                        success = false,
                        responseText = response.RequestMessage
                    });
                }
                var result = response.Content.ReadAsStringAsync().Result;
                var apiResponse = JsonConvert.DeserializeObject<ServiceResponse<PrintLabelsViewModel>>(result);

                if (apiResponse.ResponseCode != HttpStatusCode.OK)
                {
                    return Json(new
                    {
                        success = false,
                        responseText = apiResponse.ErrorMessage
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(PrintLabelsRequestAsync)} - Failed calling the Print label request API. Message: {ex.Message}");
                return Json(new
                {
                    success = false,
                    responseText = ex.Message
                });
            }
            return Json(new
            {
                success = true
            });
        }

        #endregion

        #region Label Invoice

        /// Invoice the selected labels
        /// </summary>
        /// <param name="labelIds"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> InvoiceSelectedLabeslAsync(List<int> labelIds)
        {
            try
            {
                var userPreference = HttpContext.Session.Get<UserPreferenceViewModel>(SessionKeys.UserPreferences);
                var billingUrl = _apiSettings.Uri + ApiRouteConstants.GetLabelsBillingData();
                var billingResponse = await _apiClientService.PostRequestAsync(billingUrl, labelIds);
                var billingResults = JsonConvert.DeserializeObject<ServiceResponse<List<LabelBilling>>>(billingResponse.Content.ReadAsStringAsync().Result);
                if (billingResults != null && billingResults.Data.Any())
                {
                    var labelUrl = _apiSettings.Uri + ApiRouteConstants.GetLabelsData();
                    var labelResponse = await _apiClientService.PostRequestAsync(labelUrl, billingResults.Data.Select(x => x.LabelId).ToList());
                    var labels = JsonConvert.DeserializeObject<ServiceResponse<List<Label>>>(labelResponse.Content.ReadAsStringAsync().Result);
                    var currentUser = User.Identity.Name;
                    var invoiceUrl = _apiSettings.Uri + ApiRouteConstants.PerformBulkInvoice() + $"/{userPreference.ClientCode}/{currentUser}";
                    var invoiceResponse = await _apiClientService.PostRequestAsync(invoiceUrl, labels.Data);
                    var invoiceResult = JsonConvert.DeserializeObject<ApiResponseDto>(invoiceResponse.Content.ReadAsStringAsync().Result);
                    return Json(new { StatusCode = invoiceResult.ResponseCode != HttpStatusCode.OK ? "False" : "True", Message = invoiceResult.ResponseCode != HttpStatusCode.OK ? invoiceResult.ErrorMessage : "Invoice Processed successfully" });
                }
                else
                {
                    return Json(new { StatusCode = "False", Message = "There are no billings to process !" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(InvoiceSelectedLabeslAsync)} - Error in submitting invoice request" + ex.Message);
                return Json(new { StatusCode = "False", Message = ex.Message });
            }
        }
        #endregion

        #region Commented Out Code

        //private SearchLabelViewModel GetSearchCriteriaFromSession(SearchLabelViewModel searchCriteria)
        //{
        //    _logger.LogInformation("Getting SearchCriteria from cache");
        //    if (!_cache.TryGetValue("SearchCriteria", out SearchLabelViewModel searchCriteriaFromCache))
        //    {
        //        // Not found in Cache so add the search criteria 

        //        _logger.LogInformation("Adding SearchCriteria to cache");
        //        var options = new MemoryCacheEntryOptions
        //        {
        //            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15), //cache will expire in 15 mins
        //            SlidingExpiration = TimeSpan.FromMinutes(5) // cache will expire if inactive for 5 mins
        //        };

        //        if (searchCriteria != null)
        //        {
        //            _cache.Set("SearchCriteria", searchCriteria, options);
        //        }

        //        searchCriteriaFromCache = searchCriteria;
        //    }

        //    searchCriteriaFromCache.ClientCode = HttpContext.Session.Get<string>(SessionKeys.SelectedClientCode);
        //    searchCriteriaFromCache.ProcessingLocationCode = HttpContext.Session.Get<PersonalSetting>(SessionKeys.PersonalSettingsSession).ProcessingLocationCode;

        //    return searchCriteriaFromCache;
        //}

        //public async Task<List<LabelStatusType>> GetLabelStatusTypesAsync()
        //{
        //    var uri = _apiSettings.Uri + ApiRouteConstants.GetAllLabelStatuses();
        //    _logger.LogInformation($"Method: {nameof(GetBagLabelDataAsync)} - Before processing bag labels web API");
        //    var response = await _apiClientService.GetResponseAsync(uri);
        //    _logger.LogInformation($"Method: {nameof(GetBagLabelDataAsync)} - After processing bag labels web API");
        //    if (response != null && response.IsSuccessStatusCode)
        //    {
        //        var result = response.Content.ReadAsStringAsync().Result;
        //        var labelStatuses = JsonConvert.DeserializeObject<ServiceResponse<List<LabelStatusType>>>(result);
        //        return labelStatuses.Data;
        //    }
        //    return new List<LabelStatusType>();
        //}


        ///// <summary>
        ///// This method will update a list of label Requests
        ///// </summary>
        ///// <param name="request"></param>
        ///// <param name="updatedLabels"></param>
        ///// <returns></returns>
        //[HttpPost]
        //// [Authorize(Policy = AuthorizationPolicyNames.ApplicationAccessPolicy)]
        //public async Task<IActionResult> UpdateLabelsAsync([DataSourceRequest] DataSourceRequest request, [Bind(Prefix = "models")] IEnumerable<LabelViewModel> updatedLabels)
        //{
        //    try
        //    {
        //        var clientCode = User.GetSelectedClient(HttpContext.Session.GetString(SessionKeys.SelectedClientCode));
        //        _apiClientService.SetClientCode(clientCode);

        //        var uri = _apiSettings.Uri + ApiRouteConstants.UpdateLabels();

        //        var apiResponse = await _apiClientService.GetResponseAsync(uri, updatedLabels);
        //        var result = apiResponse.Content.ReadAsStringAsync().Result;
        //        var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<IEnumerable<LabelViewModel>>>(result);

        //        var savedLabelSearch = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.LabelSearch);
        //        savedLabelSearch.Results = null;
        //        HttpContext.Session.Set(SessionKeys.LabelSearch, savedLabelSearch);

        //        if (serviceResponse.ResponseCode != HttpStatusCode.OK)
        //        {
        //            _logger.LogError($"Method: {nameof(UpdateLabelsAsync)} - Error updating labels.");
        //            _logger.LogError($"POST method: {nameof(UpdateLabelsAsync)} - Unable to save changes. Message: {serviceResponse.ErrorMessage}");
        //            ModelState.AddModelError("UpdateLabelsError", serviceResponse.ErrorMessage);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Method: {nameof(UpdateLabelsAsync)} - Error updating labels");
        //        _logger.LogError($"POST method: {nameof(UpdateLabelsAsync)} - Unable to save changes. Message: {ex.Message}");
        //        ModelState.AddModelError("UpdateOrdersUnexpectedError", "Unexpected error occurred while updating labels!");
        //    }

        //    return Json(updatedLabels.ToDataSourceResult(request, ModelState));
        //}

        ///// <summary>
        ///// Method : Assign search value to the session
        ///// </summary>
        ///// <param name="searchCriteria"></param>
        ///// <returns></returns>
        //[HttpPost]
        //public async Task SearchOrders(SearchLabelViewModel searchCriteria)
        //{
        //    var searchData = HttpContext.Session.Get<SearchLabelViewModel>(SessionKeys.LabelSearch);
        //    searchData.Search = true;
        //    searchData.SearchColumn = searchCriteria.SearchColumn;
        //    searchData.SearchTextField = searchCriteria.SearchTextField;
        //    searchData.SelectedLabelStatuses = searchCriteria.SelectedLabelStatuses;
        //    HttpContext.Session.Set(SessionKeys.LabelSearch, searchData);
        //}
        #endregion

        #region Label Credits

        /// <summary>
        /// Validated labels to process credits for labels
        /// </summary>
        /// <param name="labels"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ValidateLabelsToApplyCreditsAsync(List<int> labels)
        {
            var serviceResponse = new ServiceResponse<List<CreditLabelViewModel>>();
            var invalidLabels = new List<int>();

            try
            {
                var userPreferences = HttpContext.Session.Get<UserPreferenceViewModel>(SessionKeys.UserPreferences);
                _apiClientService.SetClientCode(userPreferences.ClientCode);

                var uri = _apiSettings.Uri + ApiRouteConstants.ValidateLabelsToApplyCredits();

                var response = await _apiClientService.PostRequestAsync(uri, labels);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Http response was not successful");
                }

                serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<List<CreditLabelViewModel>>>(response.Content.ReadAsStringAsync().Result);

                if (serviceResponse.ResponseCode == HttpStatusCode.InternalServerError || serviceResponse.ResponseCode == HttpStatusCode.BadRequest)
                {
                    return Json(new { isSuccess = false, Message = serviceResponse.ErrorMessage });
                }

                invalidLabels = labels.Where(a => !serviceResponse.Data.Select(x => x.LabelId).Contains(a)).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(ValidateLabelsToApplyCreditsAsync)} - Error occurred performing a request to validate labels to apply credits.\r\n Message: { ex.Message } ");
                return Json(new { isSuccess = false, ex.Message });
            }

            return Json(new { isSuccess = true, Data = serviceResponse.Data, InvalidLabels = invalidLabels });
        }

        /// <summary>
        ///  Applying credit to labels 
        /// </summary>
        /// <param name="labels"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ApplyCreditsToLabelsAsync(IEnumerable<int> labelIds, IEnumerable<int> invoiceIds)
        {
            try
            {
                var model = new CreditLabelRequestModel() { LabelIdList = labelIds, UserName = User.GetUserId(), InvoiceIdList = invoiceIds };

                var userPreferences = HttpContext.Session.Get<UserPreferenceViewModel>(SessionKeys.UserPreferences);
                _apiClientService.SetClientCode(userPreferences.ClientCode);

                // 1. Invoke api to get Invoice status
                var invoiceResponse = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.GetInvoiceStatusByIds(), model.InvoiceIdList);
                if (!invoiceResponse.IsSuccessStatusCode)
                {
                    throw new Exception("Failed to get invoice status details");
                }
                var invoiceResponseList = JsonConvert.DeserializeObject<ServiceResponse<List<SelectInvoiceViewModel>>>(invoiceResponse.Content.ReadAsStringAsync().Result);
                model.InvoiceList = (invoiceResponseList != null) ? invoiceResponseList.Data : new List<SelectInvoiceViewModel>();

                // 2. Invoke api to apply plate credits
                var response = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.ApplyCreditsToLabels(), model);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Apply credits http response was not successful");
                }

                var creditLabelResponModel = JsonConvert.DeserializeObject<ServiceResponse<CreditLabelRequestModel>>(response.Content.ReadAsStringAsync().Result);

                if (creditLabelResponModel.ResponseCode == HttpStatusCode.InternalServerError || creditLabelResponModel.ResponseCode == HttpStatusCode.BadRequest)
                {
                    throw new Exception(creditLabelResponModel.ErrorMessage);
                }

                // 3. Delete Invoice Details for any Voided Label Billings
                if (creditLabelResponModel.Data != null && creditLabelResponModel.Data.VoidLabelBillings.Any())
                {
                    var deleteInvoiceDetailsResponse = await _apiClientService.PostRequestAsync(_apiSettings.Uri + ApiRouteConstants.DeleteInvoiceBillingsByLineItemId() + "/" + userPreferences.ClientCode + "/" + (int)InvoiceItemTypes.LabelInvoice, creditLabelResponModel.Data.VoidLabelBillings);
                    if (!deleteInvoiceDetailsResponse.IsSuccessStatusCode)
                    {
                        throw new Exception("Delete Invoice http response was not successful");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(ApplyCreditsToLabelsAsync)} - Failed calling the api. Message: {ex.Message}");
                return Json(new { isSuccess = false, ex.Message });
            }

            return Json(new { isSuccess = true });
        }

        #endregion

        #region Move Labels

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetMoveLabelsWindowContentAsync(int id)
        {
            var currentUser = User.Identity.Name;
            var model = new MoveLabelsViewModel();
            var ProcessingLocations = await GetProcessingLocationListAsync();
            model.ProcessingLocation = ProcessingLocations;
            return PartialView("~/Views/Label/_MoveLabelsWindowContent.cshtml", model);
        }

        /// <summary>
        /// Update the label processing office
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> UpdateLabelProcessingOfficeAsync(MoveLabelsViewModel model)
        {
            var currentUser = User.Identity.Name;
            var uri = _apiSettings.Uri + ApiRouteConstants.UpdateLabelProcessingOfficeAsync();

            _logger.LogInformation($"Post method: {nameof(UpdateLabelProcessingOfficeAsync)} - Calling {uri}");

            model.UserName = currentUser;
            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<bool>(responseResult);
            return Json(new { Status = result, ResponseText = "Label processing office has been updated" });
        }
        #endregion

        #region Move Labels Private Methods

        /// <summary>
        /// Private method to get the search criteria
        /// </summary>
        /// <param name="reportType"></param>
        /// <returns></returns>
        private async Task<List<SelectListItem>> GetProcessingLocationListAsync()
        {
            var uri = _pmApiSettings.Uri + ApiRouteConstants.CommonLookUps();
            var _lmLookups = await _apiClient.GetResponseAsync<Dictionary<string, object>>(uri);
            var response = ((JArray)_lmLookups?["ProcessingLocations"])?.ToObject<List<ProcessingLocation>>().Where(a => a.Active)
                            .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ProcessingLocationCode }).ToList();
            return response;
        }
        #endregion

        #region Copy Labels

        /// <summary>
        /// Copy label data
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> CopyLabelsResponseWindowContentAsync(CopyLabelsViewModel model)
        {
            var currentUser = User.Identity.Name;
            var uri = _apiSettings.Uri + ApiRouteConstants.CopyLabelsAsync();

            _logger.LogInformation($"Post method: {nameof(CopyLabelsResponseWindowContentAsync)} - Calling {uri}");

            model.UserName = currentUser;
            var response = await _apiClientService.PostRequestAsync(uri, model);
            if (!response.IsSuccessStatusCode)
                return Json(new { Status = false, ResponseText = "HttpError" });
            var responseResult = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<CopyLabelsViewModel>(responseResult);

            return PartialView(result);
        }

        /// <summary>
        /// Returns the internal log editor window content for the copy labels log 
        /// </summary>
        /// <returns>IActionResult</returns>
        [HttpPost]
        public IActionResult CopyLabelsLogWindowContent(CopyLabelsViewModel model)
        {
            var reportEditorModel = new ReportEditorModel() { ReportLog = model.LogReport };

            return PartialView("LogEditorWindowContent", reportEditorModel);
        }
        #endregion
    }
}
