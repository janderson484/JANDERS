using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.LM.Web.Models;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;

namespace VM.FleetServices.TnR.LM.Web.Controllers
{
    [ValidateSessionActionFilter]
    [ViewBagInitializerActionFilter]
    public class BulkProcessingController : BaseController
    {
        private readonly IApiClientService _apiClientService;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private readonly IConfiguration _iConfiguration;
        private readonly ILogger<BulkProcessingController> _logger;
        private readonly IMemoryCache _cache;
        private readonly AppSettings _appSettings;

        #region Constructor

        public BulkProcessingController(IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IApiClientService apiClientService,
            ILogger<BulkProcessingController> logger, IMemoryCache cache, IOptions<AppSettings> appSettings) : base(apiSettings, pmApiSettings, apiClientService, logger)
        {
            _apiClientService = apiClientService;
            _apiSettings = apiSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
            _logger = logger;
            _cache = cache;
            _appSettings = appSettings.Value;
        }

        #endregion

        [VerifyClientLocationUserPreferencesActionFilter]
        [VerifyPersonalSettingsActionFilter]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (User.IsLMReadWriteUser())
            {
                var model = new BulkProcessViewModel();

                try
                {
                    var response = await GetBulkProcessRecordCountsAsync();

                    if (response.ResponseCode == HttpStatusCode.Accepted)
                    {
                        model = response.Data;
                    }
                    else
                    {
                        _logger.LogError($"GET method: {nameof(Index)} - Unable to process. Message: {response.ErrorMessage}");
                    }

                }
                catch (Exception ex)
                {
                    _logger.LogError($"GET method: {nameof(Index)} - Unable to process. Message: {ex.Message}");
                }

                return View("BulkProcessing", model);
            }

            return AccessDenied();
        }

        /// <summary>
        /// Sends requested job to API to run Bulk Processes
        /// </summary>
        /// <param name="bulkAction"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> BulkProcessAsync(string bulkAction, string recordCount)
        {
            if (bulkAction.IsNullOrEmpty())
            {
                _logger.LogError($"POST method: {nameof(BulkProcessAsync)} - Error: BulkAction cannot be null");
                return Json(bulkAction);
            }

            try
            {
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                var clientCode = clientLocationPreference?.ClientCode;
                var processingLocationCode = clientLocationPreference?.ProcessingLocationCode;
                
                var uri = _apiSettings.Uri + ApiRouteConstants.PerformBulkProcess();
                _apiClientService.SetClientCode(clientCode);
                var userId = User.GetUserId();

                var model = new BulkProcessViewModel
                {
                    BulkAction = bulkAction,
                    ProcessType = ProcessTypes.BulkProcess.GetDescription(),
                    ClientName = clientCode,
                    TotalCount = Convert.ToInt32(recordCount),
                    ProcessingLocationCode = processingLocationCode,
                    UserId = userId
                };

                _logger.LogInformation($"POST method: {nameof(BulkProcessAsync)} - Calling {uri} ,posting {bulkAction} to process");
                var response = await _apiClientService.PostRequestAsync(uri, model);
                var responseResult = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(responseResult);

                if (serviceResponse.ErrorMessage is null)
                {
                    _logger.LogInformation($"POST method: {nameof(BulkProcessAsync)} - Returned from Web Api Call. Messages placed on Service Bus successfully");
                }
                else
                {
                    _logger.LogError($"POST method: {nameof(BulkProcessAsync)} - Error: {serviceResponse.ErrorMessage}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"POST method: {nameof(BulkProcessAsync)} - Unable to process. Message: {ex.Message}");
                ModelState.AddModelError("Bulk Process System Error", "There was a critical error while Bulk Processing. \r\nYour changes have been cancelled.");
            }

            return Json(bulkAction);
        }

        /// <summary>
        /// Gets Bulk Process pending counts for all Jobs
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<JsonResult> RefreshBulkProcessCountsAsync()
        {
            var model = new BulkProcessViewModel();

            try
            {
                var response = await GetBulkProcessRecordCountsAsync();

                if (response.ResponseCode == HttpStatusCode.Accepted)
                {
                    model = response.Data;
                }
                else
                {
                    _logger.LogError($"GET method: {nameof(RefreshBulkProcessCountsAsync)} - Unable to process. Message: {response.ErrorMessage}");
                    model = null;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"GET method: {nameof(RefreshBulkProcessCountsAsync)} - Unable to process. Message: {ex.Message}");
                model = null;
            }

            return Json(model);
        }


        #region Private Methods - Miscellaneous

        /// <summary>
        /// Method to call API to get Bulk Process pending counts
        /// </summary>
        /// <returns></returns>
        private async Task<ServiceResponse<BulkProcessViewModel>> GetBulkProcessRecordCountsAsync()
        {
            try
            {
                var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
                var clientCode = clientLocationPreference?.ClientCode;
                var processingLocationCode = clientLocationPreference?.ProcessingLocationCode;

                _apiClientService.SetClientCode(clientCode);

                var uri = _apiSettings.Uri + ApiRouteConstants.GetBulkProcessRecordCounts()
                                               + $"/{clientCode}/{processingLocationCode}";

                return await _apiClientService.GetResponseAsync<ServiceResponse<BulkProcessViewModel>>(uri);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Method: {nameof(GetBulkProcessRecordCountsAsync)} - {ex.Message}");
                throw ex;
            }
        }

        #endregion
    }
}
