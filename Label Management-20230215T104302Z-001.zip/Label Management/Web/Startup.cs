using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Serialization;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.Core.Common.SignalR;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Web.ActionFilters;
using VM.FleetServices.TnR.LM.Web.Helpers;
using VM.FleetServices.TnR.LM.Web.Integrations.Identity;
using VM.FleetServices.TnR.LM.Web.Models;
using VM.FleetServices.TnR.LM.Web.Security;
using VM.FleetServices.TnR.SVRS.Common.SignalR;

namespace VM.FleetServices.TnR.LM.Web
{
    public class Startup
    {
        public Startup(IHostingEnvironment env, IConfiguration configuration)
        {
            Environment = env;
            Configuration = configuration;

            //Register Aspose.Pdf license
            var lic = new Aspose.Pdf.License();
            lic.SetLicense(@"Aspose.Total.lic");
        }

        public IConfiguration Configuration { get; }
        public IHostingEnvironment Environment { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddLocalization(options => options.ResourcesPath = "Resources");
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => false;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            // Register the IConfiguration instance which MyOptions binds against.
            services.Configure<OpenIdSettings>(options => Configuration.GetSection("OpenIdSettings").Bind(options));
            services.Configure<ApiSettings>(options => Configuration.GetSection("ApiSettings").Bind(options));
            services.Configure<AppSettings>(options => Configuration.GetSection("AppSettings").Bind(options));
            services.Configure<PMApiSettings>(options => Configuration.GetSection("PMApiSettings").Bind(options));
            services.Configure<StorageOptions>(options => Configuration.GetSection("StorageOptions").Bind(options));
            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));


            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            services.Configure<IISOptions>(options =>
            {
                options.AutomaticAuthentication = false;
                options.ForwardClientCertificate = false;
            });

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = "Cookies";
                options.DefaultChallengeScheme = "oidc";
            })
            .AddCookie()
            .AddOpenIdConnect("oidc", options =>
            {
                options.SignInScheme = "Cookies";

                options.Authority = Configuration.GetSection("OpenIdSettings")?.Get<OpenIdSettings>()?.Authority;
                options.RequireHttpsMetadata = false;

                options.ClientId = "fstnr.lbmgmt";
                options.ClientSecret = "secret";

                options.ResponseType = "code id_token";

                options.GetClaimsFromUserInfoEndpoint = true;

                options.SaveTokens = true;
                options.Scope.Clear();
                options.Scope.Add("fstnrlmapi");
                options.Scope.Add("umid");
                options.Scope.Add("offline_access");
                options.Scope.Add("openid");
                options.Scope.Add("profile");

                // Test note

                options.Events = new OpenIdConnectEvents
                {
                    OnUserInformationReceived = UserManagerClaimsTransformer.OnUserInformationReceivedAsync,
                    OnRemoteFailure = RemoteAuthFail
                };

            });

            services.AddScoped<IApiClientService, ApiClientService>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IClaimsTransformation, UserManagerClaimsTransformer>();

            services
                .AddMvc(options =>
                {
                    options.MaxModelValidationErrors = int.MaxValue;
                    options.Filters.Add<ViewBagInitializerActionFilter>();
                })
                //.AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver())
                // .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
                .AddDataAnnotationsLocalization();

            services.AddOptions();
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddHttpClient();
            services.AddScoped<IAuthService, AuthService>();
            services.AddAzureStorageService(Configuration.GetSection("StorageOptions"));
            services.AddDistributedMemoryCache();

            var settings = Configuration.GetSection(nameof(AppSettings)).Get<AppSettings>();
            var expireMinutes = 30;//settings.CookieAuthentication.ExpireMinutes;

            services.AddSession(options =>
            {
                options.Cookie.Name = ".LabelManagement.Session";
                options.IdleTimeout = TimeSpan.FromMinutes(expireMinutes);

                // for session timeout testing set a short timeout
                //options.IdleTimeout = TimeSpan.FromSeconds(60);

                // Make the session cookie essential
                options.Cookie.IsEssential = true;

            });

            if (!Environment.IsDevelopment())
            {
                // require HTTPS for non development Environment
                services.Configure<MvcOptions>(options =>
                {
                    options.Filters.Add(new RequireHttpsAttribute());
                });
            }

            services.AddScoped<IUserSession, UserSession>();

            services.Configure<FormOptions>(x =>
            {
                x.ValueLengthLimit = int.MaxValue;
                x.MultipartBodyLengthLimit = int.MaxValue; // In case of multipart
            });

            services.AddLocalization(l =>
            {
                // we will put our translations in a folder called resources
                l.ResourcesPath = "Resources";
            });

            //services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2).AddSessionStateTempDataProvider();

            services.AddControllersWithViews()
                .AddMvcOptions(options => { options.EnableEndpointRouting = false; options.MaxModelValidationErrors = int.MaxValue; options.SuppressAsyncSuffixInActionNames = false; })
                .AddNewtonsoftJson(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver())
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddRazorPages()
                .AddMvcOptions(options => { options.EnableEndpointRouting = false; options.MaxModelValidationErrors = int.MaxValue; options.SuppressAsyncSuffixInActionNames = false; })
                .AddNewtonsoftJson(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver())
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            // Add Kendo UI services to the services container
            services.AddKendo();

            services.AddSignalR();
            services.AddScoped<INotificationService, NotificationService>();

            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
                builder
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                .WithOrigins("https://localhost:58991");
            }));

            services.Configure<RequestLocalizationOptions>(options =>
            {
                var cultures = new List<CultureInfo> {
                    //new CultureInfo("en-US"),
                    //new CultureInfo("de-DE"),
                    //new CultureInfo("fr-FR"),
                    //new CultureInfo("en-GB")
                    new CultureInfo("en"),
                    new CultureInfo("es")
                };
                options.DefaultRequestCulture = new RequestCulture("en");
                options.SupportedCultures = cultures;
                options.SupportedUICultures = cultures;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            //app.UseCookiePolicy();

            app.UseAuthentication();
            app.UseRefreshAccessToken();

            app.UseSession();

            app.Use(async (context, next) =>
            {
                context.Request.EnableBuffering();
                await next();
            });

            if (!Environment.IsDevelopment())
            {
                // require HTTPS for non development Environment
                var options = new RewriteOptions()
                    .AddRedirectToHttps();
                app.UseRewriter(options);
            }

            //app.UseRequestLocalization(app.ApplicationServices.GetRequiredService<IOptions<RequestLocalizationOptions>>().Value);

            app.UseRouting();
            app.UseAuthorization();
            app.UseCors("CorsPolicy");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<NotificationHub>("/notificationHub/{username}");
                endpoints.MapControllerRoute("default",
                     "{controller=Home}/{action=Index}/{id?}");
            });

            //app.UseSignalR(routes =>
            //{
            //    routes.MapHub<NotificationHub>("/notificationHub?{username}");
            //});
        }

        private Task RemoteAuthFail(RemoteFailureContext context)
        {
            context.Response.Redirect("/Account/SignIn");
            context.HandleResponse();
            return Task.CompletedTask;
        }
    }
}
