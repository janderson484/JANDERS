namespace VM.FleetServices.TnR.LM.Web.Models
{
    public class ReportEditorModel
    {
        public string ReportLog { get; set; }
    }
}
