using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Web.Models
{
    internal class DeleteInvoiceBillingsResult
    {
        public bool HasError { get; set; }
        public string ErrorDescription { get; set; }
        public List<int> VoidedLabelBillingIds { get; set; }

    }
}
