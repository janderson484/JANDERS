using System.Collections.Generic;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.Web.Models
{
    public class InvoiceDetailsResult
    {
        public bool HasError { get; set; }
        public string ErrorDescription { get; set; }
        public List<SelectInvoiceViewModel> InvoiceDetails { get; set; }
    }
}
