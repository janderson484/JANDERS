namespace VM.FleetServices.TnR.LM.Web.Models
{
    public class AppSettings
    {
        public CookieAuthentication CookieAuthentication { get; set; }
        public bool EnableGridFiltering { get; set; }
        public int TextMaxPlateCount { get; set; }
        public int FileMaxPlateCount { get; set; }
        public DownloadSettings DownloadSettings { get; set; }
    }

    public class CookieAuthentication
    {
        /// <summary>
        /// Session expiration in minutes. Default is 30 minutes
        /// </summary>
        public int ExpireMinutes { get; set; } = 30;

        /// <summary>
        /// Display a message box before session expires. Default is 5 minutes.
        /// </summary>
        public int SessionExpireNotificationMinutes { get; set; } = 5;
    }
    public class DownloadSettings
    {
        /// <summary>
        /// Set record limit on Export All functionality.
        /// </summary>
        public int ExportLimit { get; set; }
    }


}
