using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.LM.Web.Models
{
    public class Constant
    {
        public static class ApiRouteConstants
        {
            public static string CommonLookUps() => "api/Tnr/CommonLookUps";
            public static string GetBillingLookUps() => "api/LabelManagement/GetBillingLookUps";
            public static string LabelManagementLookUps() => "api/LabelManagement/GetLabelLookUps";
            public static string GetImportLayouts() => "api/Configuration/GetImportLayouts";
            public static string UpdateImportLayoutStatus() => "api/Configuration/UpdateImportLayoutStatus";
            public static string GetMasterData() => "api/Configuration/GetMasterData";
            public static string GetImportLayout() => "api/Configuration/GetImportLayout";
            public static string SaveLayoutConfig() => "api/Configuration/SaveLayoutConfig";
            public static string GetLabelSortOrder() => "api/Configuration/GetLabelSortOrder";
            public static string GetLabelData() => "api/Configuration/GetLabelData";
            public static string GetSortOrder() => "api/Configuration/GetSortOrder";
            public static string SaveLabelSortOrder() => "api/Configuration/SaveLabelSortOrder";
            public static string UpdateSortOrderStatus() => "api/Configuration/UpdateSortOrderStatus";
            public static string DeleteLabelSortOrder() => "api/Configuration/DeleteLabelSortOrder";
            public static string GetLabels() => "api/LabelManagement/GetLabels";
            public static string GetImportTypes() => "api/Configuration/GetImportTypes";
            public static string GetLabelType() => "api/Configuration/GetLabelType";
            public static string GetAllLabelStatuses() => "api/LabelManagement/GetLabelStatuses";
            public static string UpdateLabels() => "api/LabelManagement/UpdateLabels";
            public static string GetBulkProcessRecordCounts() => "api/LabelManagement/GetBulkProcessRecordCounts";
            public static string PerformBulkProcess() => "api/LabelManagement/PerformBulkProcess";
            public static string ImportLabels() => "api/LabelManagement/ImportLabels";
            public static string GetUserPreference() => "api/Tnr/UserPreferencesByActionCode";
            public static string ValidateLabelsToApplyCredits() => "api/LabelManagement/ValidateLabelsToApplyCredits";
            public static string ApplyCreditsToLabels() => "api/LabelManagement/ApplyCreditsToLabels";
            public static string SaveUserPreference() => "api/Tnr/SaveUserPreference";
            public static string GetNotifications() => "api/LabelManagement/GetNotifications";
            public static string GetPersonalSettingsAndPreferences() => "api/Tnr/PersonalSettingsAndPreferences";
            public static string GetInvoiceIdsForLabels() => "api/LabelManagement/GetInvoiceIdsForLabels";
            public static string GetInvoiceStatusByIds() => "api/LabelManagement/GetInvoiceStatusByIds";
            public static string DeleteInvoiceBillingsByLineItemId() => "api/LabelManagement/DeleteInvoiceBillingsByLineItemId";

            public static string CreateNotifications() => "api/LabelManagement/CreateNotifications";
            public static string GetLabelsLogSummary() => "api/LabelManagement/GetLogs";
            public static string GetLabelsLogDetails() => "api/LabelManagement/GetLogDetails";
            public static string PerformBulkUpdate() => "api/LabelManagement/PerformBulkUpdate";

            public static string SubmitExportAllRequest() => "api/LabelManagement/SubmitExportAllRequest";

            public static string GetLabelPrintData() => "api/Printer/GetLabelPrintData";
            public static string UpdatePrinterLabelSettings() => "api/Printer/UpdatePrinterLabelSettings";
            public static string GetLabelsData() => "api/LabelManagement/GetLabelsData";
            public static string GetLabelsBillingData() => "api/LabelManagement/GetLabelsBillingData";
            public static string PerformBulkInvoice() => "api/LabelManagement/PerformBulkInvoice";
            public static string CreateInvoiceAsync() => "api/Invoice/CreateInvoiceAsync";
            public static string CreateInvoiceBillingsAsync() => "api/Invoice/CreateInvoiceBillingsAsync";
            public static string UpdataLabelBillingAsync() => "api/LabelManagement/UpdataLabelBillingAsync";
            public static string PrintInvoice() => "api/LabelManagement/PrintInvoice";
            public static string PrintLabels() => "api/Printer/PrintLabels";

            //Invoice API's
            public static string GetInvoiceLookUps() => "api/Invoice/GetInvoiceLookUps";
            public static string GetInvoices() => "api/Invoice/GetInvoices";
            public static string GetInvoiceDetails() => "api/Invoice/GetInvoiceDetails";
            public static string GetInvoiceDataToPrint() => "api/Invoice/GetInvoiceDataToPrint";
            public static string AddUpdateBillingFeeAsync() => "api/Tnr/AddUpdateBillingFeeAsync";
            public static string UpdateBillingFeeActiveStatusAsync() => "api/Tnr/UpdateBillingFeeActiveStatusAsync";
            public static string GetBillingFeesAsync() => "api/Tnr/GetBillingFees";
            public static string UpdateInvoiceAsync() => "api/Invoice/UpdateInvoiceAsync";
            public static string SetPersonalSettings() => "api/Configuration/SetPersonalSettings"; 
            public static string GetAllLabelSortOrders() => "api/Configuration/GetAllLabelSortOrders"; 
            public static string GetPersonalSettings() => "api/Configuration/GetPersonalSettings";
            public static string GetLabelPrinterAssignments() => "api/Printer/GetLabelPrinterAssignments";
            public static string AddUpdatePrinterAssignmentSaveAsync() => "api/Printer/AddUpdatePrinterAssignment";
            public static string GetPrinterAssignmentDetailsAsync() => "api/Printer/GetPrinterAssignmentDetails";
            public static string UpdatePrinterAssignmentStatusAsync() => "api/Printer/UpdatePrinterAssignmentStatus";
            public static string GetLabelPrintersAsync() => "api/Printer/GetLabelPrinters";
            public static string GetPrinterDetailsAsync() => "api/Printer/GetPrinterDetails";
            public static string AddUpdatePrinterSaveAsync() => "api/Printer/AddUpdatePrinter";
            public static string UpdatePrinterStatusAsync() => "api/Printer/UpdatePrinterStatus";
            public static string UpdateLabelProcessingOfficeAsync() => "api/LabelManagement/UpdateLabelProcessingOffice";
            public static string CopyLabelsAsync() => "api/LabelManagement/CopyLabelsAsync";
            public static string GetBillingReasonTypeAsync() => "api/LabelManagement/GetBillingReasonType";
            public static string UpdateLogStatusByIdAsync() => "api/LabelManagement/UpdateJobStatusById";
        }

        public static class SessionKeys
        {
            public const string ImportLayouts = "ImportLayouts";
            public const string LabelSortOrder = "LabelSortOrder";
            public const string LabelSearch = "LabelSearch";
            public const string BagLabelSearch = "BagLabelSearch";
            public const string UnitLabelSearch = "UnitLabelSearch";
            public const string LabelManagementCommonLookUps = "LabelManagementCommonLookUps";
            public const string SelectedClientCode = "SelectedClientCode";
            public const string LabelsLogSummarySearch = "LabelsLogSummarySearch";
            public const string LabelsLogDetailsSearch = "LabelsLogDetailsSearch";
            public const string LabelManagementLookUps = "LabelManagementLookUps";

            //public const string UserPreference = "UserPreference";
            public const string UserPreferences = "UserPreferences";
            public const string ClientLocationUserPreferences = "ClientLocationUserPreferences";
            public const string ViewLabelsUserPreferences = "ViewLabelsUserPreferences";
            public const string ViewLabelsBagUserPreferences = "ViewLabelsBagUserPreferences";
            public const string ViewLabelsUnitUserPreferences = "ViewLabelsUnitUserPreferences";
            public const string InvoiceUserPreferences = "InvoiceUserPreferences";
            public const string BillingFeeTypeData = "BillingFeeTypeData";
            public const string BillingFeeData = "BillingFeeData";
            /// <summary>
            /// Holds current PersonalSettings values from db
            /// </summary>
            public const string PersonalSettingsDefaults = "PersonalSettingsDefaults";

            /// <summary>
            /// Holds PersonalSettings for session. Defaults to db values on logout/in.
            /// </summary>
            public const string PersonalSettingsSession = "PersonalSettingsSession";
            public const string ClientLocationPreferenceExists = "ClientLocationPreferenceExists";
            public const string BulkUpdateReport = "BulkUpdateReport";
            public const string SelectedBulkLabels = "SelectedBulkLabels";
            public const string SelectedInventory = "SelectedInventory";

            public const string SelectedRowsPerPage = "SelectedRowsPerPage";

        }

        public static class ProcessingOfficeConstants
        {
            public const string SunshineBradenton = "FL-BRADENTON";
            public const string SunCity = "AZ-SUNCITY";
        }

        public static class LabelTypeConstants
        {
            public const string Bag = "Bag";
            public const string Unit = "Unit";
        }

        public static class RecordCountLimits
        {
            public const int MaxRecordCount = 1000;
            public const int MinRecordCount = 1;
            public const int VinLength = 17;
            public const int VinImportMinLength = 1;
            public const int VinImportMaxLength = 25;
        }

        public static class Delimiters
        {
            public const string NewLine = "\n";
            public const string Tab = "\t";
            public const string Comma = ",";
            public const string Colon = ":";
        }
        public static class LogSearchFilters
        {
            public const string FileName = "FileName";
            public const string LogStatus = "LogStatus";
            public const string ProcessType = "ProcessType";
            public const string ProcessName = "ProcessName";
            public const string ProcessStartDate = "ProcessStartDate";
            public const string ProcessEndDate = "ProcessEndDate";
            public const string ShowErrors = "ShowErrors";
            public const string ShowWarnings = "ShowWarnings";
        }
        
    }
}
