using System.Collections.Generic;

namespace VM.FleetServices.TnR.LM.Web.Models
{
    public class BillingLookupsResult
    {
        public bool HasError { get; set; }
        public string ErrorDescription { get; set; }
        public Dictionary<string, object> BillingLookUps { get; set; }
    }
}
