using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;

namespace VM.FleetServices.TnR.Web.Components.Notifications
{
    public class NotificationsViewComponent : ViewComponent
    {
        private readonly ApiSettings _apiSettings;

        private readonly IApiClientService _apiClient;

        public NotificationsViewComponent(IOptions<ApiSettings> apiSettings, IApiClientService apiClient)
        {
            _apiSettings = apiSettings.Value;
            _apiClient = apiClient;

        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var notifications = await GetNotificationsAsync();
            return View(notifications);
        }

        private async Task<List<NotificationViewModel>> GetNotificationsAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            var clientCode = clientLocationPreference?.ClientCode;
            _apiClient.SetClientCode(clientCode);

            var uri = $"{_apiSettings.Uri}{ApiRouteConstants.GetNotifications()}/{User.Identity.Name}";
            var notifications = await _apiClient.GetResponseAsync<ServiceResponse<List<NotificationViewModel>>>(uri);
            return notifications?.Data ?? new List<NotificationViewModel>();
        }
    }
}
