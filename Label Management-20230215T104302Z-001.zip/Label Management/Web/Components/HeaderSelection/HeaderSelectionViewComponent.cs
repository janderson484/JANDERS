using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.LM.Web.Models;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;
using Client = VM.FleetServices.TnR.LM.Model.DTO.Client;

namespace VM.FleetServices.TnR.Web.Components.ClientSelection
{
    public class HeaderSelectionViewComponent : ViewComponent
    {

        private readonly IApiClientService _apiClient;
        private readonly ApiSettings _apiSettings;
        private readonly PMApiSettings _pmApiSettings;
        private Dictionary<string, object> _lmLookups;

        public HeaderSelectionViewComponent(IOptions<ApiSettings> apiSettings, IOptions<PMApiSettings> pmApiSettings, IApiClientService apiClient)
        {
            _apiClient = apiClient;
            _apiSettings = apiSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
        }

        public async Task<IViewComponentResult> InvokeAsync(string clientCode, string processingLocationCode, string inventoryCode)
        {
            var clientLocationUserPreferences = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);

            var model = new HeaderSelectionViewModel
            {
                HeaderClientCode = clientLocationUserPreferences?.ClientCode,
                HeaderClientCodeList = await GetClientListAsync(),
                HeaderProcessingLocationCode = clientLocationUserPreferences?.ProcessingLocationCode,
                HeaderProcessingLocationCodeList = await GetProcessingLocationListAsync()
            };

            return View(model);
        }

        #region Private Methods

        private async Task<IEnumerable<SelectListItem>> GetClientListAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            _apiClient.SetClientCode(clientLocationPreference?.ClientCode);
            _lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementCommonLookUps);
            if (_lmLookups == null)
            {
                var uri = _pmApiSettings.Uri + ApiRouteConstants.CommonLookUps();
                _lmLookups = await _apiClient.GetResponseAsync<Dictionary<string, object>>(uri);
                HttpContext.Session.Set(SessionKeys.LabelManagementCommonLookUps, _lmLookups);
            }
            return ((JArray)_lmLookups?["Clients"])?.ToObject<List<Client>>().Where(a => a.Active)
                .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ClientCode });
        }

        private async Task<IEnumerable<SelectListItem>> GetProcessingLocationListAsync()
        {
            var clientLocationPreference = HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(SessionKeys.ClientLocationUserPreferences);
            _apiClient.SetClientCode(clientLocationPreference?.ClientCode);
            _lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementCommonLookUps);
            if (_lmLookups == null)
            {
                var uri = _pmApiSettings.Uri + ApiRouteConstants.CommonLookUps();
                _lmLookups = await _apiClient.GetResponseAsync<Dictionary<string, object>>(uri);
                HttpContext.Session.Set(SessionKeys.LabelManagementCommonLookUps, _lmLookups);
            }
            return ((JArray)_lmLookups?["ProcessingLocations"])?.ToObject<List<ProcessingLocation>>().Where(a => a.Active)
                .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ProcessingLocationCode });
        }
        #endregion
    }
}
