using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.ApplicationInsights.Extensibility.Implementation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using static VM.FleetServices.TnR.LM.Web.Models.Constant;

namespace VM.FleetServices.TnR.Web.Components.CustomerList
{
    public class CustomerListViewComponent : ViewComponent
    {
        private readonly IApiClientService _apiClient;
        private readonly ApiSettings _apiSettings;
        private readonly ILogger _logger;
        private readonly PMApiSettings _pmApiSettings;

        public CustomerListViewComponent(IOptions<ApiSettings> apiSettings, IApiClientService apiClient,
             ILogger<CustomerListViewComponent> logger, IOptions<PMApiSettings> pmApiSettings)
        {
            _apiClient = apiClient;
            _apiSettings = apiSettings.Value;
            _pmApiSettings = pmApiSettings.Value;
            _logger = logger;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            try
            {
                var userPreference = HttpContext.Session.Get<UserPreference>(SessionKeys.UserPreferences);
                var clientLocationJsonString = userPreference?.ActionPreference;
                var clientLocationDetails = string.IsNullOrEmpty(clientLocationJsonString) ? null : JsonConvert.DeserializeObject<ClientLocationUserPreferencesViewModel>(clientLocationJsonString);
                if (clientLocationDetails != null)
                {
                    HttpContext.Session.Set(SessionKeys.ClientLocationUserPreferences, clientLocationDetails);
                }
                _apiClient.SetClientCode(clientLocationDetails?.ClientCode);
                var lmLookups = HttpContext.Session.Get<Dictionary<string, object>>(SessionKeys.LabelManagementCommonLookUps);
                if (lmLookups == null)
                {
                var uri = _pmApiSettings.Uri + ApiRouteConstants.CommonLookUps();
                    lmLookups = await _apiClient.GetResponseAsync<Dictionary<string, object>>(uri);
                    HttpContext.Session.Set(SessionKeys.LabelManagementCommonLookUps, lmLookups);
                }
                var clientsList = lmLookups != null ? ((JArray)lmLookups["Clients"]).ToObject<List<Client>>().Where(a => a.Active == true)
                    .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ClientCode }) : null;
                var processingLocationList = lmLookups != null ? ((JArray)lmLookups["ProcessingLocations"]).ToObject<List<ProcessingLocation>>().Where(a => a.Active == true)
                    .Select(a => new SelectListItem { Text = a.DisplayName, Value = a.ProcessingLocationCode }) : null;
                var model = new CustomerListViewModel
                {
                    ClientCode = clientLocationDetails?.ClientCode,
                    ProcessingLocation = clientLocationDetails?.ProcessingLocationCode,
                    ClientCodeList = clientsList,
                    ProcessingLocationList = processingLocationList
                };
                return View(model);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Method: {nameof(InvokeAsync)} - {ex.Message}");
                return null;
            }
        }
    }
}
