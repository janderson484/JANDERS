using System;
using System.Linq;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Web.Models;

namespace VM.FleetServices.TnR.LM.Web.ActionFilters
{
    /// <summary>
    /// Verifies if the user has personal settings established by checking the session state.
    /// Personal settings are checked at the start of the application.
    /// A session object is set if the user has the settings setup already or when the user saves or updates settings
    /// </summary>
    public class VerifyPersonalSettingsActionFilter : ActionFilterAttribute
    { 
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var result = context.HttpContext.Session.Get<PersonalSetting>(Constant.SessionKeys.PersonalSettingsSession);
            if (result == null)
            {
                context.Result = new RedirectToRouteResult(
                    new RouteValueDictionary
                    {
                        { "controller", "Configuration" },
                        { "action", "PersonalSettings" }
                    });
            }
        }
    }
}
