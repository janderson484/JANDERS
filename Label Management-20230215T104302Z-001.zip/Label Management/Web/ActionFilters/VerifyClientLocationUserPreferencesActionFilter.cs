using System;
using System.Linq;
using System.Reflection.Metadata;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using VM.FleetServices.TnR.Model.ViewModel;
using Constant = VM.FleetServices.TnR.LM.Web.Models.Constant;

namespace VM.FleetServices.TnR.LM.Web.ActionFilters
{
    /// <summary>
    /// Verifies if the user has client location user preferences established by checking the session state.
    /// Client location user preferences are checked at the start of the application.
    /// A session object is set if the user has client location user preferences setup already or when the user saves or updates settings
    /// </summary>
    public class VerifyClientLocationUserPreferencesActionFilter : ActionFilterAttribute
    { 
        public override void OnActionExecuting(ActionExecutingContext context)
        {

            var result = context.HttpContext.Session.Get<ClientLocationUserPreferencesViewModel>(Constant.SessionKeys.ClientLocationUserPreferences);
            if (result == null)
            {
                context.Result = new RedirectToRouteResult(
                    new RouteValueDictionary
                    {
                        { "controller", "Home" },
                        { "action", "Index" }
                    });
            }
        }
    }
}
