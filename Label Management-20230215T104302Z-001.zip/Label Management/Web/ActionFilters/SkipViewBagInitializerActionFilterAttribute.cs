using System;

namespace VM.FleetServices.TnR.LM.Web.ActionFilters
{
    public class SkipViewBagInitializerActionFilterAttribute : Attribute
    {
    }
}
