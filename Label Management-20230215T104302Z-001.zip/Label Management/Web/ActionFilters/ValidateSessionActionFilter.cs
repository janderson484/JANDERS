using System;
using System.Linq;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace VM.FleetServices.TnR.LM.Web.ActionFilters
{
    public class ValidateSessionActionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var actionDescriptor = (ControllerActionDescriptor)context.ActionDescriptor;
            var isExpired = false;

            var info = context.HttpContext.AuthenticateAsync("Cookies").Result;
            var tokens = info?.Properties?.GetTokens()?.ToList();
            var accessToken = tokens
                    ?.FirstOrDefault(x => x.Name.Equals(OpenIdConnectParameterNames.AccessToken))
                    ?.Value;

            if (accessToken == null)
            {
                isExpired = true;
            }
            else
            {
                // process access token
                var now = DateTimeOffset.UtcNow;

                var expirationDateStr = tokens.FirstOrDefault(x => x.Name.Equals("expires_at"))?.Value;
                var expirationDate = DateTimeOffset.Parse(expirationDateStr);

                var expiresIn = expirationDate - now;

                if (expiresIn.TotalSeconds <= 0)
                {
                    isExpired = true;
                }
            }

            if ((!context.HttpContext.User.Identity.IsAuthenticated && actionDescriptor.ActionName != "SignIn"))
            {
                context.HttpContext.Session.Clear();
                context.Result = new RedirectToRouteResult(
                    new RouteValueDictionary
                    {
                        { "controller", "Account" },
                        { "action", "SignIn" }
                    });
            }
            else if (isExpired)
            {
                context.Result = new RedirectToRouteResult(
                    new RouteValueDictionary
                    {
                        { "controller", "Account" },
                        { "action", "SignOut" }
                    });
            }
        }
    }
}
