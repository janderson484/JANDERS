
function setClientLocationKendoWindowPosition(kendoWindowRef, topY) {
    // Calculate position of kendo window
    // The kendo window must have a fixed width and height to start with
    var x = 0;
    var y = 0;
    var pointX = 0;
    var pointY = 0;

    // Get browser Window width and height
    x = $(window).width();
    y = $(window).height();

    // Determine coordinates and set window position
    pointX = (x - kendoWindowRef.wrapper.width()) / 2;
    pointY = (y - kendoWindowRef.wrapper.height()) / 2;
    kendoWindowRef.setOptions({ position: { top: 0, left: 0 } });
    kendoWindowRef.setOptions({ position: { top: pointY - topY, left: pointX } });
}

function onClickSelectClientLocation(windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the select button after selecting client location on the grid

    if (getSelectedClientLocationCount() === 0) {
        // None seleected!
        $.notify("Client Location Selection Error!\r\nPlease select a Client Location to continue", "error");
        return;
    }
    else if (getSelectedClientLocationCount() > 1) {
        $.notify("Client Location Selection Error\r\nPlease select only one Client Location to continue", "error");
        return;
    }

    //Get the selected plates (if any)
    var clientLocationsList = getSelectedClientLocations();

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setClientLocationKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Client Location...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: clientLocationsList
    });
    // Open the window
    theKendoWindow.open();
}

function onClickAddClientLocation(windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setClientLocationKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: {}
    });
    // Open the window
    theKendoWindow.open();
}

function onClickEditorLink(windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the editor link to show report content
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);

    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setClientLocationKendoWindowPosition(theKendoWindow, 50);
    theKendoWindow.content("Loading Editor Data...");
    theKendoWindow.refresh({
        url: contentUrl
    });

    theKendoWindow.open();
}

function filterFieldValues() {
    // Used by the ClientLocationContent Partial View
    // Called from the dropdown list control
    return {
        fieldId: $("#fields").val()
    };
}

function getSelectedClientLocations() {
    // Gets the selected client location
    var grid = $("#ClientLocations").data("kendoGrid");
    var selectedElement = grid.dataItem(grid.select());

    var data = selectedElement ? selectedElement.toJSON() : {};
    return data;
}

function getSelectedClientLocationCount() {
    // Gets the selected client locations count
    var grid = $("#ClientLocations").data("kendoGrid");
    var selectedElements = grid.select();
    return selectedElements.length;
}

function getUserLocalDateTime() {
    var d = new Date();
    var localDateTime = d.toLocaleDateString() + " " + d.toLocaleTimeString();
    return localDateTime;
}
