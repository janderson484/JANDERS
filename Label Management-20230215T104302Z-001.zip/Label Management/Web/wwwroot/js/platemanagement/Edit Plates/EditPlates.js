
function setKendoWindowPosition(kendoWindowRef, topY) {
    // Calculate position of kendo window
    // The kendo window must have a fixed width and height to start with
    var x = 0;
    var y = 0;
    var pointX = 0;
    var pointY = 0;

    // Get browser Window width and height
    x = $(window).width();
    y = $(window).height();

    // Determine coordinates and set window position
    pointX = (x - kendoWindowRef.wrapper.width()) / 2;
    pointY = (y - kendoWindowRef.wrapper.height()) / 2;
    kendoWindowRef.setOptions({ position: { top: 0, left: 0 } });
    kendoWindowRef.setOptions({ position: { top: pointY - topY, left: pointX } });
}

function onClickItem(plateId, state, plateNumber, windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the dmvQuery link, holds or errors count badges for a plate in the grid

    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);

    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);
    theKendoWindow.content("Loading Plate Data...");
    theKendoWindow.refresh({
        url: contentUrl,
        data: { plateId: plateId, state: state, plateNumber: plateNumber }
    });

    theKendoWindow.open();
}

function onClickBulkUpdate(windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the bulk update option/button after selecting plates to bulk update

    if (getSelectedPlateCount() === 0) {
        // None selected!
        $.notify("Bulk Update Error\r\nPlease select plates for bulk update action", "error");
        return;
    }

    //Get the selected plates (if any)
    var platesList = getSelectedPlates();

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading Plate Data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: platesList
    });
    // Open the window
    theKendoWindow.open();
}

function onResponsePopupModal(windowName, contentUrl, content, response, title) {
    
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content(content);
    theKendoWindow.title(title);
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: response
    });
    // Open the window
    theKendoWindow.open();
}


function onPlateManualAssignment(windowName, contentUrl, plateData) {
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: { "plateReservation": plateData }
    });
    // Open the window
    theKendoWindow.open();
}

function onClickEditorLink(windowName, contentUrl) {
    //Load the kendoWindow and position it, then open the window,
    //based on clicking the editor link to show report content
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);

    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);
    theKendoWindow.content("Loading Editor Data...");
    theKendoWindow.refresh({
        url: contentUrl
    });

    theKendoWindow.open();
}

function filterFieldValues() {
    // Used by the BulkUpdateWindowContent Partial View
    // Called from the dropdown list control
    return {
        fieldId: $("#fields").val()
    };
}

function getSelectedPlates() {
    // Gets the selected plates
    var items = {};
    var grid = $("#ViewPlates").data("kendoGrid");
    var selectedElements = grid.select();

    for (var j = 0; j < selectedElements.length; j++) {
        var item = grid.dataItem(selectedElements[j]);
        var x = item.PlateId;
        //items['plates[' + j + '].PlateId'] = item.PlateId;
        items['plates[' + j + ']'] = x;
    }

    return items;
}

function getSelectedPlateCount() {
    // Gets the selected plates count
    var grid = $("#ViewPlates").data("kendoGrid");
    var selectedElements = grid.select();
    return selectedElements.length;
}

function SelectBulkErrorPlates() {
    // Selects all bulk error plates in the grid on ViewPlates grid only
    var bulkErrorplateIds = $("#BulkUpdateErrorPlates").val();

    if (bulkErrorplateIds !== "") {
        var grid = $("#ViewPlates").getKendoGrid();
        var arr = JSON.parse(bulkErrorplateIds);

        for (var i = 0; i < arr.length; i++) {
            var item = arr[i];
            var dataItem = grid.dataSource.get(item);
            var row = grid.tbody.find("tr[data-uid='" + dataItem.uid + "']");
            grid.select(row);
        }

        // Clear the hidden plates after selection in grid
        $("#BulkUpdateErrorPlates").val("");
    }
}

function onBulkUpdateFieldsChange(e) {
    var dataItem = this.dataItem();
    var fieldDescription = dataItem.FieldDescription;
    var fieldId = dataItem.FieldId;
    var dropdownlist = $("#fieldValues").data("kendoDropDownList");
    if (fieldDescription === "Plate Comment" && fieldId === 4) {
        dropdownlist.wrapper.hide();
        $("#Comment").show().focus();
    } else {
        $("#Comment").hide();
        dropdownlist.wrapper.show().focus();
    }
}

function getUserLocalDateTime() {
    var d = new Date();
    var localDateTime = d.toLocaleDateString() + " " + d.toLocaleTimeString();
    return localDateTime;
}
