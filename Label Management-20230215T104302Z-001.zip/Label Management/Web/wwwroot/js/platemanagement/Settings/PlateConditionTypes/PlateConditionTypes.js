function getSelectedPlateConditionTypeCount() {
    var grid = $("#PlateConditionTypes").data("kendoGrid");
    var selectedElements = grid.select();
    return selectedElements.length;
}

function getSelectedPlateConditionType() {
    var grid = $("#PlateConditionTypes").data("kendoGrid");
    var selectedPlateConditionType = grid.dataItem(grid.select());
    var data = selectedPlateConditionType ? selectedPlateConditionType.toJSON() : {};
    return data;
}

function onClickAddEditPlateConditionType(windowName, contentUrl, buttonType) {
    //Load the kendoWindow and position it, then open the window,
    //Based on clicking the plate type select/new button 
    var selectedPlateConditionType;
    
    if (buttonType === "EDIT") {
        if (getSelectedPlateConditionTypeCount() === 0) {
            // None selected!
            $.notify("Plate Condition Type Selection Error\r\nPlease select a plate condition type to edit", "error");
            return;
        }

        //Get the selected plate type
        selectedPlateConditionType = getSelectedPlateConditionType();
    }
    
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading plate condition type data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: selectedPlateConditionType
    });
    // Open the window
    theKendoWindow.open();
}
