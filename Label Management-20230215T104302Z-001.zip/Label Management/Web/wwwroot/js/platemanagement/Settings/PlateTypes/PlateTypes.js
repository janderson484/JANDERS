function getSelectedPlateTypeCount() {
    // Gets the selected plate type count
    var grid = $("#PlateTypes").data("kendoGrid");
    var selectedElements = grid.select();
    return selectedElements.length;
}

function getSelectedPlateType() {
    // Gets the selected plate type
    var grid = $("#PlateTypes").data("kendoGrid");
    var selectedPlateType = grid.dataItem(grid.select());
    var data = selectedPlateType ? selectedPlateType.toJSON() : {};
    return data;
}

function onClickPlateTypeButton(windowName, contentUrl, buttonType) {
    //Load the kendoWindow and position it, then open the window,
    //Based on clicking the plate type select/new button 
    var selectedPlateType;

    if (buttonType === "SELECT") {
        if (getSelectedPlateTypeCount() === 0) {
            // None seleected!
            $.notify("Plate Type Selection Error\r\nPlease select a plate type to edit", "error");
            return;
        }
        //Get the selected plate type
        selectedPlateType = getSelectedPlateType();
    }
    
    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading plate type data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: selectedPlateType
    });
    // Open the window
    theKendoWindow.open();
}
