
function getSelectedPlateMatchingItemCount(gridName) {
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(gridName);
    var grid = $(jqIdentifier).data("kendoGrid");
    var selectedElements = grid.select();
    return selectedElements.length;
}

function getSelectedPlateMatchingItem(gridName) {
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(gridName);
    var grid = $(jqIdentifier).data("kendoGrid");
    var selectedField = grid.dataItem(grid.select());
    var data = selectedField ? selectedField.toJSON() : {};
    return data;
}

function getMaxFieldOrderValue() {
    var maxOrder = 1;
    var grid = $("#grdPlateMatchingFields").data('kendoGrid');
    if (grid.dataItems().filter(x => x.Active).length == 0) { return maxOrder; }
    for (var i = 0; i < grid.dataItems().length; i++) {
        if (grid.dataItems()[i].FieldOrder > maxOrder)
            maxOrder = grid.dataItems()[i].FieldOrder;
    }
    return parseInt(maxOrder + 1);
}

function onClickAddEditPlateMatchingConfiguration(windowName, contentUrl, buttonType, grid, configType) {
    //Load the kendoWindow and position it, then open the window,
    //Based on clicking the plate type select/new button 
    var selectedPlateMatchingItem;
    var kendoTitle = "Add " + configType;
    if (buttonType === "EDIT") {
        kendoTitle = "Edit " + configType;
        if (getSelectedPlateMatchingItemCount(grid) === 0) {
            // None selected!
            $.notify("Plate Matching Error\r\nPlease select a plate matching " + configType + " to edit", "error");
            return;
        }

        //Get the selected plate type
        selectedPlateMatchingItem = getSelectedPlateMatchingItem(grid);
    }

    //Load the kendoWindow and position it, then open the window
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(windowName);
    //var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    var theKendoWindow = $(jqIdentifier).kendoWindow({
        width: 500,
        title: kendoTitle,
        height: 420
    }).data("kendoWindow");
    setKendoWindowPosition(theKendoWindow, 50);

    // Load the window content
    theKendoWindow.content("Loading plate matching configuration data...");
    theKendoWindow.refresh({
        type: "POST",
        url: contentUrl,
        data: selectedPlateMatchingItem
    });
    // Open the window
    theKendoWindow.open();

    if (buttonType === "EDIT") {
        setTimeout(function () {
            if (windowName == "plateMatchingFields") {
                $("#plateMatchingFieldId").data("kendoDropDownList").readonly();
            } else {
                $("#plateMatchingRuleId").data("kendoDropDownList").readonly();
            }
        }, 2000);
    }
    if (buttonType === "NEW") {
        setTimeout(function () {
            $("#plateMatching_Active").prop('checked', true);
            $("#plateMatchingRule_Active").prop('checked', true);
            if (windowName == "plateMatchingFields") {
                var maxFieldOrder = getMaxFieldOrderValue();
                $("#plateMatching_FieldOrder").val(maxFieldOrder);
            }
        }, 2000);
    }
}

function closeWindow(window) {
    var jqHash = "#";
    var jqIdentifier = jqHash.concat(window);
    var theKendoWindow = $(jqIdentifier).data("kendoWindow");
    theKendoWindow.close();
}


