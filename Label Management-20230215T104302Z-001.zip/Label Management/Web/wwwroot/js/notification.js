$(function() {

    $.ajax({
        type: "GET",
        url: "/Home/GetConfigurationValue"
    }).done(function(data) {

        var connection = new signalR.HubConnectionBuilder().withUrl(data.configurationValue + "notificationHub?username=" + data.userId).build();

        connection.on("ReceiveNotifications",
            function(notification) {
                var response = JSON.parse(notification);
                //var testNotification = '{ "notificationId": 123,  "logId": 1234, "notificationType": "Export", "totalRecordsCount": 0, "successfulRecordsCount": 0,  "warningRecordsCount": 0, "erroredRecordsCount": 0,  "message": "Test",  "isRead": false,  "userName": MPINNINTI,  "createdBy": mpinninti,  "createdDate": "2020-01-01T00:00:00",  "lastRefreshDate": "2020-01-01",  "logStatus": "Success"}';
                //var response = $.parseJSON(notification);
                var isValidUser = IsValidUserForNotification(response.UserName, response.NotificationType);
                if (isValidUser) {
                    try {
                        if (window.location.href.includes('BulkProcessing')) {
                            bulkProcessDone();
                        }
                    } catch (err) {
                        console.error(err.toString());
                    };

                    if (response.LogStatus == "Failed") {
                        $.notify(response.NotificationType + " is failed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "error");
                    }
                    else {
                        if (response.ErrorCount > 0) {
                            $.notify(response.NotificationType + " is completed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "error");
                        }
                        else if (response.WarningCount > 0) {
                            $.notify(response.NotificationType + " is completed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "warning");
                        }
                        else {
                            $.notify(response.NotificationType + " is completed\r\n Total: " + response.TotalCount + "\t Success: " + response.SuccessCount + "\r\n Warning: " + response.WarningCount + "\t Errors: " + response.ErrorCount, "success");
                        }
                    }

                    if (response.NotificationType == "Export Labels" && response.Message != "" && response.Message != null) {
                        if (response.Message.indexOf('csv') > 0) {
                            ExportCSV(response.Message);
                        }
                    }

                    if (response.NotificationType == "Print Invoice" && response.Message != "" && response.Message != null) {
                        if (response.Message.indexOf('csv') > 0) {
                            ExportCSV(response.Message);
                        }
                        else {
                            onClickAttachment(response.Message);
                        }    
                    }

                    //Refreshes the notifications dropdown
                    var notificationsContainer = $('#Logs');
                    notificationsContainer.load("/Home/GetNotificationViewComponentAsync");
                }
            });

        connection.start().then(function() {
            console.log("connected");
        }).catch(function(err) {
            console.error(err.toString());
        });

    });
});



function errorHandler(e, gridName) {

    if (e.errors) {

        // Default error message
        var message = "An error occured during the request. \r\n Please retry.";

        if (e.errors.length > 0 ) {
            message = "";
            e.errors.forEach(function(error)
            {
                message += error + "</br>";
            });
        }
        
        var kendoWindow = $('#ErrorDialog').data("kendoDialog");
        kendoWindow.content(message);
        kendoWindow.open();

        // To stop the spinner
        //$(".k-loading-image").hide();

        var grid = $(gridName).data("kendoGrid");
        kendo.ui.progress(grid.element, false);
        var grid = $("#grdViewRegisterReserve").data("kendoGrid");
        grid.cancelChanges();
    }
};

function IsValidUserForNotification(user, notificationType) {
    var isSuccess = false;
    $.ajax({
        type: "POST",
        url: "/Reports/ValidUserToDownload",
        dataType: "json",
        async: false,
        data: { userName: user, processType: notificationType },
        success: function (response) {
            isSuccess = response.isValid;
        },
        error: function () {
            isSuccess = false;
        }
    });
    return isSuccess;
}
