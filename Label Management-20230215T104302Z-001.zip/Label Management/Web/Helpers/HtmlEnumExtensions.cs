using System;
using System.Linq;
using System.Reflection;
using System.Text;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Newtonsoft.Json;
using VM.FleetServices.TnR.LM.Model;

namespace VM.FleetServices.TnR.LM.Web.Helpers
{
    public static class HtmlExtensions
    {
        public static HtmlString EnumToString<T>(this HtmlHelper helper)
        {
            return new HtmlString(EnumToString<T>());
        }

        private static string EnumToString<T>()
        {
            return EnumToString(typeof(T));
        }

        private static string EnumToString(Type enumType)
        {
            var values = Enum.GetValues(enumType).Cast<int>();
            var enumDictionary = values.ToDictionary(value => Enum.GetName(enumType, value));

            return JsonConvert.SerializeObject(enumDictionary);
        }

        public static HtmlString JavaScriptEnums(this HtmlHelper helper)
        {
            var query = from a in AppDomain.CurrentDomain.GetAssemblies()
                from t in a.GetTypes()
                from r in t.GetCustomAttributes<JavaScriptEnumAttribute>()
                where t.BaseType == typeof(Enum)
                select t;

            var buffer = new StringBuilder(10000);

            foreach (var jsEnum in query)
            {
                buffer.Append("var ");
                buffer.Append(jsEnum.Name);
                buffer.Append(" = ");
                buffer.Append(EnumToString(jsEnum));
                buffer.Append("; \r\n");
            }

            return new HtmlString(buffer.ToString());
        }
    }

}
