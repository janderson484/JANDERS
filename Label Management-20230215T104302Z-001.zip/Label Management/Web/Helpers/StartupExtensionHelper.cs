using System.Linq;
using System.Security.Claims;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Identity;
using VM.FleetServices.TnR.LM.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;

namespace VM.FleetServices.TnR.LM.Web.Helpers
{
    public static class StartupExtensionHelper
    {
        public static IServiceCollection AddAzureStorageService(this IServiceCollection services, IConfigurationSection configSection)
        {
            IOptions<StorageOptions> options = Options.Create(new StorageOptions
            {
                StorageConnection = configSection["StorageConnection"],
                BlobContainer = configSection["BlobContainer"]
            });

            services.AddSingleton<IBlobStorage>(provider => new CloudBlobStorage(options));

            return services;
        }

    
    }
}
