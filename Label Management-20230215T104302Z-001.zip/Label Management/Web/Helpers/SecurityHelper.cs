using System.Linq;
using System.Security.Claims;
using VM.FleetServices.TnR.Core.Common.Identity;

namespace VM.FleetServices.TnR.LM.Web.Helpers
{
    public static class SecurityHelper
    {
        public static bool IsLMReadOnlyUser(this ClaimsPrincipal user)
        {
            return !IsLMReadWriteUser(user);
        }

        public static bool IsLMReadWriteUser(this ClaimsPrincipal user)
        {
            return IsLMInternalUser(user) || IsTnrSupervisorUser(user) || IsTnrAdminUser(user);
        }

        public static bool IsTnrInvoiceUser(this ClaimsPrincipal user)
        {
            return IsTnrSupervisorUser(user) || IsTnrAdminUser(user);
        }

        public static bool IsTnrAdminUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == "/ats/usermanager/rights").Select(a => a.Value).Any(a => new[] { "LABELMANAGEMENT-ADMIN" }.Any(a.Contains));
        }
        public static bool IsLMExternalUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == "/ats/usermanager/rights").Select(a => a.Value).Any(a => new[] { "LABELMANAGEMENT-EXTERNAL" }.Any(a.Contains));
        }

        public static bool IsTnrSupervisorUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == "/ats/usermanager/rights").Select(a => a.Value).Any(a => new[] { "LABELMANAGEMENT-SUPERVISOR" }.Any(a.Contains));
        }

        public static bool IsLMInternalUser(this ClaimsPrincipal user)
        {
            return user.Claims.Where(a => a.Type == "/ats/usermanager/rights").Select(a => a.Value).Any(a => new[] { "LABELMANAGEMENT-INTERNAL" }.Any(a.Contains));
        }

        public static string GetSelectedClient(this ClaimsPrincipal user, string selectedClientCode)
        {
            if (!string.IsNullOrEmpty(selectedClientCode))
                return selectedClientCode;

            var clients = user.GetClientList().Select(a => a.Code).ToList();

            if (clients == null || clients.Count == 0)
                return null;

            return clients[0];
        }
    }
}
