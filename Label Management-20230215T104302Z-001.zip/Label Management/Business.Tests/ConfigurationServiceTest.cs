using System;
using System.Collections.Generic;
using AutoFixture.Xunit2;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Business.Tests;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Mapping;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Xunit;

[assembly: CollectionBehavior(MaxParallelThreads = 10)]
namespace Business.Tests
{
    public class ConfigurationServiceTest : IClassFixture<ConfigureTestDataFixture>
    {
        private readonly LabelModel _labelContext;
        private readonly ConfigureTestDataFixture _fixture;
        private readonly ConfigurationService _inMemoryLabelService;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILogger<ConfigurationService> _logger;
        private readonly Mock<IMapper> _mockMapper;

        public ConfigurationServiceTest(ConfigureTestDataFixture fixture)
        {
            _fixture = fixture;
            _labelContext = _fixture.InMemoryLabelContext;
            _unitOfWorkService = new UnitOfWorkService<LabelModel>(_labelContext);
            _logger = new Logger<ConfigurationService>(new LoggerFactory());
            _mockMapper = new Mock<IMapper>();
            var serviceProvider = new ServiceCollection().AddLogging().BuildServiceProvider();
            _inMemoryLabelService = new ConfigurationService(_unitOfWorkService, serviceProvider.GetService<ILoggerFactory>()
                .CreateLogger<ConfigurationService>(), _mockMapper.Object);
        }

        [Fact]
        public async void ConfigurationServiceTest_GetImportLayoutsAsync_ImportLayoutsReturnedAsync()
        {
            var personalSetting = new UserProfileSettingsViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                DmvStateCode = StateProvinces.Florida.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                SelectedRowsPerPage = 5
            };
            var labelImports = CreateImportLayout();
            var model = new ImportLayoutConfigurationViewModel()
            {
                ImportLayouts = new List<ImportLayoutViewModel> {
                    labelImports
                },
                TotalCount = 4
            };
            labelImports.LabelImportId = 1;
            var existingImportLayout = await _inMemoryLabelService.GetImportLayoutsAsync(personalSetting);
            Assert.Equal(model.PageNumber, existingImportLayout.PageNumber);
        }

        [Fact]
        public async void ConfigurationServiceTest_UpdateImportLayoutStatusAsync_UpdateImportLayoutAsync()
        {
            var existingImportLayout = CreateImportLayout();
            var isUpdated = await _inMemoryLabelService.UpdateImportLayoutStatusAsync(existingImportLayout);
            Assert.True(isUpdated == true);
        }

        [Fact]
        public async void ConfigurationServiceTest_UpdateImportLayoutStatusAsync_UpdateImportLayoutFailAsync()
        {
            ImportLayoutViewModel existingImportLayout = new ImportLayoutViewModel
            {
                LabelImportId = 100
            };
            var isUpdated = await _inMemoryLabelService.UpdateImportLayoutStatusAsync(existingImportLayout);
            Assert.True(isUpdated == false);
        }

        [Fact]
        public async void ConfigurationServiceTest_GetImportLayoutAsync_ReturnImportLayoutAsync()
        {
            var existingImportLayout = CreateImportLayout();
            var labelImport = await _inMemoryLabelService.GetImportLayoutAsync(existingImportLayout.LabelImportId);
            Assert.Equal(labelImport.LabelImportId, existingImportLayout.LabelImportId);
        }

        [Fact]
        public async void ConfigurationServiceTest_GetImportLayoutAsync_NotReturnImportLayoutAsync()
        {
            ImportLayoutViewModel existingImportLayout = new ImportLayoutViewModel
            {
                LabelImportId = 100
            };
            var labelImport = await _inMemoryLabelService.GetImportLayoutAsync(existingImportLayout.LabelImportId);
            Assert.Null(labelImport);
        }

        [Fact]
        public async void ConfigurationServiceTest_SaveLayoutConfigAsync_SaveNewImportConfigAsync()
        {
            var importLayout = CreateImportLayout();
            importLayout.LabelImportId = 0;
            var isAdded = await _inMemoryLabelService.SaveLayoutConfigAsync(importLayout);
            Assert.True(isAdded = true);
        }

        [Fact]
        public async void ConfigurationServiceTest_SaveLayoutConfigAsync_UpdateImportConfigAsync()
        {
            var importLayout = CreateImportLayout();
            var isUpdated = await _inMemoryLabelService.SaveLayoutConfigAsync(importLayout);
            Assert.True(isUpdated = true);
        }

        [Fact]
        public async void ConfigurationServiceTest_SaveLayoutConfigAsync_UpdateImportConfigReturnFalseAsync()
        {
            ImportLayoutViewModel importLayout = new ImportLayoutViewModel
            {
                LabelImportId = 100
            };
            var isUpdated = await _inMemoryLabelService.SaveLayoutConfigAsync(importLayout);
            Assert.False(isUpdated = false);
        }

        [Fact]
        public async void ConfigurationServiceTest_GetMasterDataAsync_ReturnDataAsync()
        {
            var masterDatas = CreateMasterDatas();
            var data = await _inMemoryLabelService.GetMasterDataAsync();
            Assert.Equal(masterDatas.Item1[0].LabelImportFieldId, data.Item1[0].LabelImportFieldId);
        }

        /// <summary>
        /// Creates the test import layout.
        /// </summary>
        /// <returns></returns>
        private ImportLayoutViewModel CreateImportLayout()
        {
            var model = new ImportLayoutViewModel()
            {
                SelectedClientCodeList = new List<string>() { "HERTZ", "EHI" },
                SelectedProcessingLocationCodeList = new List<string>() { ProcessingLocations.FlSunshineBradenton.ToString() }
            };
            var labelImport = new LabelImport()
            {
                Active = true,
                // ClientCode = ClientCodes.Hertz.GetDescription(),
                StateProvinceCode = StateProvinces.Florida.GetDescription(),
                //ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                CreatedUser = "TestUser",
                CreatedDate = DateTime.Today,
                LabelTypeId = 0,
                LabelType = string.Empty,
            };
            _unitOfWorkService.Context.LabelImports.Add(labelImport);
            _unitOfWorkService.SaveChanges();

            _unitOfWorkService.Context.Entry(labelImport).State = EntityState.Detached;
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });
            var mapper = config.CreateMapper();

            return mapper.Map<VM.FleetServices.TnR.LM.Model.ViewModel.ImportLayoutViewModel>(labelImport);
        }

        /// <summary>
        /// Creates the test master datas.
        /// </summary>
        /// <returns></returns>
        private Tuple<List<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>, List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>> CreateMasterDatas()
        {
            var labelImportFields = new List<LabelImportField>()
            {
                new LabelImportField{
                LabelImportFieldId = 1,
                Active = true,
                CreatedUser = "TestUser",
                CreatedDate = DateTime.Today,
                ModifiedUser = "TestUser",
                ModifiedDate = DateTime.Today
                }
            };
            var labelTypes = new List<LabelType>()
            {
                new LabelType{
                LabelTypeId = 1,
                DisplayName = "Type1",
                Active = true,
                CreatedUser = "TestUser",
                CreatedDate = DateTime.Today,
                ModifiedUser = "TestUser",
                ModifiedDate = DateTime.Today
                }
            };
            _unitOfWorkService.Context.LabelImportFields.AddRange(labelImportFields);
            _unitOfWorkService.Context.LabelTypes.AddRange(labelTypes);
            _unitOfWorkService.SaveChanges();
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });
            var mapper = config.CreateMapper();
            var labelImportField = mapper.Map<List<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>>(labelImportFields);
            var labelType = mapper.Map<List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>>(labelTypes);
            return new Tuple<List<VM.FleetServices.TnR.LM.Model.DTO.LabelImportField>, List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>>(labelImportField, labelType);
        }


        [Fact]
        private void ConfigurationServiceTest_SaveLabelSortOrderAsync_ReturnDataAsync()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.LabelType> labelOrders = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>();
            VM.FleetServices.TnR.LM.Model.DTO.LabelType label = new VM.FleetServices.TnR.LM.Model.DTO.LabelType();
            label.DisplayName = "VIN";
            labelOrders.Add(label);
            var labelSortOrder = new LabelSortOrderViewModel()
            {
                Active = true,
                SelectedClientCodeList = new List<string>() { "HERTZ", "EHI" },
                SelectedProcessingLocationCodeList = new List<string>() { ProcessingLocations.FlSunshineBradenton.ToString() },
                LabelSortOrderId = 0,
                Description = "Print Test Orders",
                LabelFieldOrders = labelOrders
            };
            var res = _inMemoryLabelService.SaveLabelSortOrderAsync(labelSortOrder);

            Assert.True(res.Result == true);
        }

        [Fact]
        private void ConfigurationServiceTest_UpdateLabelSortOrderAsync_ReturnDataAsync()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.LabelType> labelOrders = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>();
            VM.FleetServices.TnR.LM.Model.DTO.LabelType label = new VM.FleetServices.TnR.LM.Model.DTO.LabelType();
            label.DisplayName = "VIN";
            labelOrders.Add(label);
            var labelSortOrder = new LabelSortOrderViewModel()
            {
                Active = true,
                SelectedClientCodeList = new List<string>() { "HERTZ" },
                SelectedProcessingLocationCodeList = new List<string>() { ProcessingLocations.FlSunshineBradenton.ToString() },
                LabelSortOrderId = 16,
                Description = "Print Test Orders",
                LabelFieldOrders = labelOrders
            };
            var res = _inMemoryLabelService.SaveLabelSortOrderAsync(labelSortOrder);

            Assert.True(res.Result == true);
        }

        [Fact]
        private void ConfigurationServiceTest_DeleteSortOrderAsync_ReturnDataAsync()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.LabelType> labelOrders = new List<VM.FleetServices.TnR.LM.Model.DTO.LabelType>();

            int LabelSortOrderId = 17;

            var res = _inMemoryLabelService.DeleteSortOrderAsync(LabelSortOrderId);

            Assert.True(res.Result == true);
        }

        [Fact]
        public async void ConfigurationServiceTest_GetLabelSortOrderAsync_LabelSortOrderReturnedAsync()
        {
            var personalSetting = new UserProfileSettingsViewModel()
            {
                SelectedRowsPerPage = 16
            };
            var res = await _inMemoryLabelService.GetLabelSortOrderAsync(personalSetting);
            Assert.NotNull(res.LabelSortOrders);
        }

        #region AddLabels Import ConfigurationTests

        [Fact]
        public async void ConfigurationServiceTest_GetImportConfigurationAsync_ImportLayoutDescriptionReturnedAsync()
        {
            var importId = 1;
            var labelImports = CreateImportLayout();
            var labelImportId = labelImports.LabelImportId;
            var existingImportLayout = await _inMemoryLabelService.GetImportLayoutAsync(importId);
            Assert.Equal(labelImportId, existingImportLayout.LabelImportId);
        }

        #endregion

        [Fact]
        public async void ConfigurationServiceTest_GetPersonalSettingsAsync_PersonalSettingReturnedAsync()
        {
            string userId = "TestUser";
            string clientCode = "HERTZ";
            string processingCode = ProcessingLocations.FlSunshineBradenton.ToString();
            var res = await _inMemoryLabelService.GetPersonalSettingsAsync(userId, clientCode, processingCode);
            Assert.Equal(res.RowsPerPage, (int)RowsPerPage.TwentyFive);
        }

        [Fact]
        public async void ConfigurationServiceTest_SetPersonalSettingsAsync_PersonalSettingReturnedAsync()
        {
            var model = new PersonalSettingsViewModel()
            {
                UserId = "TestUser",
                ClientCode = "HERTZ",
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.ToString(),
                LabelSortOrderId = 17,
            };
            var res = await _inMemoryLabelService.SetPersonalSettingsAsync(model);
            Assert.True(res);
        }
    }
}

