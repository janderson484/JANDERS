using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Business.Tests;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations;
using VM.FleetServices.TnR.LM.Business.Integrations.PrinterService;
using VM.FleetServices.TnR.LM.Business.ServiceBus;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Xunit;
using PrinterLabelSetting = VM.FleetServices.TnR.LM.Model.DTO.PrinterLabelSetting;
using PrintLabelRequest = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrintLabelRequest;
using Label = VM.FleetServices.TnR.LM.Data.LabelModel.Entities.Label;
using VM.FleetServices.TnR.LM.Business.Mapping;

namespace Business.Tests
{
    public class PrinterServiceTest : IClassFixture<ConfigureTestDataFixture>
    {
        private readonly LabelModel _labelContext;
        private readonly PrinterService _inMemoryPrinterService;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly Mock<IServiceBusService> _mockServiceBusService;
        private readonly IOptions<ApiSettings> _apiSettings;
        private readonly IOptions<PMApiSettings> _pmApiSettings;
        private readonly Mock<IAuthService> _authService;
        private readonly ServiceProvider _serviceProvider;
        private readonly Mock<IServiceScopeFactory> _serviceScopeFactory;
        private readonly Mock<IMapper> _mockMapper;
        private readonly int _unitLabelTypeId = 1;
        private readonly int _bagLabelTypeId = 2;

        public PrinterServiceTest(ConfigureTestDataFixture fixture)
        {
            _labelContext = fixture.InMemoryLabelContext;

            _serviceProvider = new ServiceCollection().AddLogging().BuildServiceProvider();

            var sProvider = new Mock<IServiceProvider>();
            sProvider.Setup(x => x.GetService(typeof(ILabelModel))).Returns(_labelContext);

            _unitOfWorkService = new UnitOfWorkService<LabelModel>(_labelContext);
            var logger = new Logger<LabelManagementService>(new LoggerFactory());

            var serviceScope = new Mock<IServiceScope>();
            serviceScope.Setup(x => x.ServiceProvider).Returns(sProvider.Object);

            _mockMapper = new Mock<IMapper>();
            _serviceScopeFactory = new Mock<IServiceScopeFactory>();
            _serviceScopeFactory.Setup(x => x.CreateScope()).Returns(serviceScope.Object);

            _apiSettings = Options.Create(new ApiSettings()
            {
                PrintServiceUri = "https://localhost:5002/",
                PrintApiBatchCount =  25
            });

            _pmApiSettings = Options.Create(new PMApiSettings()
            {
                Uri = "https://localhost:5002/"
            });

            _mockServiceBusService = new Mock<IServiceBusService>();
            _authService = new Mock<IAuthService>();

            #region HttpClientFactory Mock

            // Setup http client factory mock
            var mockHttpClientFactory = new Mock<IHttpClientFactory>();

            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                // Content can be anything
                Content = new StringContent(JsonConvert.SerializeObject(
                          new PrintResponseModel { LabelTypeId = _bagLabelTypeId, HasError = false, ErrorDescription = string.Empty }))
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            var httpClient = new HttpClient(handlerMock.Object);
            mockHttpClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(httpClient);

            #endregion

            _inMemoryPrinterService = new PrinterService(_unitOfWorkService, _serviceProvider.GetService<ILoggerFactory>()
                .CreateLogger<PrinterService>(), _serviceScopeFactory.Object,
                _authService.Object, mockHttpClientFactory.Object, _apiSettings, _pmApiSettings, _mockMapper.Object);
        }

        #region Print Preview

        [Fact(DisplayName = "PrinterServiceTest_PrinterServiceTest_TestAsync")]
        public async void PrinterServiceTest_PrinterServiceTest_TestAsync()
        {
            var testUserName = "testuser";
            var testLabelTypeId = 1;
            var clientCode = "HERTZ";
            var processingLocationCode = ProcessingLocations.FlSunshineBradenton.ToString();

            var userPrinters = await _inMemoryPrinterService.GetUserConfiguredPrintersAsync(testUserName, testLabelTypeId,clientCode,processingLocationCode);

            Assert.Equal(0, userPrinters.Printers.Count);
        }

        [Fact(DisplayName = "PrinterServiceTest_GetPrinterLabelSettingsAsync_TestAsync")]
        public async void PrinterServiceTest_GetPrinterLabelSettingsAsync_TestAsync()
        {
            var printerIds = new List<int>();
            printerIds.Add(1);
            var testLabelTypeId = 1;

            var printerLabelSettings = await _inMemoryPrinterService.GetPrinterLabelSettingsAsync(printerIds, testLabelTypeId);
            Assert.Empty(printerLabelSettings);
        }

        [Fact(DisplayName = "PrinterServiceTest_UpdatePrinterLabelSettingsAsync_TestAsync")]
        public async void PrinterServiceTest_UpdatePrinterLabelSettingsAsync_TestAsync()
        {
            var printerLabelSettingEntity = new VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrinterLabelSetting()
            {
                PrinterLabelSettingId = 50
            };

            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });

            var mapper = config.CreateMapper();

            var printerLabelSettingDto = mapper.Map<PrinterLabelSetting>(printerLabelSettingEntity);

            await _unitOfWorkService.Context.PrinterLabelSettings.AddAsync(printerLabelSettingEntity);
            _unitOfWorkService.SaveChanges();

            // To avoid an exception; set state to detached
            // The instance of entity type 'PrinterLabelSetting' cannot be tracked because another instance with the same key value
            // for {'PrinterLabelSettingId'} is already being tracked.
            _unitOfWorkService.Context.Entry(printerLabelSettingEntity).State = EntityState.Detached;

            var updatedPrinterLabelSettings = await _inMemoryPrinterService.UpdatePrinterLabelSettingsAsync(printerLabelSettingDto);
            Assert.NotNull(updatedPrinterLabelSettings);
            Assert.Equal(printerLabelSettingDto.PrinterLabelSettingId, updatedPrinterLabelSettings.PrinterLabelSettingId);
        }

        #endregion

        #region Print bag labels

        // PrintDocument throws error when printLabelRequestId is out of range
        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_Returns_ErrorResponse_When_ArgumentOutOfRangeException")]
        public async void PrinterServiceTest_PrintDocumentAsync_Returns_ErrorResponse_When_ArgumentOutOfRangeException_Async()
        {
            var printResponseModel = await _inMemoryPrinterService.PrintDocumentAsync(0,true,false);

            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError);
            Assert.Contains("OUT OF THE RANGE OF VALID VALUES", printResponseModel.ErrorDescription.ToUpper());
        }

        // PrintDocument throws error when a print labels request record was not found
        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_Returns_ErrorResponse_When_PrintLabelRequestRecord_NotFound")]
        public async void PrinterServiceTest_PrintDocumentAsync_Returns_ErrorResponse_When_PrintLabelRequestRecord_NotFound_Async()
        {
            var printResponseModel = await _inMemoryPrinterService.PrintDocumentAsync(1,true,false);
            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError);
            Assert.Contains("A PRINT LABELS REQUEST WAS NOT FOUND FOR PRINTLABELREQUESTID:1", printResponseModel.ErrorDescription.ToUpper());
        }

        // PrintDocument returns expected success response when api response is successful
        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_BagLabel_Returns_SuccessResponse_Async")]
        public async void PrinterServiceTest_PrintDocumentAsync_BagLabel_Returns_SuccessResponse_Async()
        {
            // Setup a print request record
            #region Setup PrintRequestRecord

            var labelId = 6608;
            var labelPrintRequestId = 998;

            var messageDictionary = new PrintLabelMessageRequest();

            messageDictionary.Data.Add("ClientCode", ClientCodes.Hertz.GetDescription());
            messageDictionary.Data.Add("UserName", "FSAMSTESTUSER");
            messageDictionary.Action.Add("ActionCode", "Print Labels");
            messageDictionary.Action.Add("LogId", "12239");
            //messageDictionary.LabelId = labelId;
            messageDictionary.LabelType = _bagLabelTypeId;
            messageDictionary.SelectedPrinterLabelSettingId = 1;
            messageDictionary.SelectedPrinterId = 1;

            var msgText = JsonConvert.SerializeObject(messageDictionary);

            await _labelContext.PrintLabelRequests.AddAsync(new PrintLabelRequest()
            {
                PrintLabelRequestId = labelPrintRequestId,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                Request = msgText,
                PrinterId = 1
            });

            await _labelContext.PrinterLabelSettings.AddAsync(new VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrinterLabelSetting()
            {
                PrinterLabelSettingId = 1,
                PrinterId = 1,
                LabelTypeId = _unitLabelTypeId,
                HorizontalMargin = 0,
                VerticalMargin = 0
            });

            await _labelContext.SaveChangesAsync();

            #endregion

            // Setup label data
            #region Setup Label Data

            await _labelContext.Labels.AddAsync(new Label()
            {
                LabelId = labelId,
                LabelTypeId = _bagLabelTypeId,
                VIN = "3FCMF53G7NJA02954",
                DeliveryCode = "2194",
                Model = "Nissan"
            });
            await _labelContext.SaveChangesAsync();

            #endregion

            // Act
            var printResponseModel = await _inMemoryPrinterService.PrintDocumentAsync(labelPrintRequestId,true,false);

            // Assert
            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError == false);
            Assert.Empty(printResponseModel.ErrorDescription);
            Assert.Equal(_bagLabelTypeId, printResponseModel.LabelTypeId);
        }

        // PrintDocument deletes the print labels request record 
        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_Deletes_PrintLabelsRequest")]
        public async void PrinterServiceTest_PrintDocumentAsync_Deletes_PrintLabelsRequest_Async()
        {
            // Setup a print request record
            #region Setup PrintRequestRecord

            var labelId = 6609;
            var printLabelRequestId = 999;

            var messageDictionary = new PrintLabelMessageRequest();

            messageDictionary.Data.Add("ClientCode", ClientCodes.Hertz.GetDescription());
            messageDictionary.Data.Add("UserName", "FSAMSTESTUSER");
            messageDictionary.Action.Add("ActionCode", "Print Labels");
            messageDictionary.Action.Add("LogId", "12239");
            //messageDictionary.LabelId = labelId;
            messageDictionary.LabelType = _bagLabelTypeId;
            messageDictionary.SelectedPrinterLabelSettingId = 2;
            messageDictionary.SelectedPrinterId = 1;

            var msgText = JsonConvert.SerializeObject(messageDictionary);

            await _labelContext.PrintLabelRequests.AddAsync(new PrintLabelRequest()
            {
                PrintLabelRequestId = printLabelRequestId,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                Request = msgText,
                PrinterId = 1
            });

            await _labelContext.PrinterLabelSettings.AddAsync(new VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrinterLabelSetting()
            {
                PrinterLabelSettingId = 2,
                PrinterId = 1,
                LabelTypeId = _unitLabelTypeId,
                HorizontalMargin = 0,
                VerticalMargin = 0
            });

            await _labelContext.SaveChangesAsync();

            #endregion

            // Setup label data
            #region Setup Label Data

            await _labelContext.Labels.AddAsync(new Label()
            {
                LabelId = labelId,
                LabelTypeId = _bagLabelTypeId,
                VIN = "3FCMF53G7NJA02954",
                DeliveryCode = "2194",
                Model = "Nissan"
            });
            await _labelContext.SaveChangesAsync();

            #endregion

            // Act
            var printResponseModel = await _inMemoryPrinterService.PrintDocumentAsync(printLabelRequestId,true,false);

            // Assert
            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError == false);
            Assert.Empty(printResponseModel.ErrorDescription);
            Assert.Equal(_bagLabelTypeId, printResponseModel.LabelTypeId);

            // Assert deletion of print labels request record
            var printLabelRequestEntity = _labelContext.PrintLabelRequests.FirstOrDefault(lr => lr.PrintLabelRequestId == printLabelRequestId);
            Assert.Null(printLabelRequestEntity);
        }

        // PrintDocument returns expected error response when when api response is not successful
        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_Returns_ErrorResponse_When_ApiResponseNotSuccessful")]
        public async void PrinterServiceTest_PrintDocumentAsync_Returns_ErrorResponse_When_ApiResponseNotSuccessful_Async()
        {
            // Setup custom Api Response and PrinterService Mocks
            #region HttpClientFactory and PrinterService Mock

            // Setup http client factory mock

            var mockMapper = new Mock<IMapper>();
            var mockHttpClientFactory = new Mock<IHttpClientFactory>();

            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.InternalServerError,
                // Content can be anything
                Content = new StringContent(JsonConvert.SerializeObject(
                    new PrintResponseModel { LabelTypeId = _bagLabelTypeId, HasError = true, ErrorDescription = "An unexpected error occurred for request" })),
                ReasonPhrase = "An unexpected error occurred for request"
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            var httpClient = new HttpClient(handlerMock.Object);
            mockHttpClientFactory.Setup(_ => _.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var inMemoryPrinterService = new PrinterService(_unitOfWorkService, _serviceProvider.GetService<ILoggerFactory>()
                    .CreateLogger<PrinterService>(), _serviceScopeFactory.Object, 
                _authService.Object, mockHttpClientFactory.Object, _apiSettings, _pmApiSettings, mockMapper.Object);

            #endregion

            // Setup a print request record
            #region Setup PrintRequestRecord

            var labelId = 6615;
            var labelPrintRequestId = 1010;

            var messageDictionary = new PrintLabelMessageRequest();

            messageDictionary.Data.Add("ClientCode", ClientCodes.Hertz.GetDescription());
            messageDictionary.Data.Add("UserName", "FSAMSTESTUSER");
            messageDictionary.Action.Add("ActionCode", "Print Labels");
            messageDictionary.Action.Add("LogId", "12239");
            //messageDictionary.LabelId = labelId;
            messageDictionary.LabelType = _bagLabelTypeId;
            messageDictionary.SelectedPrinterLabelSettingId = 3;
            messageDictionary.SelectedPrinterId = 1;

            var msgText = JsonConvert.SerializeObject(messageDictionary);

            await _labelContext.PrintLabelRequests.AddAsync(new PrintLabelRequest()
            {
                PrintLabelRequestId = labelPrintRequestId,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                Request = msgText,
                PrinterId = 1
            });

            await _labelContext.PrinterLabelSettings.AddAsync(new VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrinterLabelSetting()
            {
                PrinterLabelSettingId = 3,
                PrinterId = 1,
                LabelTypeId = _unitLabelTypeId,
                HorizontalMargin = 0,
                VerticalMargin = 0
            });

            await _labelContext.SaveChangesAsync();

            #endregion

            // Setup label data
            #region Setup Label Data

            await _labelContext.Labels.AddAsync(new Label()
            {
                LabelId = labelId,
                LabelTypeId = _bagLabelTypeId,
                VIN = "3FCMF53G7NJA02954",
                DeliveryCode = "2194",
                Model = "Nissan"
            });
            await _labelContext.SaveChangesAsync();

            #endregion

            var printResponseModel = await inMemoryPrinterService.PrintDocumentAsync(labelPrintRequestId,true,false);

            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError);
            Assert.Contains($"RESPONSE ERROR CODE WAS RECEIVED: {response.StatusCode.GetDescription().ToUpper()}", printResponseModel.ErrorDescription.ToUpper());
            Assert.Contains($"REASON: {response.ReasonPhrase.ToUpper()}", printResponseModel.ErrorDescription.ToUpper());
        }

        #endregion

        #region Print Unit Labels

        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_UnitLabel_Returns_ErrorResponse_When_LabelSettingsNotFound_Async")]
        public async void PrinterServiceTest_PrintDocumentAsync_UnitLabel_Returns_ErrorResponse_When_LabelSettingsNotFound_Async()
        {
            // Setup a print request record
            #region Setup PrintRequestRecord

            var labelId = 6622;
            var labelPrintRequestId = 333;

            var messageDictionary = new PrintLabelMessageRequest();

            messageDictionary.Data.Add("ClientCode", ClientCodes.Hertz.GetDescription());
            messageDictionary.Data.Add("UserName", "FSAMSTESTUSER");
            messageDictionary.Action.Add("ActionCode", "Print Labels");
            messageDictionary.Action.Add("LogId", "12239");
            //messageDictionary.LabelId = labelId;
            messageDictionary.LabelType = _unitLabelTypeId;
            messageDictionary.SelectedPrinterLabelSettingId = 4;
            messageDictionary.SelectedPrinterId = 1;

            var msgText = JsonConvert.SerializeObject(messageDictionary);

            await _labelContext.PrintLabelRequests.AddAsync(new PrintLabelRequest()
            {
                PrintLabelRequestId = labelPrintRequestId,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                Request = msgText,
                PrinterId = 1
            });

            await _labelContext.SaveChangesAsync();

            #endregion

            // Setup label data
            #region Setup Label Data

            await _labelContext.Labels.AddAsync(new Label()
            {
                LabelId = labelId,
                LabelTypeId = _unitLabelTypeId,
                VIN = "3FCMF53G7NJA02954",
                DeliveryCode = "2194",
                Model = "Nissan"
            });
            await _labelContext.SaveChangesAsync();

            #endregion

            // Act
            var printResponseModel = await _inMemoryPrinterService.PrintDocumentAsync(labelPrintRequestId,true,false);

            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError);
            Assert.Contains("PRINT LABELS SETTINGS WERE NOT FOUND FOR PRINTERLABELSETTINGID:4", printResponseModel.ErrorDescription.ToUpper());
        }


        [Fact(DisplayName = "PrinterServiceTest_PrintDocumentAsync_UnitLabel_Returns_SuccessResponse_Async")]
        public async void PrinterServiceTest_PrintDocumentAsync_UnitLabel_Returns_SuccessResponse_Async()
        {
            // Setup a print request record
            #region Setup PrintRequestRecord

            var labelId = 6623;
            var labelPrintRequestId = 334;

            var messageDictionary = new PrintLabelMessageRequest();

            messageDictionary.Data.Add("ClientCode", ClientCodes.Hertz.GetDescription());
            messageDictionary.Data.Add("UserName", "FSAMSTESTUSER");
            messageDictionary.Action.Add("ActionCode", "Print Labels");
            messageDictionary.Action.Add("LogId", "12239");
            //messageDictionary.LabelId = labelId;
            messageDictionary.LabelType = _unitLabelTypeId;
            messageDictionary.SelectedPrinterLabelSettingId = 5;
            messageDictionary.SelectedPrinterId = 1;

            var msgText = JsonConvert.SerializeObject(messageDictionary);

            await _labelContext.PrintLabelRequests.AddAsync(new PrintLabelRequest()
            {
                PrintLabelRequestId = labelPrintRequestId,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                Request = msgText,
                PrinterId = 1
            });

            await _labelContext.PrinterLabelSettings.AddAsync(new VM.FleetServices.TnR.LM.Data.LabelModel.Entities.PrinterLabelSetting()
            {
                PrinterLabelSettingId = 5,
                PrinterId = 1,
                LabelTypeId = _unitLabelTypeId,
                HorizontalMargin = 0,
                VerticalMargin = 0
            });

            await _labelContext.SaveChangesAsync();

            #endregion

            // Setup label data
            #region Setup Label Data

            await _labelContext.Labels.AddAsync(new Label()
            {
                LabelId = labelId,
                LabelTypeId = _unitLabelTypeId,
                VIN = "3FCMF53G7NJA02954",
                DeliveryCode = "2194",
                Model = "Nissan"
            });
            await _labelContext.SaveChangesAsync();

            #endregion

            // Act
            var printResponseModel = await _inMemoryPrinterService.PrintDocumentAsync(labelPrintRequestId,true,false);

            // Assert
            Assert.NotNull(printResponseModel);
            Assert.True(printResponseModel.HasError == false);
            Assert.Empty(printResponseModel.ErrorDescription);
        }

        #endregion

        #region Printer Configuration

        [Fact(DisplayName = "PrinterServiceTest_GetPrinterAssignmentDetailsAsync_TestAsync")]
        public async void PrinterServiceTest_GetPrinterAssignmentDetailsAsync_TestAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterUserId = 1;
            model.ClientCode = "HERTZ";

            var result = await _inMemoryPrinterService.GetPrinterAssignmentDetailsAsync(model);

            Assert.NotNull(result);
        }

        [Fact(DisplayName = "PrinterServiceTest_AddUpdatePrinterAssignmentSaveAsync_TestAsync")]
        public async void PrinterServiceTest_AddUpdatePrinterAssignmentSaveAsync_TestAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterId = 1;
            model.DisplayName = "Printer 9";
            model.UserName = "FSAMSTESTUSER";
            model.ClientCode = "HERTZ";

            var result = await _inMemoryPrinterService.AddUpdatePrinterAssignmentSaveAsync(model);

            Assert.True(result);
        }

        [Fact(DisplayName = "PrinterServiceTest_GetPrinterDetailsAsync_TestAsync")]
        public async void PrinterServiceTest_GetPrinterDetailsAsync_TestAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterId = 1;
            model.ClientCode = "HERTZ";

            var result = await _inMemoryPrinterService.GetPrinterDetailsAsync(model);

            Assert.NotNull(result);
        }

        [Fact(DisplayName = "PrinterServiceTest_AddUpdatePrinterSaveAsync_TestAsync")]
        public async void PrinterServiceTest_AddUpdatePrinterSaveAsync_TestAsync()
        {
            var model = new PrinterAssignViewModel();
            model.PrinterId = 1;
            model.DisplayName = "Printer 1";
            model.UserName = "FSAMSTESTUSER";
            model.ClientCode = "HERTZ";
            model.IPAddress = "192.168.11.30";
            model.PortNumber = "23";

            var result = await _inMemoryPrinterService.AddUpdatePrinterSaveAsync(model);

            Assert.True(result);
        }

        #endregion
    }
}
