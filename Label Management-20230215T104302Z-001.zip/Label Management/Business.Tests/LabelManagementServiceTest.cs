using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoFixture.Xunit2;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.Business.Tests;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService;
using VM.FleetServices.TnR.LM.Business.Mapping;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Xunit;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;

namespace Business.Tests
{
    public class LabelManagementServiceTest : IClassFixture<ConfigureTestDataFixture>
    {
        private readonly LabelModel _labelContext;
        private readonly ConfigureTestDataFixture _fixture;
        private readonly LabelManagementService _inMemoryLabelService;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILogger<LabelManagementService> _logger;
        private readonly Mock<IInvoiceService> _mockInvoiceService;
        private readonly Mock<IMapper> _mockMapper;
        //private readonly BulkDbContext _bulkDbContext;

        public LabelManagementServiceTest(ConfigureTestDataFixture fixture)
        {
            _fixture = fixture;
            _labelContext = _fixture.InMemoryLabelContext;
            _unitOfWorkService = new UnitOfWorkService<LabelModel>(_labelContext);
            _logger = new Logger<LabelManagementService>(new LoggerFactory());
            _mockInvoiceService = new Mock<IInvoiceService>();
            _mockMapper = new Mock<IMapper>();
            var serviceProvider = new ServiceCollection().AddLogging().BuildServiceProvider();
            _inMemoryLabelService = new LabelManagementService(_unitOfWorkService, serviceProvider.GetService<ILoggerFactory>()
                .CreateLogger<LabelManagementService>(), _mockInvoiceService.Object, _mockMapper.Object);
        }
        #region Get Labels

        [Fact]
        public async void LabelManagementServiceTest_GetLabelLookUpsAsync_ReturnsExpectedResult_Async()
        {
            // Arrange

            var labelStatusType = new LabelStatusType()
            {
                LabelStatusTypeId = 1,
                DisplayName = "Pending",
                Active = true,
                CreatedDate = DateTime.Now,
                CreatedUser = "TestUser",
                ModifiedDate = DateTime.Now,
                ModifiedUser = "TestUser"
            };
            var labelType = new LabelType()
            {
                LabelTypeId = 1,
                DisplayName = "Unit",
                Active = true,
                CreatedDate = DateTime.Now,
                CreatedUser = "TestUser",
                ModifiedDate = DateTime.Now,
                ModifiedUser = "TestUser"
            };

            await _unitOfWorkService.Context.LabelStatusTypes.AddAsync(labelStatusType);
            await _unitOfWorkService.Context.LabelTypes.AddAsync(labelType);
            _unitOfWorkService.SaveChanges();

            // Act
            IDictionary<string, object> returnedLookupsResult = await _inMemoryLabelService.GetLabelLookUpsAsync();

            // Assert

            Assert.NotNull(returnedLookupsResult);
            Assert.Contains("LabelStatusTypes", returnedLookupsResult);
            Assert.Contains("LabelTypes", returnedLookupsResult);
        }

        /// <summary>
        /// Creates the test labels.
        /// </summary>
        /// <returns></returns>
        private LabelViewModel CreateLabel(ClientCodes clientCode, ProcessingLocations processingLocation, LabelStatusTypes labelStatusType, Labeltypes labelType, string vin = null, int labelId = 1)
        {
            var label = new Label()
            {
                LabelId = labelId,
                LabelStatusTypeId = (int)labelStatusType,
                LabelTypeId = (int)labelType,
                VIN = vin ?? "TESTVIN",
                ClientCode = clientCode.GetDescription(),
                ProcessingLocationCode = processingLocation.GetDescription(),
                CreatedUser = "TESTUSER"
            };
            _unitOfWorkService.Context.Labels.Add(label);
            _unitOfWorkService.SaveChanges();

            _unitOfWorkService.Context.Entry(label).State = EntityState.Detached;

            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });

            var mapper = config.CreateMapper();
            return mapper.Map<LabelViewModel>(label);
        }

        [Fact]
        public async void LabelManagementServiceTest_GetLabelDataAsync_ReturnsExpectedResult_Async()
        {
            // Arrange
            var label = new List<Label>
            {
                new Label
                {
                    LabelId = 1,
                    LabelTypeId = 2
                }
            };

            await _unitOfWorkService.Context.Labels.AddRangeAsync(label);
            _unitOfWorkService.SaveChanges();

            // Act
            var labelIds = new List<int>
            {
                1
            };
            var labelDto = await _inMemoryLabelService.GetLabelDataAsync(labelIds);

            // Assert
            Assert.NotNull(labelDto);
        }


        [Fact]
        public async void LabelManagementServiceTest_GetLabelBillingDataAsync_ReturnsExpectedResult_Async()
        {
            // Arrange
            var labelBilling = CreateLabelBilling();
            var labelBillings = new List<DTO.LabelBilling>();
            labelBillings.Add(labelBilling);
            // Act
            var labelIds = new List<int>
            {
                1
            };
            var labelBillingDto = await _inMemoryLabelService.GetLabelBillingDataAsync(labelIds);

            // Assert
            Assert.NotNull(labelBillingDto);
        }

        [Fact]
        public async void LabelManagementServiceTest_UpdateLabelBillingAsync_ReturnsExpectedResult_Async()
        {
            // Arrange
            var labelBilling = CreateLabelBilling();
            var labelBillings = new List<DTO.LabelBilling>();
            labelBillings.Add(labelBilling);
            // Act
            var labelBillingIds = new List<int>
            {
                1
            };
            var result = await _inMemoryLabelService.UpdateLabelBillingAsync(labelBillingIds, 1);

            // Assert
            Assert.True(result);
        }


        [Fact]
        public async void LabelManagementServiceTest_BulkInvoiceProcessAsync_ReturnsExpectedResult_Async()
        {
            // Arrange
            var labels = new List<DTO.Label>();
            var label = new DTO.Label()
            {
                LabelId = 1,
                LabelStatusTypeId = 2
            };
            labels.Add(label);
            var result = await _inMemoryLabelService.BulkInvoiceProcessAsync(labels, "HERTZ", "TestUser");

            // Assert
            Assert.Equal(HttpStatusCode.OK, result.ResponseCode);
        }

        /// <summary>
        /// Creates the test labels.
        /// </summary>
        /// <returns></returns>
        private DTO.LabelBilling CreateLabelBilling()
        {
            var labelBilling = new LabelBilling()
            {
                LabelBillingId = 1,
                LabelId = 1,
                BillingAmount = 1,
                IsDebit = true,
                Void = false,
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };
            _unitOfWorkService.Context.LabelBillings.Add(labelBilling);
            _unitOfWorkService.SaveChanges();

            _unitOfWorkService.Context.Entry(labelBilling).State = EntityState.Detached;
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });
            var mapper = config.CreateMapper();
            return mapper.Map<VM.FleetServices.TnR.LM.Model.DTO.LabelBilling>(labelBilling);
        }


        #endregion

        #region BulkProcessing

        [Fact(DisplayName = "LabelManagementServiceTest_GetBulkProcessingCountTask_Valid_ModelReturned")]
        public async void LabelManagementServiceTest_GetBulkProcessingCountTask_Valid_ModelReturnedAsync()
        {
            var clientCode = ClientCodes.Hertz.ToString();
            var processingLocation = ProcessingLocations.FlSunshineBradenton.ToString();

            var model = await _inMemoryLabelService.GetBulkProcessRecordCountTaskAsync(clientCode, processingLocation);

            Assert.True(model.PendingNonActiveUnitLabelCount >= 0);
            Assert.True(model.PendingNonActiveBagLabelCount >= 0);
        }

        [Fact(DisplayName = "LabelManagementServiceTest_GetPendingNonActiveLabelsForBulkProcessAsync_Valid_ResultsReturned")]
        public async void LabelManagementServiceTest_GetPendingNonActiveLabelsForBulkProcessAsync_Valid_ResultsReturnedAsync()
        {
            var clientCode = ClientCodes.Hertz.ToString();
            var processingLocation = ProcessingLocations.FlSunshineBradenton.ToString();

            var unitLabelResults = await _inMemoryLabelService.GetPendingNonActiveLabelsForBulkProcessAsync(clientCode, processingLocation, (int)Labeltypes.Unit);

            Assert.True(unitLabelResults.Count >= 0);

            var bagLabelResults = await _inMemoryLabelService.GetPendingNonActiveLabelsForBulkProcessAsync(clientCode, processingLocation, (int)Labeltypes.Bag);

            Assert.True(bagLabelResults.Count >= 0);
        }

        #endregion

        #region AddLabels ImportTests

        [Fact(DisplayName = "LabelManagementControllerTest_ImportLabelsAsync_TestAsync")]
        public async Task<LabelImportViewModel> LabelManagementControllerTest_ImportLabelsAsync_TestAsync()
        {
            var importOrderList = new List<string>() { "VIN", "Unit", "Batch_Number" };
            var importLabelData = new List<Dictionary<string, string>>();
            var labelDataDictionary = new Dictionary<string, string>();

            var model = new LabelImportViewModel()
            {
                ClientCode = "HERTZ",
                LogId = 1,
                RequestNumber = 1,
                LabelImportId = 45,
                ImportConfigurationDescription = "HERTZ SUNCITY UNIT",
                LabelTypeId = 1,
                ProcessingOffice = ProcessingLocations.FlSunshineBradenton.ToString(),
                ImportOrderList = importOrderList,
                GenerateBagLabels = true,
                LabelData = "5NPEU46F96H147412	FL-23422	AutoTag637437953833305453\n",
                CreatedUser = "TESTUSER",
                CreatedDate = DateTime.Now,
                ModifiedUser = "TESTUSER",
                ModifiedDate = DateTime.Now
            };

            for (int i = 0; i < importOrderList.Count; i++)
            {
                for (int x = i; x < model.LabelData.Split("\t").Length; x++)
                {
                    if (x == i)
                    {
                        labelDataDictionary.Add(importOrderList[i], model.LabelData.Split("\t")[x]);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            importLabelData.Add(labelDataDictionary);

            foreach (var row in importLabelData)
            {
                await _unitOfWorkService.GetRepositoryAsync<ImportLabelRequest>().AddAsync(new ImportLabelRequest()
                {
                    RequestNumber = model.RequestNumber,
                    LogId = model.LogId,
                    LabelTypeId = model.LabelTypeId,
                    ClientCode = model.ClientCode,
                    ProcessingOffice = model.ProcessingOffice,
                    LabelImportId = model.LabelImportId,
                    ImportConfigurationDescription = model.ImportConfigurationDescription,
                    ImportLabelRecord = JsonConvert.SerializeObject(row),
                    GenerateBagFlag = model.GenerateBagLabels,
                    Active = true,
                    CreatedUser = model.CreatedUser,
                    CreatedDate = model.CreatedDate,
                    ModifiedUser = model.ModifiedUser,
                    ModifiedDate = model.ModifiedDate
                });
            }
            _unitOfWorkService.SaveChanges();

            return model;
        }


        [Fact(DisplayName = "LabelManagementControllerTest_GetImportLabelsAsync_TestAsync")]
        public async Task LabelManagementControllerTest_GetImportLabelsAsync_TestAsync()
        {
            var importOrderList = new List<string>() { "VIN", "Unit", "Batch_Number" };
            var importLabelData = new List<Dictionary<string, string>>();
            var labelDataDictionary = new Dictionary<string, string>();

            var model = new LabelImportViewModel()
            {
                ClientCode = "HERTZ",
                LogId = 1,
                RequestNumber = 1,
                LabelImportId = 45,
                ImportConfigurationDescription = "HERTZ SUNCITY UNIT",
                LabelTypeId = 1,
                ProcessingOffice = ProcessingLocations.FlSunshineBradenton.ToString(),
                ImportOrderList = importOrderList,
                GenerateBagLabels = true,
                LabelData = "5NPEU46F96H147412	FL-23422	AutoTag637437953833305453\n",
                CreatedUser = "TESTUSER",
                CreatedDate = DateTime.Now,
                ModifiedUser = "TESTUSER",
                ModifiedDate = DateTime.Now
            };

            for (int i = 0; i < importOrderList.Count; i++)
            {
                for (int x = i; x < model.LabelData.Split("\t").Length; x++)
                {
                    if (x == i)
                    {
                        labelDataDictionary.Add(importOrderList[i], model.LabelData.Split("\t")[x]);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            importLabelData.Add(labelDataDictionary);

            foreach (var row in importLabelData)
            {
                await _unitOfWorkService.GetRepositoryAsync<ImportLabelRequest>().AddAsync(new ImportLabelRequest()
                {
                    RequestNumber = model.RequestNumber,
                    LogId = model.LogId,
                    LabelTypeId = model.LabelTypeId,
                    ClientCode = model.ClientCode,
                    ProcessingOffice = model.ProcessingOffice,
                    LabelImportId = model.LabelImportId,
                    ImportConfigurationDescription = model.ImportConfigurationDescription,
                    ImportLabelRecord = JsonConvert.SerializeObject(row),
                    GenerateBagFlag = model.GenerateBagLabels,
                    Active = true,
                    CreatedUser = model.CreatedUser,
                    CreatedDate = model.CreatedDate,
                    ModifiedUser = model.ModifiedUser,
                    ModifiedDate = model.ModifiedDate
                });
            }
            _unitOfWorkService.SaveChanges();

            var importLabels = await _inMemoryLabelService.GetImportLabelDetailsAsync(model.LogId, model.ClientCode);
            Assert.NotNull(importLabels);
            Assert.Equal(importLabels.Count, importLabelData.Count);
        }

        #endregion

        #region Notifications

        [Fact]
        public async void LabelManagementServiceTest_GetNotificationsByUserNameAsync_NotificationsReturnedAsync()
        {
            var testUserName = "TESTUSER";
            CreateTestNotification(testUserName);

            var notificationsResult = await _inMemoryLabelService.GetNotificationsByUserNameAsync(testUserName);
            Assert.True(notificationsResult.Count > 0);
        }

        [Fact]
        public async void LabelManagementServiceTest_GetNotificationsByUserNameAsync_AddSixNotifications_FiveMaxNotificationsReturnedAsync()
        {
            var testUserName = "TESTUSER";
            CreateTestNotification(testUserName);
            CreateTestNotification(testUserName);
            CreateTestNotification(testUserName);
            CreateTestNotification(testUserName);
            CreateTestNotification(testUserName);
            CreateTestNotification(testUserName);

            var notificationsResult = await _inMemoryLabelService.GetNotificationsByUserNameAsync(testUserName);
            Assert.True(notificationsResult.Count > 0 && notificationsResult.Count <= 5);
        }

        [Fact]
        public async void LabelManagementServiceTest_GetNotificationsByUserNameAsync_DifferentUser_ZeroNotificationsReturnedAsync()
        {
            var testUserName = "TESTUSER";
            var testUserName2 = "TESTUSER2";
            CreateTestNotification(testUserName);

            var notificationsResult = await _inMemoryLabelService.GetNotificationsByUserNameAsync(testUserName2);
            Assert.True(notificationsResult.Count == 0);
        }

        /*
        [Fact]
        public async void LabelManagementServiceTest_GetNotificationsByUserNameAsync_NotficiationsClearedAfterRead()
        {
            var testUserName = "TESTUSER";

            CreateTestNotification(testUserName);

            var notificationsResult = await _inMemoryLabelService.GetNotificationsByUserNameAsync(testUserName);
            Assert.True(notificationsResult.Count > 0);

            var notificationsResult2 = await _inMemoryLabelService.GetNotificationsByUserNameAsync(testUserName);
            Assert.True(notificationsResult.Count == 0);
        }
        */

        [Fact]
        public async void LabelManagementServiceTest_CreateNotificationsAsync_NotificationsReturnedAsync()
        {
            var testUserName = "TESTUSER";

            var testLog = new Log()
            {
                LogId = 1002,
                ProcessName = "UnitTestType",
                TotalCount = 1,
                SuccessfulCount = 0,
                WarningCount = 0,
                ErrorCount = 0,
                CreatedUser = testUserName
            };

            await _inMemoryLabelService.CreateNotificationsAsync(testLog);

            var notificationsResult = await _inMemoryLabelService.GetNotificationsByUserNameAsync(testUserName);

            Assert.True(notificationsResult.Count > 0);
        }

        private Notification CreateTestNotification(string userName)
        {
            var notification = new Notification()
            {
                LogId = 1,
                NotificationType = "UnitTestType",
                TotalCount = 1,
                SuccessCount = 0,
                WarningCount = 0,
                ErrorCount = 0,
                IsRead = false,
                UserName = userName,
                CreatedUser = userName,
                CreatedDate = DateTime.Now,
                ModifiedUser = userName,
                ModifiedDate = DateTime.Now
            };

            _unitOfWorkService.Context.Notifications.Add(notification);
            _unitOfWorkService.SaveChanges();

            _unitOfWorkService.Context.Entry(notification).State = EntityState.Detached;
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });
            return notification;
        }

        #endregion

        #region Logs

        [Fact(DisplayName = "LabelManagementServiceTest_GetLogsAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLogsAsync_LogsReturnedAsync()
        {
            var label = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, null, 1009);
            var model = new LogSummaryViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                IsAtLeastSupervisor = false,
                TotalCount = 4,
                PageNumber = 1
            };
            var existingLabel = await _inMemoryLabelService.GetLogsAsync(model);
            Assert.Equal(model.PageNumber, existingLabel.PageNumber);
        }

        [Fact(DisplayName = "LabelManagementServiceTest_GetLogDetailsAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLogDetailsAsync_LogDetailsReturnedAsync()
        {
            var label = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, null, 1010);
            var model = new LogDetailViewModel()
            {
                LogId = 11,
                TotalCount = 4,
                PageNumber = 1
            };
            var existingLabel = await _inMemoryLabelService.GetLogDetailsAsync(model);
            Assert.Equal(model.PageNumber, existingLabel.PageNumber);
        }

        [Fact(DisplayName = "LabelManagementServiceTest_AddLogsAsync")]
        public async void LabelManagementServiceTest_AddLogsAsync()
        {
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });

            var log = new VM.FleetServices.TnR.LM.Model.DTO.Log
            {
                LogId = 1004,
                ProcessName = ProcessNames.ImportLabels,
                TotalCount = 10,
                SuccessfulCount = 0,
                ErrorCount = 0,
                WarningCount = 0,
                Status = JobLogStatus.Ready.ToString(),
                CreatedUser = "TESTUSER",
                ModifiedUser = "TESTUSER",
                ClientCode = "HERTZ",
                ProcessType = ProcessTypes.Import.GetDescription()
            };
            var logEntity = await _inMemoryLabelService.CreateJobLogTaskAsync(log);
            Assert.NotNull(logEntity);
            Assert.Equal(logEntity.LogId, log.LogId);
        }


        [Fact(DisplayName = "LabelManagementServiceTest_UpdateLogStatusAsync")]
        public async void LabelManagementServiceTest_UpdateLogStatusAsync()
        {
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });

            var log = new VM.FleetServices.TnR.LM.Model.DTO.Log
            {
                LogId = 1005,
                ProcessName = ProcessNames.ImportLabels,
                TotalCount = 10,
                SuccessfulCount = 0,
                ErrorCount = 0,
                WarningCount = 0,
                Status = JobLogStatus.Ready.ToString(),
                CreatedUser = "TESTUSER",
                ModifiedUser = "TESTUSER",
                ClientCode = "HERTZ",
                ProcessType = ProcessTypes.Import.GetDescription()
            };
            var logEntity = await _inMemoryLabelService.CreateJobLogTaskAsync(log);
            Assert.NotNull(logEntity);

            logEntity = await _inMemoryLabelService.UpdateLogStatusByIdAsync(log.LogId, JobLogStatus.Completed.GetDescription());
            Assert.NotNull(logEntity);
            Assert.Equal(logEntity.LogId, log.LogId);
            Assert.Equal(logEntity.Status, JobLogStatus.Completed.GetDescription());
        }


        [Fact(DisplayName = "LabelManagementServiceTest_UpdateLogsAsync")]
        public async void LabelManagementServiceTest_UpdateLogsAsync()
        {
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });

            var log = new VM.FleetServices.TnR.LM.Model.DTO.Log
            {
                LogId = 1006,
                ProcessName = ProcessNames.ImportLabels,
                TotalCount = 10,
                SuccessfulCount = 0,
                ErrorCount = 0,
                WarningCount = 0,
                Status = JobLogStatus.Ready.ToString(),
                CreatedUser = "TESTUSER",
                ModifiedUser = "TESTUSER",
                ClientCode = "HERTZ",
                ProcessType = ProcessTypes.Import.GetDescription()
            };
            var logEntity = await _inMemoryLabelService.CreateJobLogTaskAsync(log);
            Assert.NotNull(logEntity);

            log.Status = JobLogStatus.Completed.GetDescription();
            log.SuccessfulCount = log.TotalCount;

            logEntity = await _inMemoryLabelService.UpdateLogStatusAsync(log, new List<VM.FleetServices.TnR.LM.Model.DTO.LogDetail>());
            Assert.NotNull(logEntity);
            Assert.Equal(logEntity.LogId, log.LogId);
            Assert.Equal(logEntity.SuccessfulCount, log.SuccessfulCount);
            Assert.Equal(logEntity.TotalCount, log.TotalCount);
            Assert.Equal(logEntity.Status, JobLogStatus.Completed.GetDescription());
        }

        [Fact(DisplayName = "LabelManagementServiceTest_UpdateErrorLogs_LogDetailsAsync")]
        public async void LabelManagementServiceTest_UpdateErrorLogs_LogDetailsAsync()
        {
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });

            var log = new VM.FleetServices.TnR.LM.Model.DTO.Log
            {
                LogId = 1001,
                ProcessName = ProcessNames.ImportLabels,
                TotalCount = 10,
                SuccessfulCount = 0,
                ErrorCount = 0,
                WarningCount = 0,
                Status = JobLogStatus.Ready.ToString(),
                CreatedUser = "TESTUSER",
                ModifiedUser = "TESTUSER",
                ClientCode = "HERTZ",
                ProcessType = ProcessTypes.Import.GetDescription()
            };
            var logEntity = await _inMemoryLabelService.CreateJobLogTaskAsync(log);
            Assert.NotNull(logEntity);

            log.Status = JobLogStatus.Failed.GetDescription();
            log.ErrorCount = log.TotalCount;

            var logDetails = new List<VM.FleetServices.TnR.LM.Model.DTO.LogDetail>() {
                new VM.FleetServices.TnR.LM.Model.DTO.LogDetail(){
                    Active=true,
                    CreatedDate=DateTime.Now,
                    CreatedUser="TESTUSER",
                    ModifiedDate=DateTime.Now,
                    ModifiedUser="TESTUSER",
                    ErrorMessage="Test Error",
                    ErrorRecord=log.LogId.ToString(),
                    LogId = log.LogId,
                    ErrorType="Error",
                    LogDetailsId=1
                }
            };

            logEntity = await _inMemoryLabelService.UpdateLogStatusAsync(log, logDetails);
            Assert.NotNull(logEntity);
            Assert.Equal(logEntity.LogId, log.LogId);
            Assert.Equal(logEntity.ErrorCount, log.ErrorCount);
            Assert.Equal(logEntity.TotalCount, log.TotalCount);
            Assert.Equal(logEntity.Status, JobLogStatus.Failed.GetDescription());

            var model = new LogDetailViewModel()
            {
                LogId = 1,
                TotalCount = 4,
                PageNumber = 1
            };
            var logDetailsEntity = await _inMemoryLabelService.GetLogDetailsAsync(model);
            Assert.NotNull(logDetailsEntity);
            Assert.Equal(logDetailsEntity.LogId, log.LogId);
            Assert.Equal(logDetailsEntity.LogId, logDetails.First().LogId);
        }

        [Fact(DisplayName = "LabelManagementServiceTest_GetLogsByIdAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLogsByIdAsync_LogsReturnedAsync()
        {
            var log = CreateLog(990);
            var existingLog = await _inMemoryLabelService.GetLogAsync(1);
            Assert.Equal(log.LogId, existingLog.LogId);
        }

        [Fact(DisplayName = "LabelManagementServiceTest_GetLogsByIdAsync_TestAsync")]
        public async void LabelManagementServiceTest_CreateInProgressLogAsync_LogsReturnedAsync()
        {
            var log = CreateLog(991);
            await _inMemoryLabelService.CreateInProgressLogAsync(log, 2);
            Assert.Equal(2, log.LogId);
        }

        [Fact(DisplayName = "LabelManagementServiceTest_GetLogsByIdAsync_TestAsync")]
        public async void LabelManagementServiceTest_UpdateLogStatusAsync_LogsReturnedAsync()
        {
            var log = CreateLog(992);
            var existingLog = await _inMemoryLabelService.UpdateLogStatusAsync(log, 4, 2);
            Assert.Equal(log.LogId, existingLog.LogId);
        }

        /// <summary>
        /// Creates the test logs.
        /// </summary>
        /// <returns></returns>
        /// <returns></returns>
        private Log CreateLog(int logId)
        {
            var log = new Log()
            {
                LogId = logId,
                ClientCode = "HERTZ",
                ProcessingLocationCode = "FL"
            };
            _unitOfWorkService.Context.Logs.Add(log);
            _unitOfWorkService.SaveChanges();

            _unitOfWorkService.Context.Entry(log).State = EntityState.Detached;
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });
            return log;
        }

        #endregion

        #region Commented Code

        // The 'GetLabelsAsync' method calls a stored procedure now so this method should be part of an integration test instead
        //[Fact]
        //public async void LabelManagementServiceTest_GetLabelsAsync_LabelsReturnedAsync()
        //{
        //    var personalSetting = new UserProfileSettingsViewModel()
        //    {
        //        ClientCode = ClientCodes.Hertz.GetDescription(),
        //        DmvStateCode = StateProvinces.Florida.GetDescription(),
        //        ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
        //        SelectedRowsPerPage = 5
        //    };
        //    var label = CreateLabel();
        //    var model = new SearchLabelViewModel()
        //    {
        //        Results = new List<LabelViewModel> {
        //            label
        //        },
        //        TotalCount = 4,
        //        PageNumber = 1
        //    };
        //    var existingLabel = await _inMemoryLabelService.GetLabelsAsync(model);
        //    Assert.Equal(model.PageNumber, existingLabel.PageNumber);
        //}

        #endregion

        #region Export Labels

        [Fact(DisplayName = "LabelManagementServiceTest_SubmitExportAllRequestAsync_TestAsync")]
        public async void LabelManagementServiceTest_SubmitExportAllRequestAsync_LogReturnedAsync()
        {
            var label = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, null, 1011);
            var model = new ExportLabelViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                UserId = "FSAMSTESTUSER",
                ReportType = Reports.ViewBagLabels,
                SearchCriteria = "",
                TotalCount = 1080
            };
            var result = await _inMemoryLabelService.SubmitExportAllRequestAsync(model);
            Assert.True(result != null);
            var insertedLog = _unitOfWorkService.Context.Logs.SingleOrDefault(x => x.LogId == result.LogId);
            if (insertedLog != null)
                _unitOfWorkService.Context.Logs.Remove(insertedLog);
            await _unitOfWorkService.Context.SaveChangesAsync();
        }

        [Fact(DisplayName = "LabelManagementServiceTest_GetLabelsForExportAsync_TestAsync")]
        public async void LabelManagementServiceTest_GetLabelsForExportAsync_LabelsReturnedAsync()
        {
            var label = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, null, 1012);
            var model = new SearchLabelViewModel()
            {
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                LabelTypeId = 1,
                PageNumber = 1,
                DefaultRowsPerPage = 25
            };
            var result = await _inMemoryLabelService.GetLabelsForExportAsync(model);
            Assert.Equal(model.PageNumber, result.PageNumber);
        }

        #endregion

        #region Update Labels
        /// <summary>
        /// Test method to perform bulk update for labels - Pending to Active
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_BulkUpdate_PendingToActive")]
        public async void LabelManagementServiceTest_PerformBulkUpdateAsync_PendingToActive_Async()
        {
            const int labelId = 1013;
            const string vin = "XCF23FGP012356fGT";
            CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, vin, labelId);

            var model = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Active,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };
            var bulkUpdateResult = await _inMemoryLabelService.PerformBulkUpdateAsync(model);
            Assert.Equal(model.TotalLabels, bulkUpdateResult.TotalPassed);
        }

        /// <summary>
        /// Test method to perform bulk update for labels - Active to Pending
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_BulkUpdate_ActiveToPending_ExpectChargesVoided")]
        public async void LabelManagementServiceTest_PerformBulkUpdateAsync_ActiveToPending_Async()
        {
            const int labelId = 1000;

            var createdLabel = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Active, Labeltypes.Unit, null, labelId);
            CreateBilling(createdLabel, ProcessingLocations.FlSunshineBradenton);

            var model = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Pending,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };

            var bulkUpdateResult = await _inMemoryLabelService.PerformBulkUpdateAsync(model);

            // Verify that the the billing was voided
            var billing = GetBilling(createdLabel.LabelId);

            Assert.NotNull(billing);
            Assert.True(billing.Void);

            // Verify results
            Assert.Equal(model.TotalLabels, bulkUpdateResult.TotalPassed);

        }

        /// <summary>
        /// Test method to perform bulk update for labels - Active to Duplicate
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_BulkUpdate_ActiveToDuplicate_ExpectChargesVoided")]
        public async void LabelManagementServiceTest_PerformBulkUpdateAsync_ActiveToDuplicate_Async()
        {
            const int labelId = 1001;
            var createdLabel = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Active, Labeltypes.Unit, null, labelId);
            CreateBilling(createdLabel, ProcessingLocations.FlSunshineBradenton);

            var model = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Duplicate,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };

            var bulkUpdateResult = await _inMemoryLabelService.PerformBulkUpdateAsync(model);

            // Verify that the the billing was voided
            var billing = GetBilling(createdLabel.LabelId);

            Assert.NotNull(billing);
            Assert.True(billing.Void);

            // Verify results
            Assert.Equal(model.TotalLabels, bulkUpdateResult.TotalPassed);

        }

        /// <summary>
        /// Test method to perform bulk update for labels - Active to Void
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_BulkUpdate_ActiveToVoid_ExpectChargesVoided")]
        public async void LabelManagementServiceTest_PerformBulkUpdateAsync_ActiveToVoid_Async()
        {
            const int labelId = 1002;
            var createdLabel = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Active, Labeltypes.Unit, null, labelId);
            CreateBilling(createdLabel, ProcessingLocations.FlSunshineBradenton);

            var model = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Void,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };

            var bulkUpdateResult = await _inMemoryLabelService.PerformBulkUpdateAsync(model);

            // Verify that the billing was voided
            var billing = GetBilling(createdLabel.LabelId);

            Assert.NotNull(billing);
            Assert.True(billing.Void);

            // Verify results
            Assert.Equal(model.TotalLabels, bulkUpdateResult.TotalPassed);

        }

        /// <summary>
        /// Test method to perform bulk update for labels - Void to Active - Expect denial
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_BulkUpdate_VoidToActive_ExpectDenied")]
        public async void LabelManagementServiceTest_PerformBulkUpdateAsync_VoidToActive_ExpectDenied_Async()
        {
            const int labelId = 1003;
            CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Void, Labeltypes.Unit, null, labelId);

            var model = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Active,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };
            var bulkUpdateResult = await _inMemoryLabelService.PerformBulkUpdateAsync(model);
            Assert.Equal(0, bulkUpdateResult.TotalPassed);
            Assert.Equal(1, bulkUpdateResult.TotalFailed);
        }

        /// <summary>
        /// Test method to perform bulk update for labels - 2 labels with same vin and status - expect denial
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_BulkUpdate_DuplicateActiveLabels_ExpectDenied")]
        public async void LabelManagementServiceTest_PerformBulkUpdateAsync_DuplicateActiveLabels_ExpectDenial_Async()
        {
            const int labelId = 1004;
            const string vin = "XCF23FGP012356fGT";
            CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, vin, labelId);

            const int labelId2 = 1005;
            const string vin2 = vin;
            CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, vin2, labelId2);

            var passModel = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Active,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };

            var failModel = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = (int)LabelStatusTypes.Active,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId2 }
            };

            var bulkUpdatePassResult = await _inMemoryLabelService.PerformBulkUpdateAsync(passModel);
            var bulkUpdateFailResult = await _inMemoryLabelService.PerformBulkUpdateAsync(failModel);

            // Should pass and changed to ACTIVE
            Assert.Equal(passModel.TotalLabels, bulkUpdatePassResult.TotalPassed);
            Assert.Equal(0, bulkUpdatePassResult.TotalFailed);

            // Should fail when attempting to update to ACTIVE
            Assert.Equal(0, bulkUpdateFailResult.TotalPassed);
            Assert.Equal(1, bulkUpdateFailResult.TotalFailed);

        }

        /// <summary>
        /// Test method to update the label status and notes 
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_GridUpdates_PendingToActive")]
        public async void LabelManagementServiceTest_UpdateLabelsAsync_PendingToActive_Async()
        {
            const int labelId = 1006;
            var label = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Pending, Labeltypes.Unit, null, labelId);
            label.LabelStatusData = new DTO.LabelStatusType()
            {
                LabelStatusTypeId = (int)LabelStatusTypes.Active
            };

            var model = new UpdateLabelsModel()
            {
                LabelsList = new List<LabelViewModel>() { label },
                Userid = "TESTUSER"
            };

            var expectedBulkUpdateViewModel = new BulkUpdateViewModel()
            {
                TotalLabels = 1,
                LabelsStatusTypeId = 3,
                Notes = "Test Notes",
                ClientCode = "HERTZ",
                Labels = new List<int>() { labelId }
            };
            var bulkUpdateResult = await _inMemoryLabelService.UpdateLabelsAsync(model);
            Assert.Equal(expectedBulkUpdateViewModel.TotalLabels, bulkUpdateResult.TotalPassed);
        }


        #endregion

        #region Charges

        /// <summary>
        /// Test method to save charges, expect success 
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_SaveCharges_ExpectSuccess")]
        public async void LabelManagementServiceTest_SaveLabelBillingsAsync_Async()
        {
            // Stage a label in the database
            const int labelId = 1007;
            const string user = "FSAMSTESTUSER";

            var createdLabel = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Active, Labeltypes.Unit, null, labelId);
            var createdLabels = new List<LabelViewModel> { createdLabel };

            // Create the billingLookups Fees collection
            var billingFeeList = new List<DTO.BillingFee>();
            var billingFee1 = new DTO.BillingFee()
            {
                BillingFeeId = 22,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                BillingTypeId = 1,
                BillingReasonTypeId = 5,
                BillingItemTypeId = 2,
                ConditionTypeId = 2,
                DefaultAmount = (decimal?)1.0,
                DisplayName = "HERTZ PRINT BAG LABELS",
                Active = true,
                CreatedUser = user,
                CreatedDate = DateTime.Now
            };
            var billingFee2 = new DTO.BillingFee()
            {
                BillingFeeId = 44,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                BillingTypeId = 1,
                BillingReasonTypeId = 4,
                BillingItemTypeId = 2,
                ConditionTypeId = 1,
                DefaultAmount = (decimal?)1.5,
                DisplayName = "HERTZ PRINT UNIT LABELS",
                Active = true,
                CreatedUser = user,
                CreatedDate = DateTime.Now
            };
            billingFeeList.Add(billingFee1);
            billingFeeList.Add(billingFee2);
            var billingFeesJsonArray = (JArray)JToken.FromObject(billingFeeList);

            // Stage a billing in the database
            //var createdBilling = CreateBilling(createdLabel, ProcessingLocations.FlSunshineBradenton, billingFee2);

            // Call save label billings
            var saveBillingsResult = await _inMemoryLabelService.SaveLabelBillingsAsync(createdLabels, user);

            Assert.NotNull(saveBillingsResult);
            Assert.True(saveBillingsResult.FailedLabels.Count == 0);
            Assert.True(saveBillingsResult.SuccessLabels.Count == 1);

            // Get the new billing created
            var newBilling = GetBilling(createdLabel.LabelId);
            Assert.NotNull(newBilling);
        }

        /// <summary>
        /// Test method to save charges, expect success 
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_SaveCharges_ExistingChargeExists_ExpectDenied")]
        public async void LabelManagementServiceTest_SaveLabelBillingsAsync_ExistingChargeExists_Async()
        {
            // Stage a label in the database
            const int labelId = 1008;
            const string user = "FSAMSTESTUSER";

            var createdLabel = CreateLabel(ClientCodes.Hertz, ProcessingLocations.FlSunshineBradenton, LabelStatusTypes.Active, Labeltypes.Unit, null, labelId);
            var createdLabels = new List<LabelViewModel> { createdLabel };

            // Create the billingLookups Fees collection
            var billingFeeList = new List<DTO.BillingFee>();
            var billingFee1 = new DTO.BillingFee()
            {
                BillingFeeId = 22,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                BillingTypeId = 1,
                BillingReasonTypeId = 5,
                BillingItemTypeId = 2,
                ConditionTypeId = 2,
                DefaultAmount = (decimal?)1.0,
                DisplayName = "HERTZ PRINT BAG LABELS",
                Active = true,
                CreatedUser = user,
                CreatedDate = DateTime.Now
            };
            var billingFee2 = new DTO.BillingFee()
            {
                BillingFeeId = 44,
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription(),
                BillingTypeId = 1,
                BillingReasonTypeId = 4,
                BillingItemTypeId = 2,
                ConditionTypeId = 1,
                DefaultAmount = (decimal?)1.5,
                DisplayName = "HERTZ PRINT UNIT LABELS",
                Active = true,
                CreatedUser = user,
                CreatedDate = DateTime.Now
            };
            billingFeeList.Add(billingFee1);
            billingFeeList.Add(billingFee2);
            var billingFeesJsonArray = (JArray)JToken.FromObject(billingFeeList);

            // Stage an existing billing in the database, should cause the charge to be denied
            var createdBilling = CreateBilling(createdLabel, ProcessingLocations.FlSunshineBradenton, billingFee2);

            // Call save label billings
            var saveBillingsResult = await _inMemoryLabelService.SaveLabelBillingsAsync(createdLabels, user);

            Assert.NotNull(saveBillingsResult);
            Assert.True(saveBillingsResult.FailedLabels.Count == 1);
            Assert.True(saveBillingsResult.SuccessLabels.Count == 0);
        }

        /// <summary>
        /// Creates the test labels.
        /// </summary>
        /// <returns></returns>
        private LabelBilling CreateBilling(LabelViewModel label, ProcessingLocations processingLocation, DTO.BillingFee billingFee = null)
        {
            var labelBilling = new LabelBilling()
            {
                BillingFeeId = billingFee?.BillingFeeId ?? 1,
                LabelBillingId = label.LabelId,
                LabelId = label.LabelId,
                ProcessingLocationCode = processingLocation.GetDescription(),
                CreatedUser = label.UserName,
                BillingAmount = (decimal?)1.00,
                CreatedDate = DateTime.Now,
                InvoiceId = null,
                IsDebit = true,
                Void = false
            };

            _unitOfWorkService.Context.LabelBillings.Add(labelBilling);
            _unitOfWorkService.SaveChanges();

            _unitOfWorkService.Context.Entry(labelBilling).State = EntityState.Detached;
            _mockMapper.Reset();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<LabelManagementMappingProfile>();
            });
            var mapper = config.CreateMapper();

            return mapper.Map<LabelBilling>(labelBilling);
        }

        /// <summary>
        /// Creates the test labels.
        /// </summary>
        /// <returns></returns>
        private LabelBilling GetBilling(int labelId)
        {
            var labelBilling = _unitOfWorkService.Context.LabelBillings.Single(bill => bill.LabelId == labelId);

            return labelBilling;
        }


        #endregion

        #region Credit Labels

        [Fact]
        public async void Validate_ApplyLabelCredits_OpenInvoiceAsync()
        {
            var label = new Label()
            {
                LabelStatusTypeId = (int)LabelStatusTypes.Active,
                VIN = "123333333",
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };

            await _inMemoryLabelService.AddLabelsAsync(new List<Label>() { label });

            var labelBilling = new LabelBilling
            {
                LabelId = label.LabelId,
                BillingAmount = 2,
                BillingFeeId = 1,
                Comment = "Test",
                CreatedDate = DateTime.Now,
                CreatedUser = "TestUser",
                InvoiceId = 1,
                IsDebit = true,
                ProcessingLocationCode = "TestLoc",
                Void = false
            };

            await _unitOfWorkService.Context.LabelBillings.AddAsync(labelBilling);

            var model = new CreditLabelRequestModel
            {
                LabelIdList = new List<int> { label.LabelId },
                InvoiceIdList = new List<int> { labelBilling.InvoiceId.GetValueOrDefault() },
                UserName = "UpdateUser",
                InvoiceList = new List<SelectInvoiceViewModel>() { new SelectInvoiceViewModel() { InvoiceId = 1, InvoiceStatus = InvoiceStatusTypes.Open.GetDescription() } }
            };

            await _inMemoryLabelService.ApplyCreditsToLabelsAsync(model);

            Assert.True(labelBilling.Void == true);
        }

        [Fact]
        public async void Validate_ApplyLabelCredits_ClosedInvoiceAsync()
        {
            var label = new Label()
            {
                LabelStatusTypeId = (int)LabelStatusTypes.Active,
                VIN = "123333333",
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };

            await _inMemoryLabelService.AddLabelsAsync(new List<Label>() { label });

            var labelBilling = new LabelBilling
            {
                LabelId = label.LabelId,
                BillingAmount = 2,
                BillingFeeId = 1,
                Comment = "Test",
                CreatedDate = DateTime.Now,
                CreatedUser = "TestUser",
                InvoiceId = 1,
                IsDebit = true,
                ProcessingLocationCode = "TestLoc",
                Void = false
            };

            await _unitOfWorkService.Context.LabelBillings.AddAsync(labelBilling);

            var model = new CreditLabelRequestModel
            {
                LabelIdList = new List<int> { label.LabelId },
                InvoiceIdList = new List<int> { labelBilling.InvoiceId.GetValueOrDefault() },
                UserName = "UpdateUser",
                InvoiceList = new List<SelectInvoiceViewModel>() { new SelectInvoiceViewModel() { InvoiceId = 1, InvoiceStatus = InvoiceStatusTypes.Closed.GetDescription() } }
            };

            await _inMemoryLabelService.ApplyCreditsToLabelsAsync(model);

            Assert.True(labelBilling.Void);
            Assert.True(!labelBilling.IsDebit);
        }

        [Fact]
        public async void Validate_ApplyLabelCredits_NullInvoiceAsync()
        {
            var label = new Label()
            {
                LabelStatusTypeId = (int)LabelStatusTypes.Active,
                VIN = "123333333",
                ClientCode = ClientCodes.Hertz.GetDescription(),
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };

            await _inMemoryLabelService.AddLabelsAsync(new List<Label>() { label });

            var labelBilling = new LabelBilling
            {
                LabelId = label.LabelId,
                BillingAmount = 2,
                BillingFeeId = 1,
                Comment = "Test",
                CreatedDate = DateTime.Now,
                CreatedUser = "TestUser",
                InvoiceId = 1,
                IsDebit = true,
                ProcessingLocationCode = "TestLoc",
                Void = false
            };

            await _unitOfWorkService.Context.LabelBillings.AddAsync(labelBilling);

            var model = new CreditLabelRequestModel
            {
                LabelIdList = new List<int> { label.LabelId },
                InvoiceIdList = new List<int> { labelBilling.InvoiceId.GetValueOrDefault() },
                UserName = "UpdateUser",
                InvoiceList = new List<SelectInvoiceViewModel>() { }
            };

            await _inMemoryLabelService.ApplyCreditsToLabelsAsync(model);

            Assert.True(labelBilling.Void);
        }


        [Fact]
        public async void Validate_ValidateLabelsToApplyCredits_TestAsync()
        {
            var label = new Label()
            {
                LabelStatusTypeId = (int)LabelStatusTypes.Active,
                VIN = "123333333",
                ClientCode = ClientCodes.Hertz.GetDescription(),
                PrintCount = 1,
                ProcessingLocationCode = ProcessingLocations.FlSunshineBradenton.GetDescription()
            };

            await _inMemoryLabelService.AddLabelsAsync(new List<Label>() { label });

            var labelBilling = new LabelBilling
            {
                LabelId = label.LabelId,
                BillingAmount = 2,
                BillingFeeId = 1,
                Comment = "Test",
                CreatedDate = DateTime.Now,
                CreatedUser = "TestUser",
                InvoiceId = 1,
                IsDebit = true,
                ProcessingLocationCode = "TestLoc",
                Void = false
            };

            await _unitOfWorkService.Context.LabelBillings.AddAsync(labelBilling);

            var creditLabel = await _inMemoryLabelService.ValidateLabelsToApplyCreditsAsync(new List<int>() { label.LabelId });

            Assert.NotNull(creditLabel);
        }

        #endregion

        #region Move Labels

        [Fact(DisplayName = "LabelManagementServiceTest_UpdateLabelProcessingOffice_TestAsync")]
        public async void LabelManagementServiceTest_UpdateLabelProcessingOffice_StatusReturnedAsync()
        {
            MoveLabelsViewModel model = new MoveLabelsViewModel();
            var labelList = new List<VM.FleetServices.TnR.LM.Model.DTO.Label>();
            var label = new VM.FleetServices.TnR.LM.Model.DTO.Label() { LabelId = 1206 };
            labelList.Add(label);
            model.ProcessingLocationOffice = ProcessingLocations.FlSunshineBradenton.ToString();

            model.Labels = labelList;
            var existingLabel = await _inMemoryLabelService.UpdateLabelProcessingOfficeAsync(model);
            Assert.True(existingLabel);
        }

        #endregion

        #region Copy Labels

        /// <summary>
        /// Test method to perform copy labels
        /// </summary>
        [Fact(DisplayName = "LabelManagementServiceTest_CopyLabels_VoidOrClosedToActive")]
        public async void LabelManagementServiceTest_CopyLabelsAsync_VoidOrClosedToActive_Async()
        {
            List<VM.FleetServices.TnR.LM.Model.DTO.Label> LabelData = new List<VM.FleetServices.TnR.LM.Model.DTO.Label>();
            Label label = new Label();
            label.LabelId = 13208;
            var model = new CopyLabelsViewModel()
            {
                Labels = LabelData,
                UserName = "FSAMSTESTUSER"
            };

            var copyLabelsResult = await _inMemoryLabelService.CopyLabelsAsync(model);
            Assert.Equal(copyLabelsResult.TotalLabels, copyLabelsResult.TotalPassed);
        }

        #endregion
    }
}
