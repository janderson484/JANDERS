using System;
using AutoMapper;
using Business.Tests.Mapping;
using Microsoft.EntityFrameworkCore;
using VM.FleetServices.TnR.LM.Data.LabelModel;

namespace VM.FleetServices.TnR.Business.Tests
{
    public class ConfigureTestDataFixture : IDisposable
    {
        public LabelModel InMemoryLabelContext => GetInMemoryLabelContext();

        public void Dispose()
        {

        }

        public static object ThisLock = new object();
        private static LabelModel GetInMemoryLabelContext()
        {
            // This will ensure one thread can access to this static initialize call
            // and ensure the mapper is reset before initialized
            lock (ThisLock)
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile<LabelManagementTestMappingProfile>();
                });
                var mapper = config.CreateMapper();
                //Mapper.Reset();
            }

            return new LabelModel(new DbContextOptionsBuilder<LabelModel>().UseInMemoryDatabase("LabelManagement").Options);
        }
    }
}
