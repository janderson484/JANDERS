using System.Collections.Generic;
using AutoMapper;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using Entities = VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using DTO= VM.FleetServices.TnR.LM.Model.DTO;

namespace Business.Tests.Mapping
{
    public class LabelManagementTestMappingProfile : Profile
    {
        public LabelManagementTestMappingProfile()
        {
            CreateMap<Entities.LabelStatusType, DTO.LabelStatusType>();
            CreateMap<DTO.LabelStatusType, Entities.LabelStatusType>();

            CreateMap<Entities.LabelType, DTO.LabelType>();
            CreateMap<DTO.LabelType,Entities.LabelType>();

            CreateMap<Entities.LabelImport, ImportLayoutViewModel>();
            CreateMap<ImportLayoutViewModel, Entities.LabelImport>();

            CreateMap<Entities.LabelImportField, DTO.LabelImportField>();
            CreateMap<DTO.LabelImportField, DTO.LabelImportField>();

            CreateMap<Entities.LabelImportFieldsMapping, DTO.LabelImportFieldsMapping>();
            CreateMap<DTO.LabelImportFieldsMapping, Entities.LabelImportFieldsMapping>();

            CreateMap<Entities.Label, LabelViewModel>();
            CreateMap< LabelViewModel, Entities.Label>();
        }
    }



}
