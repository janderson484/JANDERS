namespace VM.FleetServices.TnR.LM.BackendJob.JobSettings
{
    public class WebjobSettings
    {
        public string ASBTopicName { get; set; }
        public string ASBSubscriptionName { get; set; }
        public int BatchCount { get; set; }
        public string AppUserName { get; set; }
        public int ExportReportRequestCount { get; set; }
        public bool IsPrintLabelsToEnabled { get; set; }
    }
}
