using System;

namespace VM.FleetServices.TnR.LM.BackendJob.JobSettings
{
    //[Obsolete]
    //public class ApiSettings
    //{
    //    public string Uri { get; set; }
    //    public string PrintServiceUri { get; set; }
    //}
}
