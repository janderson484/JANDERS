using System.Globalization;
using CsvHelper.Configuration;
using VM.FleetServices.TnR.LM.Model.ViewModel;

namespace VM.FleetServices.TnR.LM.BackendJob.Models
{
    public class LabelViewModelExportHeader : ClassMap<LabelViewModel>
    {
        public LabelViewModelExportHeader()
        {
            AutoMap(CultureInfo.InvariantCulture);
            Map(m => m.LabelStatusTypeId).Ignore();
            Map(m => m.LabelStatusData.LabelStatusTypeId).Ignore();
            Map(m => m.LabelStatusData.ModifiedDate).Ignore();
            Map(m => m.LabelStatusData.ModifiedUser).Ignore();
            Map(m => m.LabelStatusData.Active).Ignore();
            Map(m => m.LabelStatusData.CreatedDate).Ignore();
            Map(m => m.LabelStatusData.CreatedUser).Ignore();
            Map(m => m.LabelStatusData.DisplayName).Ignore();
            Map(m => m.LabelTypeId).Ignore();
            Map(m => m.ClientCode).Ignore();
            Map(m => m.StateProvinceCode).Ignore();
            Map(m => m.ProcessingLocationCode).Ignore();
            Map(m => m.ModifiedUser).Ignore();
            Map(m => m.PrintStatus).Ignore();
            Map(m => m.TotalRowCount).Ignore();
            Map(m => m.LabelId).Name("Id");
            Map(m => m.LabelStatus).Name("Status");
            Map(m => m.PrintCount).Name("Print Count");
            Map(m => m.UserName).Name("User Name");
            Map(m => m.BatchNumber).Name("Batch Number");
            Map(m => m.DeliveryCode).Name("Delivery Code");
            Map(m => m.TotalAmount).Name("Total Amount");
            Map(m => m.DebitOrCredit).Name("Debit/credit");
            Map(m => m.ShipTo).Name("Ship To");
            Map(m => m.OwningAreaDeliveryCode).Name("Owning Area");
            Map(m => m.CreatedDate).Name("Created Date");
            Map(m => m.ModifiedDate).Name("Modified Date");
        }
    }
}
