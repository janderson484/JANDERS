using System;
using Ats.FleetServices.Core.Data;
using AutoMapper;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.ServiceBus;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.BackendJob.JobSettings;
using VM.FleetServices.TnR.LM.BackendJob.Services;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations;
using VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService;
using VM.FleetServices.TnR.LM.Business.Integrations.PrinterService;
using VM.FleetServices.TnR.LM.Business.Mapping;
using VM.FleetServices.TnR.LM.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Data.LabelModel;

namespace VM.FleetServices.TnR.LM.BackendJob
{
    class Program
    {
        private const string _appsettings = "appsettings.json";
        //private const string _appsettingsDev = "appsettings.Development.json";
        private const string _prefix = "ASPNETCORE_";

        private static void Main()
        {
            // Initialize Aspose license object
            var license = new Aspose.Pdf.License();
            var barcodeLicense = new Aspose.BarCode.License();
            // Set license
            license.SetLicense("Aspose.Total.lic");
            barcodeLicense.SetLicense("Aspose.Total.lic");

            var serviceBusOptions = new ServiceBusOptions();

            var builder = new HostBuilder();

            builder.ConfigureHostConfiguration(configHost =>
            {
                configHost.AddJsonFile(_appsettings, optional: true);
                //configHost.AddJsonFile(_appsettingsDev, optional: true);
                configHost.AddEnvironmentVariables(prefix: _prefix);
            });

            builder.ConfigureAppConfiguration((hostContext, configApp) =>
            {
                Console.WriteLine("Environment name:" + hostContext.HostingEnvironment.EnvironmentName);
                configApp.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                //configApp.AddJsonFile($"appsettings.{hostContext.HostingEnvironment.EnvironmentName}.json", optional: true);
                var builtConfig = configApp.Build();

                var kvUrl = builtConfig["KeyVaultConfiguration:KVUrl"];

                if (!string.IsNullOrEmpty(kvUrl) && hostContext.HostingEnvironment.IsDevelopment())
                {
                    var tenantId = builtConfig["KeyVaultConfiguration:TenantId"];
                    var clientId = builtConfig["KeyVaultConfiguration:ClientId"];
                    var clientSecret = builtConfig["KeyVaultConfiguration:ClientSecretId"];

                    var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
                    var client = new SecretClient(new Uri(kvUrl), credential);
                    configApp.AddAzureKeyVault(client, new AzureKeyVaultConfigurationOptions());
                }
            });

            builder.ConfigureServices((context, services) =>
            {
                services.Configure<StorageOptions>(options => context.Configuration.GetSection("StorageOptions").Bind(options));

                Console.WriteLine("ConnectionString: " + context.Configuration.GetConnectionString("LabelModel"));
                services.AddDbContext<LabelModel>(options =>
                {
                    options.UseSqlServer(context.Configuration.GetConnectionString("LabelModel"));
                });

                services.AddTransient<IScrubMessageService, ScrubMessageService>();
                services.AddTransient<WebjobFunctions>();
                services.AddScoped<ILabelModel>(provider => provider.GetService<LabelModel>());
                services.AddTransient<ILabelModel>(provider => provider.GetService<LabelModel>());
                services.AddScoped<IBulkProcessService, BulkProcessService>();
                services.AddScoped<ILabelManagementService, LabelManagementService>();
                services.AddScoped<IPrinterService, PrinterService>();
                services.AddScoped<IAuthService, AuthService>();
                services.AddScoped<IInvoiceService, InvoiceService>();
                services.AddScoped<IUnitOfWorkService, UnitOfWorkService<LabelModel>>();
                services.AddScoped<IUnitOfWorkService<LabelModel>, UnitOfWorkService<LabelModel>>();
                services.AddScoped<IRepositoryFactory, UnitOfWorkService<LabelModel>>();
                services.AddScoped<IDbModelFactory<ILabelModel>, LabelModelFactory>();
                services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
                services.AddScoped<IConfigurationService, ConfigurationService>();

                services.AddSingleton<IBlobStorage, BlobStorage>();
                services.AddMessagePipelineComponents();
                services.AddHttpClient();
                services.Configure<OpenIdSettings>(options => { context.Configuration.GetSection("OpenIdSettings").Bind(options); });
                services.Configure<WebjobSettings>(options => { context.Configuration.GetSection("WebjobSettings").Bind(options); });
                //services.Configure<JobSettings.ApiSettings>(options => { context.Configuration.GetSection("ApiSettings").Bind(options); });
                services.Configure<TnR.Core.Common.Mvc.ApiSettings>(options => { context.Configuration.GetSection("ApiSettings").Bind(options); });
                services.Configure<PMApiSettings>(options => { context.Configuration.GetSection("PMApiSettings").Bind(options); });
                var test = context.Configuration.GetSection("WebjobSettings").GetChildren();

              
                serviceBusOptions.ConnectionString = context.Configuration.GetConnectionString("WebjobSettings:ASBConnectionString");

                // Configure Automapper
                //Mapper.Initialize(cfg => cfg.AddProfile<LabelManagementMappingProfile>());
                var mapperConfig = new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new LabelManagementMappingProfile());
                });

                IMapper mapper = mapperConfig.CreateMapper();
                services.AddSingleton(mapper);
                //services.AddAutoMapper(typeof(LabelManagementMappingProfile));
            });

            builder.ConfigureWebJobs(b =>
            {
                b.AddAzureStorageCoreServices();
                b.AddServiceBus();
            });
            builder.ConfigureLogging((context, b) => { b.AddConsole(); });

            var host = builder.Build();
            using (host)
            {
                host.Run();
            }
        }
    }
}
