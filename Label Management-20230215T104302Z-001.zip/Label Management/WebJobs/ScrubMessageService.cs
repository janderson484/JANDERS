using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using VM.FleetServices.TnR.LM.Model.ServiceBus;

namespace VM.FleetServices.TnR.LM.BackendJob
{
    public interface IScrubMessageService
    {
        Dictionary<string, string> ConvertRawMessageToDictionary(string rawMessage);
    }

    /// <summary>
    /// Scrub message also parse the messsage into dictionary
    /// </summary>
    public class ScrubMessageService : IScrubMessageService
    {
        private readonly ILogger _logger;
        private readonly List<string> _requireFields = new List<string> { ServiceBusMessageProperties.ClientCode, ServiceBusMessageProperties.LogId };

        public ScrubMessageService(ILogger<ScrubMessageService> logger)
        {
            _logger = logger;
        }


        public Dictionary<string, string> ConvertRawMessageToDictionary(string rawMessage)
        {
            var values = ConvertJsonToObject(CleanString(rawMessage));
            if (!Validation(values))
            {
                throw new InvalidOperationException("The message has missing require property(ies)");
            }

            return values;
        }

        private static Dictionary<string, string> ConvertJsonToObject(string message)
        {
            var obj = JObject.Parse(message);
            var dic = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (obj.Count > 0)
            {
                foreach (var item in obj)
                {
                    var key = item.Key;
                    var jToken = item.Value;

                    if (jToken.Type != JTokenType.Object)
                        continue;

                    foreach (var child in jToken.Children<JProperty>())
                    {
                        dic.Add(child.Name.ToUpper(), child.Value.ToString());
                    }
                }
            }

            return dic;
        }

        /// <summary>
        /// Remove all junk
        /// </summary>
        /// <param name="body"></param>
        /// <returns></returns>
        private static string CleanString(string body)
        {
            var start = body.IndexOf("{", StringComparison.Ordinal);
            var end = body.LastIndexOf("}", StringComparison.Ordinal) + 1;
            var length = end - start;

            var cleanedJsonString = body.Substring(start, length);
            var veryClean = Regex.Replace(cleanedJsonString, "[^ -~]", "");
            return veryClean;
        }

        /// <summary>
        /// Validate 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        private bool Validation(IReadOnlyDictionary<string, string> values)
        {
            foreach (var value in _requireFields)
            {
                if (values.TryGetValue(value.ToUpper(), out var result))
                    continue;
                _logger.LogDebug($"Missing {value}");
                return false;
            }
            return true;
        }
    }
}
