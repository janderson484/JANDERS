using System;
using System.Collections.Generic;
using System.Text;

namespace VM.FleetServices.TnR.LM.BackendJob.Services
{
    public class IBulkProcessService
    {
    }
}
