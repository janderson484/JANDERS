using Microsoft.Extensions.Logging;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.LM.Data.LabelModel;

namespace VM.FleetServices.TnR.LM.BackendJob.Services
{
    public class BulkProcessService : IBulkProcessService
    {
        private readonly ILogger<BulkProcessService> _logger;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;

        public BulkProcessService(ILogger<BulkProcessService> logger, IUnitOfWorkService<LabelModel> unitOfWorkService)
        {
            _unitOfWorkService = unitOfWorkService;
            _logger = logger;
        }
    }
}
