
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.BackendJob.JobSettings;
using VM.FleetServices.TnR.LM.BackendJob.Models;
using VM.FleetServices.TnR.LM.BackendJob.Services;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations;
using VM.FleetServices.TnR.LM.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using ApiRouteConstants = VM.FleetServices.TnR.LM.BackendJob.Models.ApiRouteConstants;

namespace VM.FleetServices.TnR.LM.BackendJob.Components
{
    public class ExportLabelsPipelineComponent : PipelineComponent, IPipelineComponent
    {
        private readonly ILogger<BulkProcessPipelineComponent> _logger;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILabelManagementService _labelManagementService;
        private readonly WebjobSettings _settings;
        private readonly ApiSettings _apiSettings;
        private readonly IBlobStorage _blobStorage;
        private readonly StorageOptions _storageOptions;
        private readonly IMapper _mapper;

        public ExportLabelsPipelineComponent(ILogger<BulkProcessPipelineComponent> logger, IAuthService authenticationService, IUnitOfWorkService<LabelModel> unitOfWorkService,
            IBulkProcessService bulkProcessService, ILabelManagementService labelManagementService, IOptions<WebjobSettings> settings, IOptions<ApiSettings> apiSettings, IBlobStorage blobStorage, IOptions<StorageOptions> storageOptions, IMapper mapper) : base(logger, authenticationService)
        {
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _labelManagementService = labelManagementService;
            _settings = settings.Value;
            _apiSettings = apiSettings.Value;
            _blobStorage = blobStorage;
            _storageOptions = storageOptions.Value;
            _mapper = mapper;
        }

        /// <summary>
        /// Verifies job in message can be ran
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);

            return clientCode != null && actionCode != null && logId != null && actionCode == LabelProcessNames.ExportLabels.GetDescription();
        }

        /// <summary>
        /// Main driver method to run WebJob Processes
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override async Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.UserName, out var userName);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionDateTime, out var actionDateTime);
            messageValues.TryGetValue(ServiceBusMessageProperties.ProcessingLocationCode, out var processingLocationCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ReportType, out var reportType);
            messageValues.TryGetValue(ServiceBusMessageProperties.SearchCriteria, out var searchCriteria);

            var logDetails = new List<Model.DTO.LogDetail>();

            // var labelsViewModel = JsonConvert.DeserializeObject<SearchLabelViewModel>(searchCriteria);

            Console.WriteLine("Export Labels Pipeline component will be applied");
            var result = new PipelineResult(this);

            // Update the log status to In-Progress for specific LogId
            if (!logId.IsNullOrEmpty())
            {
                var log = await _labelManagementService.GetLogStatusAsync(Convert.ToInt32(logId));

                var labelInputData = new List<Dictionary<string, string>>();
                var filePath = string.Empty;
                var fileName = $"{userName?.Trim()}_{reportType.Replace(' ', '_')}_{DateTime.Now:MMddyyyyHHmmss}.csv";
                var totalCount = 0;
                var processedCount = 0;

                try
                {
                    var currentBatch = 1;
                    var countPerRequest = _settings.ExportReportRequestCount;
                    var processCompletionStatus = false;

                    log = await _labelManagementService.UpdateLogStatusByIdAsync(log.LogId, JobLogStatus.InProgress.GetDescription());

                    totalCount = log.TotalCount;

                    var labelsViewModel = JsonConvert.DeserializeObject<SearchLabelViewModel>(searchCriteria);
                    switch (reportType.ToString())
                    {
                        case Reports.ViewBagLabels:
                            SearchLabelViewModel bagLabelsSearchCriteria = new SearchLabelViewModel();
                            do
                            {
                                //Gets the labels data
                                labelsViewModel.DefaultRowsPerPage = countPerRequest;
                                labelsViewModel.PageNumber = currentBatch;
                                labelsViewModel.Search = false;
                                var results = await _labelManagementService.GetLabelsAsync(labelsViewModel);

                                //Create CSV and appened to blob
                                filePath = await GenerateCSVAsync(results.Results.ToList(), fileName, clientCode, currentBatch == 1 ? true : false);
                                processedCount += results.Results.Count;
                                currentBatch++;

                                //update the log count
                                await UpdateLogCountAsync(processedCount, log);

                                processCompletionStatus = totalCount == processedCount ? true : false;
                            }

                            while (!processCompletionStatus);
                            break;
                        case Reports.ViewUnitLabels:
                            SearchLabelViewModel unitLabelSearchCriteria = new SearchLabelViewModel();
                            do
                            {
                                //Gets the labels data
                                labelsViewModel.DefaultRowsPerPage = countPerRequest;
                                labelsViewModel.PageNumber = currentBatch;
                                labelsViewModel.Search = false;
                                var results = await _labelManagementService.GetLabelsAsync(labelsViewModel);


                                //Create CSV and appened to blob
                                filePath = await GenerateCSVAsync(results.Results.ToList(), fileName, clientCode, currentBatch == 1 ? true : false);
                                processedCount += results.Results.Count;
                                currentBatch++;

                                //update the log count
                                await UpdateLogCountAsync(processedCount, log);

                                processCompletionStatus = totalCount == processedCount ? true : false;
                            }

                            while (!processCompletionStatus);
                            break;
                        default:
                            break;
                    }
                    log.Status = JobLogStatus.Completed.ToString();
                    log.Filename = filePath;
                }
                catch (Exception e)
                {
                    _logger.LogError($"Error processing component {nameof(ExportLabelsPipelineComponent)}: {e.Message}");
                    log.Status = JobLogStatus.Failed.ToString();
                    log.ErrorCount = totalCount - processedCount;

                    var currentLogDate = DateTime.Now;

                    logDetails.Add(new Model.DTO.LogDetail()
                    {
                        Active = true,
                        ErrorType = LogDetailTypeConstants.Error,
                        LogId = log.LogId,
                        CreatedDate = currentLogDate,
                        CreatedUser = log.CreatedUser,
                        ModifiedDate = currentLogDate,
                        ModifiedUser = log.CreatedUser,
                        ErrorMessage = e.InnerException != null ? e.InnerException.Message : e.Message,
                        ErrorRecord = reportType,
                    });
                }
                finally
                {
                    log = await UpdateLogStatusAsync(log, logDetails);
                    var notifications = await _labelManagementService.CreateNotificationsAsync(_mapper.Map<Log>(log));
                    await SendNotificationsAsync(notifications, _apiSettings.Uri + ApiRouteConstants.SendNotification());
                }
            }

            _logger.LogInformation($"Method: {nameof(ProcessAsync)} - Export Labels completed for {actionCode} action.");

            return await Task.FromResult(result);
        }

        /// <summary>
        /// Generates the Csv file and upload to blob.
        /// </summary>
        /// <typeparam name="T">Type of result object for which we need to generate excel.</typeparam>
        /// <param name="results">The results list.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="addHeader">Bit field to add header or not.</param>
        public async Task<string> GenerateCSVAsync<T>(List<T> results, string fileName, string clientCode, bool addHeader = true)
        {
            try
            {
                var csvConfig = new CsvConfiguration(CultureInfo.CurrentCulture)
                {
                    HasHeaderRecord = addHeader,
                };

                using (var memoryStream = new MemoryStream())
                {
                    using (var streamWriter = new StreamWriter(memoryStream))
                    {
                        using (var csvWriter = new CsvWriter(streamWriter, csvConfig))
                        {
                            if (results is List<LabelViewModel>)
                            {
                                csvWriter.Context.RegisterClassMap<LabelViewModelExportHeader>();
                            }
                            csvWriter.WriteRecords(results);
                            streamWriter.Flush();
                        }
                    }

                    var blob = await _blobStorage.AppendBlobAsync(_storageOptions.BlobContainer, clientCode, fileName, memoryStream.ToArray());

                    blob.Properties.ContentType = "text/csv";
                    blob.SetPropertiesAsync().Wait();
                    var filePath = blob.StorageUri.PrimaryUri.ToString();
                    return filePath;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing {nameof(GenerateCSVAsync)}: {ex.Message}");
                throw ex;
            }
        }

        /// <summary>
        /// Private method to update log count
        /// </summary>
        /// <param name="processed"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        private async Task<Model.DTO.Log> UpdateLogCountAsync(int processed, Model.DTO.Log log)
        {
            log.SuccessfulCount = processed;
            return await _labelManagementService.UpdateLogStatusAsync(log, new List<Model.DTO.LogDetail>());
        }

        /// <summary>
        /// Private method to update log status
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        private async Task<Model.DTO.Log> UpdateLogStatusAsync(Model.DTO.Log log, List<Model.DTO.LogDetail> logDetails)
        {
            log.ProcessEndDate = DateTime.Now;
            return await _labelManagementService.UpdateLogStatusAsync(log, logDetails);
        }
    }
}
