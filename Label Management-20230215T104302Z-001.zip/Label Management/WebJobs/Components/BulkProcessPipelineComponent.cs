using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.BackendJob.JobSettings;
using VM.FleetServices.TnR.LM.BackendJob.Services;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using ApiRouteConstants = VM.FleetServices.TnR.LM.BackendJob.Models.ApiRouteConstants;

namespace VM.FleetServices.TnR.LM.BackendJob.Components
{
    public class BulkProcessPipelineComponent : PipelineComponent, IPipelineComponent
    {
        private readonly ILogger<BulkProcessPipelineComponent> _logger;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly IBulkProcessService _bulkProcessService;
        private readonly ILabelManagementService _labelManagementService;
        private readonly WebjobSettings _settings;
        private readonly ApiSettings _apiSettings;

        public BulkProcessPipelineComponent(ILogger<BulkProcessPipelineComponent> logger, IAuthService authenticationService , IUnitOfWorkService<LabelModel> unitOfWorkService, 
            IBulkProcessService bulkProcessService, ILabelManagementService labelManagementService, IOptions<WebjobSettings> settings, IOptions<ApiSettings> apiSettings) : base(logger, authenticationService)
        {
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _bulkProcessService = bulkProcessService;
            _labelManagementService = labelManagementService;
            _settings = settings.Value;
            _apiSettings = apiSettings.Value;
        }

        /// <summary>
        /// Verifies job in message can be ran
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);

            return clientCode != null && actionCode != null && logId != null && (actionCode == ProcessNames.PendingNonActiveBagLabelAction || actionCode == ProcessNames.PendingNonActiveUnitLabelAction || actionCode == ProcessNames.SetPrintedAndActiveToClosedAction || actionCode == ProcessNames.PendingInvoiceLabelAction);
        }

        /// <summary>
        /// Main driver method to run WebJob Processes
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override async Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.UserName, out var userName);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionDateTime, out var actionDateTime);
            messageValues.TryGetValue(ServiceBusMessageProperties.InventoryCode, out var inventoryCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ProcessingLocationCode, out var processingLocationCode);

            Console.WriteLine("Bulk Process Pipeline component will be applied");
            var result = new PipelineResult(this);

            // Update the log status to In-Progress for specific LogId
            if (!logId.IsNullOrEmpty())
            {
                var currentLog = await _labelManagementService.GetLogAsync(Convert.ToInt32(logId)); 

                IPaginate<Data.LabelModel.Entities.Label> labelsToProcess = null;
                IPaginate<Data.LabelModel.Entities.LabelBilling> labelBillingsToProcess = null;

                try
                {
                    var totalLabelsCompletedCount = 0;

                    if (actionCode != LabelProcessNames.ExportLabels.GetDescription())
                    {
                        var totalLabelsRemainingCount = 0;
                        do
                        {
                            if (actionCode == BulkProcessTypes.PendingInvoiceLabelAction.GetDescription())
                            {
                                labelBillingsToProcess = await _labelManagementService.GetInvoicePendingLabelsForBulkProcessAsync(clientCode, _settings.BatchCount);
                            }
                            else
                            {
                                labelsToProcess = await GetBulkProcessLabelsAsync(actionCode, clientCode, processingLocationCode, _settings.BatchCount);
                            }

                            totalLabelsRemainingCount = labelsToProcess != null ? labelsToProcess.Count : labelBillingsToProcess.Count;
                            var currentBatchLabelCount = labelsToProcess != null ? labelsToProcess.Items.Count : labelBillingsToProcess.Items.Count;

                            if (totalLabelsRemainingCount == 0)
                            {
                                currentLog = await _labelManagementService.UpdateLogStatusAsync(currentLog, totalLabelsCompletedCount, totalLabelsRemainingCount); // TODO: Add when LM has logging
                            }
                            else
                            {
                                if (totalLabelsCompletedCount == 0)
                                {
                                    currentLog.TotalCount = totalLabelsRemainingCount;
                                    await _labelManagementService.CreateInProgressLogAsync(currentLog, totalLabelsRemainingCount); // TODO: Add when LM has logging
                                }

                                var response = await PerformBulkProcessActionAsync(actionCode, clientCode, processingLocationCode, userName, inventoryCode, labelsToProcess, labelBillingsToProcess);
                                if(response.ResponseCode != HttpStatusCode.OK)
                                {
                                    currentLog = await _labelManagementService.CreateLogFailedAsync(currentLog);
                                    await _labelManagementService.CreateLogDetailsErrorsAsync(currentLog, response.ErrorMessage, labelsToProcess,labelBillingsToProcess);
                                    _logger.LogError($"BackendJob: {nameof(BulkProcessPipelineComponent)}; Method: {nameof(ProcessAsync)}; Error: {response.ErrorMessage}");
                                    return await Task.FromResult(result);
                                }
                                totalLabelsCompletedCount += currentBatchLabelCount;
                                totalLabelsRemainingCount -= currentBatchLabelCount;
                                currentLog = await _labelManagementService.UpdateLogStatusAsync(currentLog, totalLabelsCompletedCount, totalLabelsRemainingCount);
                            }

                        }

                        while (totalLabelsRemainingCount != 0);
                    }
                }
                catch (Exception e)
                {
                    currentLog = await _labelManagementService.CreateLogFailedAsync(currentLog);
                    await _labelManagementService.CreateLogDetailsErrorsAsync(currentLog, e.Message, labelsToProcess, labelBillingsToProcess);
                    _logger.LogError($"BackendJob: {nameof(BulkProcessPipelineComponent)}; Method: {nameof(ProcessAsync)}; Error: {e.Message}");
                }
                finally
                {
                    var notification = await _labelManagementService.CreateNotificationsAsync(currentLog);
                    var notificationUri = _apiSettings.Uri + ApiRouteConstants.SendNotification();
                    await SendNotificationsAsync(notification, notificationUri);
                }
            }

            _logger.LogInformation($"Method: {nameof(ProcessAsync)} - Bulk Process completed for {actionCode} action.");

            return await Task.FromResult(result);
        }



        /// <summary>
        /// Gets list of Labels for BulkProcessing based on ActionCode name
        /// </summary>
        /// <param name="actionCode">BulkProcess action</param>
        /// <param name="clientCode">ClientCode to get Plates</param>
        /// <param name="processingLocationCode">ProcessingLocation to get Plates</param>
        /// <param name="batchSize">Configured BatchSize for BulkProcess</param>
        /// <returns>List of Label entities for desired BulkAction</returns>
        private async Task<IPaginate<Data.LabelModel.Entities.Label>> GetBulkProcessLabelsAsync(
            string actionCode, string clientCode, string processingLocationCode, int batchSize = 20)
        {
            actionCode = Regex.Replace(actionCode, @"\s+", "");
            switch (actionCode)
            {
                case nameof(BulkProcessTypes.PendingNonActiveBagLabelAction):
                    return await _labelManagementService.GetPendingNonActiveLabelsForBulkProcessAsync(clientCode, processingLocationCode, (int)Labeltypes.Bag, batchSize);
                case nameof(BulkProcessTypes.PendingNonActiveUnitLabelAction):
                    return await _labelManagementService.GetPendingNonActiveLabelsForBulkProcessAsync(clientCode, processingLocationCode, (int)Labeltypes.Unit, batchSize);
                case nameof(BulkProcessTypes.SetPrintedAndActiveToClosedAction):
                    return await _labelManagementService.CloseActivePrintedLabelsForBulkProcessAsync(clientCode, processingLocationCode, batchSize);
                default:
                    return null;
            }
        }

        /// <summary>
        /// Performs Bulk Action based on an Action Code
        /// </summary>
        /// <param name="actionCode"></param>
        /// <param name="labelsToProcess"></param>
        /// <param name="clientCode"></param>
        /// <param name="processingLocationCode"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private async Task<ApiResponseDto> PerformBulkProcessActionAsync(string actionCode, string clientCode, string processingLocationCode, string userName, string inventoryCode, IPaginate<Data.LabelModel.Entities.Label> labelsToProcess = null, IPaginate<Data.LabelModel.Entities.LabelBilling> labelBillingsToProcess = null)
        {
            try
            {
                actionCode = Regex.Replace(actionCode, @"\s+", "");
                switch (actionCode)
                {
                    case nameof(BulkProcessTypes.PendingNonActiveBagLabelAction):
                    case nameof(BulkProcessTypes.PendingNonActiveUnitLabelAction):
                        await PerformPendingNonActiveLabelActionAsync(labelsToProcess, userName, clientCode, processingLocationCode);
                        break;
                    case nameof(BulkProcessTypes.SetPrintedAndActiveToClosedAction):
                        await CloseActivePrintedLabelsAsync(labelsToProcess, userName, clientCode, processingLocationCode);
                        break;
                    case nameof(BulkProcessTypes.PendingInvoiceLabelAction):
                        return await _labelManagementService.PerformBulkInvoiceAsync(clientCode, userName, null, labelBillingsToProcess.Items.ToList());
                }
                return new ApiResponseDto() {
                    ResponseCode = HttpStatusCode.OK
                };
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(PerformBulkProcessActionAsync)} - A critical error occurred while selecting appropriate bulk action.\r\n " +
                                 $"Message: {e.Message} ");

                throw;
            }
        }

        /// <summary>
        /// Updates LabelStatusType for list of Labels to Active
        /// </summary>
        /// <param name="labelsToProcess"></param>
        /// <returns></returns>
        private async Task PerformPendingNonActiveLabelActionAsync(IPaginate<Data.LabelModel.Entities.Label> labelsToProcess, string userName, string clientCode, string processingLocationCode)
        {
            try
            {
                _logger.LogInformation($"Method: {nameof(PerformPendingNonActiveLabelActionAsync)} - Start Bulk Action to update Pending labels to Active.");

                var labelIds = labelsToProcess.Items.Select(l => l.LabelId).ToList();
                var labelVins = labelsToProcess.Items.Select(l => l.VIN).ToList();

                var duplicateLabels = await _labelManagementService.GetActiveLabelsByVinsAsync(clientCode, processingLocationCode, labelVins);
                var duplicateLabelVins = duplicateLabels.Items.Select(l => l.VIN).ToList().Distinct();

                labelsToProcess.Items.Where(l => !duplicateLabelVins.Contains(l.VIN)).ToList().ForEach(x => x.LabelStatusTypeId = (int)LabelStatusTypes.Active);
                labelsToProcess.Items.Where(l => duplicateLabelVins.Contains(l.VIN)).ToList().ForEach(x => x.LabelStatusTypeId = (int)LabelStatusTypes.Duplicate);

                _unitOfWorkService.GetRepositoryAsync<Data.LabelModel.Entities.Label>().UpdateAsync(labelsToProcess.Items.ToArray());

                // TODO: Does LM have billing fees methods like PM? If not, can remove. Until then this method will remain async
                //await _plateManagementService.SavePlateBillingsAsync(plateIds, await _tnrService.GetBillingLookupsAsync(), userName);

                _unitOfWorkService.SaveChanges(); // TODO: This can be moved to logging methods when they are added to LM

                _logger.LogInformation($"Method: {nameof(PerformPendingNonActiveLabelActionAsync)} - End Bulk Action to update Pending labels to Active.");
            }
            catch (Exception e)
            {
                throw;
            }

        }

        /// <summary>
        /// Updates LabelStatusType for list of Labels to Closed
        /// </summary>
        /// <param name="labelsToProcess"></param>
        /// <param name="userName"></param>
        /// <param name="clientCode"></param>
        /// <param name="processingLocationCode"></param>
        /// <returns></returns>
        private async Task CloseActivePrintedLabelsAsync(IPaginate<Data.LabelModel.Entities.Label> labelsToProcess, string userName, string clientCode, string processingLocationCode)
        {
            try
            {
                _logger.LogInformation($"Method: {nameof(CloseActivePrintedLabelsAsync)} - Start Bulk Action to Close Active Printed Labels.");

                var labelIds = labelsToProcess.Items.Select(x => x.LabelId).ToList();
                var labelVins = labelsToProcess.Items.Select(l => l.VIN).ToList();

                var duplicateLabels = await _labelManagementService.GetActiveLabelsByVinsAsync(clientCode, processingLocationCode, labelVins);
                var duplicateLabelVins = duplicateLabels.Items.Select(l => l.VIN).ToList().Distinct();

                labelsToProcess.Items.Where(x => !duplicateLabelVins.Contains(x.VIN)).ToList().ForEach(x => x.LabelStatusTypeId = (int)LabelStatusTypes.Closed);
                labelsToProcess.Items.Where(x => duplicateLabelVins.Contains(x.VIN)).ToList().ForEach(x => x.LabelStatusTypeId = (int)LabelStatusTypes.Duplicate);
                labelsToProcess.Items.Where(x => labelIds.Contains(x.LabelId)).ToList().ForEach(x => x.ModifiedDate = DateTime.Now);

                _unitOfWorkService.GetRepositoryAsync<Data.LabelModel.Entities.Label>().UpdateAsync(labelsToProcess.Items.ToArray());
                _unitOfWorkService.SaveChanges();

                _logger.LogInformation($"Method: {nameof(CloseActivePrintedLabelsAsync)} - End Bulk Action to Close Active Printed Labels.");
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
