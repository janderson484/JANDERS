using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.LM.BackendJob.JobSettings;
using VM.FleetServices.TnR.LM.BackendJob.Services;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.Mvc;
using AutoMapper;
using VM.FleetServices.TnR.LM.Business.Integrations;
using ApiRouteConstants = VM.FleetServices.TnR.LM.BackendJob.Models.ApiRouteConstants;

namespace VM.FleetServices.TnR.LM.BackendJob.Components
{
    public class ImportLabelsProcessComponent : PipelineComponent, IPipelineComponent
    {

        private readonly ILogger<BulkProcessPipelineComponent> _logger;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILabelManagementService _labelManagementService;
        private readonly WebjobSettings _settings;
        private readonly ApiSettings _apiSettings;
        private readonly IMapper _mapper;

        public ImportLabelsProcessComponent(ILogger<BulkProcessPipelineComponent> logger, IAuthService authenticationService, IUnitOfWorkService<LabelModel> unitOfWorkService,
             ILabelManagementService labelManagementService, IOptions<WebjobSettings> settings, IOptions<ApiSettings> apiSettings, IMapper mapper) : base(logger, authenticationService)
        {
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _labelManagementService = labelManagementService;
            _settings = settings.Value;
            _apiSettings = apiSettings.Value;
            _mapper = mapper;
        }



        /// <summary>
        /// Verifies job in message can be ran
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);

            if (actionCode == ProcessNames.ImportLabels)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Process the request
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override async Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues)
        {
            var log = new DTO.Log();
            var logDetails = new List<DTO.LogDetail>();
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logIdStr);
            var logId = Convert.ToInt32(logIdStr);
            var result = new PipelineResult(this);

            try
            {
                log = await _labelManagementService.UpdateLogStatusByIdAsync(logId, JobLogStatus.InProgress.GetDescription());
                var importLabelRequestDetails = await _labelManagementService.GetImportLabelDetailsAsync(logId, clientCode);

                if (importLabelRequestDetails == null || !importLabelRequestDetails.Any())
                {
                    throw new Exception("Import label request details not found");
                }

                var generateBagLabel = importLabelRequestDetails.FirstOrDefault().GenerateBagFlag;
                var labelTypeId = importLabelRequestDetails.FirstOrDefault().LabelTypeId;

                //Validates the labels for duplicates by VIN
                var labelValidation = await _labelManagementService.ValidateImportLabelRequestAsync(importLabelRequestDetails, clientCode);
                if (labelValidation.IsValid)
                {
                    //Creates model for unit and bag labels 
                    var model = CreateLabelModel(importLabelRequestDetails, (Labeltypes)labelTypeId, log, clientCode);
                    await _labelManagementService.AddLabelsAsync(model);

                    //Creates Bag labels on label type or if generate bag label is selected
                    if (labelTypeId == (int)Labeltypes.Unit && generateBagLabel)
                    {
                        var bagModel = CreateLabelModel(importLabelRequestDetails, Labeltypes.Bag, log, clientCode);
                        await _labelManagementService.AddLabelsAsync(bagModel);
                    }
                    log.SuccessfulCount += importLabelRequestDetails.Count;
                    log.Status = JobLogStatus.Completed.GetDescription();
                }
                else
                {
                    var vin = labelValidation.ActualRecord.Split(',');
                    if (vin != null && vin.Length > 0)
                    {
                        var currentLogDate = DateTime.Now;
                        foreach (var item in vin)
                        {
                            logDetails.Add(new DTO.LogDetail()
                            {
                                Active = true,
                                ErrorType = LogDetailType.Error.GetDescription(),
                                LogId = log.LogId,
                                CreatedDate = currentLogDate,
                                CreatedUser = log.CreatedUser,
                                ModifiedDate = currentLogDate,
                                ModifiedUser = log.CreatedUser,
                                ErrorMessage = labelValidation.ErrorMessage,
                                ErrorRecord = item,
                            });
                        }
                    }
                    log.ErrorCount = log.TotalCount;
                    log.Status = JobLogStatus.Completed.GetDescription();
                }
                await _labelManagementService.DeleteImportLabelRequestAsync(logId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing component {nameof(ImportLabelsProcessComponent)}: {ex.Message}");
                log.Status = JobLogStatus.Failed.GetDescription();
                log.ErrorCount = log.TotalCount;
                log.SuccessfulCount = 0;

                var currentLogDate = DateTime.Now;

                logDetails.Add(new DTO.LogDetail()
                {
                    Active = true,
                    ErrorType = LogDetailType.Error.GetDescription(),
                    LogId = log.LogId,
                    CreatedDate = currentLogDate,
                    CreatedUser = log.CreatedUser,
                    ModifiedDate = currentLogDate,
                    ModifiedUser = log.CreatedUser,
                    ErrorMessage = $"Error at {nameof(ImportLabelsProcessComponent)} - method {nameof(ProcessAsync)}. Error: " + ex.Message,
                    ErrorRecord = string.Empty,
                });
            }
            finally
            {
                log = await UpdateLogStatusAsync(log, logDetails);
                var notifications = await _labelManagementService.CreateNotificationsAsync(_mapper.Map<Log>(log));
                await SendNotificationsAsync(notifications, _apiSettings.Uri + ApiRouteConstants.SendNotification());
            }
            return await Task.FromResult(result);
        }

        /// <summary>
        /// Creates Label model based on label type
        /// </summary>
        /// <param name="importLabels"></param>
        /// <param name="log"></param>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        private List<Label> CreateLabelModel(List<DTO.ImportLabelRequest> importLabels, Labeltypes labeltype, DTO.Log log, string clientCode)
        {
            var labelEntity = new List<Label>();
            foreach (var item in importLabels)
            {
                var label = new Label();
                var type = label.GetType();
                var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(item.ImportLabelRecord);
                foreach (var labelData in values)
                {
                    var key = labelData.Key;
                    if (key.Contains("_"))
                        key = key.Replace("_", "");

                    // Special case for Owning_Area and OwningAreaDeliveryCode
                    // This is a temporary workaround to fix issue  259216 Unit Labels are not printing as expected
                    // owningareadeliverycode is null for many labels
                    // TODO: owningareadelivercode must be renamed to owningarea everywhere including database entity
                    if (key.ToLower() == "owningarea")
                        key = "OwningAreaDeliveryCode";
                    
                    var propertyInfo = type.GetProperty(key);
                    if (propertyInfo != null)
                    {
                        propertyInfo.SetValue(label, labelData.Value);
                    }
                }
                label.ClientCode = clientCode;
                label.ProcessingLocationCode = item.ProcessingOffice;
                label.StateProvinceCode = string.Empty;
                label.LabelStatusTypeId = (int)LabelStatusTypes.Active;
                label.LabelTypeId = (int)labeltype;
                label.CreatedDate = DateTime.Now;
                label.ModifiedDate = DateTime.Now;
                label.CreatedUser = log.CreatedUser;
                label.ModifiedUser = log.CreatedUser;
                label.IsPrinted = false;
                label.PrintCount = 0;
                labelEntity.Add(label);
            }
            return labelEntity;
        }

        /// <summary>
        /// Private method to update log status
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        private async Task<DTO.Log> UpdateLogStatusAsync(DTO.Log log, List<DTO.LogDetail> logDetails)
        {
            log.ProcessEndDate = DateTime.Now;
            return await _labelManagementService.UpdateLogStatusAsync(log, logDetails);
        }
    }
}
