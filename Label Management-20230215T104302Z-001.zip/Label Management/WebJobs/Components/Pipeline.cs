using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace VM.FleetServices.TnR.LM.BackendJob.Components
{
    public class Pipeline
    {
        private readonly Queue<IDictionary<string, string>> _processingQueue;
        public Pipeline(Queue<IDictionary<string, string>> processingQueue)
        {
            _processingQueue = processingQueue;
        }

        private readonly List<Type> _components = new List<Type>();

        public IEnumerable<Type> Components => _components;

        public void AddComponent<T>() where T : IPipelineComponent
        {
            _components.Add(typeof(T));
        }

        public async Task<IEnumerable<PipelineResult>> RunAsync(IServiceProvider serviceProvider, IReadOnlyDictionary<string, string> messageValues)
        {
            var results = new List<PipelineResult>();
            foreach (var componentType in Components)
            {
                var component = (IPipelineComponent)serviceProvider.GetRequiredService(componentType);

                var pipelineResult = new PipelineResult(component) { Processed = false };
                if (component.CanProcess(messageValues))
                {
                    pipelineResult = await component.ProcessAsync(messageValues);

                }
                results.Add(pipelineResult);

                if (pipelineResult.ActionResults.Any())
                {
                    // re-entrant processing pipeline
                    foreach (var actionResult in pipelineResult.ActionResults)
                    {
                        _processingQueue.Enqueue(actionResult);
                    }
                }
            }

            return results;
        }
    }
}
