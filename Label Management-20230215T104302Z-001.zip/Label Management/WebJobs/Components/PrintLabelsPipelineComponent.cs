using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.LM.BackendJob.JobSettings;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using DTO = VM.FleetServices.TnR.LM.Model.DTO;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.Core.Common.Extensions;
using System.Linq;
using Aspose.Pdf;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Business.Integrations.PrinterService;
using VM.FleetServices.TnR.LM.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using AutoMapper;
using System.Reflection;
using VM.FleetServices.TnR.LM.Business.Integrations;
using ApiRouteConstants = VM.FleetServices.TnR.LM.BackendJob.Models.ApiRouteConstants;

namespace VM.FleetServices.TnR.LM.BackendJob.Components
{
    public class PrintLabelsPipelineComponent : PipelineComponent, IPipelineComponent
    {
        private readonly ILogger<PrintLabelsPipelineComponent> _logger;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILabelManagementService _labelManagementService;
        private readonly IPrinterService _printerService;
        private readonly WebjobSettings _settings;
        private readonly ApiSettings _apiSettings;
        private readonly StorageOptions _storageOptions;
        private readonly IBlobStorage _blobStorage;
        private readonly IMapper _mapper;
        private readonly IConfigurationService _configurationService;

        public PrintLabelsPipelineComponent(ILogger<PrintLabelsPipelineComponent> logger, IAuthService authenticationService, IUnitOfWorkService<LabelModel> unitOfWorkService,
                                             ILabelManagementService labelManagementService, IPrinterService printerService, IOptions<WebjobSettings> settings,
                                             IOptions<ApiSettings> apiSettings, IOptions<StorageOptions> storageOptions, IMapper mapper, IConfigurationService configurationService) : base(logger, authenticationService)
        {
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _labelManagementService = labelManagementService;
            _printerService = printerService;
            _settings = settings.Value;
            _apiSettings = apiSettings.Value;
            _storageOptions = storageOptions.Value;
            _blobStorage = new CloudBlobStorage(_storageOptions.StorageConnection, _storageOptions.LabelBlobContainer);
            _mapper = mapper;
            _configurationService = configurationService;
        }


        /// <summary>
        /// Verifies job in message can be ran
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);

            if (actionCode == ProcessNames.PrintBagLabels || actionCode == ProcessNames.PrintUnitLabels)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Main driver method to run WebJob Processes
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override async Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues)
        {
            var log = new DTO.Log();
            var logDetails = new List<DTO.LogDetail>();
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logIdStr);
            messageValues.TryGetValue(ServiceBusMessageProperties.PrintLabelRequestId, out var printLabelRequestId);
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ProcessingLocationCode, out var processingLocationCode);
            var logId = Convert.ToInt32(logIdStr);
            var jobPrintLabelRequestId = Convert.ToInt32(printLabelRequestId);
            var result = new PipelineResult(this);
            var printResponseModel = new PrintResponseModel();
            var isPrintEnabled = false;

            try
            {
                log = await _labelManagementService.UpdateLogStatusByIdAsync(logId, JobLogStatus.InProgress.GetDescription());

                // Get Label Data before Printing
                var labelPrintData = _labelManagementService.GetLabelsPrintData(jobPrintLabelRequestId);

                var personalSettings = await _configurationService.GetPersonalSettingsAsync(log.CreatedUser, clientCode, processingLocationCode);

                isPrintEnabled = !_settings.IsPrintLabelsToEnabled || personalSettings.LabelsToPrinter;

                if(_settings.IsPrintLabelsToEnabled && !personalSettings.LabelsToPrinter && !personalSettings.LabelsToPDF)
                {
                        throw new Exception("Print functionality is disabled");
                }
                printResponseModel = await _printerService.PrintDocumentAsync(jobPrintLabelRequestId, isPrintEnabled, personalSettings.LabelsToPDF);

                switch (printResponseModel.LabelTypeId)
                {
                    case (int)Labeltypes.Bag:
                        log.ProcessName = ProcessNames.PrintBagLabels;
                        break;
                    case (int)Labeltypes.Unit:
                        log.ProcessName = ProcessNames.PrintUnitLabels;
                        break;
                }

                // Store the pdf in azure regardless of a print error
                if (_settings.IsPrintLabelsToEnabled && personalSettings.LabelsToPDF && printResponseModel.PrintDocuments != null)
                {
                    var filePath = SaveDocumentInAzureAsync(printResponseModel, clientCode);
                    log.Filename = filePath;
                }

                log.SuccessfulCount = printResponseModel.SuccessCount;
                log.ErrorCount = printResponseModel.ErrorCount;

                if (printResponseModel.LabelIds != null && printResponseModel.LabelIds.Count > 0)
                {
                    labelPrintData = labelPrintData.Where(l => printResponseModel.LabelIds.Contains(l.LabelId)).ToList();
                    await SaveBillingChargeIncrementPrintCountAsync(labelPrintData, log, printResponseModel);
                }

                if (printResponseModel.HasError)
                {
                    log.Status = JobLogStatus.Failed.GetDescription();
                    var currentLogDate = DateTime.Now;

                    logDetails.Add(new DTO.LogDetail()
                    {
                        Active = true,
                        ErrorType = LogDetailType.Error.GetDescription(),
                        LogId = log.LogId,
                        CreatedDate = currentLogDate,
                        CreatedUser = log.CreatedUser,
                        ModifiedDate = currentLogDate,
                        ModifiedUser = log.CreatedUser,
                        ErrorMessage = printResponseModel.ErrorDescription,
                        ErrorRecord = string.Empty,
                    });
                }
                else
                {
                    log.Status = JobLogStatus.Completed.GetDescription();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing component {nameof(PrintLabelsPipelineComponent)}: {ex.Message}");
                log.Status = JobLogStatus.Failed.GetDescription();
                log.ErrorCount = log.TotalCount;
                log.SuccessfulCount = 0;

                var currentLogDate = DateTime.Now;

                logDetails.Add(new DTO.LogDetail()
                {
                    Active = true,
                    ErrorType = LogDetailType.Error.GetDescription(),
                    LogId = log.LogId,
                    CreatedDate = currentLogDate,
                    CreatedUser = log.CreatedUser,
                    ModifiedDate = currentLogDate,
                    ModifiedUser = log.CreatedUser,
                    ErrorMessage = $"Error at {nameof(PrintLabelsPipelineComponent)} - method {nameof(ProcessAsync)}. Error: " + ex.Message,
                    ErrorRecord = string.Empty,
                });
            }
            finally
            {
                log = await UpdateLogStatusAsync(log, logDetails);
                if (jobPrintLabelRequestId > 0)
                    _printerService.DeletePrintRequest(jobPrintLabelRequestId);
                var notifications = await _labelManagementService.CreateNotificationsAsync(_mapper.Map<Log>(log));
                await SendNotificationsAsync(notifications, _apiSettings.Uri + ApiRouteConstants.SendNotification());
            }
            return await Task.FromResult(result);
        }

        /// <summary>
        /// Saves the pdf in azure
        /// </summary>
        /// <param name="printResponseModel"></param>
        /// <param name="clientCode"></param>
        private string SaveDocumentInAzureAsync(PrintResponseModel printResponseModel, string clientCode)
        {
            var pathAndFileName = string.Empty;
            try
            {
                if (printResponseModel.PrintDocuments.Count > 0 && printResponseModel.PrintDocuments.First().Length > 0)
                {
                    string fileName = null;
                    switch (printResponseModel.LabelTypeId)
                    {
                        case 1:

                            fileName += $"UnitLabels {DateTime.Now:MM-dd-yyyy HH-mm-ss}.pdf";
                            break;
                        case 2:
                            fileName += $"BagLabels {DateTime.Now:MM-dd-yyyy HH-mm-ss}.pdf";
                            break;
                    }

                    using (var pdfMemoryStream = new MemoryStream(printResponseModel.PrintDocuments.First()) { Position = 0 })
                    {
                        //TODO: Determine ClientCode from message request
                        var blob = _blobStorage.UploadBlobAsync(_storageOptions.LabelBlobContainer, clientCode, fileName, pdfMemoryStream).Result;
                        blob.Properties.ContentType = "application/pdf";
                        blob.SetPropertiesAsync().Wait();
                        pathAndFileName = blob.StorageUri.PrimaryUri.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                var errorMessage = $"Method: {nameof(SaveDocumentInAzureAsync)} resulted in error!\r\nError details:{e.Message}.\r\nInner Exception: { e.InnerException?.Message ?? "No inner exception details"}";
                throw new Exception(errorMessage);
            }

            return pathAndFileName;
        }

        /// <summary>
        /// Private method to update log status
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        private async Task<DTO.Log> UpdateLogStatusAsync(DTO.Log log, List<DTO.LogDetail> logDetails)
        {
            log.ProcessEndDate = DateTime.Now;
            return await _labelManagementService.UpdateLogStatusAsync(log, logDetails);
        }

        private async Task SaveBillingChargeIncrementPrintCountAsync(List<LabelViewModel> labelPrintData, DTO.Log log, PrintResponseModel printResponseModel)
        {
            try
            {              
                    await _labelManagementService.SaveLabelBillingsAsync(labelPrintData, log.CreatedUser);

                    await _printerService.IncrementLabelPrintCountsAsync(printResponseModel.LabelIds);             
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        
    }
}
