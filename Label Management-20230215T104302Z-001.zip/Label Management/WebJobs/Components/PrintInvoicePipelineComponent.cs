using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Aspose.Pdf;
using Aspose.Pdf.Drawing;
using Aspose.Pdf.Forms;
using Aspose.Pdf.Text;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using VM.FleetServices.TnR.Core.Common.ApiHelpers;
using VM.FleetServices.TnR.Core.Common.Data.Repository;
using VM.FleetServices.TnR.Core.Common.Extensions;
using VM.FleetServices.TnR.Core.Common.Mvc;
using VM.FleetServices.TnR.LM.BackendJob.JobSettings;
using VM.FleetServices.TnR.LM.BackendJob.Models;
using VM.FleetServices.TnR.LM.Business;
using VM.FleetServices.TnR.LM.Business.Integrations;
using VM.FleetServices.TnR.LM.Business.Integrations.InvoiceManagementService;
using VM.FleetServices.TnR.LM.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Core.Common.AzureStorage;
using VM.FleetServices.TnR.LM.Data.LabelModel;
using VM.FleetServices.TnR.LM.Data.LabelModel.Entities;
using VM.FleetServices.TnR.LM.Model;
using VM.FleetServices.TnR.LM.Model.Enums;
using VM.FleetServices.TnR.LM.Model.ServiceBus;
using VM.FleetServices.TnR.LM.Model.ViewModel;
using ApiRouteConstants = VM.FleetServices.TnR.LM.BackendJob.Models.ApiRouteConstants;

namespace VM.FleetServices.TnR.LM.BackendJob.Components
{
    class PrintInvoicePipelineComponent : PipelineComponent, IPipelineComponent
    {

        private readonly ILogger<BulkProcessPipelineComponent> _logger;
        private readonly IUnitOfWorkService<LabelModel> _unitOfWorkService;
        private readonly ILabelManagementService _labelManagementService;
        private readonly IInvoiceService _invoiceService;
        private readonly WebjobSettings _settings;
        private readonly ApiSettings _apiSettings;
        private readonly IBlobStorage _blobStorage;
        private readonly StorageOptions _storageOptions;
        private readonly IMapper _mapper;
        public PrintInvoicePipelineComponent(ILogger<BulkProcessPipelineComponent> logger, IAuthService authenticationService,   IUnitOfWorkService<LabelModel> unitOfWorkService,
           IInvoiceService invoiceService, ILabelManagementService labelManagementService, IOptions<WebjobSettings> settings, IOptions<ApiSettings> apiSettings, IBlobStorage blobStorage, IOptions<StorageOptions> storageOptions, IMapper mapper) : base(logger, authenticationService)
        {
            _logger = logger;
            _unitOfWorkService = unitOfWorkService;
            _labelManagementService = labelManagementService;
            _settings = settings.Value;
            _invoiceService = invoiceService;
            _apiSettings = apiSettings.Value;
            _blobStorage = blobStorage;
            _storageOptions = storageOptions.Value;
            _mapper = mapper;
        }

        /// <summary>
        /// Verifies job in message can be ran
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override bool CanProcess(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);

            return clientCode != null && actionCode != null && logId != null && actionCode == LabelProcessNames.PrintInvoice.GetDescription();
        }

        /// <summary>
        /// Main driver method to run WebJob Processes
        /// </summary>
        /// <param name="messageValues"></param>
        /// <returns></returns>
        public override async Task<PipelineResult> ProcessAsync(IReadOnlyDictionary<string, string> messageValues)
        {
            messageValues.TryGetValue(ServiceBusMessageProperties.LogId, out var logId);
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientCode, out var clientCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ActionCode, out var actionCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.UserName, out var userName);
            messageValues.TryGetValue(ServiceBusMessageProperties.InvoiceID, out var invoiceId);
            messageValues.TryGetValue(ServiceBusMessageProperties.ProcessingLocationCode, out var processingLocationCode);
            messageValues.TryGetValue(ServiceBusMessageProperties.ClientId, out var clientId);
            messageValues.TryGetValue(ServiceBusMessageProperties.ProcessingLocationId, out var processingLocationId);

            var log = new Model.DTO.Log();
            var logDetails = new List<Model.DTO.LogDetail>();
            var result = new PipelineResult(this);

            try
            {
                if (logId.IsNullOrEmpty())
                {
                    throw new Exception("Invalid JobLog Id");
                }

                if (invoiceId.IsNullOrEmpty())
                {
                    throw new Exception("Invalid Invoice Id");
                }

                log = await _labelManagementService.UpdateLogStatusByIdAsync(Convert.ToInt32(logId), JobLogStatus.InProgress.GetDescription());
                var invoiceData = await GetInvoiceDataToPrintAsync(new SearchInvoiceDataToPrintViewModel() { InvoiceId = Convert.ToInt32(invoiceId), ProcessingLocationCode = processingLocationCode, ClientId = Convert.ToInt32(clientId), ProcessingLocationId = Convert.ToInt32(processingLocationId),ClientCode = clientCode });
                if (invoiceData == null)
                {
                    throw new Exception($"Invoice data not found for the Invoice Id {invoiceId}");
                }

                var invoicePDF = GenerateInvoicePDF(invoiceData);
                if (invoicePDF == null)
                {
                    throw new Exception("Error generating Invoice PDF");
                }

                var filePath = SaveDocumentInAzure(invoicePDF, clientCode, invoiceData.InvoiceName);

                log.Filename = filePath;
                log.SuccessfulCount = 1;
                log.Status = JobLogStatus.Completed.GetDescription();
            }
            catch (Exception e)
            {
                _logger.LogError($"Error processing component {nameof(ExportLabelsPipelineComponent)}: {e.Message}");
                log.Status = JobLogStatus.Failed.ToString();
                log.ErrorCount = log.TotalCount;

                var currentLogDate = DateTime.Now;

                logDetails.Add(new Model.DTO.LogDetail()
                {
                    Active = true,
                    ErrorType = LogDetailTypeConstants.Error,
                    LogId = log.LogId,
                    CreatedDate = currentLogDate,
                    CreatedUser = log.CreatedUser,
                    ModifiedDate = currentLogDate,
                    ModifiedUser = log.CreatedUser,
                    ErrorMessage = e.InnerException != null ? e.InnerException.Message : e.Message,
                    ErrorRecord = invoiceId,
                });
            }
            finally
            {
                log = await UpdateLogStatusAsync(log, logDetails);
                var notifications = await _labelManagementService.CreateNotificationsAsync(_mapper.Map<Log>(log));
                await SendNotificationsAsync(notifications, _apiSettings.Uri + ApiRouteConstants.SendNotification());
            }
            return await Task.FromResult(result);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private async Task<SearchInvoiceDataToPrintViewModel> GetInvoiceDataToPrintAsync(SearchInvoiceDataToPrintViewModel model)
        {
            try
            {
                var response = await _invoiceService.GetInvoiceDataToPrintAsync(model);
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Invoice HTTP Service Response was not successful");
                }

                var result = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<SearchInvoiceDataToPrintViewModel>>(result);

                serviceResponse.Data.InvoiceDetails = await MapBillingDetailsAsync(serviceResponse.Data.InvoiceDetails);

                return serviceResponse.Data;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing component {nameof(ExportLabelsPipelineComponent)}: {ex.Message}");
                throw ex;
            }

        }
        /// <summary>
        /// Maps the billing data with the billing lookups
        /// </summary>
        /// <param name="invoiceDetails"></param>
        /// <returns></returns>
        private async Task<List<InvoiceDetailsViewModel>> MapBillingDetailsAsync(List<InvoiceDetailsViewModel> invoiceDetails)
        {
            var billingLookups = await _labelManagementService.GetBillingLookupsAsync();
            invoiceDetails.ForEach(i =>
            {
                var billing = (billingLookups.BillingFees == null) ? null : billingLookups.BillingFees.Where(x => x.BillingFeeId == i.BillingFeeId).FirstOrDefault();
                if (billing != null)
                {
                    i.BillingFee = billing.DisplayName;
                    i.BillingReason = (billingLookups.BillingFees == null) ? string.Empty : billingLookups.BillingFees.Where(x => x.BillingReasonTypeId == billing.BillingReasonTypeId).Select(x => x.DisplayName).FirstOrDefault();
                    i.BillingItemType = (billingLookups.BillingItemTypes == null) ? string.Empty : billingLookups.BillingItemTypes.Where(x => x.BillingItemTypeId == billing.BillingItemTypeId).Select(x => x.DisplayName).FirstOrDefault();
                }
            });
            return invoiceDetails;
        }

        /// <summary>
        /// Generates Invoice PDF for printing
        /// </summary>
        /// <param name="invoiceData"></param>
        private byte[] GenerateInvoicePDF(SearchInvoiceDataToPrintViewModel invoiceData)
        {
            try
            {
                if (invoiceData.InvoiceDetails.Count == 0)
                {
                    throw new Exception("This Invoice has no Charges to Print!");
                }

                if (invoiceData.InvoiceToAddress == null)
                {
                    throw new Exception("This Client has no configured Invoice Contact");
                }

                if (invoiceData.InvoiceFromAddress == null)
                {
                    throw new Exception("This Processing Location has no configured Invoice Contact");
                }

                var pdfTemplateLocation = Assembly.GetExecutingAssembly().GetManifestResourceStream("VM.FleetServices.TnR.LM.BackendJob.Properties.PrintInvoicesTemplateForm.pdf");
                var pdfDocument = new Document(pdfTemplateLocation);
                var currentPageNumber = 1;
                var currentPage = pdfDocument.Pages[1];

                currentPage.PageInfo.Height = PageSize.PageLetter.Height;
                currentPage.PageInfo.Width = PageSize.PageLetter.Width;
                currentPage.PageInfo.Margin = new MarginInfo(0, 0, 0, 0);

                /* Invoice Fields */
                var invoiceNumberField = pdfDocument.Form["InvoiceNumber"] as TextBoxField;
                var invoiceDateField = pdfDocument.Form["InvoiceDate"] as TextBoxField;

                invoiceNumberField.Value = "Invoice: " + invoiceData.InvoiceName;
                invoiceDateField.Value = invoiceData.InvoiceCreatedDate.ToString("MM/dd/yyyy");

                /*
                 *  Invoice "To Address" Fields
                 *      ContactName (Optional?)
                 *      CompanyClientName (Optional?)
                 *      Address1 (Required)
                 *      Address2 (Optional)
                 *      City (Required), StateProvinceCode (Required) ZipCode (Required)
                 */
                var currentToAddressFieldNumber = 1;
                TextBoxField currentToAddressField = null;

                if (!invoiceData.InvoiceToAddress.ContactName.IsNullOrEmpty())
                {
                    currentToAddressField = pdfDocument.Form["ToAddressLine" + currentToAddressFieldNumber] as TextBoxField;
                    currentToAddressField.Value = invoiceData.InvoiceToAddress.ContactName;

                    currentToAddressField = null;
                    currentToAddressFieldNumber++;
                }

                if (!invoiceData.InvoiceToAddress.CompanyClientName.IsNullOrEmpty())
                {
                    currentToAddressField = pdfDocument.Form["ToAddressLine" + currentToAddressFieldNumber] as TextBoxField;
                    currentToAddressField.Value = invoiceData.InvoiceToAddress.CompanyClientName;

                    currentToAddressField = null;
                    currentToAddressFieldNumber++;
                }

                currentToAddressField = pdfDocument.Form["ToAddressLine" + currentToAddressFieldNumber] as TextBoxField;
                currentToAddressField.Value = invoiceData.InvoiceToAddress.Address1;

                currentToAddressField = null;
                currentToAddressFieldNumber++;

                if (!invoiceData.InvoiceToAddress.Address2.IsNullOrEmpty())
                {
                    currentToAddressField = pdfDocument.Form["ToAddressLine" + currentToAddressFieldNumber] as TextBoxField;
                    currentToAddressField.Value = invoiceData.InvoiceToAddress.Address2;

                    currentToAddressField = null;
                    currentToAddressFieldNumber++;
                }

                currentToAddressField = pdfDocument.Form["ToAddressLine" + currentToAddressFieldNumber] as TextBoxField;
                currentToAddressField.Value = invoiceData.InvoiceToAddress.City + ", " + invoiceData.InvoiceToAddress.StateProvinceCode + " " + invoiceData.InvoiceToAddress.ZipCode;

                currentToAddressField = null;
                currentToAddressFieldNumber++;


                /*
                 *  Invoice "From Address" Fields
                 *      ContactName (Optional?)
                 *      CompanyClientName (Optional?)
                 *      Address1 (Required)
                 *      Address2 (Optional)
                 *      City (Required), StateProvinceCode (Required) ZipCode (Required)
                 */
                var currentFromAddressFieldNumber = 1;
                TextBoxField currentFromAddressField = null;

                if (!invoiceData.InvoiceFromAddress.ContactName.IsNullOrEmpty())
                {
                    currentFromAddressField = pdfDocument.Form["FromAddressLine" + currentFromAddressFieldNumber] as TextBoxField;
                    currentFromAddressField.Value = invoiceData.InvoiceFromAddress.ContactName;

                    currentFromAddressField = null;
                    currentFromAddressFieldNumber++;
                }

                if (!invoiceData.InvoiceFromAddress.CompanyClientName.IsNullOrEmpty())
                {
                    currentFromAddressField = pdfDocument.Form["FromAddressLine" + currentFromAddressFieldNumber] as TextBoxField;
                    currentFromAddressField.Value = invoiceData.InvoiceFromAddress.CompanyClientName;

                    currentFromAddressField = null;
                    currentFromAddressFieldNumber++;
                }

                currentFromAddressField = pdfDocument.Form["FromAddressLine" + currentFromAddressFieldNumber] as TextBoxField;
                currentFromAddressField.Value = invoiceData.InvoiceFromAddress.Address1;

                currentFromAddressField = null;
                currentFromAddressFieldNumber++;

                if (!invoiceData.InvoiceFromAddress.Address2.IsNullOrEmpty())
                {
                    currentFromAddressField = pdfDocument.Form["FromAddressLine" + currentFromAddressFieldNumber] as TextBoxField;
                    currentFromAddressField.Value = invoiceData.InvoiceFromAddress.Address2;

                    currentFromAddressField = null;
                    currentFromAddressFieldNumber++;
                }

                currentFromAddressField = pdfDocument.Form["FromAddressLine" + currentFromAddressFieldNumber] as TextBoxField;
                currentFromAddressField.Value = invoiceData.InvoiceFromAddress.City + ", " + invoiceData.InvoiceFromAddress.StateProvinceCode + " " + invoiceData.InvoiceFromAddress.ZipCode;

                currentFromAddressField = null;
                currentFromAddressFieldNumber++;


                /*
                 * Add Invoice Details Header
                 */
                var txtBuilder = new TextBuilder(pdfDocument.Pages[1]);
                var graph = new Graph((float)pdfDocument.Pages[currentPageNumber].PageInfo.Width, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Height);
                pdfDocument.Pages[currentPageNumber].Paragraphs.Add(graph);

                string[] headerLabels = { "Trans Id", "Plate/VIN Label", "Billing Detail", "Type", "Charge Date", "Amount", "Orig Location", "Note" };
                int[] invoiceDetailsColWidth = { 50, 80, 120, 30, 55, 40, 70, 45 };

                var yCoordinateInvoiceDetail = PrintInvoiceConfigs.InvoiceDetailsYCoordinateStartFirstPage;
                var xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                var invoiceDetailRowHeight = PrintInvoiceConfigs.InvoiceDetailRowHeight;
                var invoiceSeparatorRowHeight = PrintInvoiceConfigs.InvoiceSeparatorRowHeight;

                var invoiceDetailsCount = invoiceData.InvoiceDetails.Count().ToString();
                var invoiceDetailsPlatesSubTotal = invoiceData.InvoiceDetails.Where(x => x.Amount.HasValue).Sum(y => y.Amount).Value.ToString("C");
                var invoiceDetailsTotal = invoiceData.InvoiceDetails.Where(x => x.Amount.HasValue).Sum(y => y.Amount).Value.ToString("C");

                AddInvoiceDetailsHeaderRow(txtBuilder, yCoordinateInvoiceDetail);

                var headerRowSeperator = new Line(new float[] { PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Width - PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding });
                headerRowSeperator.GraphInfo.Color = Color.FromRgb(System.Drawing.Color.Black);
                headerRowSeperator.GraphInfo.LineWidth = 0.6f;
                graph.Shapes.Add(headerRowSeperator);

                xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight;


                /*
                 * Add Transaction Group Header for Plates
                 */
                AddTextRowToInvoicePdf(txtBuilder, "Transaction Group", xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail, isBold: true);

                xCoordinateInvoiceDetailRow += 90;

                AddTextRowToInvoicePdf(txtBuilder, PrintInvoiceConfigs.PlateGroupTypeLabel, xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail, isBold: true);

                var transGroupRowSeperator = new Line(new float[] { PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Width - PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding });
                transGroupRowSeperator.GraphInfo.Color = Color.FromRgb(System.Drawing.Color.Black);
                transGroupRowSeperator.GraphInfo.LineWidth = 0.6f;
                graph.Shapes.Add(transGroupRowSeperator);

                xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight;

                /*
                 * Add Invoice Detail Rows
                 */
                string[] invoiceDetailCols = { "TransactionId", "PlateNumber", "BillingFeeId", "IsDebit", "CreatedDate", "Amount", "Origination", "Note" };

                var currentPageInvoiceDetailRow = 3; // Header + Trans Group Rows
                var invoiceDetailsMaxRows = (PrintInvoiceConfigs.InvoiceDetailsYCoordinateStartFirstPage / PrintInvoiceConfigs.InvoiceDetailRowHeight) - 3; // Leave a Row for Page Number Footer

                foreach (var invoiceDetail in invoiceData.InvoiceDetails)
                {
                    if (currentPageInvoiceDetailRow > invoiceDetailsMaxRows)
                    {
                        currentPageNumber++;
                        pdfDocument.Pages.Add();

                        var firstPage = pdfDocument.Pages[1];
                        var newPage = pdfDocument.Pages[currentPageNumber];

                        newPage.MediaBox = firstPage.MediaBox;
                        newPage.TrimBox = firstPage.TrimBox;
                        newPage.CropBox = firstPage.CropBox;
                        newPage.PageInfo.Height = PageSize.PageLetter.Height;
                        newPage.PageInfo.Width = PageSize.PageLetter.Width;
                        newPage.PageInfo.Margin = new MarginInfo(0, 0, 0, 0);
                        txtBuilder = new TextBuilder(newPage);

                        currentPageInvoiceDetailRow = 2;
                        invoiceDetailsMaxRows = PrintInvoiceConfigs.InvoiceDetailsYCoordinateStartContinuePage / PrintInvoiceConfigs.InvoiceSeparatorRowHeight;
                        yCoordinateInvoiceDetail = PrintInvoiceConfigs.InvoiceDetailsYCoordinateStartContinuePage;

                        graph = new Graph((float)pdfDocument.Pages[currentPageNumber].PageInfo.Width, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Height);
                        pdfDocument.Pages[currentPageNumber].Paragraphs.Add(graph);
                        AddInvoiceDetailsHeaderRow(txtBuilder, yCoordinateInvoiceDetail);

                        headerRowSeperator = new Line(new float[] { PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Width - PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding });
                        headerRowSeperator.GraphInfo.Color = Color.FromRgb(System.Drawing.Color.Black);
                        headerRowSeperator.GraphInfo.LineWidth = 0.6f;
                        headerRowSeperator.GraphInfo.IsDoubled = false;
                        graph.Shapes.Add(headerRowSeperator);

                        yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight;
                    }

                    // Transaction Id
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetail.TransactionId, xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[0];

                    // Plate/VIN Label
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetail.PlateNumber, xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[1];

                    // Billing Detail
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetail.BillingReason, xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[2];

                    // Type
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetail.IsDebit ? "Debit" : "Credit", xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[3];

                    // Charge Date
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetail.CreatedDate.ToString("MM/dd/yyyy"), xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[4];

                    // Amount
                    var invoiceDetailAmount = invoiceDetail.Amount ?? 0.00m;
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetailAmount.ToString("C"), xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[5];

                    // Orig Location
                    AddTextRowToInvoicePdf(txtBuilder, invoiceDetail.Origination, xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[6];

                    // Note
                    var initialRowYCoordinate = yCoordinateInvoiceDetail;

                    if (!invoiceDetail.Note.IsNullOrEmpty())
                    {
                        var detailNoteArr = invoiceDetail.Note.Split(" ");
                        var noteLines = new List<string> { };
                        var currentNoteLine = detailNoteArr[0];
                        var currentNoteLineIndex = 1;

                        while (currentNoteLineIndex < detailNoteArr.Length - 1 && (currentNoteLine.Length + detailNoteArr[currentNoteLineIndex].Length) < PrintInvoiceConfigs.MaxInvoiceDetailCommentCharLength)
                        {
                            currentNoteLine += detailNoteArr[currentNoteLineIndex] + " ";
                            currentNoteLineIndex++;
                        }

                        if (currentNoteLineIndex < detailNoteArr.Length - 1)
                        {
                            currentNoteLine += "...";
                        }
                        else if (currentNoteLine.Length > PrintInvoiceConfigs.MaxInvoiceDetailCommentCharLength)
                        {
                            currentNoteLine = currentNoteLine.Substring(0, PrintInvoiceConfigs.MaxInvoiceDetailCommentCharLength) + "...";
                        }

                        AddTextRowToInvoicePdf(txtBuilder, currentNoteLine ?? "", xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);
                    }

                    xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[7];

                    // Reset Row Starting Locations
                    xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                    yCoordinateInvoiceDetail = initialRowYCoordinate - invoiceDetailRowHeight;

                    currentPageInvoiceDetailRow++;
                }

                /*
                 * Add Subtotal, Total, and Count Lines
                 *
                 * Note: If there is not enough room for all three sections, break to new page
                 */
                var xCoordinateAmountLabels = xCoordinateInvoiceDetailRow + invoiceDetailsColWidth[0] + invoiceDetailsColWidth[1] + invoiceDetailsColWidth[2] + invoiceDetailsColWidth[3];
                var xCoordinateAmounts = xCoordinateAmountLabels + invoiceDetailsColWidth[4];

                var amountCountCommentBlockHeight = 5 * invoiceSeparatorRowHeight;

                if (yCoordinateInvoiceDetail < amountCountCommentBlockHeight)
                {
                    currentPageNumber++;
                    pdfDocument.Pages.Add();

                    var firstPage = pdfDocument.Pages[1];
                    var newPage = pdfDocument.Pages[currentPageNumber];

                    newPage.MediaBox = firstPage.MediaBox;
                    newPage.TrimBox = firstPage.TrimBox;
                    newPage.CropBox = firstPage.CropBox;
                    newPage.PageInfo.Height = PageSize.PageLetter.Height;
                    newPage.PageInfo.Width = PageSize.PageLetter.Width;
                    newPage.PageInfo.Margin = new MarginInfo(0, 0, 0, 0);
                    txtBuilder = new TextBuilder(newPage);

                    invoiceDetailsMaxRows = (PrintInvoiceConfigs.InvoiceDetailsYCoordinateStartContinuePage / PrintInvoiceConfigs.InvoiceSeparatorRowHeight) - 3; // Leave room for Page Number Footer
                    yCoordinateInvoiceDetail = PrintInvoiceConfigs.InvoiceDetailsYCoordinateStartContinuePage;

                    graph = new Graph((float)pdfDocument.Pages[currentPageNumber].PageInfo.Width, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Height);
                    pdfDocument.Pages[currentPageNumber].Paragraphs.Add(graph);
                }

                // Sub total for Plates
                AddTextRowToInvoicePdf(txtBuilder, "Subtotal: ", xCoordinateAmountLabels, yCoordinateInvoiceDetail, isBold: true);
                AddTextRowToInvoicePdf(txtBuilder, invoiceDetailsPlatesSubTotal ?? "", xCoordinateAmounts, yCoordinateInvoiceDetail, isBold: true);

                var subtotalSectionSeperator = new Line(new float[] { PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Width - PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding });
                subtotalSectionSeperator.GraphInfo.Color = Color.FromRgb(System.Drawing.Color.Black);
                subtotalSectionSeperator.GraphInfo.LineWidth = 0.6f;
                graph.Shapes.Add(subtotalSectionSeperator);

                // Reset Row Starting Locations
                xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight;

                // Total for all Charges
                AddTextRowToInvoicePdf(txtBuilder, "Total: ", xCoordinateAmountLabels, yCoordinateInvoiceDetail, isBold: true);
                AddTextRowToInvoicePdf(txtBuilder, invoiceDetailsTotal ?? "", xCoordinateAmounts, yCoordinateInvoiceDetail, isBold: true);

                var totalSectionSeperator = new Line(new float[] { PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding, (float)pdfDocument.Pages[currentPageNumber].PageInfo.Width - PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart, yCoordinateInvoiceDetail - PrintInvoiceConfigs.SeparatorLinePadding });
                totalSectionSeperator.GraphInfo.Color = Color.FromRgb(System.Drawing.Color.Black);
                totalSectionSeperator.GraphInfo.LineWidth = 0.6f;
                graph.Shapes.Add(totalSectionSeperator);

                // Reset Row Starting Locations
                xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight;

                // Total Count for all Charges
                AddTextRowToInvoicePdf(txtBuilder, "Count: ", xCoordinateAmountLabels, yCoordinateInvoiceDetail, isBold: true);
                AddTextRowToInvoicePdf(txtBuilder, invoiceDetailsCount ?? "", xCoordinateAmounts, yCoordinateInvoiceDetail, isBold: true);

                // Reset Row Starting Locations
                xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight * 3;


                /*
                 * Add Comments Box
                 */
                var commentBoxBorder = new Aspose.Pdf.Drawing.Rectangle(PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart + invoiceDetailsColWidth[0] + 5, yCoordinateInvoiceDetail - 25, (float)(pdfDocument.Pages[currentPageNumber].PageInfo.Width - (2 * PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart) - invoiceDetailsColWidth[0] - 5), 35);
                commentBoxBorder.GraphInfo.LineWidth = 0.6f;
                graph.Shapes.Add(commentBoxBorder);

                AddTextRowToInvoicePdf(txtBuilder, "Comments: ", xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail, isBold: true);

                xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[0] + 10;

                AddTextRowToInvoicePdf(txtBuilder, invoiceData.InvoiceComment ?? "", xCoordinateInvoiceDetailRow, yCoordinateInvoiceDetail);

                // Reset Row Starting Locations
                xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;
                yCoordinateInvoiceDetail -= invoiceSeparatorRowHeight;

                /*
                * Add Page Numbers
                */
                var totalPages = pdfDocument.Pages.Count;

                for (var i = 1; i <= totalPages; i++)
                {
                    txtBuilder = new TextBuilder(pdfDocument.Pages[i]);
                    AddTextRowToInvoicePdf(txtBuilder, "Page " + i + " of " + totalPages, PrintInvoiceConfigs.XCoordinatePageFooter, PrintInvoiceConfigs.YCoordinatePageFooter);
                    currentPageNumber++;
                }

                /*
                 * Print Final PDF to File Stream
                 */
                pdfDocument.Flatten();
                var outStream = new MemoryStream();
                pdfDocument.Save(outStream);

                return outStream.ToArray();
            }
            catch (Exception e)
            {
                _logger.LogError($"Method: {nameof(GenerateInvoicePDF)} - Error updating the invoice", e.Message);
                throw;
            }
        }

        /// <summary>
        /// Saves the pdf in azure
        /// </summary>
        /// <param name="printResponseModel"></param>
        /// <param name="clientCode"></param>
        private string SaveDocumentInAzure(byte[] pdfStream, string clientCode, string InvoiceName)
        {
            var pathAndFileName = string.Empty;
            try
            {
                string fileName = $"{InvoiceName}_{clientCode}_{DateTime.Now:MM-dd-yyyy HH-mm-ss}.pdf";
                using (var pdfMemoryStream = new MemoryStream(pdfStream))
                {
                    //TODO: Determine ClientCode from message request
                    var blob = _blobStorage.UploadBlobAsync(_storageOptions.LabelBlobContainer, clientCode, fileName, pdfMemoryStream).Result;
                    blob.Properties.ContentType = "application/pdf";
                    blob.SetPropertiesAsync().Wait();
                    pathAndFileName = blob.StorageUri.PrimaryUri.ToString();
                }
            }
            catch (Exception e)
            {
                var errorMessage = $"Method: {nameof(SaveDocumentInAzure)} resulted in error!\r\nError details:{e.Message}.\r\nInner Exception: { e.InnerException?.Message ?? "No inner exception details"}";
                throw new Exception(errorMessage);
            }

            return pathAndFileName;
        }

        /// <summary>
        /// Add header row to a given yPostion of the PDF Document
        /// </summary>
        /// <param name="txtBuilder"></param>
        /// <param name="yPositionStart"></param>
        private void AddInvoiceDetailsHeaderRow(TextBuilder txtBuilder, int yPositionStart)
        {
            string[] headerLabels = { "Trans Id", "Plate/VIN Label", "Billing Detail", "Type", "Charge Date", "Amount", "Orig Location", "Note" };
            int[] invoiceDetailsColWidth = { 50, 80, 120, 30, 55, 40, 70, 45 };

            var xCoordinateInvoiceDetailRow = PrintInvoiceConfigs.InvoiceDetailRowXCoordinateStart;

            for (var i = 0; i < headerLabels.Length; i++)
            {
                AddTextRowToInvoicePdf(txtBuilder, headerLabels[i], xCoordinateInvoiceDetailRow, yPositionStart, isBold: true);

                xCoordinateInvoiceDetailRow += invoiceDetailsColWidth[i];
            }
        }

        /// <summary>
        /// Add a text row to the PDF document of given x and y coordinates
        /// </summary>
        /// <param name="txtBuilder"></param>
        /// <param name="text"></param>
        /// <param name="xCoord"></param>
        /// <param name="yCoord"></param>
        /// <param name="fontSize"></param>
        /// <param name="font"></param>
        /// <param name="isBold"></param>
        private void AddTextRowToInvoicePdf(TextBuilder txtBuilder, string text, int xCoord, int yCoord, float fontSize = PrintInvoiceConfigs.FontSize, string font = PrintInvoiceConfigs.Font, bool isBold = false)
        {
            text = (text == null) ? "" : text.ToString();
            var txtFragment = new TextFragment(text) { Position = new Position(xCoord, yCoord) };
            txtFragment.TextState.FontSize = fontSize;
            txtFragment.TextState.Font = FontRepository.FindFont(font);
            txtFragment.TextState.ForegroundColor = Color.FromRgb(System.Drawing.Color.Black);

            if (isBold)
            {
                txtFragment.TextState.FontStyle = FontStyles.Bold;
            }

            txtBuilder.AppendText(txtFragment);
        }

        /// <summary>
        /// Private method to update log status
        /// </summary>
        /// <param name="log"></param>
        /// <param name="logDetails"></param>
        /// <returns></returns>
        private async Task<Model.DTO.Log> UpdateLogStatusAsync(Model.DTO.Log log, List<Model.DTO.LogDetail> logDetails)
        {
            log.ProcessEndDate = DateTime.Now;
            return await _labelManagementService.UpdateLogStatusAsync(log, logDetails);
        }
    }
}
