using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Blob;

namespace VM.FleetServices.TnR.LM.Common.AzureStorage
{
    /// <summary>
    /// Defines the contract of a generic blob storage management system.
    /// </summary>
    public interface IBlobStorage
    {
        /// <summary>
        /// Creates a container compartment for a set of blobs.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        Task<bool> CreateContainerAsync(string containerName);

        /// <summary>
        /// Deletes a container and all contained blobs from the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<bool> DeleteContainerAsync(string containerName);

        /// <summary>
        /// Deletes a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<bool> DeleteBlobAsync(string containerName, string blobName);

        /// <summary>
        /// Deletes a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<bool> DeleteBlobAsync(string containerName, string directory, string blobName);

        /// <summary>
        /// Returns <c>true</c> is the specified container exists within the repository.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<bool> DoesContainerExistAsync(string containerName);

        /// <summary>
        /// Returns <c>true</c> is the specified blob exists within the container.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<bool> DoesBlobExistAsync(string containerName, string blobName);

        /// <summary>
        /// Returns <c>true</c> is the specified blob exists within the container.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<bool> DoesBlobExistAsync(string containerName, string directory, string blobName);

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="blobName">name of the blob to download</param>
        /// <param name="fileStream">stream to return file data</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<Stream> DownloadBlobAsync(string blobName, Stream fileStream);

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="fileStream">Stream to return file data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<Stream> DownloadBlobAsync(string containerName, string blobName, Stream fileStream);

        /// <summary>
        /// Downloads a blob from the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="fileStream">Stream to return file data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<Stream> DownloadBlobAsync(string containerName, string directory, string blobName, Stream fileStream);

        //Task<FileStreamResult> DownloadBlobAsync(string blobName);

        Task<Stream> DownloadBlobAsync(string containerName, string directory, string blobName, Stream fileStream, BlobType blobType);

        /// <summary>
        /// Lists the files in the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<IEnumerable<string>> ListBlobsAsync(string containerName);

        /// <summary>
        /// Lists the files in the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<IEnumerable<string>> ListBlobsAsync(string containerName, string directory);

        /// <summary>
        /// Uploads a blob to the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="source">Source blob data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<CloudBlockBlob> UploadBlobAsync(string containerName, string blobName, Stream source);

        /// <summary>
        /// Uploads a blob to the specified container within the storage management system.
        /// </summary>
        /// <param name="blobName">name of the blob to upload</param>
        /// <param name="source">Source blob data</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<CloudBlockBlob> UploadBlobAsync(string blobName, Stream source);

        /// <summary>
        /// Uploads a blob to the specified container within the storage management system.
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="directory">Virtual directory structure.</param>
        /// <param name="blobName">Name of the blob to upload.</param>
        /// <param name="source">Source blob data.</param>
        /// <returns>Allows for asynchronous processing of the function.</returns>
        Task<CloudBlockBlob> UploadBlobAsync(string containerName, string directory, string blobName, Stream source);

        /// <summary>
        /// Copies a blob to new blob and deletes the old blob
        /// </summary>
        /// <param name="containerName">Name of container.</param>
        /// <param name="blobName">Name of the blob to be copied</param>
        /// <param name="blobNameNew">Name of the new blob</param>
        /// <returns></returns>
        Task<CloudBlockBlob> RenameBlobAsync(string containerName, string blobName, string blobNameNew);

        /// <summary>
        /// Returns Shared Access Signature Token for a container
        /// </summary>
        /// <returns>returns token</returns>
        string GetBlobReadSasToken();

        Task AppendBlobAsync(string blobName, byte[] data);
        Task<CloudAppendBlob> AppendBlobAsync(string containerName, string directory, string blobName, byte[] source);

    }
}
