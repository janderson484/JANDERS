using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace VM.FleetServices.TnR.Core.Common.SignalR
{
    public class NotificationHub : Hub
    {
        public static readonly Dictionary<string, string> UserConnectionMappings = new Dictionary<string, string>();

        /// <summary>
        /// Invokes when signalr connected
        /// </summary>
        /// <returns></returns>
        public override Task OnConnectedAsync()
        {
            var httpContext = Context.GetHttpContext();
            var userId = httpContext.Request.Query["username"];

            if (!string.IsNullOrEmpty(Context.ConnectionId))
                UserConnectionMappings.Add(Context.ConnectionId, userId);

            return base.OnConnectedAsync();
        }

        /// <summary>
        /// removes connection id from the list when signalr disconnected
        /// </summary>
        /// <param name="exception"></param>
        /// <returns></returns>
        public override Task OnDisconnectedAsync(Exception exception)
        {
            if (!string.IsNullOrEmpty(Context.ConnectionId))
            {
                var connectionId = UserConnectionMappings.FirstOrDefault(a => a.Key.Equals(Context.ConnectionId)).Key;

                if (!string.IsNullOrEmpty(connectionId))
                    UserConnectionMappings.Remove(connectionId);
            }

            return base.OnDisconnectedAsync(exception);
        }
    }
}
