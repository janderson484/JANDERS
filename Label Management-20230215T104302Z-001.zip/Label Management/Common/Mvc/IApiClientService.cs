using System.Net.Http;
using System.Threading.Tasks;

namespace VM.FleetServices.TnR.Core.Common.Mvc
{
    public interface IApiClientService
    {
        void SetClientCode(string value);
        void SetCustomHeader(string key, string value);
        bool TryRemoveCustomHeader(string key);
        void ClearCustomHeaders();
        void SetTimeOut(int minutes);
        Task<HttpResponseMessage> GetResponseAsync(string href);
        Task<T> GetResponseAsync<T>(string href);
        Task<T> GetResponseAsync<T>(string href, string token);
        Task<HttpResponseMessage> GetResponseAsync<T>(string href, T model);
        Task<HttpResponseMessage> PostRequestAsync<T>(string href, T model);
        Task<HttpResponseMessage> PostRequestAsync<T>(string href, T model, string token);
    }
}
