namespace VM.FleetServices.TnR.Core.Common.Mvc
{
    public class OpenIdSettings
    {
        public string Authority { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
    }

    public class ApiSettings
    {
        public string Uri { get; set; }
        public string PrintServiceUri { get; set; }
        public int PrintApiBatchCount { get; set; }
    }

    public class PMApiSettings
    {
        public string Uri { get; set; }
    }

    public class Settings
    {
        public bool IsPrintLabelsToEnabled { get; set; }
    }
}
