namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    /// <summary>
    /// This class will contain all common extensions handling extended functionality
    /// when utilizing Single types within code.
    /// </summary>
    public static class DecimalExtensions
    {
        /// <summary>
        /// Returns true if the base value is between the range of values.
        /// </summary>
        /// <param name="baseValue">Base value to use as the comparison check</param>
        /// <param name="startValue">Absolute minimum value for the comparison</param>
        /// <param name="endValue">Absolute maximum value for the comparison</param>
        /// <returns>True value indicates the value is between the valid range.</returns>
        public static bool IsBetween(this decimal baseValue, decimal startValue, decimal endValue)
            => (baseValue.CompareTo(startValue) >= 0) && (baseValue.CompareTo(endValue) <= 0);

        /// <summary>
        /// Returns true if the base value is between the range of values.
        /// </summary>
        /// <param name="baseValue">Base value to use as the comparison check</param>
        /// <param name="startValue">Absolute minimum value for the comparison</param>
        /// <param name="endValue">Absolute maximum value for the comparison</param>
        /// <returns>True value indicates the value is between the valid range.</returns>
        public static bool IsBetween(this decimal? baseValue, decimal startValue, decimal endValue)
        {
            if (!baseValue.HasValue)
            {
                baseValue = default(decimal);
            }

            return (baseValue.Value.CompareTo(startValue) >= 0) && (baseValue.Value.CompareTo(endValue) <= 0);
        }

        /// <summary>
        /// Returns a value or default value, if null, of a decimal.
        /// </summary>
        /// <param name="fromValue">Decimal containing value or null.</param>
        /// <returns>The decimal value or default.</returns>
        public static decimal ValueOrDefault(this decimal? fromValue)
            => fromValue ?? default(decimal);

        /// <summary>
        /// Returns a value or default value, if null, of a decimal.
        /// </summary>
        /// <param name="fromValue">Decimal containing value or null.</param>
        /// <param name="defaultValue">Default decimal value if the decimal value is null.</param>
        /// <returns>The decimal value or default.</returns>
        public static decimal ValueOrDefault(this decimal? fromValue, decimal defaultValue)
            => fromValue ?? defaultValue;
    }
}
