using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    public static class EnumExtensions
    {
        public static string GetDescription(this Enum value)
        {
            var enumType = value.GetType();
            var field = enumType.GetField(value.ToString());
            var attributes = field?.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return attributes == null || attributes.Length == 0 ? value.ToString() : ((DescriptionAttribute)attributes[0]).Description;
        }

        public static IEnumerable<string> GetDescriptions(this Type type)
        {
            var descs = new List<string>();
            var names = Enum.GetNames(type);
            foreach (var name in names)
            {
                var field = type.GetField(name);
                var fds = field.GetCustomAttributes(typeof(DescriptionAttribute), true);
                foreach (DescriptionAttribute fd in fds)
                {
                    descs.Add(fd.Description);
                }
            }
            return descs;
        }

        public static T GetEnumFromDesc<T>(string desc) where T : struct
        {
            var type = typeof(T);

            if (!type.IsEnum)
                throw new ArgumentException("ToEnumValue<T>(): Must be of enum type", "T");
            
          
            foreach (var val in Enum.GetNames(type))
                if (val.Equals(desc, comparisonType: StringComparison.CurrentCultureIgnoreCase))
                    return (T)Enum.Parse(typeof(T), val);

            throw new ArgumentException("ToEnumValue<T>(): Invalid description for enum " + type.Name, "enumerationDescription");
        }

        public static Dictionary<string, string> GetAllEnumsWithDescription(this Type enumType)
        {
            var enumValues = enumType.GetEnumValues();
            var descs = new Dictionary<string, string>();
            foreach (var value in enumValues)
            {
                var type = value.GetType();
                var field = type.GetField(value.ToString());
                var attributes = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
                descs.Add(value.ToString(), attributes.Length == 0 ? value.ToString() : ((DescriptionAttribute)attributes[0]).Description);
            }

            return descs;
        }
    }
}

