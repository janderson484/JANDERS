using System;
using System.Collections.Generic;
using System.Linq;

namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    /// <summary>
    /// This class will contain all common extensions handling extended functionality
    /// when utilizing Single types within code.
    /// </summary>
    public static class GenericsExtensions
    {
        /// <summary>
        /// Returns the lesser of the two values
        /// </summary>
        /// <param name="baseValue">Primary value.</param>
        /// <param name="compareValue">Comparison value</param>
        /// <returns>Lesser amount of two values</returns>
        public static T FindLesserAmount<T>(this T baseValue, T compareValue) where T : IComparable
            => baseValue.CompareTo(compareValue) < 0 ? baseValue : compareValue;

        /// <summary>
        /// Returns the greater of the two values
        /// </summary>
        /// <param name="baseValue">Primary value.</param>
        /// <param name="compareValue">Comparison value</param>
        /// <returns>Greater amount of two values</returns>
        public static T FindGreaterAmount<T>(this T baseValue, T compareValue) where T : IComparable
            => baseValue.CompareTo(compareValue) > 0 ? baseValue : compareValue;

        /// <summary>
        /// Returns the value (or default) of a type that may be null.
        /// </summary>
        /// <typeparam name="T">Given type.</typeparam>
        /// <param name="nullableValue">Given value.</param>
        /// <returns>The default value for the type.</returns>
        public static T ToValue<T>(this T? nullableValue) where T : struct
            => nullableValue ?? default(T);
        
        /// <summary>
        /// Interrogates a list to make sure it is not null
        /// and that it has values.
        /// </summary>
        /// <typeparam name="T">Given type.</typeparam>
        /// <param name="list">List to interrogate.</param>
        /// <returns>True if the list is not null and contains at least one value.</returns>
        public static bool HasValues<T>(this IList<T> list)
            => list != null && list.Count > 0;
        //{
        //    return list != null && list.Count > 0;
        //}

        /// <summary>
        /// Interrogates a list to make sure it is not null.
        /// </summary>
        /// <typeparam name="TKey">Given type.</typeparam>
        /// <typeparam name="TValue">Given value.</typeparam>
        /// <param name="list">List to interrogate.</param>
        /// <returns>True if the list is not null and contains at least one value.</returns>
        public static bool HasValues<TKey, TValue>(this IDictionary<TKey, TValue> list)
            => list != null && list.Count > 0;
        //{
        //    return list != null && list.Count > 0;
        //}

        /// <summary>
        /// Adds a range of values to an IList.
        /// </summary>
        /// <typeparam name="T">Given type.</typeparam>
        /// <param name="list">List to interrogate.</param>
        /// <param name="items">List containing desired items to add.</param>
        public static void AddRange<T>(this IList<T> list, IList<T> items)
            => list.AddRange(items, false);
        //{
        //    list.AddRange(items, false);
        //}

        /// <summary>
        /// Adds a range of values to an IList.
        /// </summary>
        /// <typeparam name="T">Given type.</typeparam>
        /// <param name="list">List to interrogate.</param>
        /// <param name="items">List containing desired items to add.</param>
        /// <param name="checkForDuplicates">A true will ensure the list is checked for duplicates, a False will ignore duplicate check.</param>
        public static void AddRange<T>(this IList<T> list, IList<T> items, bool checkForDuplicates)
        {
            foreach (T item in items)
            {
                if (checkForDuplicates)
                {
                    if (!list.Contains(item))
                    {
                        list.Add(item);
                    }
                }
                else
                {
                    list.Add(item);
                }
            }
        }

        /// <summary>
        /// Removes all.
        /// </summary>
        /// <typeparam name="T">The object</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="where">The where.</param>
        /// <returns>
        /// Count of removed items
        /// </returns>
        public static int RemoveAll<T>(this IList<T> list, Func<T, bool> where)
        {
            int removedCount = 0;
            List<T> itemsToRemove = list.Where(@where).ToList();

            for (int i = 0; i < itemsToRemove.Count(); i++)
            {
                list.Remove(itemsToRemove[i]);
                removedCount++;
            }

            return removedCount;
        }

        /// <summary>
        /// Compare two entities and identify if they are equal.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="firstEntity"></param>
        /// <param name="secondEntity"></param>
        /// <param name="skipProperties">Properties within entities to skip comparison (e.g. Id, CreatedDate)</param>
        /// <returns></returns>
        public static bool EntitiesEqual<T>(T firstEntity, T secondEntity, string[] skipProperties = null) where T : class
        {
            var type = typeof(T);

            if (skipProperties == null)
            {
                skipProperties = new string[0];
            }

            if (skipProperties.Except(type.GetProperties().Select(x => x.Name)).Any())
            {
                throw new ArgumentException("Type does not contain property to skip");
            }

            var propertyInfos = type.GetProperties()
                .Except(type.GetProperties().Where(x => skipProperties.Contains(x.Name)));

            foreach (var propertyInfo in propertyInfos)
            {
                if (!Equals(propertyInfo.GetValue(firstEntity, null), propertyInfo.GetValue(secondEntity, null)))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
