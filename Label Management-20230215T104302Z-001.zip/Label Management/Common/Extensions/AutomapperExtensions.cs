using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace VM.FleetServices.TnR.Core.Common.Extensions
{
    public static class AutomapperExtensions
    {
        public static List<TDestination> MapList<TSource, TDestination>(this IMapper mapper, List<TSource> source)
        {
            return source.Select(x => mapper.Map<TDestination>(x)).ToList();
        }
    }
}
