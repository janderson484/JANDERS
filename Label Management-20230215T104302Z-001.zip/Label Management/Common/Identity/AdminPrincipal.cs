using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using Newtonsoft.Json;

namespace VM.FleetServices.TnR.Core.Common.Identity
{
    /// <inheritdoc />
    /// <summary>
    /// Claims principal for an admin user
    /// </summary>
    public class AdminPrincipal : ClaimsPrincipal
    {
        private const string AdminRight = "-SUPER";

        /// <inheritdoc />
        /// <summary>
        /// </summary>
        /// <param name="identity"></param>
        public AdminPrincipal(IIdentity identity) : base(identity) { }

        /// <summary>
        /// 
        /// </summary>
        public bool IsAdminUser => true;

        /// <summary>
        /// 
        /// </summary>
        public string AdminUser => GetAdminClientCode();    //"FSAMS";

        /// <summary>
        /// Gets client code of admin account
        /// </summary>
        /// <returns></returns>
        public string GetAdminClientCode()
        {
            var allRightsClaims = this.FindAll(UserManagerClaimTypes.Rights);
            foreach (var rightsClaim in allRightsClaims)
            {
                // decode json value
                var clientRights = JsonConvert.DeserializeObject<ClientRights>(rightsClaim.Value);
                if (clientRights.Rights.Any(r => r.Contains(AdminRight)))
                {
                    return clientRights.ClientCode;
                }
            }
            return null;
        }
    }

}
