using System;

namespace VM.FleetServices.TnR.Core.Common.Identity
{
    public class Client
    {
        public static Client All = new Client("ALL", "All");
        private string _code;

        public string Code
        {
            get { return _code; }
            set
            {
                if (value != null)
                {
                    _code = value.Trim().ToUpper();
                }
            }
        }

        public string DisplayName { get; set; }

        public string OriginalClientCode { get; internal set; }

        public Client()
        {

        }

        public Client(string code)
        {
            if (code == null)
                throw new ArgumentNullException(nameof(code));
            Code = code;
        }

        public Client(string code, string displayName)
        {
            if (code == null)
                throw new ArgumentNullException(nameof(code));
            Code = code;
            DisplayName = displayName;
        }

        public static bool operator ==(Client a, Client b)
        {
            // If both are null, or both are same instance, return true.
            if (ReferenceEquals(a, b))
            {
                return true;
            }

            // If one is null, but not both, return false.
            if (((object)a == null) || ((object)b == null))
            {
                return false;
            }

            // Return true if the Code field match:
            return a.Code == b.Code;
        }

        public static bool operator !=(Client a, Client b)
        {
            return !(a == b);
        }

        protected bool Equals(Client other)
        {
            // only Code matters..
            return string.Equals(Code, other.Code);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
                return false;
            if (ReferenceEquals(this, obj))
                return true;
            if (obj.GetType() != GetType())
                return false;
            return Equals((Client)obj);

        }

        public override int GetHashCode()
        {
            return Code?.GetHashCode() ?? 0;
        }

        public override string ToString()
        {
            return Code;
        }
    }

}
