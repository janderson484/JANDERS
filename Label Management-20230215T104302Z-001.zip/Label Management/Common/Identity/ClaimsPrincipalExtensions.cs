using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using Newtonsoft.Json;

namespace VM.FleetServices.TnR.Core.Common.Identity
{
    public static class ClaimsPrincipalExtensions
    {
        public static List<Client> GetClientList(this ClaimsPrincipal user, bool addAllCode = false)
        {
            var list = new List<Client>();

            var allClientClaims = user.FindAll(UserManagerClaimTypes.Client).ToList();
            foreach (var clientClaim in allClientClaims)
            {
                // decode json value
                var client = JsonConvert.DeserializeObject<Client>(clientClaim.Value);
                list.Add(client);
            }

            // add ALL if requested..
            if (addAllCode && list.Count > 1)
            {
                list.Insert(0, Client.All);
            }

            return list;
        }

        /// <summary>
        /// Get a list of all clients the user has access to under a certain asset type
        /// </summary>
        public static List<Client> GetClientList(this ClaimsPrincipal principal, string assetTypeCode)
        {
            var clients = principal.GetClientList()?.Where(client =>
            {
                var clientRights = principal.GetClientRights(client.Code);
                if (clientRights.Any(rights => rights.Name.Contains($"{assetTypeCode.ToUpper()}-")))
                    return true;
                return false;
            }).ToList();

            return clients;
        }

        public static List<Right> GetClientRights(this ClaimsPrincipal user, string clientCode)
        {
            return GetClientRights(user, new Client(clientCode));
        }
        public static List<Right> GetClientRights(this ClaimsPrincipal user, Client client)
        {
            var allRightsClaims = user.FindAll(UserManagerClaimTypes.Rights);

            foreach (var rightsClaim in allRightsClaims)
            {
                // decode json value
                var clientRights = JsonConvert.DeserializeObject<ClientRights>(rightsClaim.Value);
                if (clientRights.ClientCode == client.Code)
                {
                    return clientRights.Rights.Select(t => new Right(t)).ToList();
                }
            }

            // no rights found...
            return new List<Right>();
        }

        public static Right GetClientRight(this ClaimsPrincipal user, string clientCode, string rightName)
        {
            return GetClientRight(user, new Client(clientCode), new Right(rightName));
        }

        public static Right GetClientRight(this ClaimsPrincipal user, Client client, Right right)
        {
            var list = GetClientRights(user, client);
            return list.SingleOrDefault(t => t.Name.Equals(right.Name));
        }


        public static string GetClaimValue(this ClaimsPrincipal user, string claimType)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            var identity1 = user.Identity as ClaimsIdentity;
            return identity1?.FindFirst(claimType)?.Value;
        }

        public static string GetUserId(this ClaimsPrincipal user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            return user.GetClaimValue("sub");
        }

        /// <summary>
        /// Check if client had admin rights
        /// </summary>
        /// <param name="user"></param>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        public static bool IsAdminUser(this ClaimsPrincipal user, string clientCode)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            var rights = user.GetClientRights(clientCode);
            return rights.Any(r => r.Name.Contains("-SUPER"));
        }

        /// <summary>
        /// Check if current user is an admin
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static bool IsAdminUser(this ClaimsPrincipal user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            var allRightsClaims = user.FindAll(UserManagerClaimTypes.Rights);
            foreach (var rightsClaim in allRightsClaims)
            {
                // decode json value
                var clientRights = JsonConvert.DeserializeObject<ClientRights>(rightsClaim.Value);
                return clientRights.Rights.Any(r => r.Contains("-SUPER"));
            }
            return false;
        }

        /// <summary>
        /// Check if the user has a particular right under the specified client
        /// </summary>
        /// <param name="user"></param>
        /// <param name="clientCode"></param>
        /// <param name="rightName"></param>
        /// <returns></returns>
        public static bool HasRight(this ClaimsPrincipal user, string clientCode, string rightName)
        {
            var allRights = user.GetClientRights(clientCode);
            return allRights.Any(r => r.Name == rightName);
        }

        /// <summary>
        /// Checks if the user has admin right(s) under the specified client
        /// </summary>
        /// <param name="user"></param>
        /// <param name="clientCode"></param>
        /// <returns></returns>
        public static bool HasAdminRights(this ClaimsPrincipal user, string clientCode)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            var allRightsClaims = user.FindAll(UserManagerClaimTypes.Rights);
            foreach (var rightsClaim in allRightsClaims)
            {
                // decode json value
                var clientRights = JsonConvert.DeserializeObject<ClientRights>(rightsClaim.Value);
                if (clientRights.ClientCode.Equals(clientCode, StringComparison.CurrentCultureIgnoreCase))
                {
                    return clientRights.Rights.Any(r => r.Contains("-SUPER"));
                }
            }
            return false;
        }

        /// <summary>
        /// Gets the client code for the administrative client
        /// </summary>
        /// <param name="principal"></param>
        /// <returns></returns>
        public static string GetAdminClientCode(this ClaimsPrincipal principal)
        {
            foreach (Claim claim in principal.FindAll(UserManagerClaimTypes.Rights))
            {
                ClientRights clientRights = JsonConvert.DeserializeObject<ClientRights>(claim.Value);
                List<string> rights = clientRights.Rights;
                if (rights.Any(r => r.Contains("-SUPER")))
                    return clientRights.ClientCode;
            }
            return (string)null;
        }


        /// <summary>
        /// Checks if the user has admin rights for a particular asset type
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="assetTypeCode"></param>
        /// <returns></returns>
        public static bool IsAdminUserByAssetType(this ClaimsPrincipal principal, string assetTypeCode)
        {
            return principal.HasRight(principal.GetAdminClientCode(), $"{assetTypeCode.ToUpper()}-SUPER");
        }


    }

}
