using System;
using System.Net;

namespace VM.FleetServices.TnR.Core.Common.ApiHelpers
{
    public class ServiceResponse<T> where T: class
    {             
        public T Data { get; set; }
        public HttpStatusCode ResponseCode { get; set; }        
        public string ErrorMessage { get; set; }
        public Exception Exception { get; set; }
    }
}
