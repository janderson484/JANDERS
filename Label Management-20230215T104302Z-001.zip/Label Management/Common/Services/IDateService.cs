using System;

namespace VM.FleetServices.TnR.Core.Common.Services
{
    /// <summary>
    /// Interface for date services to consolidate all date operations to a single service
    /// for consistency and potential date maintenance issues.
    /// </summary>
    public interface IDateService
    {
        /// <summary>
        /// Retrieves the current date as defined by the system.
        /// </summary>
        /// <returns>Current date.</returns>
        DateTime GetDate();
    }
}
