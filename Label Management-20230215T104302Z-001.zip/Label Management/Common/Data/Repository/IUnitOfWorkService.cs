using System;
using Microsoft.EntityFrameworkCore;

namespace VM.FleetServices.TnR.Core.Common.Data.Repository
{
    public interface IUnitOfWorkService : IDisposable
    {
        IRepository<TEntity> GetRepository<TEntity>() where TEntity : class;
        IRepositoryAsync<TEntity> GetRepositoryAsync<TEntity>() where TEntity : class;
        IRepositoryReadOnly<TEntity> GetReadOnlyRepository<TEntity>() where TEntity : class;

        int SaveChanges();
    }

    public interface IUnitOfWorkService<TContext> : IUnitOfWorkService where TContext : DbContext
    {
        TContext Context { get; }
    }
}
