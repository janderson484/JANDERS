namespace VM.FleetServices.TnR.Core.Common.Data.Repository
{
    public interface IRepositoryReadOnly<T> : IReadRepository<T> where T : class
    {

    }
}
